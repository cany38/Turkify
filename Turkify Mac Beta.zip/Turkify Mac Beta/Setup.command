#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
[[ "$(uname -s)" == Darwin ]] || { echo 'macOS required.'; exit 1; }
export PATH="/opt/homebrew/bin:/opt/homebrew/opt/node@22/bin:/usr/local/bin:/usr/local/opt/node@22/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export NEXT_TELEMETRY_DISABLED=1
for tool in node npm python3.12 ffmpeg deno; do
  command -v "$tool" >/dev/null || { echo "Missing: $tool. See README.md."; exit 1; }
done
node -e 'if(Number(process.versions.node.split(".")[0]) < 22) process.exit(1)'
python3.12 -m venv .venv
.venv/bin/python3 -m pip install -r requirements.txt
.venv/bin/python3 scripts/launcher.py stop
(cd app && npm ci && npm run build)
chmod u+x Launcher.command Stop.command
/usr/bin/osacompile -o 'Turkify.app' scripts/launcher.applescript
echo 'Setup complete. Open Turkify.app. Terminal may now be closed.'
