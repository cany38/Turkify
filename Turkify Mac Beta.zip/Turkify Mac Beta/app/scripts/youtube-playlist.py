#!/usr/bin/env python3
"""YouTube / YouTube Music playlistini yt-dlp ile okuyup tek satir JSON yazar.

Kullanim: `python scripts/youtube-playlist.py <playlist-url ya da id>`

Giris herkese acik olmali; API anahtari gerekmez. Liste meta verisi ve
parcalar `extract_flat` ile tek cagrida gelir (video dosyalari indirilmez).
Cikti her zaman stdout'ta tek satir JSON'dur; yt-dlp uyarilari stderr'de
kalir, stdout kirlenmez.
"""

import json
import re
import sys

# Windows konsolu varsayilan olarak cp1254; listede o kod sayfasinda olmayan
# bir karakter varsa JSON yazarken patlar. Cikti her zaman UTF-8 olsun.
sys.stdout.reconfigure(encoding="utf-8")
sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# `list=xxx` sorgusu ya da ciplak liste kimligi (PL... / RD... / OL...).
LIST_RE = re.compile(r"[?&]list=([A-Za-z0-9_-]+)")
BARE_ID_RE = re.compile(r"\A(?:PL|RD|OL|UU|LL|FL)[A-Za-z0-9_-]{8,}\Z")


def extract_id(value):
    """Tam URL ya da ciplak kimlikten playlist kimligini cikarir."""
    if not value:
        return None
    text = value.strip()
    match = LIST_RE.search(text)
    if match:
        return match.group(1)
    if BARE_ID_RE.fullmatch(text):
        return text
    return None


def fail(message):
    """Hata JSON'unu stdout'a yazip 1 ile cikar; stdout disina yazilmaz."""
    short = (message or "Liste okunamadi.").strip().splitlines()[0][:200]
    sys.stdout.write(json.dumps({"ok": False, "error": short}, ensure_ascii=False))
    sys.stdout.write("\n")
    sys.stdout.flush()
    sys.exit(1)


def best_image_url(images):
    """Gecerli gorseller arasindan en yuksek cozumurluklu URL'yi secer."""
    if not isinstance(images, list):
        return ""
    candidates = [image for image in images if isinstance(image, dict) and image.get("url")]
    if not candidates:
        return ""
    selected = max(
        candidates,
        key=lambda image: (image.get("width") or 0) * (image.get("height") or 0),
    )
    return str(selected["url"])


def split_artist_title(title, uploader):
    """Video basligindan sanatci/parca ayirir.

    YouTube Music basliklari genellikle "Sanatci - Parca" bicimindedir;
    degilse yukleyici kanal adi kullanilir (" - Topic" eki temizlenir).
    """
    text = (title or "").strip()
    if " - " in text:
        artist, _, rest = text.partition(" - ")
        artist = artist.strip()
        rest = rest.strip()
        if artist and rest:
            return artist, rest
    artist = (uploader or "").strip()
    if artist.endswith(" - Topic"):
        artist = artist[: -len(" - Topic")].strip()
    return artist, text


def as_track_dict(entry):
    """yt-dlp liste girdisini Turkify parca kaydina cevirir."""
    if not isinstance(entry, dict):
        return None
    video_id = entry.get("id")
    if not isinstance(video_id, str) or not video_id:
        return None
    # Ozel/kaldirilmis videolar ve canli yayinlar atlanir.
    if entry.get("live_status") == "is_live":
        return None
    title = entry.get("title")
    if not isinstance(title, str) or not title.strip():
        return None
    if title in ("[Private video]", "[Deleted video]"):
        return None
    uploader = entry.get("uploader") or entry.get("channel") or ""
    artist, clean_title = split_artist_title(title, uploader if isinstance(uploader, str) else "")
    duration = entry.get("duration")
    return {
        "id": video_id,
        "title": clean_title,
        "artist": artist,
        "album": "YouTube",
        "duration": round(duration) if isinstance(duration, (int, float)) else 0,
        "url": "https://www.youtube.com/watch?v=%s" % video_id,
        "cover": best_image_url(entry.get("thumbnails")),
    }


def main():
    if len(sys.argv) != 2 or not sys.argv[1].strip():
        fail("Kullanim: python scripts/youtube-playlist.py <playlist-url>")

    try:
        from yt_dlp import YoutubeDL
    except Exception as exc:
        fail("yt-dlp yuklu degil: %s" % exc)

    playlist_id = extract_id(sys.argv[1])
    if not playlist_id:
        fail("Gecerli bir YouTube playlist baglantisi yapistir.")

    try:
        options = {
            "extract_flat": True,
            "quiet": True,
            "no_warnings": True,
            "socket_timeout": 30,
        }
        with YoutubeDL(options) as client:
            info = client.extract_info(
                "https://www.youtube.com/playlist?list=%s" % playlist_id,
                download=False,
            )
    except Exception as exc:
        fail(str(exc) or "YouTube playlist okunamadi.")

    try:
        info = info if isinstance(info, dict) else {}
        entries = info.get("entries")
        if not isinstance(entries, list):
            entries = []

        name = info.get("title") if isinstance(info.get("title"), str) else ""
        if not name:
            name = "YouTube playlist"
        cover = best_image_url(info.get("thumbnails"))

        tracks = []
        for entry in entries:
            track = as_track_dict(entry)
            if track is None:
                continue
            tracks.append(track)

        sys.stdout.write(
            json.dumps(
                {
                    "ok": True,
                    "id": playlist_id,
                    "name": name,
                    "cover": cover,
                    "tracks": tracks,
                },
                ensure_ascii=False,
            )
        )
        sys.stdout.write("\n")
        sys.stdout.flush()
    except Exception as exc:
        fail(str(exc) or "YouTube playlist okunamadi.")


if __name__ == "__main__":
    main()
