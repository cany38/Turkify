#!/usr/bin/env python3
"""Spotify playlistini spotDL istemcisiyle okuyup tek satir JSON yazar.

Kullanim: `python scripts/spotify-playlist.py <playlist-id ya da URL>`

Spotify Web API anahtarsiz calisir; spotDL kendi kayitli kimlikleriyle
listeyi okur ve kendi icinde sayfalar (1000 parcalik liste de tek cagrida
gelir). Cikti her zaman stdout'ta tek satir JSON'dur; spotDL uyarilari
stderr'de kalir, stdout kirlenmez.
"""

import json
import re
import sys

# Windows konsolu varsayilan olarak cp1254; listede o kod sayfasinda olmayan bir
# karakter varsa JSON yazarken patlar. Cikti her zaman UTF-8 olsun.
sys.stdout.reconfigure(encoding="utf-8")
sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# `playlist/xxx` ya da `playlist:xxx` bicimindeki girdiden kimligi alir.
ID_RE = re.compile(r"(?:playlist[/:])([A-Za-z0-9]+)")


def extract_id(value):
    """Tam URL, URI ya da ciplak kimlikten playlist kimligini cikarir."""
    if not value:
        return None
    text = value.strip()
    match = ID_RE.search(text)
    if match:
        return match.group(1)
    # Kimlik zaten ciplak verilmisse (22 karakter base62) aynen kullanilir.
    if re.fullmatch(r"[A-Za-z0-9]{10,40}", text):
        return text
    return None


def fail(message):
    """Hata JSON'unu stdout'a yazip 1 ile cikar; stdout disina yazilmaz."""
    short = (message or "Liste okunamadi.").strip().splitlines()[0][:200]
    sys.stdout.write(json.dumps({"ok": False, "error": short}, ensure_ascii=False))
    sys.stdout.write("\n")
    sys.stdout.flush()
    sys.exit(1)


def best_image_url(images):
    """Gecerli gorseller arasindan en yuksek cozumurluklu URL'yi secer."""
    if not isinstance(images, list):
        return ""
    candidates = [image for image in images if isinstance(image, dict) and image.get("url")]
    if not candidates:
        return ""
    selected = max(
        candidates,
        key=lambda image: (image.get("width") or image.get("maxWidth") or 0)
        * (image.get("height") or image.get("maxHeight") or 0),
    )
    return str(selected["url"])


def artist_names(artists):
    """Spotify sanatci listesini ekranda kullanilan tek metne cevirir."""
    if not isinstance(artists, list):
        return ""
    return ", ".join(
        str(artist.get("name", "")).strip()
        for artist in artists
        if isinstance(artist, dict) and artist.get("name")
    )


def as_track_dict(entry):
    """SpotAPI veya spotDL girdisini Turkify parca kaydina cevirir."""
    if not isinstance(entry, dict):
        return None

    # SpotipyFree formatter album bilgisini ve kapagi siliyor. Ham SpotAPI
    # girdisinde bu alanlar itemV2.albumOfTrack icinde hala mevcut.
    item_v3 = entry.get("itemV3", {}).get("data", {})
    item_v2 = entry.get("itemV2", {}).get("data", {})
    if isinstance(item_v3, dict) and isinstance(item_v2, dict) and item_v2:
        identity = item_v3.get("identityTrait", {})
        identity = identity if isinstance(identity, dict) else {}
        contributors = identity.get("contributors", {})
        contributors = contributors if isinstance(contributors, dict) else {}
        album = item_v2.get("albumOfTrack", {})
        album = album if isinstance(album, dict) else {}
        cover_art = album.get("coverArt", {})
        cover_art = cover_art if isinstance(cover_art, dict) else {}
        uri = item_v3.get("uri") or item_v2.get("uri") or ""
        track_id = str(uri).removeprefix("spotify:track:")
        duration = item_v2.get("trackDuration", {})
        duration = duration if isinstance(duration, dict) else {}
        duration_ms = duration.get("totalMilliseconds")
        if item_v2.get("mediaType") != "AUDIO" or not track_id:
            return None
        return {
            "id": track_id,
            "title": identity.get("name") if isinstance(identity.get("name"), str) else "",
            "artist": artist_names(contributors.get("items")),
            "album": album.get("name") if isinstance(album.get("name"), str) else "",
            "duration": round(duration_ms / 1000) if isinstance(duration_ms, (int, float)) else 0,
            "url": "https://open.spotify.com/track/%s" % track_id,
            "cover": best_image_url(cover_art.get("sources")),
        }

    # Resmi API veya eski spotDL bicimi icin uyumluluk yolu.
    candidate = entry.get("track", entry.get("item", entry))
    if not isinstance(candidate, dict) or candidate.get("is_local"):
        return None
    track_id = candidate.get("id")
    if not isinstance(track_id, str) or not track_id:
        return None
    album = candidate.get("album", {})
    album = album if isinstance(album, dict) else {}
    external = candidate.get("external_urls", {})
    external = external if isinstance(external, dict) else {}
    duration_ms = candidate.get("duration_ms")
    return {
        "id": track_id,
        "title": candidate.get("name") if isinstance(candidate.get("name"), str) else "",
        "artist": artist_names(candidate.get("artists")),
        "album": album.get("name") if isinstance(album.get("name"), str) else "",
        "duration": round(duration_ms / 1000) if isinstance(duration_ms, (int, float)) else 0,
        "url": external.get("spotify")
        if isinstance(external.get("spotify"), str)
        else "https://open.spotify.com/track/%s" % track_id,
        "cover": best_image_url(album.get("images")),
    }


def main():
    if len(sys.argv) != 2 or not sys.argv[1].strip():
        fail("Kullanim: python scripts/spotify-playlist.py <playlist-id>")

    try:
        from spotdl.utils.spotify import SpotifyClient
        from spotdl.utils.config import DEFAULT_CONFIG
    except Exception as exc:
        fail("spotDL yuklu degil: %s" % exc)

    playlist_id = extract_id(sys.argv[1])
    if not playlist_id:
        fail("Gecerli bir Spotify playlist baglantisi yapistir.")

    try:
        # Indirmelerde kullanilan ayni istemci; kullanici anahtari gerekmez.
        SpotifyClient.init(
            client_id=DEFAULT_CONFIG["client_id"],
            client_secret=DEFAULT_CONFIG["client_secret"],
            user_auth=False,
            cache_path=None,
            no_cache=True,
        )
        client = SpotifyClient()
        meta = client.playlist(playlist_id)
        # SpotipyFree'in formatter'i album ve kapagi bosalttigi icin ham
        # SpotAPI sayfalari kullanilir. SpotifyClient.init yukarida ayni
        # anonim istemcinin gerekli oturumunu hazirlar.
        import spotapi

        items = []
        for chunk in spotapi.PublicPlaylist(playlist_id).paginate_playlist():
            if isinstance(chunk, dict) and isinstance(chunk.get("items"), list):
                items.extend(chunk["items"])
    except Exception as exc:
        fail(str(exc) or "Spotify playlist okunamadi.")

    try:
        meta = meta if isinstance(meta, dict) else {}
        if not isinstance(items, list):
            items = []

        images = meta.get("images") if isinstance(meta.get("images"), list) else []
        cover = ""
        if images and isinstance(images[0], dict) and images[0].get("url"):
            cover = str(images[0]["url"])
        name = meta.get("name") if isinstance(meta.get("name"), str) else ""
        if not name:
            name = "Spotify playlist"

        tracks = []
        for entry in items:
            track = as_track_dict(entry)
            if track is None:
                continue
            tracks.append(track)

        sys.stdout.write(
            json.dumps(
                {"ok": True, "name": name, "cover": cover, "tracks": tracks},
                ensure_ascii=False,
            )
        )
        sys.stdout.write("\n")
        sys.stdout.flush()
    except Exception as exc:
        fail(str(exc) or "Spotify playlist okunamadi.")


if __name__ == "__main__":
    main()
