import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Geist, Geist_Mono } from "next/font/google";
import { LocaleProvider } from "../components/locale-provider";
import { SwRegister } from "../components/sw-register";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Turkify",
  description:
    "Yerel müzik kütüphanesi: arama, beğeni ve çalma listesi yönetimi, kendi ses dosyalarını çalma.",
  applicationName: "Turkify",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: "Turkify",
    statusBarStyle: "black-translucent",
  },
  icons: {
    icon: "/icon.png",
    apple: "/apple-touch-icon.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#121212",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="flex min-h-full flex-col bg-[#121212] text-white">
        <SwRegister />
        <LocaleProvider>{children}</LocaleProvider>
      </body>
    </html>
  );
}
