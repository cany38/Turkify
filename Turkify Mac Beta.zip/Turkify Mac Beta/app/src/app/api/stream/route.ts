import { NextRequest, NextResponse } from "next/server";
import { killByPurpose } from "../../../lib/child-processes";
import {
  forgetStreamUrl,
  readStreamTarget,
  resolveStream,
} from "../../../lib/stream-resolve";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * Anlik dinleme ucu.
 *
 * `/api/download` parcayi bastan sona indirip yeniden kodladigi icin ilk ses
 * duyulana kadar tum is bitmek zorunda. Burada indirme yok: adres cozulur ve
 * baytlar istemciye aktarilir. Range basligi yukariya gectigi icin ileri
 * sarma da calisiyor.
 *
 * Cozumleme `/api/stream/resolve` ile ayni onbellegi paylasir. Oynatici once
 * orayi cagirdigi icin buraya gelindiginde adres hazirdir ve bu istek aninda
 * bayt akitmaya baslar - element hicbir zaman yarim kalmis bir yuklemede
 * asili kalmaz.
 */
export async function GET(request: NextRequest) {
  const spec = readStreamTarget(request.nextUrl.searchParams);
  if (!spec.ok) {
    return NextResponse.json({ error: spec.error }, { status: spec.status });
  }

  // Kullanicinin kurali: tiklandiginda ne is varsa birakilir. Rozet
  // yoklamalari calma ile ayni yt-dlp'yi kullaniyor, once onlar olur.
  killByPurpose("badge");

  const outcome = await resolveStream(spec.value, request.signal);
  if (outcome.aborted || request.signal.aborted) {
    return new NextResponse(null, { status: 499 });
  }
  if (!outcome.url) {
    return NextResponse.json(
      { error: `Ses akışı bulunamadı. ${outcome.error}`.trim() },
      { status: 502 },
    );
  }

  // Range'i yukariya aynen gecir; ileri sarma bu sayede calisiyor.
  const range = request.headers.get("range");
  let upstream: Response;
  try {
    upstream = await fetch(outcome.url, {
      headers: range ? { Range: range } : {},
      cache: "no-store",
      signal: request.signal,
    });
  } catch (err) {
    // Adres eskimis olabilir; onbellegi dusur ki sonraki denemede yeniden cozulsun.
    forgetStreamUrl(spec.value.cacheKey);
    if (request.signal.aborted) return new NextResponse(null, { status: 499 });
    const msg = err instanceof Error ? err.message : String(err);
    return NextResponse.json(
      { error: `Ses kaynağına bağlanılamadı: ${msg.slice(0, 200)}` },
      { status: 502 },
    );
  }

  if (!upstream.ok && upstream.status !== 206) {
    forgetStreamUrl(spec.value.cacheKey);
    return NextResponse.json(
      { error: `Ses kaynağı yanıt vermedi (${upstream.status}).` },
      { status: 502 },
    );
  }

  const headers = new Headers();
  headers.set(
    "Content-Type",
    upstream.headers.get("content-type") ??
      (spec.value.format === "opus" ? "audio/webm" : "audio/mp4"),
  );
  headers.set("Accept-Ranges", "bytes");
  headers.set("Cache-Control", "no-store");
  const len = upstream.headers.get("content-length");
  if (len) headers.set("Content-Length", len);
  const contentRange = upstream.headers.get("content-range");
  if (contentRange) headers.set("Content-Range", contentRange);

  return new NextResponse(upstream.body, { status: upstream.status, headers });
}
