import { NextRequest, NextResponse } from "next/server";
import { killByPurpose } from "../../../../lib/child-processes";
import { readStreamTarget, resolveStream } from "../../../../lib/stream-resolve";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * Ses akışını hazırlar ama bayt döndürmez.
 *
 * Oynatıcı önce burayı çağırır; adres çözülene kadar `<audio>` elementine
 * hiç dokunulmaz. Böylece kullanıcı beklerken başka bir parçaya geçerse
 * iptal edilen şey sıradan bir `fetch` olur — tarayıcının yarım kalmış medya
 * yüklemesini söküp atması gerekmez, ki asıl bekleme oradan geliyordu.
 *
 * İstek iptal edilince `request.signal` yt-dlp'ye kadar iner ve süreç ölür.
 */
export async function GET(request: NextRequest) {
  const spec = readStreamTarget(request.nextUrl.searchParams);
  if (!spec.ok) {
    return NextResponse.json({ error: spec.error }, { status: spec.status });
  }

  // Kullanicinin kurali: tiklandiginda ne is varsa birakilir. Rozet
  // yoklamalari calma ile ayni yt-dlp'yi kullaniyor, once onlar olur.
  killByPurpose("badge");

  const outcome = await resolveStream(spec.value, request.signal);

  if (outcome.aborted || request.signal.aborted) {
    // İstemci zaten dinlemiyor; gövde önemsiz, bağlantı kapansın yeter.
    return new NextResponse(null, { status: 499 });
  }

  if (!outcome.url) {
    return NextResponse.json(
      { error: `Ses akışı bulunamadı. ${outcome.error}`.trim() },
      { status: 502 },
    );
  }

  // Adresin kendisi istemciye verilmiyor: bayt akışı yine kendi ucumuzdan
  // geçiyor (Range, içerik türü, referer hepsi orada ayarlanıyor).
  return NextResponse.json({ ready: true, cached: outcome.cached });
}
