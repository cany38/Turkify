import { NextRequest, NextResponse } from "next/server";

import { readLibraryFile, writeLibraryFile } from "../../../lib/library-store";
import { MUSICS_DIR } from "../../../lib/musics-dir";

export const dynamic = "force-dynamic";

const NO_STORE = { "Cache-Control": "no-store" };

/**
 * Kutuphane durumu (begeniler, listeler) sunucuda saklanir; tarayici
 * verisi silinse bile proje ayaga kalkinca geri gelir.
 */
export async function GET() {
  const state = await readLibraryFile(MUSICS_DIR);
  return NextResponse.json({ state }, { headers: NO_STORE });
}

export async function PUT(request: NextRequest) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Gecersiz istek govdesi." }, { status: 400 });
  }
  const state = (body as Record<string, unknown> | null)?.state;
  try {
    const cleaned = await writeLibraryFile(state, MUSICS_DIR);
    return NextResponse.json({ state: cleaned }, { headers: NO_STORE });
  } catch {
    return NextResponse.json({ error: "Gecersiz kutuphane kaydi." }, { status: 400 });
  }
}
