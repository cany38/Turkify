import { NextRequest, NextResponse } from "next/server";
import type { ExternalTrack, SearchApiResponse, SpotifyTrack, YoutubeTrack } from "../../../lib/types";
import { decodeHtmlEntities } from "../../../lib/html-entities";

export const dynamic = "force-dynamic";

const TOKEN_URL = "https://accounts.spotify.com/api/token";
const SPOTIFY_SEARCH_URL = "https://api.spotify.com/v1/search";
const YOUTUBE_SEARCH_URL = "https://www.googleapis.com/youtube/v3/search";
const YOUTUBE_VIDEOS_URL = "https://www.googleapis.com/youtube/v3/videos";

const tokenCache = new Map<string, { token: string; expiresAt: number }>();

async function getSpotifyToken(clientId: string, clientSecret: string): Promise<string | null> {
  if (!clientId || !clientSecret) return null;
  const now = Date.now();
  const cached = tokenCache.get(clientId);
  if (cached && now < cached.expiresAt - 60_000) return cached.token;
  const basic = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: {
      Authorization: `Basic ${basic}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
    cache: "no-store",
  });
  if (!res.ok) return null;
  const data = (await res.json()) as { access_token: string; expires_in: number };
  if (!data.access_token) return null;
  tokenCache.set(clientId, { token: data.access_token, expiresAt: now + data.expires_in * 1000 });
  return data.access_token;
}

interface SpotifyApiTrack {
  id: string;
  name: string;
  artists: { name: string }[];
  album: { name: string; images: { url: string }[] };
  duration_ms: number;
  external_urls: { spotify: string };
  preview_url: string | null;
}

function mapSpotifyTrack(item: SpotifyApiTrack): SpotifyTrack {
  return {
    id: `spotify-${item.id}`,
    title: item.name,
    artist: item.artists.map((a) => a.name).join(", ") || "Bilinmeyen sanatçı",
    album: item.album.name,
    duration: Math.round(item.duration_ms / 1000),
    cover: item.album.images[0]?.url ?? "/covers/demo-01.svg",
    source: "spotify",
    externalUrl: item.external_urls.spotify,
    previewUrl: item.preview_url,
  };
}

interface YoutubeSearchItem {
  id: { videoId: string };
  snippet: {
    title: string;
    channelTitle: string;
    thumbnails: { high?: { url: string }; medium?: { url: string }; default?: { url: string } };
  };
}

function mapYoutubeTrack(item: YoutubeSearchItem, durationSec: number): YoutubeTrack {
  const videoId = item.id.videoId;
  return {
    id: `youtube-${videoId}`,
    title: decodeHtmlEntities(item.snippet.title),
    artist: decodeHtmlEntities(item.snippet.channelTitle) || "YouTube",
    album: "YouTube",
    duration: durationSec,
    cover:
      item.snippet.thumbnails.high?.url ??
      item.snippet.thumbnails.medium?.url ??
      item.snippet.thumbnails.default?.url ??
      "/covers/demo-01.svg",
    source: "youtube",
    videoId,
    externalUrl: `https://www.youtube.com/watch?v=${videoId}`,
  };
}

function parseIsoDurationToSeconds(iso: string): number {
  const match = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!match) return 0;
  const h = parseInt(match[1] ?? "0", 10);
  const m = parseInt(match[2] ?? "0", 10);
  const s = parseInt(match[3] ?? "0", 10);
  return h * 3600 + m * 60 + s;
}

async function fetchSpotify(
  query: string,
  clientId: string,
  clientSecret: string,
  offset: number,
  limit: number,
): Promise<{ results: SpotifyTrack[]; error?: string; authFailed: boolean }> {
  const token = await getSpotifyToken(clientId, clientSecret);
  if (!token) {
    return { results: [], error: "Spotify anahtarları yok ya da token alınamadı.", authFailed: true };
  }
  const url = new URL(SPOTIFY_SEARCH_URL);
  url.searchParams.set("q", query);
  url.searchParams.set("type", "track");
  url.searchParams.set("limit", String(limit));
  url.searchParams.set("offset", String(offset));
  const res = await fetch(url.toString(), {
    headers: { Authorization: `Bearer ${token}` },
    cache: "no-store",
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    const authFailed = res.status === 401 || res.status === 403;
    return { results: [], error: `Spotify hatası (${res.status}): ${text.slice(0, 300)}`, authFailed };
  }
  const data = (await res.json()) as { tracks?: { items: SpotifyApiTrack[] } };
  return { results: (data.tracks?.items ?? []).map(mapSpotifyTrack), authFailed: false };
}

async function fetchYoutube(query: string, apiKey: string, pageToken: string, limit: number): Promise<{ results: YoutubeTrack[]; error?: string; authFailed: boolean; quotaExceeded?: boolean; nextPageToken?: string }> {
  if (!apiKey) {
    return { results: [], error: "YouTube API anahtarı yapılandırılmadı.", authFailed: true };
  }
  const searchUrl = new URL(YOUTUBE_SEARCH_URL);
  searchUrl.searchParams.set("part", "snippet");
  searchUrl.searchParams.set("q", query);
  searchUrl.searchParams.set("type", "video");
  searchUrl.searchParams.set("maxResults", String(limit));
  searchUrl.searchParams.set("videoCategoryId", "10");
  searchUrl.searchParams.set("key", apiKey);
  if (pageToken) searchUrl.searchParams.set("pageToken", pageToken);
  const searchRes = await fetch(searchUrl.toString(), { cache: "no-store" });
  if (!searchRes.ok) {
    // Kota dolunca (429) ham JSON dökümü gösterilmez; arayüz kısa uyarı verir.
    if (searchRes.status === 429) {
      return { results: [], authFailed: false, quotaExceeded: true };
    }
    const text = await searchRes.text().catch(() => "");
    const authFailed = searchRes.status === 403 || searchRes.status === 400;
    return { results: [], error: `YouTube hatası (${searchRes.status}): ${text.slice(0, 400)}`, authFailed };
  }
  const searchData = (await searchRes.json()) as {
    items?: YoutubeSearchItem[];
    error?: { message?: string };
    nextPageToken?: string;
  };
  if (searchData.error) {
    return { results: [], error: searchData.error.message ?? "YouTube API hatası.", authFailed: false };
  }
  const items = searchData.items ?? [];
  if (items.length === 0) return { results: [], authFailed: false, nextPageToken: searchData.nextPageToken };
  const videoIds = items.map((i) => i.id.videoId).join(",");
  const videosUrl = new URL(YOUTUBE_VIDEOS_URL);
  videosUrl.searchParams.set("part", "contentDetails");
  videosUrl.searchParams.set("id", videoIds);
  videosUrl.searchParams.set("key", apiKey);
  const durationMap = new Map<string, number>();
  try {
    const videosRes = await fetch(videosUrl.toString(), { cache: "no-store" });
    if (videosRes.ok) {
      const videosData = (await videosRes.json()) as {
        items?: { id: string; contentDetails: { duration: string } }[];
      };
      for (const v of videosData.items ?? []) {
        durationMap.set(v.id, parseIsoDurationToSeconds(v.contentDetails.duration));
      }
    }
  } catch {
    // Süre bilgisi opsiyonel; alınamazsa 0 kalır.
  }
  return {
    results: items.map((item) => mapYoutubeTrack(item, durationMap.get(item.id.videoId) ?? 0)),
    authFailed: false,
    nextPageToken: searchData.nextPageToken,
  };
}

function interleave(a: ExternalTrack[], b: ExternalTrack[]): ExternalTrack[] {
  const out: ExternalTrack[] = [];
  const max = Math.max(a.length, b.length);
  for (let i = 0; i < max; i++) {
    const fromA = a[i];
    if (fromA) out.push(fromA);
    const fromB = b[i];
    if (fromB) out.push(fromB);
  }
  return out;
}

export async function GET(request: NextRequest) {
  const sources = (request.nextUrl.searchParams.get("sources") ?? "spotify,youtube").split(",");
  const spotifySelected = sources.includes("spotify");
  const youtubeSelected = sources.includes("youtube");
  const limit = spotifySelected && youtubeSelected ? 5 : 10;
  const query = request.nextUrl.searchParams.get("q")?.trim() ?? "";
  if (query.length < 2 || (!spotifySelected && !youtubeSelected)) {
    const body: SearchApiResponse = { source: "mixed", query, results: [] };
    return NextResponse.json(body);
  }

  const headerClientId = request.headers.get("x-spotify-client-id")?.trim() ?? "";
  const headerClientSecret = request.headers.get("x-spotify-client-secret")?.trim() ?? "";
  const spotifyClientId = headerClientId || process.env.SPOTIFY_CLIENT_ID || "";
  const spotifyClientSecret = headerClientSecret || process.env.SPOTIFY_CLIENT_SECRET || "";
  const hasSpotifyKey = spotifyClientId.length > 0 && spotifyClientSecret.length > 0;
  const headerYoutubeKey = request.headers.get("x-youtube-api-key")?.trim() ?? "";
  const youtubeApiKey = headerYoutubeKey || process.env.YOUTUBE_API_KEY || "";
  const hasYoutubeKey = youtubeApiKey.length > 0;

  // Sayfalama: Spotify offset sayi, YouTube token metin; bos/bozuksa basa don.
  const hasSpotifyParam = request.nextUrl.searchParams.has("spotifyOffset");
  const hasYoutubeParam = request.nextUrl.searchParams.has("youtubePageToken");
  const rawOffset = request.nextUrl.searchParams.get("spotifyOffset");
  const parsedOffset = rawOffset ? parseInt(rawOffset, 10) : 0;
  const spotifyOffset = Number.isFinite(parsedOffset) && parsedOffset > 0 ? parsedOffset : 0;
  const youtubePageToken = request.nextUrl.searchParams.get("youtubePageToken")?.trim() ?? "";

  if (!hasSpotifyKey && !hasYoutubeKey) {
    return NextResponse.json(
      {
        error:
          "Harici arama için API anahtarı yok. app/.env.local dosyasına SPOTIFY_CLIENT_ID, SPOTIFY_CLIENT_SECRET ve YOUTUBE_API_KEY ekleyin (örnek: .env.example).",
      },
      { status: 503 },
    );
  }

  // Sayfalama isteğinde imleci tükenmiş sağlayıcı yeniden sorgulanmaz: ilk
  // sayfada iki parametre de yoktur, sayfalamada en az biri vardır. Eksik
  // olan tükenmiş demektir; yoksa ilk sayfası baştan çekilir, YouTube'da her
  // seferinde 100 kota birimi yakar ve sonuçlar zaten dedup'a takılır.
  const isPaginationRequest = hasSpotifyParam || hasYoutubeParam;
  const spotifyPromise: Promise<Awaited<ReturnType<typeof fetchSpotify>>> =
    spotifySelected && (!isPaginationRequest || hasSpotifyParam)
      ? fetchSpotify(query, spotifyClientId, spotifyClientSecret, spotifyOffset, limit)
      : Promise.resolve({ results: [], authFailed: false });
  const youtubePromise: Promise<Awaited<ReturnType<typeof fetchYoutube>>> =
    youtubeSelected && (!isPaginationRequest || hasYoutubeParam)
      ? fetchYoutube(query, youtubeApiKey, youtubePageToken, limit)
      : Promise.resolve({ results: [], authFailed: false });
  const [spotify, youtube] = await Promise.all([spotifyPromise, youtubePromise]);

  // Hic yapilandirilmamis saglayicinin "anahtar yok" mesajini uyari olarak gostermeye gerek yok.
  // Kota hatasi (429) ayri bayrakla tasinir, ham metin uyarilara girmez.
  const errors: string[] = [];
  if (hasSpotifyKey && spotify.error) errors.push(spotify.error);
  if (hasYoutubeKey && youtube.error && !youtube.quotaExceeded) errors.push(youtube.error);

  const results = interleave(spotify.results, youtube.results);

  // Spotify hic donmediyse tukendi sayilir; YouTube token yoksa son sayfadayiz.
  const nextSpotifyOffset = spotify.results.length === 0 ? undefined : spotifyOffset + spotify.results.length;
  const nextYoutubePageToken = youtube.nextPageToken ? youtube.nextPageToken : undefined;

  const body: SearchApiResponse = {
    source: "mixed",
    query,
    results,
    errors: errors.length ? errors : undefined,
    needsSpotifyKeys: !hasSpotifyKey || spotify.authFailed ? true : undefined,
    needsYoutubeKey: !hasYoutubeKey || youtube.authFailed ? true : undefined,
    ...(youtube.quotaExceeded ? { youtubeQuotaExceeded: true as const } : {}),
    nextSpotifyOffset,
    nextYoutubePageToken,
  };
  return NextResponse.json(body);
}
