import { NextRequest, NextResponse } from "next/server";
import { spawn } from "child_process";
import fs from "fs";
import path from "path";
import os from "os";
import { randomUUID } from "crypto";
import { MUSICS_DIR, uniqueTargetName } from "../../../lib/musics-dir";
import { readTrackMeta, removeTrackMetaEntry, saveTrackMetaEntry } from "../../../lib/track-meta";
import { decodeHtmlEntities } from "../../../lib/html-entities";
import {
  getYtDlpSelector,
  isRequestedAudioFormatUnavailable,
  matchesAudioFormat,
  parseAudioFormat,
} from "../../../lib/audio-format";
import { buildContentDisposition } from "../../../lib/download-headers";
import {
  embedCoverInM4a,
  inspectAudioFile,
  resolveSpotifyMediaUrl,
  resolveYoutubeVideoId,
} from "../../../lib/external-audio";
import { downloadKills } from "../../../lib/download-jobs";

export const dynamic = "force-dynamic";
export const maxDuration = 120;
const progressGlobal = globalThis as typeof globalThis & { __downloadProgress?: Map<string, { percent: number; phase: "matching" | "downloading"; updatedAt: number }> };
const progress = progressGlobal.__downloadProgress ??= new Map();
export async function GET(request: NextRequest) {
  const id = request.nextUrl.searchParams.get("id") ?? "";
  return NextResponse.json(progress.get(id) ?? { percent: 0 }, { headers: { "Cache-Control": "no-store" } });
}

/** yt-dlp ilerleme satırlarındaki yüzde değerleri; sahte üretim yok. */
export function parseProgressPercent(chunk: string): number[] {
  const out: number[] = [];
  for (const match of chunk.matchAll(/(\d+(?:\.\d+)?)%/g)) {
    const value = Number(match[1]);
    if (Number.isFinite(value)) out.push(value);
  }
  return out;
}

export { extractMediaUrl } from "../../../lib/external-audio";

// Aynı parçanın eşzamanlı iki indirmesi birbirini ezmesin / kopya dosya
// üretmesin diye process-içi kilit. Dev server HMR'da modül yeniden
// yüklenebildiği için globalThis üzerinde tutulur.
const globalDownloadLocks = globalThis as typeof globalThis & {
  __turkifyActiveDownloads?: Set<string>;
};
const activeDownloads =
  globalDownloadLocks.__turkifyActiveDownloads ??
  (globalDownloadLocks.__turkifyActiveDownloads = new Set<string>());

/**
 * Indirmeler passthrough: kaynak ses yeniden kodlanmadan m4a olarak alinir.
 *
 * YouTube'un verdigi en iyi ses ~130 kbps AAC / ~129 kbps Opus; MP3'e
 * cevirmek dosyayi buyutup ikinci kayipli sikistirma ekledigi icin artik
 * donusum yok, dosya oldugu gibi saklanir.
 */

function sanitizeForFile(value: string): string {
  const cleaned = value.replace(/[\\/:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim();
  const sliced = cleaned.slice(0, 80).trim();
  return sliced.length > 0 ? sliced : "parca";
}

function runCommand(
  command: string,
  args: string[],
  opts: { timeoutMs: number; onProgress?: (percent: number) => void; signal?: AbortSignal },
): Promise<{ code: number | null; stdout: string; stderr: string; timedOut: boolean; aborted?: boolean }> {
  return new Promise((resolve) => {
    // İptal geç geldiyse süreci hiç başlatma.
    if (opts.signal?.aborted) {
      resolve({ code: null, stdout: "", stderr: "", timedOut: false, aborted: true });
      return;
    }
    const child = spawn(command, args, { windowsHide: true });
    let stdout = "";
    let stderr = "";
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      try {
        child.kill();
      } catch {
        // yok say
      }
    }, opts.timeoutMs);
    const onAbort = () => {
      try {
        child.kill();
      } catch {
        // yok say
      }
    };
    opts.signal?.addEventListener("abort", onAbort, { once: true });
    const done = (result: { code: number | null; stdout: string; stderr: string; timedOut: boolean; aborted?: boolean }) => {
      clearTimeout(timer);
      opts.signal?.removeEventListener("abort", onAbort);
      resolve(result);
    };

    if (child.stdout) {
      child.stdout.on("data", (d: Buffer) => {
        stdout += d.toString();
        for (const value of parseProgressPercent(d.toString())) opts.onProgress?.(value);
      });
    }
    if (child.stderr) {
      child.stderr.on("data", (d: Buffer) => {
        stderr += d.toString();
        for (const value of parseProgressPercent(d.toString())) opts.onProgress?.(value);
      });
    }
    child.on("error", (err) => {
      done({ code: 1, stdout, stderr: stderr + String(err), timedOut, ...(opts.signal?.aborted ? { aborted: true as const } : {}) });
    });
    child.on("close", (code) => {
      done({ code, stdout, stderr, timedOut, ...(opts.signal?.aborted ? { aborted: true as const } : {}) });
    });
  });
}

// Desteklenen ses uzantilari; .m4a once tercih edilir.
const AUDIO_EXTS = [".m4a", ".mp3", ".opus", ".webm", ".ogg", ".oga", ".aac", ".flac"];

async function findFirstAudio(dir: string): Promise<string | null> {
  try {
    const entries = await fs.promises.readdir(dir, { withFileTypes: true });
    // Once .m4a, sonra diger uzantilar denensin.
    for (const ext of AUDIO_EXTS) {
      for (const e of entries) {
        if (e.isFile() && e.name.toLowerCase().endsWith(ext)) {
          return path.join(dir, e.name);
        }
      }
    }
    for (const e of entries) {
      if (e.isDirectory()) {
        const nested = await findFirstAudio(path.join(dir, e.name));
        if (nested) return nested;
      }
    }
    return null;
  } catch {
    return null;
  }
}

// Uzantiya gore yanit Content-Type degeri.
function contentTypeForExt(ext: string): string {
  switch (ext.toLowerCase()) {
    case ".m4a":
      return "audio/mp4";
    case ".mp3":
      return "audio/mpeg";
    case ".opus":
    case ".ogg":
    case ".oga":
      return "audio/ogg";
    case ".webm":
      return "audio/webm";
    case ".aac":
      return "audio/aac";
    case ".flac":
      return "audio/flac";
    default:
      return "application/octet-stream";
  }
}

// Kapak resminin indirilebileceği adresler: arama uçlarının verdiği CDN'ler.
// Sunucu rastgele adrese istek atmasın diye liste kapalı tutulur; uymayan
// adreste kapak atlanır, indirme aynen devam eder (yedek kapak gösterilir).
const COVER_HOSTS = ["i.scdn.co", "scdn.co", "i.ytimg.com", "ytimg.com", "ggpht.com", "googleusercontent.com"];

function isAllowedCoverHost(hostname: string): boolean {
  const host = hostname.toLowerCase();
  return COVER_HOSTS.some((base) => host === base || host.endsWith(`.${base}`));
}

function coverExtFor(contentType: string): string {
  const lower = contentType.toLowerCase();
  if (lower.includes("png")) return ".png";
  if (lower.includes("webp")) return ".webp";
  return ".jpg";
}

/**
 * Uzak kapak resmini belleğe indirir. Aynı veri hem M4A içine gömülür hem
 * hızlı liste görünümü için ayrı dosya olarak saklanır.
 * Herhangi bir adımda sorun çıkarsa tanımsız döner; indirme etkilenmez.
 */
async function fetchCoverAsset(
  coverUrl: string,
): Promise<{ data: Buffer; extension: string } | undefined> {
  let url: URL;
  try {
    url = new URL(coverUrl);
  } catch {
    return undefined;
  }
  if (url.protocol !== "https:") return undefined;
  if (!isAllowedCoverHost(url.hostname)) return undefined;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15_000);
  try {
    const res = await fetch(url.toString(), { signal: controller.signal });
    if (!res.ok) return undefined;
    const contentType = res.headers.get("content-type") ?? "";
    if (!contentType.toLowerCase().startsWith("image/")) return undefined;
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.byteLength < 512 || buf.byteLength > 5 * 1024 * 1024) return undefined;
    return { data: buf, extension: coverExtFor(contentType) };
  } catch {
    return undefined;
  } finally {
    clearTimeout(timer);
  }
}

export async function POST(request: NextRequest) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Gecersiz istek govdesi." }, { status: 400 });
  }

  const record = body as Record<string, unknown>;
  const progressId = typeof record.progressId === "string" && /^[a-zA-Z0-9-]{1,80}$/.test(record.progressId) ? record.progressId : "";
  for (const [id, entry] of progress) if (Date.now() - entry.updatedAt > 300_000) progress.delete(id);
  const onProgress = (percent: number) => {
    if (progressId) progress.set(progressId, { percent: Math.max(progress.get(progressId)?.percent ?? 0, Math.min(99, Math.floor(percent))), phase: "downloading", updatedAt: Date.now() });
  };
  const onPhase = (phase: "matching" | "downloading") => {
    if (progressId) progress.set(progressId, { percent: progress.get(progressId)?.percent ?? 0, phase, updatedAt: Date.now() });
  };
  onProgress(0);
  // İstemci bağlantıyı kapatırsa (sekme kapandı / iptal) yt-dlp öldürülür,
  // yarım iş temizlenir, Musics'e parça yazılmaz. Kuyruk istemcide öldüğü
  // için sunucuda yeni indirme başlamaz.
  const jobController = new AbortController();
  const onRequestAbort = () => {
    if (progressId) progress.delete(progressId);
    jobController.abort();
  };
  request.signal.addEventListener("abort", onRequestAbort, { once: true });
  const parsedFormat = parseAudioFormat(record.format);
  if (!parsedFormat.ok) {
    return NextResponse.json({ error: "Geçersiz ses formatı." }, { status: 400 });
  }
  const audioFormat = parsedFormat.value;
  const source = typeof record.source === "string" ? record.source : "";
  const videoId = typeof record.videoId === "string" ? record.videoId.trim() : "";
  const spotifyId = typeof record.spotifyId === "string" ? record.spotifyId.trim() : "";
  const spotifyUrl = typeof record.spotifyUrl === "string" ? record.spotifyUrl.trim() : "";
  const query = typeof record.query === "string" ? record.query.trim() : "";
  const title = typeof record.title === "string" ? record.title.trim() : "";
  const artist = typeof record.artist === "string" ? record.artist.trim() : "";
  const album = typeof record.album === "string" ? record.album.trim() : "";
  const cover = typeof record.cover === "string" ? record.cover.trim() : "";
  // Spotify'in verdigi sure; YouTube adaylari arasindan dogru surumu secmek icin.
  const expectedDuration = (() => {
    const raw = record.duration;
    const value = typeof raw === "number" ? raw : Number.parseFloat(String(raw ?? ""));
    return Number.isFinite(value) && value > 0 ? Math.round(value) : 0;
  })();

  let url: string | null = null;
  let useYtDlp = false;
  // Arama kaydının kalıcı kimliği; bilgi dosyasına yazılır, satırdaki düğme
  // buradan grileşir. Sorguyla inenlerde kimlik yok, boş kalır.
  let externalId: string | undefined;

  if (source === "youtube" && videoId) {
    if (!/^[A-Za-z0-9_-]{6,20}$/.test(videoId)) {
      return NextResponse.json({ error: "Gecersiz YouTube video kimligi." }, { status: 400 });
    }
    url = `https://www.youtube.com/watch?v=${videoId}`;
    useYtDlp = true;
    externalId = `youtube-${videoId}`;
  } else if (source === "spotify" && (spotifyId || spotifyUrl)) {
    if (spotifyUrl && spotifyUrl.startsWith("https://open.spotify.com/")) {
      url = spotifyUrl;
      const trackMatch = /\/track\/([A-Za-z0-9]{10,30})/.exec(spotifyUrl);
      if (trackMatch?.[1]) externalId = `spotify-${trackMatch[1]}`;
    } else if (spotifyId) {
      const clean = spotifyId.replace(/^spotify-/, "");
      if (!/^[A-Za-z0-9]{10,30}$/.test(clean)) {
        return NextResponse.json({ error: "Gecersiz Spotify kimligi." }, { status: 400 });
      }
      url = `https://open.spotify.com/track/${clean}`;
      externalId = `spotify-${clean}`;
    }
  } else if (query) {
    if (query.length < 2 || query.length > 200) {
      return NextResponse.json({ error: "Sorgu cok kisa veya cok uzun." }, { status: 400 });
    }
    url = query;
  } else if (title) {
    const q = [title, artist].filter(Boolean).join(" ").trim();
    if (q.length < 2) {
      return NextResponse.json({ error: "Indirilecek parca bilgisi eksik." }, { status: 400 });
    }
    url = q;
  }

  if (!url) {
    return NextResponse.json({ error: "Indirilecek kaynak belirtilmedi." }, { status: 400 });
  }

  // Ayni parca hizli ust uste istenirse (cift tik / cift istek) ikinci istek
  // indirmeye baslamadan reddedilir. Kilit olmadan iki istek de asagidaki
  // dupe kontrolunu ayni anda gecer, ikisi de indirip "(2)" kopya uretir.
  const downloadLockKey =
    externalId ?? (url ? `url:${source}:${url.trim().toLowerCase()}` : null);
  if (downloadLockKey) {
    if (activeDownloads.has(downloadLockKey)) {
      return NextResponse.json(
        { error: "Bu parça şu anda indiriliyor, bitmesini bekle." },
        { status: 409 },
      );
    }
    activeDownloads.add(downloadLockKey);
  }
  const releaseDownloadLock = () => {
    if (downloadLockKey) activeDownloads.delete(downloadLockKey);
  };

  // Ayni kimlik klasörde kayıtlıysa ikinci kez indirme yok: düğme eski
  // pakette takılı kalsa bile sunucu kopya dosya oluşturmaz.
  if (externalId) {
    try {
      const meta = await readTrackMeta();
      const dupe = Object.entries(meta).find(([, entry]) => entry.externalId === externalId);
      if (dupe) {
        const [dupeName] = dupe;
        try {
          const dupeStat = await fs.promises.stat(path.join(MUSICS_DIR, dupeName));
          if (dupeStat.isFile()) {
            releaseDownloadLock();
            return NextResponse.json(
              { error: `Bu parça zaten kütüphanede (${dupeName}).` },
              { status: 409 },
            );
          }
        } catch {
          // Ses dosyası yok, ölü kayıt; temizleyip indirmeye devam et.
        }
        await removeTrackMetaEntry(dupeName);
      }
    } catch {
      // Bilgi okunamazsa indirmeye devam et, kullanıcıyı bekletme.
    }
  }

  const workId = `${Date.now()}-${Math.floor(Math.random() * 100000)}`;
  const workDir = path.join(os.tmpdir(), `turkify-${workId}`);
  const decodedTitle = title ? decodeHtmlEntities(title) : title;
  const decodedArtist = artist ? decodeHtmlEntities(artist) : artist;
  const decodedAlbum = album ? decodeHtmlEntities(album) : album;
  const displayBase = sanitizeForFile([decodedTitle || query || spotifyId || videoId, decodedArtist].filter(Boolean).join(" - ").slice(0, 80) || "parca");

  try {
    await fs.promises.mkdir(workDir, { recursive: true });
  } catch {
    releaseDownloadLock();
    return NextResponse.json({ error: "Gecici klasor olusturulamadi." }, { status: 500 });
  }
  // Is kaydi SADECE gercek is baslarken dusulur; erken redlerde (400/409)
  // kalan olu kayit, iptal ucunu yaniltmasin.
  if (progressId) downloadKills.set(progressId, () => jobController.abort());

  let result: { code: number | null; stdout: string; stderr: string; timedOut: boolean; aborted?: boolean } | null = null;
  const abortError = () => NextResponse.json({ error: "İndirme iptal edildi." }, { status: 499 });

  try {
    // spotDL indirme yüzdesi yazmaz; Spotify eşleşmesi önce `spotdl url`
    // ile ses adresine çözülür, baytlar yt-dlp ile iner ki bar gerçekten dolsun.
    let downloadUrl: string | null = url;
    if (!useYtDlp && url) {
      onPhase("matching");
      downloadUrl = await Promise.race([
        resolveSpotifyMediaUrl(
          url,
          decodedTitle || title,
          decodedArtist || artist,
          expectedDuration,
        ),
        // Eşleşme bitmeden iptal gelirse spotdl kendi zaman aşımında ölür;
        // burası hemen bırakır, aşağısı yt-dlp'ye geçmez.
        new Promise<null>((resolve) => {
          if (jobController.signal.aborted) resolve(null);
          else jobController.signal.addEventListener("abort", () => resolve(null), { once: true });
        }),
      ]);
      if (jobController.signal.aborted) {
        console.info(`[download] iptal edildi (eslesme): ${displayBase}`);
        return abortError();
      }
      if (!downloadUrl) {
        return NextResponse.json({ error: "Eşleşen ses bulunamadı." }, { status: 502 });
      }
      onPhase("downloading");
    }
    if (!downloadUrl) {
      return NextResponse.json({ error: "Indirilecek kaynak belirtilmedi." }, { status: 400 });
    }
    const runYtDlp = async (downloadUrl: string): Promise<{ code: number | null; stdout: string; stderr: string; timedOut: boolean; aborted?: boolean }> => {
      const outTemplate = path.join(workDir, `${displayBase}.%(ext)s`);
      const denoPath = path.join(os.homedir(), ".spotdl", "deno");
      const ffPath = path.join(os.homedir(), ".spotdl", "ffmpeg");
      const ffDir = path.join(os.homedir(), ".spotdl");
      const ytArgs: string[] = [
        "-m",
        "yt_dlp",
        "--newline",
        "--progress",
        "-f",
        getYtDlpSelector(audioFormat),
        "--embed-metadata",
        "-o",
        outTemplate,
      ];
      try {
        if (fs.existsSync(ffPath)) {
          ytArgs.push("--ffmpeg-location", ffDir);
        }
      } catch {
        // yok say
      }
      try {
        if (fs.existsSync(denoPath)) {
          ytArgs.push("--js-runtimes", `deno:${denoPath}`);
        }
      } catch {
        // yok say
      }
      ytArgs.push(downloadUrl);
      return await runCommand(process.env.TURKIFY_PYTHON || "python3", ytArgs, {
        timeoutMs: 120_000,
        onProgress,
        signal: jobController.signal,
      });
    };

    result = await runYtDlp(downloadUrl);

    if (
      result.code !== 0 &&
      isRequestedAudioFormatUnavailable(
        audioFormat,
        `${result.stdout}\n${result.stderr}`,
      )
    ) {
      return NextResponse.json(
        {
          code: "OPUS_UNAVAILABLE",
          error: "Bu parçada Opus ses akışı yok.",
        },
        { status: 422 },
      );
    }

    // Eslesme (spotdl) yanlis ya da kullanilamaz videoya (yas kısıtı gibi)
    // gidebilir. Indirme hic baslamadan patladiysa baslik+sanatciyla
    // alternatif video bulunup tek kez daha denenir; inen dosya yoksa.
    if (result.code !== 0 && !result.timedOut && !result.aborted) {
      const hasAudio = await findFirstAudio(workDir);
      if (!hasAudio && (decodedTitle || title)) {
        const fallbackId = await resolveYoutubeVideoId(
          decodedTitle || title,
          decodedArtist || artist,
        );
        if (fallbackId && jobController.signal.aborted === false) {
          const fallbackUrl = `https://www.youtube.com/watch?v=${fallbackId}`;
          if (fallbackUrl !== downloadUrl) {
            console.info(`[download] yeniden deneniyor (${fallbackId}): ${displayBase}`);
            result = await runYtDlp(fallbackUrl);
          }
        }
      }
    }

    if (!result) {
      return NextResponse.json({ error: "Indirme baslatilamadi." }, { status: 500 });
    }
    if (result.aborted || jobController.signal.aborted) {
      console.info(`[download] iptal edildi: ${displayBase}`);
      return abortError();
    }
    if (result.timedOut) {
      return NextResponse.json({ error: "Indirme zaman asimina ugradi. Baglantiyi kontrol et ve tekrar dene." }, { status: 504 });
    }
    if (result.code !== 0) {
      const fullOutput = `${result.stdout}\n${result.stderr}`.trim();
      if (isRequestedAudioFormatUnavailable(audioFormat, fullOutput)) {
        return NextResponse.json(
          {
            code: "OPUS_UNAVAILABLE",
            error: "Bu parçada Opus ses akışı yok.",
          },
          { status: 422 },
        );
      }
      const combined = fullOutput.slice(-1200);
      const hint = combined.toLowerCase().includes("ffmpeg") ? " FFmpeg bulunamadi." : "";
      // Gerçek neden logun sonundadır (ERROR satırı); başı genelde zararsız
      // ilerleme çıktısıdır, o yüzden kuyruk gösterilir.
      return NextResponse.json({ error: `Indirme basarisiz oldu.${hint} ${combined.slice(-600)}`.trim() }, { status: 502 });
    }

    let audioPath = await findFirstAudio(workDir);
    if (!audioPath) {
      const combined = `${result.stdout}\n${result.stderr}`.trim().slice(0, 800);
      return NextResponse.json({ error: `Dosya bulunamadi. ${combined}`.trim() }, { status: 502 });
    }
    const coverAsset = cover ? await fetchCoverAsset(cover) : undefined;
    if (audioFormat === "aac" && coverAsset) {
      const temporaryCover = path.join(workDir, `cover${coverAsset.extension}`);
      try {
        await fs.promises.writeFile(temporaryCover, coverAsset.data);
        audioPath = await embedCoverInM4a(audioPath, temporaryCover);
      } catch {
        return NextResponse.json(
          { error: "AAC dosyasına kapak gömülemedi; ses dosyası kaydedilmedi." },
          { status: 502 },
        );
      }
    }

    try {
      const inspected = await inspectAudioFile(audioPath);
      if (!matchesAudioFormat(audioFormat, inspected.codec, inspected.ext)) {
        return NextResponse.json(
          { error: "İndirilen dosya seçilen ses formatıyla eşleşmedi." },
          { status: 502 },
        );
      }
    } catch {
      return NextResponse.json(
        { error: "İndirilen ses dosyası doğrulanamadı." },
        { status: 502 },
      );
    }

    // Her indirilen parca kalici olarak proje kokundeki Musics klasorune yazilir.
    let storedPath = audioPath;
    let storedName = path.basename(audioPath);
    let savedToMusics = false;
    try {
      await fs.promises.mkdir(MUSICS_DIR, { recursive: true });
      // Uzanti bulunan gercek dosyadan alinir, sabit yazilmaz.
      const foundExt = path.extname(audioPath) || ".m4a";
      storedName = await uniqueTargetName(MUSICS_DIR, `${displayBase}${foundExt}`);
      const target = path.join(MUSICS_DIR, storedName);
      try {
        await fs.promises.rename(audioPath, target);
      } catch {
        // Farkli surucu olabilir; kopyalayip gecici dosyayi birak.
        await fs.promises.copyFile(audioPath, target);
      }
      storedPath = target;
      savedToMusics = true;
    } catch (err) {
      console.error("Musics klasorune yazilamadi", err);
      return NextResponse.json(
        { error: "İndirilen dosya müzik klasörüne kaydedilemedi. Tekrar dene." },
        { status: 500 },
      );
    }

    const stat = await fs.promises.stat(storedPath);
    if (stat.size < 1024) {
      return NextResponse.json({ error: "Indirilen dosya cok kucuk, bozuk olabilir." }, { status: 502 });
    }
    if (stat.size > 80 * 1024 * 1024) {
      return NextResponse.json({ error: "Dosya cok buyuk." }, { status: 413 });
    }

    const data = await fs.promises.readFile(storedPath);

    // Parça bilgisi klasördeki bilgi dosyasına yazılır: bundan sonraki
    // liste okumaları başlık/sanatçı/albüm/kaynak ve kapağı buradan alır.
    // Klasöre yazılamadıysa (geçici dosya) kayıt tutulmaz, havada kalmasın.
    const libraryId = savedToMusics ? randomUUID() : undefined;
    if (savedToMusics) {
      const origin = source === "spotify" || source === "youtube" ? source : undefined;
      let coverFile: string | undefined;
      if (coverAsset) {
        try {
          const audioExt = path.extname(storedName);
          const stem = storedName.slice(0, storedName.length - audioExt.length);
          coverFile = await uniqueTargetName(MUSICS_DIR, `${stem}${coverAsset.extension}`);
          await fs.promises.writeFile(path.join(MUSICS_DIR, coverFile), coverAsset.data);
        } catch {
          coverFile = undefined;
        }
      }
      await saveTrackMetaEntry(storedName, {
        title: (decodedTitle || displayBase).slice(0, 80),
        artist: decodedArtist.slice(0, 80),
        album: decodedAlbum.slice(0, 80),
        ...(origin ? { origin } : {}),
        ...(coverFile ? { coverFile } : {}),
        ...(externalId ? { externalId } : {}),
        ...(libraryId ? { libraryId } : {}),
        updatedAt: Date.now(),
      });
    }

    const headers = new Headers();    headers.set("Content-Type", contentTypeForExt(path.extname(storedName)));
    headers.set("Content-Length", String(data.byteLength));
    // Dosya adi UTF-8 icerebilir (’, s, g); duz tasiyici Latin-1 disi
    // karakterde patlar, o yuzden RFC 5987 cift tasiyici kullanilir.
    headers.set("Content-Disposition", buildContentDisposition(storedName));
    headers.set("X-Saved-File", encodeURIComponent(storedName));
    if (libraryId) headers.set("X-Library-Id", libraryId);
    if (title) headers.set("X-Track-Title", encodeURIComponent(title));
    if (artist) headers.set("X-Track-Artist", encodeURIComponent(artist));
    if (album) headers.set("X-Track-Album", encodeURIComponent(album));
    if (cover) headers.set("X-Track-Cover", encodeURIComponent(cover));

    return new NextResponse(data, { status: 200, headers });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: `Bilinmeyen hata: ${msg.slice(0, 500)}` }, { status: 500 });
  } finally {
    releaseDownloadLock();
    request.signal.removeEventListener("abort", onRequestAbort);
    if (progressId) {
      progress.delete(progressId);
      downloadKills.delete(progressId);
    }
    void fs.promises.rm(workDir, { recursive: true, force: true }).catch(() => {
      // yok say
    });
  }
}
