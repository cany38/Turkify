import { NextRequest, NextResponse } from "next/server";

import { downloadKills, parseCancelBody } from "../../../../lib/download-jobs";

export const dynamic = "force-dynamic";

/**
 * Suregiden indirmeyi disaridan oldurur. Govde `{ progressId }` ya da
 * `{ progressIds }` alir; o anki parca durur, yarim dosya Musics'e
 * yazilmaz, inenler durur. Sekme kapanisinda beacon ile de cagrilir.
 */
export async function POST(request: NextRequest) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Gecersiz istek govdesi." }, { status: 400 });
  }
  const parsed = parseCancelBody(body);
  if (!parsed) {
    return NextResponse.json({ error: "Geçersiz istek gövdesi." }, { status: 400 });
  }
  let cancelled = 0;
  for (const progressId of parsed.progressIds) {
    const kill = downloadKills.get(progressId);
    if (kill) {
      try {
        kill();
        cancelled += 1;
      } catch {
        // yok say
      }
      downloadKills.delete(progressId);
    }
  }
  return NextResponse.json({ cancelled });
}
