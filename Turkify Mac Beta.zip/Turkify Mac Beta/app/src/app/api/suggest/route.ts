import { NextRequest, NextResponse } from "next/server";

const cache = new Map<string, { values: string[]; expires: number }>();

/**
 * Öneri servisi Türkçe karakterleri çoğunlukla windows-1254 baytlarıyla
 * gönderir; UTF-8 diye okunursa ı/ş/ğ harfleri � olur. Önce katı UTF-8
 * dene, olmazsa windows-1254 ile çöz.
 */
export function decodeSuggestBody(bytes: ArrayBuffer): string {
  const view = new Uint8Array(bytes);
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(view);
  } catch {
    return new TextDecoder("windows-1254").decode(view);
  }
}

export async function GET(request: NextRequest) {
  const q = request.nextUrl.searchParams.get("q")?.trim() ?? "";
  if (q.length < 2 || q.length > 200) return NextResponse.json({ suggestions: [] });
  const key = q.toLocaleLowerCase("tr-TR");
  const hit = cache.get(key);
  if (hit && hit.expires > Date.now()) return NextResponse.json({ suggestions: hit.values });
  try {
    const url = new URL("https://suggestqueries.google.com/complete/search");
    url.search = new URLSearchParams({ client: "firefox", ds: "yt", hl: "tr", gl: "TR", q }).toString();
    const response = await fetch(url, { signal: AbortSignal.timeout(2500) });
    if (!response.ok) throw new Error("Suggestion service unavailable");
    const data: unknown = JSON.parse(decodeSuggestBody(await response.arrayBuffer()));
    const suggestions = Array.isArray(data) && Array.isArray(data[1])
      ? [...new Set(data[1].filter((item): item is string => typeof item === "string" && item.length <= 200))].slice(0, 8) : [];
    if (cache.size >= 300) cache.delete(cache.keys().next().value!);
    cache.set(key, { values: suggestions, expires: Date.now() + 300_000 });
    return NextResponse.json({ suggestions });
  } catch {
    return NextResponse.json({ suggestions: [] });
  }
}
