import { NextRequest, NextResponse } from "next/server";

import { parseAudioFormat } from "../../../lib/audio-format";
import {
  createCodecMigrationService,
  InvalidMigrationStateError,
  MigrationConflictError,
  type CodecMigrationJob,
} from "../../../lib/codec-migration";
import {
  downloadTrackedAudio,
  embedCoverInM4a,
  inspectAudioFile,
} from "../../../lib/external-audio";
import { MUSICS_DIR } from "../../../lib/musics-dir";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

const service = createCodecMigrationService({
  musicsDir: MUSICS_DIR,
  download: downloadTrackedAudio,
  embedCover: embedCoverInM4a,
  inspect: inspectAudioFile,
});

const globalRuns = globalThis as typeof globalThis & {
  __turkifyCodecMigrationRuns?: Map<string, Promise<void>>;
};
const activeRuns =
  globalRuns.__turkifyCodecMigrationRuns ??
  (globalRuns.__turkifyCodecMigrationRuns = new Map<string, Promise<void>>());

function publicStatus(job: CodecMigrationJob | null) {
  if (!job) return null;
  return {
    id: job.id,
    format: job.format,
    state: job.state,
    total: job.total,
    completed: job.completed,
    succeeded: job.succeeded,
    skipped: job.skipped,
    failed: job.failed,
    percent: job.percent,
    currentTitle: job.currentTitle,
    manualCount: job.manualCount,
    failures: job.failures,
  };
}

function ensureRunning(id: string): void {
  if (activeRuns.has(id)) return;
  const running = service
    .run(id)
    .then(() => undefined)
    .catch((error) => {
      console.error("Format dönüştürme durdu", error);
    })
    .finally(() => {
      activeRuns.delete(id);
    });
  activeRuns.set(id, running);
}

export async function GET() {
  try {
    const job = await service.getStatus();
    if (job?.state === "running") ensureRunning(job.id);
    return NextResponse.json({ job: publicStatus(job) }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return NextResponse.json(
      { error: "Dönüştürme kaydı okunamadı; hiçbir dosyaya dokunulmadı." },
      { status: 500 },
    );
  }
}

export async function POST(request: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Geçersiz istek gövdesi." }, { status: 400 });
  }

  try {
    if (body.action === "start") {
      const parsed = parseAudioFormat(body.format);
      if (!parsed.ok) {
        return NextResponse.json({ error: "Geçersiz ses formatı." }, { status: 400 });
      }
      const job = await service.start(parsed.value);
      ensureRunning(job.id);
      return NextResponse.json({ job: publicStatus(job) }, { status: 202 });
    }
    if (body.action === "retry" && typeof body.id === "string") {
      const job = await service.retry(body.id);
      ensureRunning(job.id);
      return NextResponse.json({ job: publicStatus(job) }, { status: 202 });
    }
    if (body.action === "dismiss" && typeof body.id === "string") {
      await service.dismiss(body.id);
      return NextResponse.json({ job: null });
    }
    return NextResponse.json({ error: "Geçersiz dönüştürme işlemi." }, { status: 400 });
  } catch (error) {
    if (error instanceof MigrationConflictError) {
      return NextResponse.json({ error: error.message }, { status: 409 });
    }
    if (error instanceof InvalidMigrationStateError) {
      return NextResponse.json({ error: error.message }, { status: 409 });
    }
    return NextResponse.json({ error: "Dönüştürme başlatılamadı." }, { status: 500 });
  }
}
