import { NextResponse } from "next/server";
import { SERVER_PORT, buildServerStatus } from "../../../lib/server-status";

export const dynamic = "force-dynamic";

/** Sunucu yuklendigi an; dev server ayakta kaldikca sabit kalir. */
const STARTED_AT = Date.now();

/**
 * Ayarlar en alttaki Sunucu bolumu buradan okur: calisiyor mu,
 * hangi adreste, ne zamandir ayakta, hangi surum.
 */
export async function GET() {
  return NextResponse.json(
    { ...buildServerStatus({
      startedAt: STARTED_AT,
      now: Date.now(),
      version: process.env.npm_package_version ?? "0.1.0",
      port: SERVER_PORT,
    }), instance: process.env.TURKIFY_INSTANCE ?? null },
  );
}
