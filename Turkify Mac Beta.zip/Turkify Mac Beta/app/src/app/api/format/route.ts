import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import os from "os";
import path from "path";
import {
  getYtDlpSelector,
  matchesAudioFormat,
  parseAudioFormat,
} from "../../../lib/audio-format";
import { resolveYoutubeVideoId, runCommand } from "../../../lib/external-audio";
import type { AudioFormat } from "../../../lib/audio-format";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * Bir parcanin gercekte hangi ses kodegiyle geldigini soyler.
 *
 * Ne Spotify ne YouTube arama API'si kodek bilgisi vermiyor; tek yol kaynagi
 * yt-dlp ile yoklamak (~2-3 sn). Spotify satirlarinda calinabilir ses zaten
 * YouTube eslesmesinden geldigi icin oradaki format bildiriliyor - yani
 * gosterilen sey, dinlediginde gercekten alacagin sey.
 *
 * Yoklama "badge" amaciyla kaydedilir: kullanici bir parcaya bastigi anda
 * calma ucu bu sureclerin hepsini oldurur. Eskiden spotDL ile yapiliyordu
 * (cagri basina ~7 python sureci, 45 sn zaman asimi, iptal edilemez) ve
 * makineyi mesgul edip sesi bekletiyordu; artik calmanin kullandigi
 * `ytsearch1:` yolu kullaniliyor - hem tek surec hem ayni eslesme.
 */

const PROBE_TIMEOUT_MS = 20_000;
const CACHE_TTL_MS = 30 * 60 * 1000;

interface FormatInfo {
  codec: string;
  bitrate: number | null;
  ext: string;
  sampleRate: number | null;
}

const cache = new Map<string, { info: FormatInfo; expiresAt: number }>();

async function probe(
  target: string,
  format: AudioFormat,
  signal: AbortSignal,
): Promise<FormatInfo | null> {
  const args = [
    "-m",
    "yt_dlp",
    "--print",
    "%(acodec)s|%(abr)s|%(ext)s|%(asr)s",
    "-f",
    getYtDlpSelector(format),
    "--no-warnings",
  ];
  try {
    const denoPath = path.join(os.homedir(), ".spotdl", "deno");
    if (fs.existsSync(denoPath)) args.push("--js-runtimes", `deno:${denoPath}`);
  } catch {
    // yok say
  }
  args.push(target);

  const result = await runCommand(process.env.TURKIFY_PYTHON || "python3", args, PROBE_TIMEOUT_MS, signal, "badge");
  if (result.aborted || result.timedOut) return null;

  const line = result.stdout
    .split("\n")
    .map((l) => l.trim())
    .find((l) => l.includes("|"));
  if (!line) return null;
  const [codec, abr, ext, asr] = line.split("|");
  if (!codec || codec === "NA" || codec === "none") return null;
  const bitrate = abr && abr !== "NA" ? Math.round(parseFloat(abr)) : null;
  const sampleRate = asr && asr !== "NA" ? parseInt(asr, 10) : null;
  const normalizedExt = ext && ext !== "NA" ? ext : "";
  if (!matchesAudioFormat(format, codec, normalizedExt)) return null;
  return {
    codec,
    bitrate: Number.isFinite(bitrate as number) ? bitrate : null,
    ext: normalizedExt,
    sampleRate: Number.isFinite(sampleRate as number) ? sampleRate : null,
  };
}

/** Tam sorgu boş dönerse başlığa düşülerek bulunan videonun formatı. */
async function probeFallback(
  query: string,
  title: string,
  artist: string,
  format: AudioFormat,
  signal: AbortSignal,
): Promise<FormatInfo | null> {
  if (!query || !title || signal.aborted) return null;
  const videoId = await resolveYoutubeVideoId(title, artist, undefined, signal);
  if (!videoId || signal.aborted) return null;
  return probe(`https://www.youtube.com/watch?v=${videoId}`, format, signal);
}

export async function GET(request: NextRequest) {
  const videoId = request.nextUrl.searchParams.get("v")?.trim() ?? "";
  const query = request.nextUrl.searchParams.get("q")?.trim() ?? "";
  const title = request.nextUrl.searchParams.get("title")?.trim() ?? "";
  const artist = request.nextUrl.searchParams.get("artist")?.trim() ?? "";
  const parsedFormat = parseAudioFormat(request.nextUrl.searchParams.get("format"));
  if (!parsedFormat.ok) {
    return NextResponse.json({ error: "Geçersiz ses formatı." }, { status: 400 });
  }
  const format = parsedFormat.value;

  let cacheKey = "";
  let target = "";
  if (videoId) {
    if (!/^[A-Za-z0-9_-]{6,20}$/.test(videoId)) {
      return NextResponse.json({ error: "Geçersiz video kimliği." }, { status: 400 });
    }
    cacheKey = `${format}:v:${videoId}`;
    target = `https://www.youtube.com/watch?v=${videoId}`;
  } else if (query) {
    if (query.length < 2 || query.length > 200) {
      return NextResponse.json({ error: "Sorgu çok kısa veya çok uzun." }, { status: 400 });
    }
    cacheKey = `${format}:q:${query.toLowerCase()}`;
    target = `ytsearch1:${query}`;
  } else {
    return NextResponse.json({ error: "Kaynak belirtilmedi." }, { status: 400 });
  }

  const now = Date.now();
  const cached = cache.get(cacheKey);
  if (cached && now < cached.expiresAt) {
    return NextResponse.json(cached.info);
  }

  const signal = request.signal;
  if (signal.aborted) {
    return new NextResponse(null, { status: 499 });
  }
  const info =
    (await probe(target, format, signal)) ??
    (await probeFallback(query, title, artist, format, signal));
  if (signal.aborted) {
    // Kullanici baska bir parcaya gectiyse yanit da sonuc da onemsiz.
    return new NextResponse(null, { status: 499 });
  }
  if (!info) {
    return NextResponse.json({ error: "Format bilgisi alınamadı." }, { status: 502 });
  }
  cache.set(cacheKey, { info, expiresAt: now + CACHE_TTL_MS });
  return NextResponse.json(info);
}
