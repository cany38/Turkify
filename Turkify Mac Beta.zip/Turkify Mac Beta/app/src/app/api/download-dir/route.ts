import { NextRequest, NextResponse } from "next/server";
import {
  checkDownloadDir,
  normalizeDownloadDirInput,
  readDownloadDir,
  writeDownloadDir,
} from "../../../lib/download-dir";

export const dynamic = "force-dynamic";

/**
 * Remix indirmelerinin gidecegi klasoru okur/yazar.
 *
 * Secim sunucuda duruyor, tarayicida degil: dosyayi yazan sunucu ve
 * localStorage temizlense de secim kaybolmasin.
 */
export async function GET() {
  const info = await readDownloadDir();
  const problem = await checkDownloadDir(info.dir);
  return NextResponse.json({ ...info, problem });
}

export async function PUT(request: NextRequest) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek." }, { status: 400 });
  }

  const dir = normalizeDownloadDirInput(
    typeof body === "object" && body !== null ? (body as Record<string, unknown>).dir : null,
  );
  if (!dir) {
    return NextResponse.json(
      { error: "Tam bir klasör yolu gerekli (örn. /Users/you/Downloads)." },
      { status: 400 },
    );
  }

  const problem = await checkDownloadDir(dir);
  if (problem) return NextResponse.json({ error: problem }, { status: 400 });

  try {
    await writeDownloadDir(dir);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return NextResponse.json(
      { error: `Seçim kaydedilemedi: ${msg.slice(0, 200)}` },
      { status: 500 },
    );
  }
  return NextResponse.json({ dir, custom: true, problem: null });
}
