import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { MUSICS_DIR } from "../../../../lib/musics-dir";
import { readTrackMeta, removeTrackMetaEntry } from "../../../../lib/track-meta";

export const dynamic = "force-dynamic";

const ALLOWED_EXT = new Set([
  ".mp3",
  ".m4a",
  ".opus",
  ".ogg",
  ".oga",
  ".webm",
  ".wav",
  ".flac",
  ".aac",
]);

/**
 * `Musics` klasorunden tek dosya siler.
 *
 * Govde `{ fileName }`; yalnizca duz dosya adi kabul edilir, yol gecisi yok.
 */
export async function POST(request: NextRequest) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek gövdesi." }, { status: 400 });
  }

  const record = body as Record<string, unknown>;
  const rawName = typeof record.fileName === "string" ? record.fileName.trim() : "";
  if (!rawName) {
    return NextResponse.json({ error: "Dosya adı gerekli." }, { status: 400 });
  }

  // Yalnizca duz dosya adi: klasor gecisi ve mutlak yol kabul edilmez.
  const fileName = path.basename(rawName);
  if (fileName !== rawName || fileName.startsWith(".")) {
    return NextResponse.json({ error: "Geçersiz dosya adı." }, { status: 400 });
  }

  const ext = path.extname(fileName).toLowerCase();
  if (!ALLOWED_EXT.has(ext)) {
    return NextResponse.json({ error: "Desteklenmeyen dosya türü." }, { status: 400 });
  }

  const target = path.join(MUSICS_DIR, fileName);
  try {
    const stat = await fs.promises.stat(target);
    if (!stat.isFile()) throw new Error("not a file");
  } catch {
    return NextResponse.json({ error: "Dosya bulunamadı." }, { status: 404 });
  }

  try {
    await fs.promises.unlink(target);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: `Silinemedi: ${msg.slice(0, 200)}` }, { status: 500 });
  }

  // Ses dosyasıyla birlikte kapak resmi ve bilgi kaydı da kalkar; klasörde
  // yetim dosya ve ölü kayıt birikmez. İkisi de en iyi çabayla silinir.
  try {
    const meta = await readTrackMeta();
    const coverFile = meta[fileName]?.coverFile;
    if (coverFile) {
      await fs.promises.unlink(path.join(MUSICS_DIR, coverFile)).catch(() => undefined);
    }
  } catch {
    // yok say
  }
  await removeTrackMetaEntry(fileName);

  return NextResponse.json({ deleted: true });
}
