import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { Readable } from "stream";
import { MUSICS_DIR } from "../../../lib/musics-dir";

export const dynamic = "force-dynamic";

const CONTENT_TYPES: Record<string, string> = {
  ".mp3": "audio/mpeg",
  ".m4a": "audio/mp4",
  ".opus": "audio/opus",
  ".ogg": "audio/ogg",
  ".oga": "audio/ogg",
  ".webm": "audio/webm",
  ".wav": "audio/wav",
  ".flac": "audio/flac",
  ".aac": "audio/aac",
  // İndirilen parçaların kapak resimleri de bu klasörde durur, aynı uç sunar.
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
};

/**
 * `Musics` klasorundeki dosyalari servis eder.
 *
 * Klasor proje kokunde ve `public/` disinda oldugu icin Next kendiliginden
 * sunmuyor. Range destegi var: uzun parcalarda ileri sarma bunun sayesinde
 * calisiyor.
 */
export async function GET(request: NextRequest) {
  const requested = request.nextUrl.searchParams.get("f")?.trim() ?? "";
  if (!requested) {
    return NextResponse.json({ error: "Dosya adı gerekli." }, { status: 400 });
  }

  // Yalnizca duz dosya adi: klasor gecisi ve mutlak yol kabul edilmez.
  const fileName = path.basename(requested);
  if (fileName !== requested || fileName.startsWith(".")) {
    return NextResponse.json({ error: "Geçersiz dosya adı." }, { status: 400 });
  }

  const ext = path.extname(fileName).toLowerCase();
  const contentType = CONTENT_TYPES[ext];
  if (!contentType) {
    return NextResponse.json({ error: "Desteklenmeyen dosya türü." }, { status: 400 });
  }

  const filePath = path.join(MUSICS_DIR, fileName);
  let stat: fs.Stats;
  try {
    stat = await fs.promises.stat(filePath);
    if (!stat.isFile()) throw new Error("not a file");
  } catch {
    return NextResponse.json({ error: "Dosya bulunamadı." }, { status: 404 });
  }

  const size = stat.size;
  const range = request.headers.get("range");

  const headers = new Headers();
  headers.set("Content-Type", contentType);
  headers.set("Accept-Ranges", "bytes");
  headers.set(
    "Cache-Control",
    contentType.startsWith("image/")
      ? "public, max-age=31536000, immutable"
      : "no-store",
  );

  if (range) {
    const match = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (match) {
      const startRaw = match[1];
      const endRaw = match[2];
      let start = startRaw ? parseInt(startRaw, 10) : 0;
      let end = endRaw ? parseInt(endRaw, 10) : size - 1;
      if (!startRaw && endRaw) {
        // "bytes=-500" son 500 bayt demek.
        start = Math.max(0, size - parseInt(endRaw, 10));
        end = size - 1;
      }
      if (Number.isNaN(start) || Number.isNaN(end) || start > end || start >= size) {
        headers.set("Content-Range", `bytes */${size}`);
        return new NextResponse(null, { status: 416, headers });
      }
      end = Math.min(end, size - 1);
      headers.set("Content-Range", `bytes ${start}-${end}/${size}`);
      headers.set("Content-Length", String(end - start + 1));
      const stream = Readable.toWeb(
        fs.createReadStream(filePath, { start, end }),
      ) as unknown as ReadableStream<Uint8Array>;
      return new NextResponse(stream, { status: 206, headers });
    }
  }

  headers.set("Content-Length", String(size));
  const stream = Readable.toWeb(
    fs.createReadStream(filePath),
  ) as unknown as ReadableStream<Uint8Array>;
  return new NextResponse(stream, { status: 200, headers });
}
