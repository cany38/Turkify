import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { MUSICS_DIR, sanitizeMusicFileName, uniqueTargetName } from "../../../../lib/musics-dir";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

const MAX_BYTES = 100 * 1024 * 1024;
const ALLOWED_EXT = new Set([".mp3", ".m4a", ".opus", ".ogg", ".oga", ".webm", ".wav", ".flac", ".aac"]);

/**
 * Tarayicida duran bir parcayi `Musics` klasorune yazar.
 *
 * Klasor kurali gelmeden once indirilen parcalar yalnizca IndexedDB'de kaldi;
 * bu uc onlari diske cikarmak icin. Ayni ad ve ayni boyutta dosya zaten varsa
 * yeniden yazmaz, "atlandi" der.
 */
export async function POST(request: NextRequest) {
  const rawName = request.nextUrl.searchParams.get("name")?.trim() ?? "";
  if (!rawName) {
    return NextResponse.json({ error: "Dosya adı gerekli." }, { status: 400 });
  }

  const ext = path.extname(rawName).toLowerCase();
  if (!ALLOWED_EXT.has(ext)) {
    return NextResponse.json({ error: "Desteklenmeyen dosya türü." }, { status: 400 });
  }

  const stem = sanitizeMusicFileName(rawName.slice(0, rawName.length - ext.length));
  const desired = `${stem}${ext}`;

  let bytes: Buffer;
  try {
    const buf = await request.arrayBuffer();
    bytes = Buffer.from(buf);
  } catch {
    return NextResponse.json({ error: "Dosya içeriği okunamadı." }, { status: 400 });
  }

  if (bytes.byteLength < 1024) {
    return NextResponse.json({ error: "Dosya çok küçük." }, { status: 400 });
  }
  if (bytes.byteLength > MAX_BYTES) {
    return NextResponse.json({ error: "Dosya çok büyük." }, { status: 413 });
  }

  try {
    await fs.promises.mkdir(MUSICS_DIR, { recursive: true });

    // Ayni ad + ayni boyut varsa bu parca zaten diskte; kopyasini olusturma.
    try {
      const existing = await fs.promises.stat(path.join(MUSICS_DIR, desired));
      if (existing.isFile() && existing.size === bytes.byteLength) {
        return NextResponse.json({ saved: false, skipped: true, name: desired });
      }
    } catch {
      // yok, yazmaya devam
    }

    const name = await uniqueTargetName(MUSICS_DIR, desired);
    await fs.promises.writeFile(path.join(MUSICS_DIR, name), bytes);
    return NextResponse.json({ saved: true, skipped: false, name });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: `Klasöre yazılamadı: ${msg.slice(0, 200)}` }, { status: 500 });
  }
}
