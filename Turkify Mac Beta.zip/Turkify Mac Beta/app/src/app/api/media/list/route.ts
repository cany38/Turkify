import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { MUSICS_DIR } from "../../../../lib/musics-dir";
import { ensureTrackLibraryIds, pruneOrphanedTrackData } from "../../../../lib/track-meta";
import { readCodecMigrationLegacyNames } from "../../../../lib/codec-migration";
import { inspectAudioFile } from "../../../../lib/external-audio";
import { randomUUID } from "node:crypto";

export const dynamic = "force-dynamic";

const ALLOWED_EXT = new Set([
  ".mp3",
  ".m4a",
  ".opus",
  ".ogg",
  ".oga",
  ".webm",
  ".wav",
  ".flac",
  ".aac",
]);

/**
 * `Musics` klasorunun kokundeki ses dosyalarini listeler.
 *
 * Tek kaynak klasor; elle atilan dosyalar da burada gorunur. Alt klasorlere
 * inilmez, sonuc `modifiedAt` azalan siralanir (yeni eklenen ustte).
 *
 * Bilgi dosyasinda kaydi olan parca baslik/sanatci/album/kaynak ve kapak
 * dosya adiyla gelir; kaydi olmayan dosya dosya adindan turetilir.
 */
export async function GET() {
  let entries: fs.Dirent[];
  try {
    entries = await fs.promises.readdir(MUSICS_DIR, { withFileTypes: true });
  } catch (err) {
    const code = (err as NodeJS.ErrnoException | null)?.code;
    // Klasor yoksa bos dizi don, hata degil.
    if (code === "ENOENT") return NextResponse.json([]);
    return NextResponse.json({ error: "Liste okunamadı." }, { status: 500 });
  }

  const [meta, migrationLegacyNames] = await Promise.all([
    ensureTrackLibraryIds(),
    readCodecMigrationLegacyNames(MUSICS_DIR),
  ]);
  // Elle silinen parcalarin ölü kayit ve yetim kapaklari birikmesin; her
  // liste okumada sessizce budanir. Ses dosyalarina dokunulmaz.
  void pruneOrphanedTrackData().catch(() => undefined);

  const items: {
    duration: number;
    fileName: string;
    title: string;
    artist: string;
    album: string;
    origin?: "spotify" | "youtube";
    coverFile?: string;
    externalId?: string;
    libraryId?: string;
    previousFileNames?: string[];
    size: number;
    modifiedAt: number;
  }[] = [];
  const cachePath = path.join(MUSICS_DIR, ".turkify-durations.json");
  let cached: Record<string, { size: number; modifiedAt: number; duration: number }> = {};
  try {
    const parsed = JSON.parse(await fs.promises.readFile(cachePath, "utf8"));
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) cached = parsed;
  } catch {
    // Missing or damaged cache is rebuilt from audio, never from guessed metadata.
  }
  const durations: typeof cached = {};
  for (const entry of entries) {
    if (!entry.isFile()) continue;
    const fileName = entry.name;
    if (fileName.startsWith(".")) continue;
    const ext = path.extname(fileName).toLowerCase();
    if (!ALLOWED_EXT.has(ext)) continue;
    try {
      const stat = await fs.promises.stat(path.join(MUSICS_DIR, fileName));
      if (!stat.isFile()) continue;
      const known = cached[fileName];
      let duration = known?.size === stat.size && known.modifiedAt === stat.mtimeMs && Number.isFinite(known.duration) && known.duration > 0
        ? known.duration : 0;
      if (!duration) {
        try {
          duration = (await inspectAudioFile(path.join(MUSICS_DIR, fileName))).duration ?? 0;
        } catch {
          // A failed probe must not remove an otherwise playable song from the list.
        }
      }
      if (duration > 0) durations[fileName] = { size: stat.size, modifiedAt: stat.mtimeMs, duration };
      const rawExt = path.extname(fileName);
      const stem = fileName.slice(0, fileName.length - rawExt.length);
      const entryMeta = meta[fileName];
      // Kapak dosyasi adina güvenmeden once gercekten duruyor mu bakılır;
      // elle silinmişse yedek kapak gösterilir, kırık resim değil.
      let coverFile: string | undefined;
      const candidate = entryMeta?.coverFile;
      if (candidate) {
        try {
          const coverStat = await fs.promises.stat(path.join(MUSICS_DIR, candidate));
          if (coverStat.isFile()) coverFile = candidate;
        } catch {
          // yok, yedek kapak devreye girer
        }
      }
      // Kayıt yoksa ama sesle aynı adlı resim duruyorsa (indiricinin bıraktığı
      // kapak gibi) onu kullan; daha önce inen parçalar da kapağına kavuşur.
      if (!coverFile) {
        for (const imageExt of [".jpg", ".jpeg", ".png", ".webp"]) {
          try {
            const siblingStat = await fs.promises.stat(path.join(MUSICS_DIR, `${stem}${imageExt}`));
            if (siblingStat.isFile()) {
              coverFile = `${stem}${imageExt}`;
              break;
            }
          } catch {
            // bu uzantı yok, sonrakine bak
          }
        }
      }
      items.push({
        duration,
        fileName,
        title: entryMeta?.title || stem,
        artist: entryMeta?.artist ?? "",
        album: entryMeta?.album ?? "",
        ...(entryMeta?.origin ? { origin: entryMeta.origin } : {}),
        ...(coverFile ? { coverFile } : {}),
        ...(entryMeta?.externalId ? { externalId: entryMeta.externalId } : {}),
        ...(entryMeta?.libraryId ? { libraryId: entryMeta.libraryId } : {}),
        ...(entryMeta?.libraryId
          ? {
              previousFileNames: Array.from(
                new Set([
                  ...(entryMeta.previousFileNames ?? []),
                  ...(migrationLegacyNames[entryMeta.libraryId] ?? []),
                ]),
              ),
            }
          : {}),
        size: stat.size,
        modifiedAt: stat.mtimeMs,
      });
    } catch {
      // Tek dosya okunamazsa atla, listeyi bozma.
      continue;
    }
  }

  items.sort((a, b) => b.modifiedAt - a.modifiedAt);
  if (JSON.stringify(durations) !== JSON.stringify(cached)) {
    const temporary = `${cachePath}.${randomUUID()}.tmp`;
    try {
      await fs.promises.writeFile(temporary, JSON.stringify(durations));
      await fs.promises.rename(temporary, cachePath);
    } catch {
      // Cache persistence is optional; durations are still returned to the client.
    } finally {
      await fs.promises.unlink(temporary).catch(() => undefined);
    }
  }
  return NextResponse.json(items);
}
