import { NextRequest, NextResponse } from "next/server";
import type { ImportedPlaylistTrack } from "../../../../lib/types";
import {
  fetchSpotifyPlaylist,
  mapFetchedTracks,
} from "../../../../lib/spotify-playlist-source";
import { fetchTrackDetails } from "../../../../lib/spotify-track-details";

export const dynamic = "force-dynamic";

export function extractPlaylistId(value: string): string | null {
  const match = value.trim().match(/(?:playlist[/:])([A-Za-z0-9]+)(?:[?&#]|$)/);
  return match?.[1] ?? null;
}

interface SpotifyApiPlaylistTrack {
  id: string;
  name: string;
  type?: string;
  artists?: { name: string }[];
  album?: { name: string; images?: { url: string }[] };
  duration_ms?: number;
  external_urls?: { spotify?: string };
}

export function mapPlaylistTrack(track: SpotifyApiPlaylistTrack): ImportedPlaylistTrack {
  return {
    id: `spotify-${track.id}`,
    source: "spotify",
    spotifyId: track.id,
    spotifyUrl: track.external_urls?.spotify ?? `https://open.spotify.com/track/${track.id}`,
    title: track.name,
    artist: track.artists?.map((artist) => artist.name).join(", ") || "Bilinmeyen sanatçı",
    album: track.album?.name ?? "Spotify",
    duration: Math.round((track.duration_ms ?? 0) / 1000),
    cover: track.album?.images?.[0]?.url ?? "/covers/demo-01.svg",
  };
}

export async function POST(request: NextRequest) {
  const body = (await request.json().catch(() => null)) as { url?: string } | null;
  const id = body?.url ? extractPlaylistId(body.url) : null;
  if (!id) {
    return NextResponse.json(
      { error: "Geçerli bir Spotify playlist bağlantısı yapıştır." },
      { status: 400 },
    );
  }
  // Arama ucuyla ayni basliklar; yoksa .env degerlerine dusulur.
  const headerClientId = request.headers.get("x-spotify-client-id")?.trim() ?? "";
  const headerClientSecret = request.headers.get("x-spotify-client-secret")?.trim() ?? "";
  const spotifyClientId = headerClientId || process.env.SPOTIFY_CLIENT_ID || "";
  const spotifyClientSecret = headerClientSecret || process.env.SPOTIFY_CLIENT_SECRET || "";
  try {
    // Liste spotDL'in kendi kimlikleriyle okunur; kullanici anahtari gerekmez
    // ve istemci sayfalamayi kendi icinde yapar.
    const fetched = await fetchSpotifyPlaylist(id);
    const tracks = mapFetchedTracks(fetched.tracks, fetched.cover);
    // Kapak ve album adi kullanicinin anahtarlariyla zenginlestirilir;
    // anahtar yoksa ya da uc reddederse mevcut yedek aynen kalir.
    let enriched = tracks;
    try {
      const detailIds = fetched.tracks.map((track) => track.id).filter((trackId) => trackId.length > 0);
      const details = await fetchTrackDetails(detailIds, spotifyClientId, spotifyClientSecret);
      if (details.size > 0) {
        enriched = tracks.map((track) => {
          const detail = track.spotifyId ? details.get(track.spotifyId) : undefined;
          return detail ? { ...track, album: detail.album, cover: detail.cover } : track;
        });
      }
    } catch (error) {
      console.error(
        `Spotify kapak zenginlestirme atlandi: ${error instanceof Error ? error.message : "bilinmeyen hata"}`,
      );
    }
    const skipped = fetched.tracks.length - enriched.length;
    return NextResponse.json({
      id,
      name: fetched.name || "Spotify playlist",
      cover: fetched.cover || undefined,
      tracks: enriched,
      skipped,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Spotify playlist okunamadı.";
    // spotDL "not found" derse sebep gizli/yanlis kimliktir; govde sabit kalir.
    if (/bulunamad[ıi]|not found|404|gizli/i.test(message)) {
      return NextResponse.json(
        { error: "Liste bulunamadı ya da gizli. Public olduğundan emin ol." },
        { status: 404 },
      );
    }
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
