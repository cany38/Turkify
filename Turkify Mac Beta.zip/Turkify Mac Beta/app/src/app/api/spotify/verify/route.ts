import { NextRequest } from "next/server";
import type { VerifyEvent } from "../../../../lib/spotify-verify";

export const dynamic = "force-dynamic";

const TOKEN_URL = "https://accounts.spotify.com/api/token";
const SEARCH_URL = "https://api.spotify.com/v1/search";

/** Spotify'in ham hata govdesi kullaniciya yardimci degil; okunur hale getir. */
function describeTokenError(status: number, body: string): string {
  if (status === 400 || status === 401) {
    return "Spotify bu Client ID / Secret ikilisini kabul etmedi. Değerleri Settings sayfasından yeniden kopyalayın.";
  }
  if (status === 429) {
    return "Spotify çok fazla istek aldı (429). Biraz bekleyip tekrar deneyin.";
  }
  return `Spotify token hatası (${status}). ${body.slice(0, 200)}`.trim();
}

export async function POST(request: NextRequest) {
  let clientId = "";
  let clientSecret = "";
  try {
    const body = (await request.json()) as { clientId?: unknown; clientSecret?: unknown };
    if (typeof body.clientId === "string") clientId = body.clientId.trim();
    if (typeof body.clientSecret === "string") clientSecret = body.clientSecret.trim();
  } catch {
    // Bozuk govde asagidaki bos kontrolde yakalanir.
  }

  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const send = (event: VerifyEvent) => {
        controller.enqueue(encoder.encode(JSON.stringify(event) + "\n"));
      };

      if (!clientId || !clientSecret) {
        send({ step: "token", status: "fail", message: "Client ID ve Client Secret boş olamaz." });
        controller.close();
        return;
      }

      // 1) Token: anahtarlarin gercekten Spotify tarafindan taninip taninmadigi.
      send({ step: "token", status: "running" });
      let token = "";
      let tokenError = "";
      try {
        const basic = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
        const res = await fetch(TOKEN_URL, {
          method: "POST",
          headers: {
            Authorization: `Basic ${basic}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: "grant_type=client_credentials",
          cache: "no-store",
        });
        if (res.ok) {
          const data = (await res.json()) as { access_token?: string };
          token = typeof data.access_token === "string" ? data.access_token : "";
          if (!token) tokenError = "Spotify yanıtında access_token yok.";
        } else {
          const text = await res.text().catch(() => "");
          tokenError = describeTokenError(res.status, text);
        }
      } catch (err) {
        tokenError = err instanceof Error ? err.message : "Spotify'a bağlanılamadı.";
      }

      if (!token) {
        send({ step: "token", status: "fail", message: tokenError });
        controller.close();
        return;
      }
      send({ step: "token", status: "ok" });

      // 2) Arama: token'in arama ucunda da gecerli oldugunu uctan uca dogrula.
      send({ step: "search", status: "running" });
      try {
        const url = new URL(SEARCH_URL);
        url.searchParams.set("q", "test");
        url.searchParams.set("type", "track");
        url.searchParams.set("limit", "1");
        const res = await fetch(url.toString(), {
          headers: { Authorization: `Bearer ${token}` },
          cache: "no-store",
        });
        if (res.ok) {
          send({ step: "search", status: "ok" });
        } else {
          const text = await res.text().catch(() => "");
          send({
            step: "search",
            status: "fail",
            message: `Arama isteği reddedildi (${res.status}). ${text.slice(0, 200)}`.trim(),
          });
        }
      } catch (err) {
        send({
          step: "search",
          status: "fail",
          message: err instanceof Error ? err.message : "Arama denemesi başarısız.",
        });
      }

      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "application/x-ndjson; charset=utf-8",
      "Cache-Control": "no-store",
      // Akisin ara katmanlarda tamponlanmamasi icin.
      "X-Accel-Buffering": "no",
    },
  });
}
