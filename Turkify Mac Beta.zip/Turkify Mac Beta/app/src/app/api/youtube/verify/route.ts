import { NextRequest } from "next/server";
import type { YtVerifyEvent } from "../../../../lib/youtube-verify";

export const dynamic = "force-dynamic";

const VIDEOS_URL = "https://www.googleapis.com/youtube/v3/videos";

/** Kota ucuz olsun diye sabit, her zaman var olan bir video kimligi. */
const PROBE_VIDEO_ID = "dQw4w9WgXcQ";

interface GoogleApiError {
  error?: {
    message?: string;
    errors?: { reason?: string }[];
  };
}

/** Google'in ham hatasi kullaniciya yardimci degil; ne yapmasi gerektigini soyle. */
function describeKeyError(status: number, body: string): string {
  let reason = "";
  let apiMessage = "";
  try {
    const parsed = JSON.parse(body) as GoogleApiError;
    reason = parsed.error?.errors?.[0]?.reason ?? "";
    apiMessage = parsed.error?.message ?? "";
  } catch {
    // Govde JSON degilse asagidaki genel mesaja duseriz.
  }

  if (reason === "accessNotConfigured" || apiMessage.includes("has not been used in project")) {
    return "Anahtar geçerli ama bu projede YouTube Data API v3 açık değil. Google Cloud → APIs & Services → Library → YouTube Data API v3 → Enable adımını yapın.";
  }
  if (reason === "quotaExceeded" || reason === "dailyLimitExceeded") {
    return "Bu anahtarın günlük kotası dolmuş. Kota Pasifik saatiyle gece yarısı sıfırlanır.";
  }
  if (reason === "ipRefererBlocked" || reason === "forbidden") {
    return "Anahtara kısıtlama konmuş ve bu sunucudan çağrıyı kabul etmiyor. Google Cloud'da anahtarın Application restrictions ayarını None yapın.";
  }
  if (reason === "keyInvalid" || status === 400) {
    return "Anahtar geçersiz. Google Cloud → Credentials sayfasından yeniden kopyalayın.";
  }
  return `YouTube anahtarı reddedildi (${status}). ${apiMessage.slice(0, 200)}`.trim();
}

export async function POST(request: NextRequest) {
  let apiKey = "";
  try {
    const body = (await request.json()) as { apiKey?: unknown };
    if (typeof body.apiKey === "string") apiKey = body.apiKey.trim();
  } catch {
    // Bozuk govde asagidaki bos kontrolde yakalanir.
  }

  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const send = (event: YtVerifyEvent) => {
        controller.enqueue(encoder.encode(JSON.stringify(event) + "\n"));
      };

      if (!apiKey) {
        send({ step: "key", status: "fail", message: "API anahtarı boş olamaz." });
        controller.close();
        return;
      }

      // Tek sunucu adimi: 1 birimlik videos.list. Gecerse anahtar + API + kota tamam.
      send({ step: "key", status: "running" });
      try {
        const url = new URL(VIDEOS_URL);
        url.searchParams.set("part", "id");
        url.searchParams.set("id", PROBE_VIDEO_ID);
        url.searchParams.set("key", apiKey);
        const res = await fetch(url.toString(), { cache: "no-store" });
        if (res.ok) {
          send({ step: "key", status: "ok" });
        } else {
          const text = await res.text().catch(() => "");
          send({ step: "key", status: "fail", message: describeKeyError(res.status, text) });
        }
      } catch (err) {
        send({
          step: "key",
          status: "fail",
          message: err instanceof Error ? err.message : "YouTube'a bağlanılamadı.",
        });
      }

      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "application/x-ndjson; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Accel-Buffering": "no",
    },
  });
}
