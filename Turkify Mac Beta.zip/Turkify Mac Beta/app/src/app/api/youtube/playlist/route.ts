import { NextRequest, NextResponse } from "next/server";
import {
  extractYoutubePlaylistId,
  fetchYoutubePlaylist,
  mapFetchedYoutubeTracks,
} from "../../../../lib/youtube-playlist-source";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  const body = (await request.json().catch(() => null)) as { url?: string } | null;
  const id = body?.url ? extractYoutubePlaylistId(body.url) : null;
  if (!id) {
    return NextResponse.json(
      { error: "Geçerli bir YouTube playlist bağlantısı yapıştır." },
      { status: 400 },
    );
  }
  try {
    // Liste yt-dlp ile okunur; kullanici anahtari gerekmez ve betik
    // sayfalamayi kendi icinde yapar.
    const fetched = await fetchYoutubePlaylist(id);
    const tracks = mapFetchedYoutubeTracks(fetched.tracks, fetched.cover);
    const skipped = fetched.tracks.length - tracks.length;
    return NextResponse.json({
      id,
      name: fetched.name || "YouTube playlist",
      cover: fetched.cover || undefined,
      tracks,
      skipped,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "YouTube playlist okunamadı.";
    // yt-dlp "not found" derse sebep gizli/yanlis kimliktir; govde sabit kalir.
    if (/bulunamad[ıi]|not found|404|gizli|private|unavailable/i.test(message)) {
      return NextResponse.json(
        { error: "Liste bulunamadı ya da gizli. Herkese açık olduğundan emin ol." },
        { status: 404 },
      );
    }
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
