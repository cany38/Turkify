import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { Readable } from "stream";
import { pipeline } from "stream/promises";
import { checkDownloadDir, readDownloadDir } from "../../../../lib/download-dir";
import { sanitizeMusicFileName, uniqueTargetName } from "../../../../lib/musics-dir";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

/** Bir remix WAV'i: 16-bit stereo 48 kHz'de dakikasi ~11 MB. Yarim saatlik
 *  bir parca bile bu sinirin altinda kalir. */
const MAX_BYTES = 600 * 1024 * 1024;

/**
 * Remix cikisini kullanicinin sectigi klasore yazar.
 *
 * `Musics` klasorune yazmaz: bu dosya uygulamanin arsivine degil,
 * kullanicinin kendi diskine ait. Icerik akis halinde diske gecer, boylece
 * yuz megabaytlik bir WAV bellekte tutulmaz.
 */
export async function POST(request: NextRequest) {
  const rawName = request.nextUrl.searchParams.get("name")?.trim() ?? "";
  if (!rawName) {
    return NextResponse.json({ error: "Dosya adı gerekli." }, { status: 400 });
  }
  if (path.extname(rawName).toLowerCase() !== ".wav") {
    return NextResponse.json({ error: "Yalnızca .wav yazılabilir." }, { status: 400 });
  }

  const stem = sanitizeMusicFileName(rawName.slice(0, rawName.length - 4));
  const desired = `${stem}.wav`;

  const { dir } = await readDownloadDir();
  const problem = await checkDownloadDir(dir);
  if (problem) {
    return NextResponse.json({ error: `${problem} (${dir})` }, { status: 400 });
  }

  const body = request.body;
  if (!body) {
    return NextResponse.json({ error: "Dosya içeriği okunamadı." }, { status: 400 });
  }

  const name = await uniqueTargetName(dir, desired);
  const target = path.join(dir, name);
  let written = 0;

  try {
    const source = Readable.fromWeb(body as Parameters<typeof Readable.fromWeb>[0]);
    source.on("data", (chunk: Buffer) => {
      written += chunk.byteLength;
      if (written > MAX_BYTES) source.destroy(new Error("Dosya çok büyük."));
    });
    await pipeline(source, fs.createWriteStream(target));
  } catch (err) {
    // Yarim kalan dosya diskte kalmasin; kullanici bozuk bir WAV bulmasin.
    await fs.promises.rm(target, { force: true }).catch(() => undefined);
    const msg = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: `Yazılamadı: ${msg.slice(0, 200)}` }, { status: 500 });
  }

  if (written < 1024) {
    await fs.promises.rm(target, { force: true }).catch(() => undefined);
    return NextResponse.json({ error: "Dosya çok küçük." }, { status: 400 });
  }

  return NextResponse.json({ saved: true, name, dir, bytes: written });
}
