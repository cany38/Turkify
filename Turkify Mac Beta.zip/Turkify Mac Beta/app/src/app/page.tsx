import { TurkifyApp } from "../components/turkify-app";

export default function Home() {
  return <TurkifyApp />;
}
