import type { Track } from "../lib/types";
import { localeTag, type Locale } from "../lib/i18n";

// No source-machine catalog or library metadata is distributed.
export const LIBRARY_TRACKS: Track[] = [];

export function toTurkishLower(value: string): string {
  return value.toLocaleLowerCase("tr-TR");
}

export function toLocaleLower(value: string, locale: Locale): string {
  return value.toLocaleLowerCase(localeTag(locale));
}

export function formatDuration(totalSeconds: number): string {
  if (!Number.isFinite(totalSeconds) || totalSeconds <= 0) return "--:--";
  const seconds = Math.floor(totalSeconds);
  return `${Math.floor(seconds / 60)}:${(seconds % 60).toString().padStart(2, "0")}`;
}

export function formatTotalDuration(totalSeconds: number, locale: Locale): string | null {
  if (!Number.isFinite(totalSeconds) || totalSeconds < 60) return null;
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  if (locale === "tr" || locale === "az") {
    const unit = locale === "az" ? "d\u0259qiq\u0259" : "dakika";
    return hours ? `${hours} saat${minutes ? ` ${minutes} ${unit}` : ""}` : `${minutes} ${unit}`;
  }
  return [hours ? `${hours} hour${hours === 1 ? "" : "s"}` : "", minutes ? `${minutes} minute${minutes === 1 ? "" : "s"}` : ""].filter(Boolean).join(" ");
}

export function textIncludes(haystack: string, needle: string): boolean {
  const fold = (value: string) => value.toLocaleLowerCase("en-US").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\u0131/g, "i").replace(/\u015f/g, "s").replace(/\u011f/g, "g");
  return fold(haystack).includes(fold(needle.trim()));
}
