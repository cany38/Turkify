import { NextRequest, NextResponse } from "next/server";

export function proxy(request: NextRequest) {
  const host = request.headers.get("host") ?? "";
  if (!/^(127\.0\.0\.1|localhost):\d+$/.test(host)) {
    return new NextResponse("Local access only", { status: 403 });
  }
  const origin = request.headers.get("origin");
  const unsafe = !["GET", "HEAD", "OPTIONS"].includes(request.method);
  if ((origin && origin !== `http://${host}`) || (unsafe && !origin)) {
    return new NextResponse("Same-origin request required", { status: 403 });
  }
  return NextResponse.next();
}

export const config = { matcher: "/api/:path*" };
