"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type {
  CreatePlaylistResult,
  ExternalTrack,
  LibraryState,
  Playlist,
  PlaylistMutationResult,
} from "../lib/types";
import { loadLibrary, migrateLocalIdsToDisk, saveLibrary } from "../lib/storage";
import { toTurkishLower } from "../data/tracks";
import { useI18n } from "../components/locale-provider";
import { remapLibraryState } from "../lib/library-identity";

const initialState: LibraryState = { likedIds: [], playlists: [], removedTrackIds: [], externalTracks: [] };

/** Kapak data URL'i icin ust sinir: 50 MB (sunucu dosyasi tasir). */
const MAX_COVER_DATA_URL_LENGTH = 50 * 1024 * 1024;

function normalizeName(name: string): string {
  return toTurkishLower(name.trim());
}

/** Sunucuya ilk goc etmeye degecek kayit var mi. */
function hasLibraryContent(state: LibraryState): boolean {
  return (
    state.likedIds.length > 0 ||
    state.playlists.length > 0 ||
    state.removedTrackIds.length > 0 ||
    (state.externalTracks ?? []).length > 0
  );
}

export function useLibrary() {
  const { t } = useI18n();
  const [likedIds, setLikedIds] = useState<string[]>(initialState.likedIds);
  const [playlists, setPlaylists] = useState<Playlist[]>(initialState.playlists);
  const [removedTrackIds, setRemovedTrackIds] = useState<string[]>(
    initialState.removedTrackIds,
  );
  const [externalTracks, setExternalTracks] = useState<ExternalTrack[]>(
    initialState.externalTracks,
  );
  const [hydrated, setHydrated] = useState(false);
  const serverSaveChainRef = useRef(Promise.resolve());
  // Sunucuda/goc yolunda dolu kayit gorulduyse true; bos snapshot'in doluyu ezmesini onler.
  // Yalnizca async callback'lerde yazilir, effect govdesinde okunur.
  const serverHasContentRef = useRef(false);
  const likedIdsRef = useRef(likedIds);
  const playlistsRef = useRef(playlists);
  const removedTrackIdsRef = useRef(removedTrackIds);
  const externalTracksRef = useRef(externalTracks);

  useEffect(() => {
    likedIdsRef.current = likedIds;
    playlistsRef.current = playlists;
    removedTrackIdsRef.current = removedTrackIds;
    externalTracksRef.current = externalTracks;
  }, [likedIds, playlists, removedTrackIds, externalTracks]);

  // Client'ta bir kez oku; okuma commitlenmeden yazma. Iptal edilebilir
  // async init, StrictMode replay'de bos state'in kaydi ezmesini onler.
  // Kaynak sunucudaki dosyadir: varsa uygulanir; yoksa yereldeki kayit ilk
  // acilista yukari tasinir. Sunucuya ulasilamazsa yerel kayitla devam edilir.
  useEffect(() => {
    let cancelled = false;
    void migrateLocalIdsToDisk()
      .then(() => loadLibrary())
      .then(async (stored) => {
        if (cancelled) return;
        // Kaynak sunucudaki dosyadir; ama "dosya var" yetmez, ici de dolu olmali.
        // Bos dosya + dolu yerel kayit = ilk goc: yerel yukari tasinir, yerel kullanilir.
        let server: LibraryState | null = null;
        try {
          const res = await fetch("/api/library", { cache: "no-store" });
          if (!cancelled && res.ok) {
            server = ((await res.json()) as { state?: LibraryState | null }).state ?? null;
          }
        } catch {
          // Sunucuya ulasilamazsa yerel kayitla devam; muzik calmaya engel degil.
        }
        if (cancelled) return;
        const serverHas = server !== null && hasLibraryContent(server);
        const localHas = stored !== null && hasLibraryContent(stored);
        if (serverHas && server) {
          serverHasContentRef.current = true;
          setLikedIds(server.likedIds);
          setPlaylists(server.playlists);
          setRemovedTrackIds(server.removedTrackIds);
          setExternalTracks(server.externalTracks ?? []);
          saveLibrary(server);
        } else {
          if (localHas) {
            // Goc basliyor: dolu icerik yolda, bos korumasini kaldir.
            serverHasContentRef.current = true;
            await fetch("/api/library", {
              method: "PUT",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ state: stored }),
            }).catch(() => undefined);
          }
          if (stored) {
            setLikedIds(stored.likedIds);
            setPlaylists(stored.playlists);
            setRemovedTrackIds(stored.removedTrackIds);
            setExternalTracks(stored.externalTracks ?? []);
          }
        }
        setHydrated(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Okuma commitlenmeden bos state'i kaydetme (kullanici verisini ezmemek icin).
  // Yerel yedek her zaman yazilir; sunucu dosyasi siraya girer, son durum kazanir.
  // Bos snapshot, sunucuda dolu kayit gorulmedikce yukari yazilmaz (taze
  // profilden gelen bos PUT dolu dosyayi ezmesin).
  useEffect(() => {
    if (!hydrated) return;
    const snapshot: LibraryState = { likedIds, playlists, removedTrackIds, externalTracks };
    saveLibrary(snapshot);
    if (!hasLibraryContent(snapshot) && !serverHasContentRef.current) return;
    serverSaveChainRef.current = serverSaveChainRef.current
      .then(async () => {
        const res = await fetch("/api/library", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ state: snapshot }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
      })
      .catch(() => undefined);
  }, [hydrated, likedIds, playlists, removedTrackIds, externalTracks]);

  const isLiked = useCallback(
    (id: string) => likedIds.includes(id),
    [likedIds],
  );

  const toggleLike = useCallback((id: string) => {
    setLikedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );
  }, []);

  /**
   * İndirilmemiş arama sonucu beğenisi: id beğenilere işlenir, kartın
   * kendisi de Beğenilenler görünümünde çalınabilsin diye kopyası saklanır.
   * Beğeni geri alınınca kopya da silinir.
   */
  const toggleExternalLike = useCallback((track: ExternalTrack) => {
    const liked = likedIdsRef.current.includes(track.id);
    toggleLike(track.id);
    setExternalTracks((prev) =>
      liked
        ? prev.filter((t) => t.id !== track.id)
        : [...prev.filter((t) => t.id !== track.id), track],
    );
  }, [toggleLike]);

  const createPlaylist = useCallback(
    (rawName: string, cover?: string): CreatePlaylistResult => {
      const name = rawName.trim();
      if (name.length === 0) {
        return { ok: false, message: t.playlists.emptyName };
      }
      const normalized = normalizeName(name.slice(0, 60));
      const duplicate = playlists.some((p) => normalizeName(p.name) === normalized);
      if (duplicate) {
        return { ok: false, message: t.playlists.duplicateName };
      }
      // Kapak cok buyukse kotayi patlatmamak icin kapaksiz olustur.
      const trimmedCover = cover && cover.length > 0 ? cover : undefined;
      const coverTooLarge =
        trimmedCover !== undefined &&
        trimmedCover.length > MAX_COVER_DATA_URL_LENGTH;
      const playlist: Playlist = {
        id: `pl-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
        name: name.slice(0, 60),
        trackIds: [],
        createdAt: Date.now(),
        ...(trimmedCover !== undefined && !coverTooLarge
          ? { cover: trimmedCover }
          : {}),
      };
      setPlaylists((prev) => [...prev, playlist]);
      if (coverTooLarge) {
        return { ok: true, message: t.playlistPanel.coverTooLarge, playlist };
      }
      return { ok: true, message: t.playlists.created({ name: playlist.name }), playlist };
    },
    [playlists, t],
  );

  const deletePlaylist = useCallback((playlistId: string) => {
    setPlaylists((prev) => prev.filter((p) => p.id !== playlistId));
  }, []);

  const updatePlaylist = useCallback(
    (
      playlistId: string,
      patch: { name?: string; cover?: string; removeCover?: boolean },
    ): PlaylistMutationResult => {
      const target = playlists.find((p) => p.id === playlistId);
      if (!target) return { ok: false, message: t.playlists.notFound };
      let nextName = target.name;
      if (patch.name !== undefined) {
        const name = patch.name.trim().slice(0, 60);
        if (name.length === 0) return { ok: false, message: t.playlists.emptyName };
        const normalized = normalizeName(name);
        const duplicate = playlists.some(
          (p) => p.id !== playlistId && normalizeName(p.name) === normalized,
        );
        if (duplicate) return { ok: false, message: t.playlists.duplicateName };
        nextName = name;
      }
      let nextCover = target.cover;
      let coverTooLarge = false;
      if (patch.removeCover) {
        nextCover = undefined;
      } else if (patch.cover !== undefined) {
        if (patch.cover.length === 0) {
          nextCover = undefined;
        } else if (patch.cover.length > MAX_COVER_DATA_URL_LENGTH) {
          // Mevcut gorsel korunur; bilgi mesaji doner.
          coverTooLarge = true;
        } else {
          nextCover = patch.cover;
        }
      }
      setPlaylists((prev) =>
        prev.map((p) =>
          p.id === playlistId ? { ...p, name: nextName, cover: nextCover } : p,
        ),
      );
      if (coverTooLarge) return { ok: true, message: t.playlistPanel.coverTooLarge };
      return { ok: true, message: t.playlistPanel.updated({ name: nextName }) };
    },
    [playlists, t],
  );

  const addTrackToPlaylist = useCallback(
    (playlistId: string, trackId: string): PlaylistMutationResult => {
      const target = playlists.find((p) => p.id === playlistId);
      if (!target) return { ok: false, message: t.playlists.notFound };
      if (target.trackIds.includes(trackId)) {
        return { ok: false, message: t.playlists.alreadyInList };
      }
      setPlaylists((prev) =>
        prev.map((p) =>
          p.id === playlistId ? { ...p, trackIds: [...p.trackIds, trackId] } : p,
        ),
      );
      return { ok: true, message: t.playlists.addedToList({ name: target.name }) };
    },
    [playlists, t],
  );

  const importSpotifyPlaylist = useCallback((name: string, cover: string | undefined, importedTracks: Playlist["importedTracks"], spotifyId: string) => {
    const existing = playlists.find((playlist) => playlist.spotifyId === spotifyId);
    // Kaynak listede aynı parça iki kez geçebilir; React key çakışmasın diye ilki korunur.
    const seen = new Set<string>();
    const uniqueImports = (importedTracks ?? []).filter((track) => {
      if (seen.has(track.id)) return false;
      seen.add(track.id);
      return true;
    });
    const trackIds = uniqueImports.map((track) => track.id);
    if (existing) {
      setPlaylists((prev) => prev.map((playlist) => playlist.id === existing.id ? { ...playlist, name, cover, trackIds, importedTracks: uniqueImports } : playlist));
      return existing.id;
    }
    const playlist: Playlist = { id: `pl-spotify-${spotifyId}`, name: name.trim().slice(0, 60), cover, trackIds, importedTracks: uniqueImports, spotifyId, createdAt: Date.now() };
    setPlaylists((prev) => [...prev, playlist]);
    return playlist.id;
  }, [playlists]);

  const importYoutubePlaylist = useCallback((name: string, cover: string | undefined, importedTracks: Playlist["importedTracks"], youtubeId: string) => {
    const existing = playlists.find((playlist) => playlist.youtubeId === youtubeId);
    // Kaynak listede aynı parça iki kez geçebilir; React key çakışmasın diye ilki korunur.
    const seen = new Set<string>();
    const uniqueImports = (importedTracks ?? []).filter((track) => {
      if (seen.has(track.id)) return false;
      seen.add(track.id);
      return true;
    });
    const trackIds = uniqueImports.map((track) => track.id);
    if (existing) {
      setPlaylists((prev) => prev.map((playlist) => playlist.id === existing.id ? { ...playlist, name, cover, trackIds, importedTracks: uniqueImports } : playlist));
      return existing.id;
    }
    const playlist: Playlist = { id: `pl-youtube-${youtubeId}`, name: name.trim().slice(0, 60), cover, trackIds, importedTracks: uniqueImports, youtubeId, createdAt: Date.now() };
    setPlaylists((prev) => [...prev, playlist]);
    return playlist.id;
  }, [playlists]);

  const removeTrackFromPlaylist = useCallback(
    (playlistId: string, trackId: string) => {
      setPlaylists((prev) =>
        prev.map((p) =>
          p.id === playlistId
            ? {
                ...p,
                trackIds: p.trackIds.filter((id) => id !== trackId),
                importedTracks: (p.importedTracks ?? []).filter(
                  (t) => t.id !== trackId,
                ),
              }
            : p,
        ),
      );
    },
    [],
  );

  /**
   * İndirilmemiş arama sonucunu listeye ekler: kayıt `importedTracks` içinde
   * meta verisiyle durur, liste görünümünde stream ile çalınır. İndirme hâlâ
   * ayrı adımdır; ekleme indirme başlatmaz.
   */
  const addExternalToPlaylist = useCallback(
    (playlistId: string, track: ExternalTrack): PlaylistMutationResult => {
      const target = playlists.find((p) => p.id === playlistId);
      if (!target) return { ok: false, message: t.playlists.notFound };
      if (
        target.trackIds.includes(track.id) ||
        (target.importedTracks ?? []).some((t) => t.id === track.id)
      ) {
        return { ok: false, message: t.playlists.alreadyInList };
      }
      const entry =
        track.source === "youtube"
          ? {
              id: track.id,
              source: "youtube" as const,
              youtubeId: track.videoId,
              youtubeUrl: track.externalUrl,
              title: track.title,
              artist: track.artist,
              album: track.album,
              duration: track.duration,
              cover: track.cover,
            }
          : {
              id: track.id,
              source: "spotify" as const,
              spotifyId: track.id.replace(/^spotify-/, ""),
              spotifyUrl: track.externalUrl,
              title: track.title,
              artist: track.artist,
              album: track.album,
              duration: track.duration,
              cover: track.cover,
            };
      setPlaylists((prev) =>
        prev.map((p) =>
          p.id === playlistId
            ? { ...p, importedTracks: [...(p.importedTracks ?? []), entry] }
            : p,
        ),
      );
      return { ok: true, message: t.playlists.addedToList({ name: target.name }) };
    },
    [playlists, t],
  );

  /** Lokal dosya silinince playlistlerde bozuk kayıt kalmasın. */
  const detachTrackEverywhere = useCallback((trackId: string) => {
    setPlaylists((prev) =>
      prev.map((p) => ({
        ...p,
        trackIds: p.trackIds.filter((id) => id !== trackId),
      })),
    );
    setLikedIds((prev) => prev.filter((id) => id !== trackId));
  }, []);

  /** Dosya uzantisi degisse de begeni/liste baglarini ayni kayda tasir. */
  const remapTrackIds = useCallback((mapping: Record<string, string>): boolean => {
    if (Object.keys(mapping).length === 0) return true;
    const next = remapLibraryState(
      {
        likedIds: likedIdsRef.current,
        playlists: playlistsRef.current,
        removedTrackIds: removedTrackIdsRef.current,
        externalTracks: externalTracksRef.current,
      },
      mapping,
    );
    if (!saveLibrary(next)) return false;
    likedIdsRef.current = next.likedIds;
    playlistsRef.current = next.playlists;
    removedTrackIdsRef.current = next.removedTrackIds;
    externalTracksRef.current = next.externalTracks;
    setLikedIds(next.likedIds);
    setPlaylists(next.playlists);
    setRemovedTrackIds(next.removedTrackIds);
    setExternalTracks(next.externalTracks);
    return true;
  }, []);

  /** Katalog kaydını gizler; fiziksel ses dosyasına dokunmaz. */
  const removeLibraryTrack = useCallback((trackId: string) => {
    setRemovedTrackIds((prev) =>
      prev.includes(trackId) ? prev : [...prev, trackId],
    );
    setPlaylists((prev) =>
      prev.map((p) => ({
        ...p,
        trackIds: p.trackIds.filter((id) => id !== trackId),
      })),
    );
    setLikedIds((prev) => prev.filter((id) => id !== trackId));
  }, []);

  return {
    likedIds,
    playlists,
    removedTrackIds,
    externalTracks,
    hydrated,
    isLiked,
    toggleLike,
    toggleExternalLike,
    createPlaylist,
    deletePlaylist,
    updatePlaylist,
    addTrackToPlaylist,
    addExternalToPlaylist,
    importSpotifyPlaylist,
    importYoutubePlaylist,
    removeTrackFromPlaylist,
    detachTrackEverywhere,
    remapTrackIds,
    removeLibraryTrack,
  };
}
