"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { ExternalTrack, SearchApiResponse, SpotifyKeys, YoutubeKey } from "../lib/types";

interface UseMusicSearchResult {
  query: string;
  setQuery: (q: string) => void;
  submitSearch: (q: string) => void;
  submittedQuery: string;
  results: ExternalTrack[];
  isLoading: boolean;
  isLoadingMore: boolean;
  hasMore: boolean;
  error: string | null;
  hasSearched: boolean;
  warnings: string[];
  needsSpotifyKeys: boolean;
  needsYoutubeKey: boolean;
  youtubeQuotaExceeded: boolean;
  loadMore: () => void;
}


export function useMusicSearch(keys: SpotifyKeys | null, youtubeKey: YoutubeKey | null, sources = "spotify,youtube"): UseMusicSearchResult {
  const [query, setQuery] = useState("");
  const [submission, setSubmission] = useState({ query: "", version: 0 });
  const submitSearch = useCallback((q: string) => {
    setQuery(q);
    setSubmission((previous) => ({ query: q.trim(), version: previous.version + 1 }));
  }, []);
  const [results, setResults] = useState<ExternalTrack[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [needsSpotifyKeys, setNeedsSpotifyKeys] = useState(false);
  const [needsYoutubeKey, setNeedsYoutubeKey] = useState(false);
  const [youtubeQuotaExceeded, setYoutubeQuotaExceeded] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const loadMoreAbortRef = useRef<AbortController | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Havuzun geri kalanini ceken sayfalama imlecleri; state degil cunku
  // yalnizca runSearch/loadMore icinde okunup yaziliyor.
  const nextSpotifyOffsetRef = useRef<number | undefined>(undefined);
  const nextYoutubePageTokenRef = useRef<string | undefined>(undefined);
  const activeQueryRef = useRef("");
  const loadingMoreRef = useRef(false);

  const runSearch = useCallback(async (q: string) => {
    const trimmed = q.trim();
    abortRef.current?.abort();
    loadMoreAbortRef.current?.abort();
    loadingMoreRef.current = false;
    setIsLoadingMore(false);
    if (trimmed.length < 2 || !sources) {
      activeQueryRef.current = "";
      nextSpotifyOffsetRef.current = undefined;
      nextYoutubePageTokenRef.current = undefined;
      setResults([]);
      setIsLoading(false);
      setHasSearched(false);
      setError(null);
      setWarnings([]);
      setNeedsSpotifyKeys(false);
      setNeedsYoutubeKey(false);
      setYoutubeQuotaExceeded(false);
      setHasMore(false);
      return;
    }

    // Yeni sorgu: havuz ve imlecler basa doner, ilk sayfa ustune yazar.
    activeQueryRef.current = trimmed;
    nextSpotifyOffsetRef.current = undefined;
    nextYoutubePageTokenRef.current = undefined;
    setHasMore(false);

    const controller = new AbortController();
    abortRef.current = controller;
    setIsLoading(true);
    setError(null);
    setWarnings([]);
    setNeedsSpotifyKeys(false);
    setNeedsYoutubeKey(false);
    setYoutubeQuotaExceeded(false);

    try {
      const headers: Record<string, string> = {};
      if (keys?.clientId && keys?.clientSecret) {
        headers["x-spotify-client-id"] = keys.clientId;
        headers["x-spotify-client-secret"] = keys.clientSecret;
      }
      if (youtubeKey?.apiKey) {
        headers["x-youtube-api-key"] = youtubeKey.apiKey;
      }
      const res = await fetch(`/api/search?q=${encodeURIComponent(trimmed)}&sources=${encodeURIComponent(sources)}`, {
        signal: controller.signal,
        headers,
      });
      const data = (await res.json()) as SearchApiResponse & { error?: string };
      if (!res.ok) {
        setNeedsSpotifyKeys(data.needsSpotifyKeys === true);
        setNeedsYoutubeKey(data.needsYoutubeKey === true);
        setError(data.error ?? "Arama başarısız oldu.");
        setResults([]);
        setHasSearched(true);
        setHasMore(false);
        return;
      }
      if (controller.signal.aborted) return;
      setResults(data.results);
      nextSpotifyOffsetRef.current = data.nextSpotifyOffset;
      nextYoutubePageTokenRef.current = data.nextYoutubePageToken;
      setHasMore(data.nextSpotifyOffset !== undefined || !!data.nextYoutubePageToken);
      setWarnings(data.errors ?? []);
      setNeedsSpotifyKeys(data.needsSpotifyKeys === true);
      setNeedsYoutubeKey(data.needsYoutubeKey === true);
      setYoutubeQuotaExceeded(data.youtubeQuotaExceeded === true);
      setHasSearched(true);
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return;
      setError(err instanceof Error ? err.message : "Bilinmeyen hata.");
      setResults([]);
      setNeedsSpotifyKeys(false);
      setNeedsYoutubeKey(false);
      setHasSearched(true);
      setHasMore(false);
    } finally {
      if (!controller.signal.aborted) setIsLoading(false);
    }
  }, [keys, youtubeKey, sources]);

  const loadMore = useCallback(async () => {
    if (loadingMoreRef.current) return;
    const activeQuery = activeQueryRef.current;
    if (activeQuery.length < 2) return;
    const nextOffset = nextSpotifyOffsetRef.current;
    const nextToken = nextYoutubePageTokenRef.current;
    if (nextOffset === undefined && !nextToken) return;
    loadingMoreRef.current = true;
    setIsLoadingMore(true);
    const controller = new AbortController();
    loadMoreAbortRef.current = controller;
    try {
      const headers: Record<string, string> = {};
      if (keys?.clientId && keys?.clientSecret) {
        headers["x-spotify-client-id"] = keys.clientId;
        headers["x-spotify-client-secret"] = keys.clientSecret;
      }
      if (youtubeKey?.apiKey) {
        headers["x-youtube-api-key"] = youtubeKey.apiKey;
      }
      const params = new URLSearchParams({ q: activeQuery, sources });
      if (nextOffset !== undefined) params.set("spotifyOffset", String(nextOffset));
      if (nextToken) params.set("youtubePageToken", nextToken);
      const res = await fetch(`/api/search?${params.toString()}`, {
        signal: controller.signal,
        headers,
      });
      const data = (await res.json()) as SearchApiResponse & { error?: string };
      if (!res.ok) return;
      if (controller.signal.aborted) return;
      const incoming = data.results ?? [];
      if (incoming.length > 0) {
        // Ayni id iki kez girmesin; havuz buyur, ustune yazma.
        setResults((prev) => {
          const seen = new Set(prev.map((t) => t.id));
          const fresh = incoming.filter((t) => !seen.has(t.id));
          return fresh.length > 0 ? [...prev, ...fresh] : prev;
        });
      }
      nextSpotifyOffsetRef.current = data.nextSpotifyOffset;
      nextYoutubePageTokenRef.current = data.nextYoutubePageToken;
      setHasMore(data.nextSpotifyOffset !== undefined || !!data.nextYoutubePageToken);
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return;
      // Sayfalama hatasi havuzu bozmaz; imlec aynen kalir, tekrar denenebilir.
    } finally {
      loadingMoreRef.current = false;
      setIsLoadingMore(false);
    }
  }, [keys, youtubeKey, sources]);

  useEffect(() => {
    const trimmed = submission.query;
    const timer = setTimeout(() => {
      void runSearch(trimmed);
    }, 0);
    debounceRef.current = timer;
    return () => {
      clearTimeout(timer);
      abortRef.current?.abort();
      loadMoreAbortRef.current?.abort();
    };
  }, [submission, runSearch]);

  useEffect(() => {
    return () => {
      abortRef.current?.abort();
      loadMoreAbortRef.current?.abort();
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, []);

  return { query, setQuery, submitSearch, submittedQuery: submission.query, results, isLoading, isLoadingMore, hasMore, error, hasSearched, warnings, needsSpotifyKeys, needsYoutubeKey, youtubeQuotaExceeded, loadMore };
}
