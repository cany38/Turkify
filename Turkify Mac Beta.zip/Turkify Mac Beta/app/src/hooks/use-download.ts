"use client";

import { useCallback, useRef, useState } from "react";
import type { ExternalTrack, LocalTrack } from "../lib/types";
import { stableDownloadTrackId } from "../lib/library-identity";
import { audioFormatExtension } from "../lib/audio-format";
import { parseDispositionFileName } from "../lib/download-headers";
import type { AudioFormat } from "../lib/audio-format";

export interface DownloadState {
  trackId: string;
  stage: "downloading" | "needs-aac-confirmation" | "done" | "error";
  message?: string;
  percent?: number;
  phase?: "matching" | "downloading";
  /** Opus isteği başka bir nedenle de başarısızsa kullanıcı AAC deneyebilir. */
  aacRetryAvailable?: boolean;
}

// Suregiden isteklerin sunucu karsiligi: parca -> ilerleme kimligi.
// Sekme kapaninca beacon ile toplu iptal edilir.
const activeProgressIds = new Map<string, string>();

function sendCancel(progressIds: string[]): void {
  if (progressIds.length === 0) return;
  try {
    const body = JSON.stringify({ progressIds });
    if (typeof navigator !== "undefined" && typeof navigator.sendBeacon === "function") {
      const blob = new Blob([body], { type: "application/json" });
      if (navigator.sendBeacon("/api/download/cancel", blob)) return;
    }
    void fetch("/api/download/cancel", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body,
      keepalive: true,
    }).catch(() => undefined);
  } catch {
    // yok say
  }
}

let pagehideWired = false;
if (typeof window !== "undefined" && !pagehideWired) {
  pagehideWired = true;
  window.addEventListener("pagehide", () => {
    sendCancel(Array.from(new Set(activeProgressIds.values())));
  });
}

export function useDownload(audioFormat: AudioFormat) {
  const [states, setStates] = useState<Record<string, DownloadState>>({});
  // Sayfa degisse de indirme surer; tamamlanan/Iptal bilgisi burada yasar.
  const controllersRef = useRef(new Map<string, AbortController>());
  const cancelledRef = useRef(new Set<string>());

  const clearStateEntry = useCallback((id: string) => {
    setStates((prev) => {
      if (!(id in prev)) return prev;
      const next = { ...prev };
      delete next[id];
      return next;
    });
  }, []);

  const download = useCallback(
    async (
      track: ExternalTrack,
      onSaved: (local: LocalTrack) => void,
      formatOverride?: AudioFormat,
    ): Promise<boolean> => {
      const id = track.id;
      const requestedFormat = formatOverride ?? audioFormat;
      const progressId = crypto.randomUUID();
      const controller = new AbortController();
      controllersRef.current.set(id, controller);
      activeProgressIds.set(id, progressId);
      let stopped = false;
      let timer: ReturnType<typeof setTimeout> | undefined;
      const poll = async () => {
        try {
          const response = await fetch(`/api/download?id=${progressId}`, { cache: "no-store" });
          const data = await response.json();
          if (!stopped && typeof data.percent === "number") setStates((prev) => ({ ...prev, [id]: { trackId: id, stage: "downloading", percent: data.percent, ...(data.phase === "matching" ? { phase: "matching" as const } : {}) } }));
        } catch { /* The download request determines success or failure. */ }
        if (!stopped) timer = setTimeout(poll, 700);
      };

      setStates((prev) => ({ ...prev, [id]: { trackId: id, stage: "downloading" } }));

      const isSpotify = track.source === "spotify";
      const payload: Record<string, string> = {
        progressId,
        source: track.source,
        title: track.title,
        artist: track.artist,
        album: track.album,
        cover: track.cover,
        format: requestedFormat,
      };
      // Beklenen sure eslesmede yanlis surumu elemek icin kullanilir.
      if (track.duration > 0) {
        payload.duration = String(Math.round(track.duration));
      }
      if (track.source === "youtube") {
        payload.videoId = track.videoId;
      }
      if (isSpotify) {
        const rawId = (track as { id: string }).id;
        payload.spotifyId = rawId;
        payload.spotifyUrl = (track as { externalUrl: string }).externalUrl ?? "";
      }

      try {
        timer = setTimeout(poll, 700);
        const res = await fetch("/api/download", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
          signal: controller.signal,
        });

        if (!res.ok) {
          let msg = `HTTP ${res.status}`;
          try {
            const data = (await res.json()) as { code?: string; error?: string };
            if (data.error) msg = data.error;
            if (data.code === "OPUS_UNAVAILABLE" && requestedFormat === "opus") {
              setStates((prev) => ({
                ...prev,
                [id]: {
                  trackId: id,
                  stage: "needs-aac-confirmation",
                  message: data.error,
                  percent: prev[id]?.percent,
                },
              }));
              return false;
            }
          } catch {
            const text = await res.text().catch(() => "");
            if (text) msg = text.slice(0, 400);
          }
          setStates((prev) => ({
            ...prev,
            [id]: {
              trackId: id,
              stage: "error",
              message: msg,
              ...(requestedFormat === "opus" ? { aacRetryAvailable: true } : {}),
            },
          }));
          return false;
        }

        stopped = true;
        const declaredSize = Number(res.headers.get("Content-Length"));
        if (Number.isFinite(declaredSize) && declaredSize > 0 && declaredSize < 1024) {
          setStates((prev) => ({
            ...prev,
            [id]: {
              trackId: id,
              stage: "error",
              message: "Dosya cok kucuk veya bos.",
              ...(requestedFormat === "opus" ? { aacRetryAvailable: true } : {}),
            },
          }));
          return false;
        }
        // Dosya sunucuda Musics'e kaydedildi; ayni sesi tarayiciya tekrar
        // tasimak tiki gereksiz yere geciktirir.
        void res.body?.cancel().catch(() => undefined);

        const disposition = res.headers.get("Content-Disposition") ?? "";
        const savedFile = res.headers.get("X-Saved-File");
        const libraryId = res.headers.get("X-Library-Id")?.trim() ?? "";
        const headerTitle = res.headers.get("X-Track-Title");
        const headerArtist = res.headers.get("X-Track-Artist");
        const headerAlbum = res.headers.get("X-Track-Album");
        const headerCover = res.headers.get("X-Track-Cover");

        let decodedTitle: string | null = null;
        let decodedArtist: string | null = null;
        let decodedAlbum: string | null = null;
        let decodedCover: string | null = null;
        try {
          if (headerTitle) decodedTitle = decodeURIComponent(headerTitle);
        } catch {
          decodedTitle = headerTitle;
        }
        try {
          if (headerArtist) decodedArtist = decodeURIComponent(headerArtist);
        } catch {
          decodedArtist = headerArtist;
        }
        try {
          if (headerAlbum) decodedAlbum = decodeURIComponent(headerAlbum);
        } catch {
          decodedAlbum = headerAlbum;
        }
        try {
          if (headerCover) decodedCover = decodeURIComponent(headerCover);
        } catch {
          decodedCover = headerCover;
        }

        const safeBase = sanitizeFileStem(decodedTitle ?? track.title);
        // Dosya adi once sunucudan alinir, yoksa yerelde uretilir.
        let fileName: string | undefined;
        if (savedFile) {
          try {
            fileName = decodeURIComponent(savedFile).trim();
          } catch {
            fileName = savedFile.trim();
          }
          if (!fileName) fileName = undefined;
        }
        if (!fileName && disposition) {
          const parsed = parseDispositionFileName(disposition);
          if (parsed) fileName = parsed;
        }
        if (!fileName) fileName = `${safeBase}${audioFormatExtension(requestedFormat)}`;
        // Sunucu dosyayi zaten Musics klasorune yazdi; id ve adres diskten turetilir, blob tutulmaz.
        const localId = libraryId
          ? stableDownloadTrackId(libraryId)
          : `disk-${fileName}`;
        const objectUrl = `/api/media?f=${encodeURIComponent(fileName)}`;
        const local: LocalTrack = {
          id: localId,
          title: (decodedTitle ?? track.title).slice(0, 80),
          artist: (decodedArtist ?? track.artist).slice(0, 80) || "İndirilen",
          album: (decodedAlbum ?? track.album).slice(0, 80) || "İndirilenler",
          duration: track.duration || 0,
          cover: decodedCover ?? track.cover ?? "/covers/demo-01.svg",
          source: "local",
          objectUrl,
          origin: track.source,
          externalId: track.id,
          fileName,
          ...(Number.isFinite(declaredSize) && declaredSize > 0
            ? { fileSize: declaredSize }
            : {}),
        };

        onSaved(local);

        setStates((prev) => ({ ...prev, [id]: { trackId: id, stage: "done" } }));
        window.setTimeout(() => {
          setStates((prev) => {
            const next = { ...prev };
            const cur = next[id];
            if (cur && cur.stage === "done") delete next[id];
            return next;
          });
        }, 4000);
        return true;
      } catch (err) {
        // İptal hata degildir: satir bosa doner, kuyruk sayacina girmez.
        if (controller.signal.aborted || cancelledRef.current.has(id)) {
          cancelledRef.current.delete(id);
          clearStateEntry(id);
          return false;
        }
        const msg = err instanceof Error ? err.message : String(err);
        setStates((prev) => ({
          ...prev,
          [id]: {
            trackId: id,
            stage: "error",
            message: msg.slice(0, 400),
            ...(requestedFormat === "opus" ? { aacRetryAvailable: true } : {}),
          },
        }));
        return false;
      }
      finally {
        stopped = true;
        controllersRef.current.delete(id);
        activeProgressIds.delete(id);
        if (timer) clearTimeout(timer);
      }
    },
    [audioFormat, clearStateEntry],
  );

  const clearError = useCallback((trackId: string) => {
    setStates((prev) => {
      const cur = prev[trackId];
      if (!cur || (cur.stage !== "error" && cur.stage !== "needs-aac-confirmation")) return prev;
      const next = { ...prev };
      delete next[trackId];
      return next;
    });
  }, []);

  /**
   * O an inen istegi durdurur: sunucu yt-dlp'yi oldurur, yarim dosya
   * Musics'e yazilmaz, inenler durur. Sekme kapaninca tarayici istegi
   * kendisi keser, ayni yol calisir.
   */
  const cancelDownload = useCallback((trackId: string) => {
    cancelledRef.current.add(trackId);
    controllersRef.current.get(trackId)?.abort();
    const progressId = activeProgressIds.get(trackId);
    if (progressId) {
      activeProgressIds.delete(trackId);
      sendCancel([progressId]);
    }
    clearStateEntry(trackId);
  }, [clearStateEntry]);

  /** Toplu kuyruk iptal edilen parcayi hatali saymasin diye tek seferlik okunur. */
  const isCancelled = useCallback((trackId: string) => {
    if (!cancelledRef.current.has(trackId)) return false;
    cancelledRef.current.delete(trackId);
    return true;
  }, []);

  return { states, download, clearError, cancelDownload, isCancelled };
}

function sanitizeFileStem(value: string): string {
  const base = value.replace(/[\\/:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
  return base.length > 0 ? base : "parca";
}
