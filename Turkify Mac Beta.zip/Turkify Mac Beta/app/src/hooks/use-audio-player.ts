"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { RepeatMode, Track } from "../lib/types";
import type { Playlist } from "../lib/types";
import type { Messages } from "../lib/i18n";
import { useI18n } from "../components/locale-provider";
import {
  DEFAULT_EQ,
  DEFAULT_REMIX,
  createRemixChain,
  readStoredEq,
  readStoredRemix,
  sanitizeEq,
  sanitizeRemix,
  writeStoredEq,
  writeStoredRemix,
  readTrackRemix,
  writeTrackRemix,
} from "../lib/audio-effects";
import type { EqSettings, RemixChain, RemixSettings } from "../lib/audio-effects";
import { beginPlaybackResolve } from "../lib/playback-priority";
import { cancelAllFormatWork } from "../lib/format-queue";
import { HISTORY_KEY, PLAYLIST_HISTORY_PREFIX, loadListeningHistory, type ListeningHistory } from "../lib/listening-history";
import {
  clearPlaybackSession,
  loadPlaybackSession,
  resolvePlaybackTrack,
  savePlaybackSession,
} from "../lib/playback-session";
import {
  SMART_MAX,
  SMART_REFILL,
  buildShuffleOrder,
  interleaveSuggestions,
  loadShuffleMode,
  pickSuggestions,
  saveShuffleMode,
  type ShuffleMode,
} from "../lib/smart-queue";

export function getPlayableUrl(track: Track | null | undefined): string | undefined {
  if (!track) return undefined;
  if (track.source === "local") return track.objectUrl;
  return track.url;
}

export function canPlayTrack(track: Track | null | undefined): boolean {
  const url = getPlayableUrl(track);
  return typeof url === "string" && url.length > 0;
}

function getUnplayableMessage(
  track: Track | null,
  errors: Messages["playerErrors"],
): string {
  return track?.source === "local" ? errors.corruptFile : errors.noAudio;
}

function getPlayErrorName(err: unknown): string | undefined {
  if (typeof err === "object" && err !== null && "name" in err) {
    const name = (err as { name?: unknown }).name;
    if (typeof name === "string") return name;
  }
  return undefined;
}

interface PitchPreservingMediaElement {
  preservesPitch?: boolean;
  webkitPreservesPitch?: boolean;
  mozPreservesPitch?: boolean;
}

/** Hiz grafik disi: tarayicinin yuksek kaliteli yeniden orneklemesi kullanilir. */
function applySpeedToElement(el: HTMLAudioElement, speed: number): void {
  try {
    el.playbackRate = speed;
  } catch {
    // yok say
  }
  try {
    const target = el as unknown as PitchPreservingMediaElement;
    target.preservesPitch = false;
    target.webkitPreservesPitch = false;
    target.mozPreservesPitch = false;
  } catch {
    // yok say
  }
}

interface Options {
  onLocalDuration?: (trackId: string, seconds: number) => void;
  /** Akilli oneriler icin benzerlik girdileri; turkify-app her renderda guncel listeyi verir. */
  likedIds?: string[];
  playlists?: Playlist[];
  /** Oneri havuzu: calinabilir yerel kutuphane (baglam disi parcalar buradan secilir). */
  pool?: Track[];
  /** Disk ve kutuphane hidrasyonu bitmeden son parca "yok" sayilmasin. */
  restoreReady?: boolean;
}

export function useAudioPlayer(options: Options = {}) {
  const [listeningHistory, setListeningHistory] = useState<ListeningHistory>({});
  const listeningHistoryRef = useRef<ListeningHistory>({});
  const listeningSessionRef = useRef({ seconds: 0, counted: false, started: false });
  // Karistirma: off = gri/sirali, on = yesil/liste ici, smart = mor/onerili.
  const [shuffleMode, setShuffleMode] = useState<ShuffleMode>("off");
  const shuffleModeRef = useRef<ShuffleMode>("off");
  const [smartIds, setSmartIds] = useState<string[]>([]);
  const smartIdsRef = useRef<string[]>([]);
  // Karisik gidisat: null ise dogal sira. Id listesi tutulur, boylece parca
  // silinince sira bozulmadan filtrelenir.
  const [orderIds, setOrderIds] = useState<string[] | null>(null);
  const orderIdsRef = useRef<string[] | null>(null);
  const [orderPos, setOrderPos] = useState(0);
  const orderPosRef = useRef(0);
  /** Onerisiz ham baglam; mod degisiminde kuyruk buradan yeniden kurulur. */
  const contextTracksRef = useRef<Track[]>([]);
  /** Benzerlik girdileri; render disi olaylarda ref uzerinden okunur. */
  const similarityRef = useRef<{ likedIds: string[]; playlists: Playlist[]; pool: Track[] }>({
    likedIds: [],
    playlists: [],
    pool: [],
  });

  useEffect(() => {
    let cancelled = false;
    void Promise.resolve().then(() => {
      if (cancelled) return;
      const stored = loadListeningHistory();
      listeningHistoryRef.current = stored;
      setListeningHistory(stored);
      const storedShuffle = loadShuffleMode();
      shuffleModeRef.current = storedShuffle;
      setShuffleMode(storedShuffle);
    });
    return () => { cancelled = true; };
  }, []);

  const recordListening = useCallback((id: string, counted: boolean) => {
    const previous = listeningHistoryRef.current[id];
    const next = { ...listeningHistoryRef.current, [id]: {
      count: (previous?.count ?? 0) + (counted ? 1 : 0), lastPlayed: Date.now(),
    } };
    listeningHistoryRef.current = next;
    setListeningHistory(next);
    try { localStorage.setItem(HISTORY_KEY, JSON.stringify(next)); } catch { /* Keep session history if storage is unavailable. */ }
  }, []);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const queueRef = useRef<Track[]>([]);
  const fallbackQueueRef = useRef<Track[]>([]);
  const contextKeyRef = useRef("default");
  const [contextKey, setContextKey] = useState("default");
  const currentRef = useRef<Track | null>(null);
  const currentTimeRef = useRef(0);
  const pendingSeekRef = useRef<number | null>(null);
  const loadedTrackIdRef = useRef<string | null>(null);
  const persistedTimeBucketRef = useRef(-1);
  const restoredSessionRef = useRef(false);
  /**
   * Liste baglaminda dinleme: `playlist:<id>` kuyrugundan 30sn dinlenen her
   * parca, parcayla ayni olcekte listeye de yazar. Boylece En cok
   * dinlediklerin sarki ve listeyi sayiya gore karisik siralar.
   */
  const recordPlaylistFromContext = useCallback((counted: boolean) => {
    const contextKey = contextKeyRef.current;
    if (!contextKey.startsWith(PLAYLIST_HISTORY_PREFIX)) return;
    const playlistId = contextKey.slice(PLAYLIST_HISTORY_PREFIX.length);
    if (!playlistId) return;
    recordListening(`${PLAYLIST_HISTORY_PREFIX}${playlistId}`, counted);
  }, [recordListening]);
  const repeatModeRef = useRef<RepeatMode>("off");
  const requestRef = useRef(0);
  /** Suregiden ses adresi cozumlemesi; parca degisince hemen iptal edilir. */
  const resolveAbortRef = useRef<AbortController | null>(null);
  const onDurationRef = useRef(options.onLocalDuration);

  useEffect(() => {
    onDurationRef.current = options.onLocalDuration;
  }, [options.onLocalDuration]);

  useEffect(() => {
    similarityRef.current = {
      likedIds: options.likedIds ?? [],
      playlists: options.playlists ?? [],
      pool: options.pool ?? [],
    };
  }, [options.likedIds, options.playlists, options.pool]);
  const startPlaybackRef = useRef<(track: Track, nextQueue: Track[], startAt?: number) => void>(() => {});

  const [queue, setQueue] = useState<Track[]>([]);
  const [fallbackQueue, setFallbackQueue] = useState<Track[]>([]);
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(0.9);
  const [muted, setMuted] = useState(false);
  const [playerError, setPlayerError] = useState<string | null>(null);
  /** Uzak kaynagin adresi cozuluyor: ses henuz baslamadi ama hata da yok. */
  const [isResolving, setIsResolving] = useState(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>("off");
  // Ilk render her zaman DEFAULT_REMIX (hidrasyon guvenligi); depolanmis
  // deger mount sonrasi async okunup uygulanir.
  const [remix, setRemixState] = useState<RemixSettings>(DEFAULT_REMIX);
  const remixRef = useRef<RemixSettings>(DEFAULT_REMIX);
  const generalRemixRef = useRef<RemixSettings>(DEFAULT_REMIX);
  const entryRemixRef = useRef<RemixSettings>(DEFAULT_REMIX);
  // Esitleyici parca bazli degil, cihaz geneli bir ayardir.
  const [eq, setEqState] = useState<EqSettings>(DEFAULT_EQ);
  const eqRef = useRef<EqSettings>(DEFAULT_EQ);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const chainRef = useRef<RemixChain | null>(null);
  const sourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const { t } = useI18n();
  const errorsRef = useRef(t.playerErrors);

  useEffect(() => {
    errorsRef.current = t.playerErrors;
  }, [t.playerErrors]);

  useEffect(() => {
    queueRef.current = queue;
  }, [queue]);

  useEffect(() => {
    currentRef.current = currentTrack;
  }, [currentTrack]);

  /** Tembel Web Audio kurulumu: yalnizca kullanici kaynakli calma aninda. */
  const ensureAudioGraph = useCallback(() => {
    try {
      if (typeof window === "undefined") return;
      const el = audioRef.current;
      if (!el) return;
      // Hiz grafige bagli degil; Web Audio desteksizse bile uygulanir.
      applySpeedToElement(el, remixRef.current.speed);
      const Ctor = window.AudioContext;
      if (typeof Ctor !== "function") return;
      let ctx = audioCtxRef.current;
      if (!ctx) {
        try {
          ctx = new Ctor();
        } catch {
          // yok say: efektsiz normal oynatma surer
          return;
        }
        audioCtxRef.current = ctx;
      }
      if (ctx.state === "suspended") {
        try {
          const resumed = ctx.resume();
          if (resumed && typeof resumed.catch === "function") {
            resumed.catch(() => {
              // yok say
            });
          }
        } catch {
          // yok say
        }
      }
      let chain = chainRef.current;
      if (!chain) {
        try {
          chain = createRemixChain(ctx);
        } catch {
          // yok say
          return;
        }
        chainRef.current = chain;
        try {
          chain.output.connect(ctx.destination);
        } catch {
          // yok say
        }
      }
      // Zincir ilk kurulumda da sonradan da o anki ayarlari yansirsin.
      {
        const activeChain = chainRef.current;
        if (activeChain) {
          try {
            activeChain.apply(remixRef.current);
          } catch {
            // yok say
          }
          try {
            activeChain.applyEq(eqRef.current);
          } catch {
            // yok say
          }
        }
      }
      // createMediaElementSource bir eleman icin yalnizca bir kez cagrilabilir.
      if (!sourceRef.current) {
        try {
          const src = ctx.createMediaElementSource(el);
          sourceRef.current = src;
          try {
            src.connect(chain.input);
          } catch {
            // yok say
          }
        } catch {
          // InvalidStateError: zaten bagli; sessiz gec
        }
      }
    } catch {
      // Web Audio desteksizse uygulama cokmez, normal oynatma surer.
    }
  }, []);

  const applyOrder = useCallback((ids: string[] | null, pos: number) => {
    orderIdsRef.current = ids;
    setOrderIds(ids);
    orderPosRef.current = pos;
    setOrderPos(pos);
  }, []);

  const applySmartIds = useCallback((ids: string[]) => {
    smartIdsRef.current = ids;
    setSmartIds(ids);
  }, []);

  /** Baglamdan etkin kuyrugu kurar; smart modda benzer oneriler serpisir. */
  const buildEffectiveQueue = useCallback((context: Track[], mode: ShuffleMode): { queue: Track[]; smartIds: string[] } => {
    if (mode !== "smart") return { queue: context, smartIds: [] };
    const sim = similarityRef.current;
    const pool = sim.pool.filter(canPlayTrack);
    const suggestions = pickSuggestions(pool, context, SMART_MAX, {
      likedIds: sim.likedIds,
      playlists: sim.playlists,
      history: listeningHistoryRef.current,
    });
    return interleaveSuggestions(context, suggestions);
  }, []);

  const startPlayback = useCallback((track: Track, nextQueue: Track[], startAt = 0) => {
    listeningSessionRef.current = { seconds: 0, counted: false, started: false };
    if (currentRef.current?.id !== track.id) {
      entryRemixRef.current = generalRemixRef.current;
    }
    const nextRemix = readTrackRemix(track.id) ?? generalRemixRef.current;
    remixRef.current = nextRemix;
    setRemixState(nextRemix);
    ensureAudioGraph();
    const el = audioRef.current;
    const myRequest = ++requestRef.current;
    // Onceki cozumleme suruyorsa hemen iptal: sunucudaki yt-dlp de olur,
    // yeni parca onun arkasinda siraya girmez.
    resolveAbortRef.current?.abort();
    resolveAbortRef.current = null;
    setIsResolving(false);
    cancelAllFormatWork();
    const url = getPlayableUrl(track);
    if (!el || !url) {
      requestRef.current += 1;
      loadedTrackIdRef.current = null;
      pendingSeekRef.current = null;
      if (el) {
        try {
          el.pause();
        } catch {
          // yok say
        }
        el.removeAttribute("src");
        el.load();
      }
      setIsPlaying(false);
      setPlayerError(
        track.source === "local"
          ? errorsRef.current.missingSource
          : errorsRef.current.noAudio,
      );
      return;
    }
    setPlayerError(null);
    setQueue(nextQueue);
    setCurrentTrack(track);
    queueRef.current = nextQueue;
    currentRef.current = track;
    const resumeAt = Number.isFinite(startAt) ? Math.max(0, startAt) : 0;
    currentTimeRef.current = resumeAt;
    pendingSeekRef.current = resumeAt;
    persistedTimeBucketRef.current = Math.floor(resumeAt / 5);
    setCurrentTime(resumeAt);
    setDuration(track.duration);
    savePlaybackSession(track, contextKeyRef.current, resumeAt);

    const attachAndPlay = () => {
    try {
      // Kaynak degismeden once boru hatti tam sifirlanir: onceki yukleme
      // yarim/stalled kaldiysa tarayici yeni src'i sessizce reddedebiliyor
      // (readyState 0'da takilma). Bos src + load() eski durumu kesin atar.
      try {
        el.pause();
      } catch {
        // yok say
      }
      el.removeAttribute("src");
      el.load();
      el.src = url;
      loadedTrackIdRef.current = track.id;
      // Kaynak degisimi hizi sifirlayabilir; guncel ayari kaynagin ardindan
      // yeniden uygula ki parca degisiminde ayar korunur.
      applySpeedToElement(el, remixRef.current.speed);
      const activeChain = chainRef.current;
      if (activeChain) {
        try {
          activeChain.apply(remixRef.current);
        } catch {
          // yok say
        }
      }
      try {
        el.currentTime = resumeAt;
        pendingSeekRef.current = null;
      } catch {
        // Metadata gelince handleLoadedMetadata kayitli konumu uygular.
      }
      const promise = el.play();
      if (promise && typeof promise.catch === "function") {
        promise.catch((err: unknown) => {
          // Stale event: başka bir track'e geçildiyse hata yazma.
          if (requestRef.current !== myRequest) return;
          const name = getPlayErrorName(err);
          if (name === "AbortError") return;
          if (name === "NotSupportedError") {
            setIsPlaying(false);
            setPlayerError(getUnplayableMessage(track, errorsRef.current));
            return;
          }
          // Kaynak hatasi (handleError) zaten varsa genel mesajla ezme.
          try {
            if (el.error) return;
          } catch {
            // yok say
          }
          setIsPlaying(false);
          setPlayerError(
            name === "NotAllowedError"
              ? errorsRef.current.blocked
              : errorsRef.current.startFailed,
          );
        });
      }
    } catch {
      if (requestRef.current !== myRequest) return;
      setPlayerError(errorsRef.current.startFailed);
    }
    };

    // Uzak kaynak: adres cozulene kadar elemente hic dokunma.
    //
    // Eskiden `el.src` dogrudan `/api/stream` idi ve element yt-dlp bitene
    // kadar (2-25 sn) yarim kalmis bir yuklemede asili kalirdi. Kullanici o
    // sirada hazir bir parcaya gecince tarayici once o yuklemeyi sokmek
    // zorundaydi; bekleme oradan geliyordu. Simdi bekleyen sey sadece bir
    // `fetch`; iptali aninda ve elementi hic etkilemiyor.
    if (url.startsWith("/api/stream")) {
      loadedTrackIdRef.current = null;
      try {
        el.pause();
      } catch {
        // yok say
      }
      const controller = new AbortController();
      resolveAbortRef.current = controller;
      setIsResolving(true);
      // Rozet yoklamalari bu sirada yeni yt-dlp baslatmasin; kullanicinin
      // bekledigi sey ses, kodek etiketi degil.
      const releasePriority = beginPlaybackResolve();
      const queryIndex = url.indexOf("?");
      const search = queryIndex >= 0 ? url.slice(queryIndex + 1) : "";
      void fetch(`/api/stream/resolve?${search}`, {
        signal: controller.signal,
        cache: "no-store",
      })
        .then(async (response) => {
          if (requestRef.current !== myRequest) return;
          // 499: istek sunucuda iptal edildi, kullanici zaten baska yerde.
          if (response.status === 499) return;
          if (response.ok) {
            attachAndPlay();
            return;
          }
          const data: unknown = await response.json().catch(() => null);
          const message =
            typeof data === "object" && data !== null &&
            typeof (data as Record<string, unknown>).error === "string"
              ? ((data as Record<string, unknown>).error as string)
              : errorsRef.current.noAudio;
          setIsPlaying(false);
          setPlayerError(message);
        })
        .catch((err: unknown) => {
          if (requestRef.current !== myRequest) return;
          if (getPlayErrorName(err) === "AbortError") return;
          setIsPlaying(false);
          setPlayerError(errorsRef.current.noAudio);
        })
        .finally(() => {
          releasePriority();
          if (resolveAbortRef.current === controller) resolveAbortRef.current = null;
          if (requestRef.current === myRequest) setIsResolving(false);
        });
      return;
    }

    attachAndPlay();
  }, [ensureAudioGraph]);

  useEffect(() => {
    startPlaybackRef.current = startPlayback;
  }, [startPlayback]);

  // Sayfa/bilesen kapanirken suregiden cozumleme birakilmasin: iptal
  // sunucuya kadar iner ve arkada yt-dlp calisir kalmaz.
  useEffect(() => {
    const ref = resolveAbortRef;
    return () => {
      ref.current?.abort();
      ref.current = null;
    };
  }, []);

  /**
   * Mor modda kuyruk bitince durmak yerine havuzdan benzer parcalarla devam
   * eder. Yeni oneriler siraya eklenir ve ilki hemen calar.
   */
  const tryRefill = useCallback((): boolean => {
    if (shuffleModeRef.current !== "smart") return false;
    const sim = similarityRef.current;
    const effective = queueRef.current;
    const effectiveIds = new Set(effective.map((t) => t.id));
    const pool = sim.pool.filter((t) => canPlayTrack(t) && !effectiveIds.has(t.id));
    if (pool.length === 0) return false;
    const seeds = contextTracksRef.current.length > 0 ? contextTracksRef.current : effective;
    const suggestions = pickSuggestions(pool, seeds, SMART_REFILL, {
      likedIds: sim.likedIds,
      playlists: sim.playlists,
      history: listeningHistoryRef.current,
    });
    if (suggestions.length === 0) return false;
    const nextEffective = [...effective, ...suggestions];
    queueRef.current = nextEffective;
    setQueue(nextEffective);
    applySmartIds([...smartIdsRef.current, ...suggestions.map((s) => s.id)]);
    const order = orderIdsRef.current;
    if (order) applyOrder([...order, ...suggestions.map((s) => s.id)], order.length);
    startPlayback(suggestions[0]!, nextEffective);
    return true;
  }, [applyOrder, applySmartIds, startPlayback]);

  /** Karisik sirada bir adim; sira disi kalmissa guvenli duser. */
  const stepOrdered = useCallback((direction: 1 | -1): void => {
    const order = orderIdsRef.current;
    const effective = queueRef.current;
    const cur = currentRef.current;
    if (!order || !cur) return;
    const pos = order.indexOf(cur.id);
    const base = pos >= 0 ? pos : orderPosRef.current;
    let nextPos = base + direction;
    if (nextPos < 0 || nextPos >= order.length) {
      if (repeatModeRef.current !== "off") {
        nextPos = (nextPos + order.length) % order.length;
      } else if (direction === 1) {
        if (!tryRefill()) setIsPlaying(false);
        return;
      } else {
        return;
      }
    }
    const next = effective.find((t) => t.id === order[nextPos] && canPlayTrack(t));
    if (!next) return;
    applyOrder(order, nextPos);
    startPlayback(next, effective);
  }, [applyOrder, startPlayback, tryRefill]);

  const stepOrderedRef = useRef<(direction: 1 | -1) => void>(() => {});

  useEffect(() => {
    stepOrderedRef.current = stepOrdered;
  }, [stepOrdered]);

  // Tek HTMLAudioElement + gerçek media eventleri.
  useEffect(() => {
    const el = new Audio();
    el.preload = "metadata";
    el.volume = 0.9;
    // Yeni eleman o andaki hizla baslasin; zincir tembel kuruldugunda da
    // guncel ayarla baslatilir (ensureAudioGraph).
    applySpeedToElement(el, remixRef.current.speed);
    audioRef.current = el;

    let lastTick = performance.now();
    const listeningTimer = window.setInterval(() => {
      const now = performance.now();
      const elapsed = Math.min((now - lastTick) / 1000, 1.5);
      lastTick = now;
      const track = currentRef.current;
      if (!track || el.paused || el.ended || el.seeking || el.readyState < 3) return;
      const session = listeningSessionRef.current;
      if (!session.started) {
        session.started = true;
        recordListening(track.id, false);
        recordPlaylistFromContext(false);
      }
      session.seconds += elapsed;
      if (!session.counted && session.seconds >= 30) {
        session.counted = true;
        recordListening(track.id, true);
        recordPlaylistFromContext(true);
      }
    }, 1000);

    const handleTimeUpdate = () => {
      const track = currentRef.current;
      if (!track) return;
      const position = Number.isFinite(el.currentTime) ? Math.max(0, el.currentTime) : 0;
      currentTimeRef.current = position;
      setCurrentTime(position);
      const bucket = Math.floor(position / 5);
      if (bucket !== persistedTimeBucketRef.current) {
        persistedTimeBucketRef.current = bucket;
        savePlaybackSession(track, contextKeyRef.current, position);
      }
    };

    const handleLoadedMetadata = () => {
      const track = currentRef.current;
      if (!track) return;
      const d = Number.isFinite(el.duration) ? el.duration : 0;
      setDuration(d);
      const pending = pendingSeekRef.current;
      if (pending !== null) {
        const position = d > 0 ? Math.min(pending, Math.max(0, d - 0.25)) : pending;
        try {
          el.currentTime = position;
          currentTimeRef.current = position;
          setCurrentTime(position);
          pendingSeekRef.current = null;
        } catch {
          // Kaynak seek desteklemiyorsa baslangictan devam eder.
        }
      }
      if (track.source === "local" && d > 0 && onDurationRef.current) {
        onDurationRef.current(track.id, d);
      }
    };

    const handlePlay = () => {
      setIsPlaying(true);
      const track = currentRef.current;
      if (track) savePlaybackSession(track, contextKeyRef.current, currentTimeRef.current);
    };
    const handlePause = () => {
      setIsPlaying(false);
      const track = currentRef.current;
      if (track) savePlaybackSession(track, contextKeyRef.current, currentTimeRef.current);
    };

    const handleEnded = () => {
      const q = queueRef.current;
      const cur = currentRef.current;
      if (!cur) {
        setIsPlaying(false);
        return;
      }

      if (repeatModeRef.current === "one") {
        startPlaybackRef.current(cur, q);
        return;
      }

      // Karisik gidisat siranin tek sahibidir; dogal mantiga dusmesin.
      if (orderIdsRef.current) {
        stepOrderedRef.current(1);
        return;
      }

      const idx = q.findIndex((t) => t.id === cur.id);
      const rest = idx >= 0 ? q.slice(idx + 1) : [];
      const next = rest.find((t) => canPlayTrack(t));
      if (next) {
        startPlaybackRef.current(next, q);
        return;
      }

      if (repeatModeRef.current === "context") {
        const first = q.find((t) => canPlayTrack(t));
        if (first) {
          startPlaybackRef.current(first, q);
          return;
        }
      } else {
        const fallback = fallbackQueueRef.current;
        const fallbackIndex = fallback.findIndex((t) => t.id === cur.id);
        const candidates = fallbackIndex >= 0
          ? fallback.slice(fallbackIndex + 1)
          : fallback;
        const outside =
          candidates.find((t) => t.id !== cur.id && canPlayTrack(t)) ??
          fallback.find((t) => t.id !== cur.id && canPlayTrack(t));
        if (outside) {
          contextKeyRef.current = "fallback";
          setContextKey("fallback");
          startPlaybackRef.current(outside, fallback);
          return;
        }
      }
      setIsPlaying(false);
    };

    const handleError = () => {
      // Kaynak temizligi (aktif parca kaldirma / bosa alma) sonrasi bos-kaynak
      // error eventi kullaniciya hata olarak gosterilmez.
      try {
        if (!el.currentSrc && !el.getAttribute("src")) return;
      } catch {
        // yok say
      }
      const track = currentRef.current;
      if (!track) return;
      setIsPlaying(false);
      setPlayerError(getUnplayableMessage(track, errorsRef.current));
    };

    el.addEventListener("timeupdate", handleTimeUpdate);
    el.addEventListener("loadedmetadata", handleLoadedMetadata);
    el.addEventListener("play", handlePlay);
    el.addEventListener("pause", handlePause);
    el.addEventListener("ended", handleEnded);
    el.addEventListener("error", handleError);

    return () => {
      window.clearInterval(listeningTimer);
      el.pause();
      el.removeEventListener("timeupdate", handleTimeUpdate);
      el.removeEventListener("loadedmetadata", handleLoadedMetadata);
      el.removeEventListener("play", handlePlay);
      el.removeEventListener("pause", handlePause);
      el.removeEventListener("ended", handleEnded);
      el.removeEventListener("error", handleError);
      el.removeAttribute("src");
      el.load();
      loadedTrackIdRef.current = null;
      try {
        chainRef.current?.dispose();
      } catch {
        // yok say
      }
      chainRef.current = null;
      sourceRef.current = null;
      const graphCtx = audioCtxRef.current;
      audioCtxRef.current = null;
      if (graphCtx) {
        try {
          void graphCtx.close();
        } catch {
          // yok say
        }
      }
      audioRef.current = null;
    };
  }, [recordListening, recordPlaylistFromContext]);

  // Hidrasyon guvenligi: depolanmis remix mount sonrasi async okunur
  // (locale-provider ile ayni iptal edilebilir desen).
  useEffect(() => {
    let cancelled = false;
    void Promise.resolve()
      .then(() => readStoredRemix())
      .then((stored) => {
        if (cancelled) return;
        if (stored === null) return;
        generalRemixRef.current = stored;
        entryRemixRef.current = stored;
        remixRef.current = stored;
        setRemixState(stored);
        const el = audioRef.current;
        if (el) applySpeedToElement(el, stored.speed);
        const chain = chainRef.current;
        if (chain) {
          try {
            chain.apply(stored);
          } catch {
            // yok say
          }
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Etkin ayar her degistiginde (hidrasyonla gelen kayitli ayar dahil) sese
  // uygula: state degisikligi imperatif zamanlamayi kacirsa bile ses
  // senkron kalir. State yazimi yok, yalnizca mevcut eleman/zincire uygular.
  useEffect(() => {
    const el = audioRef.current;
    if (el) applySpeedToElement(el, remix.speed);
    const chain = chainRef.current;
    if (chain) {
      try {
        chain.apply(remix);
      } catch {
        // yok say
      }
    }
  }, [remix]);

  // Esitleyici de ayni desende: mount sonrasi kayittan okunur, her degisimde
  // mevcut zincire uygulanir.
  useEffect(() => {
    let cancelled = false;
    void Promise.resolve()
      .then(() => readStoredEq())
      .then((stored) => {
        if (cancelled || stored === null) return;
        eqRef.current = stored;
        setEqState(stored);
        const chain = chainRef.current;
        if (chain) {
          try {
            chain.applyEq(stored);
          } catch {
            // yok say
          }
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    const chain = chainRef.current;
    if (chain) {
      try {
        chain.applyEq(eq);
      } catch {
        // yok say
      }
    }
  }, [eq]);

  /** Yeni baglamda kuyruk + sira kurulur; calan parca ayri baslatilir. */
  const setupContext = useCallback((context: Track[], startId: string) => {
    contextTracksRef.current = context;
    const { queue: effective, smartIds: ids } = buildEffectiveQueue(context, shuffleModeRef.current);
    applySmartIds(ids);
    queueRef.current = effective;
    setQueue(effective);
    if (shuffleModeRef.current === "off") {
      applyOrder(null, effective.findIndex((t) => t.id === startId));
      return;
    }
    const playableIds = effective.filter(canPlayTrack).map((t) => t.id);
    const order = buildShuffleOrder(playableIds, startId, listeningHistoryRef.current);
    applyOrder(order, Math.max(0, order.indexOf(startId)));
  }, [applyOrder, applySmartIds, buildEffectiveQueue]);

  const playTracks = useCallback(
    (
      tracks: Track[],
      startId: string,
      fallbackTracks: Track[] = tracks,
      contextKey = "default",
    ) => {
      const start = tracks.find((t) => t.id === startId);
      if (!start) return;
      fallbackQueueRef.current = fallbackTracks;
      setFallbackQueue(fallbackTracks);
      contextKeyRef.current = contextKey;
      setContextKey(contextKey);
      if (!canPlayTrack(start)) {
        requestRef.current += 1;
        loadedTrackIdRef.current = null;
        pendingSeekRef.current = null;
        const staleEl = audioRef.current;
        if (staleEl) {
          try {
            staleEl.pause();
          } catch {
            // yok say
          }
          staleEl.removeAttribute("src");
          staleEl.load();
        }
        setQueue(tracks);
        queueRef.current = tracks;
        contextTracksRef.current = tracks;
        applySmartIds([]);
        applyOrder(null, tracks.findIndex((t) => t.id === startId));
        setCurrentTrack(start);
        currentRef.current = start;
        currentTimeRef.current = 0;
        setCurrentTime(0);
        setDuration(start.duration);
        setIsPlaying(false);
        setPlayerError(
          start.source === "local"
            ? errorsRef.current.missingSource
            : errorsRef.current.noAudio,
        );
        return;
      }
      setupContext(tracks, startId);
      startPlayback(start, queueRef.current);
    },
    [applyOrder, applySmartIds, startPlayback, setupContext],
  );

  /**
   * Son parcayi UI ve OS medya oturumuna geri koyar, fakat sayfa acilisinda
   * kendiliginden ses baslatmaz. Kulakliktaki Play daha sonra ayni kaynagi acar.
   */
  const preparePlayback = useCallback(
    (track: Track, position: number, storedContextKey: string, pool: Track[]) => {
      resolveAbortRef.current?.abort();
      resolveAbortRef.current = null;
      requestRef.current += 1;
      const resumeAt = track.duration > 0 && position >= track.duration - 2
        ? 0
        : Math.max(0, position);
      const nextQueue = [track];
      queueRef.current = nextQueue;
      fallbackQueueRef.current = pool;
      contextTracksRef.current = nextQueue;
      contextKeyRef.current = storedContextKey;
      currentRef.current = track;
      currentTimeRef.current = resumeAt;
      pendingSeekRef.current = resumeAt;
      persistedTimeBucketRef.current = Math.floor(resumeAt / 5);
      setQueue(nextQueue);
      setFallbackQueue(pool);
      setContextKey(storedContextKey);
      setCurrentTrack(track);
      setCurrentTime(resumeAt);
      setDuration(track.duration);
      setIsPlaying(false);
      setPlayerError(null);
      applySmartIds([]);
      applyOrder(null, 0);

      const el = audioRef.current;
      const url = getPlayableUrl(track);
      if (!el || !url) return;
      try {
        el.pause();
        el.removeAttribute("src");
        el.load();
        loadedTrackIdRef.current = null;
        // Stream cozumlemesini sayfa acilisinda baslatma. Fiziksel Play komutu
        // geldiginde startPlayback iptal edilebilir resolve yolunu kullanir.
        if (url.startsWith("/api/stream")) return;
        el.src = url;
        loadedTrackIdRef.current = track.id;
        applySpeedToElement(el, remixRef.current.speed);
        el.load();
      } catch {
        loadedTrackIdRef.current = null;
      }
    },
    [applyOrder, applySmartIds],
  );

  useEffect(() => {
    if (restoredSessionRef.current || options.restoreReady === false) return;
    restoredSessionRef.current = true;
    const stored = loadPlaybackSession();
    if (!stored) return;
    const pool = options.pool ?? [];
    const track = resolvePlaybackTrack(stored, pool);
    if (!track) {
      clearPlaybackSession();
      return;
    }
    let cancelled = false;
    void Promise.resolve().then(() => {
      if (!cancelled) preparePlayback(track, stored.position, stored.contextKey, pool);
    });
    return () => {
      cancelled = true;
    };
  }, [options.pool, options.restoreReady, preparePlayback]);

  const toggle = useCallback(() => {
    const el = audioRef.current;
    const track = currentRef.current;
    if (!el || !track) return;
    if (!canPlayTrack(track)) return;
    if (el.paused) {
      if (loadedTrackIdRef.current !== track.id || !el.getAttribute("src")) {
        const nextQueue = queueRef.current.length > 0 ? queueRef.current : [track];
        startPlayback(track, nextQueue, currentTimeRef.current);
        return;
      }
      ensureAudioGraph();
      setPlayerError(null);
      const myRequest = requestRef.current;
      const promise = el.play();
      if (promise && typeof promise.catch === "function") {
        promise.catch((err: unknown) => {
          if (requestRef.current !== myRequest) return;
          const name = getPlayErrorName(err);
          if (name === "AbortError") return;
          if (name === "NotSupportedError") {
            setIsPlaying(false);
            setPlayerError(getUnplayableMessage(track, errorsRef.current));
            return;
          }
          // Kaynak hatasi (handleError) zaten varsa genel mesajla ezme.
          try {
            if (el.error) return;
          } catch {
            // yok say
          }
          setIsPlaying(false);
          setPlayerError(
            name === "NotAllowedError"
              ? errorsRef.current.blocked
              : errorsRef.current.startFailed,
          );
        });
      }
    } else {
      el.pause();
    }
  }, [ensureAudioGraph, startPlayback]);

  const seekTo = useCallback((seconds: number) => {
    const el = audioRef.current;
    if (!el || !Number.isFinite(el.duration)) return;
    const max = el.duration;
    const clamped = Math.max(0, Math.min(seconds, max || 0));
    try {
      el.currentTime = clamped;
      currentTimeRef.current = clamped;
      setCurrentTime(clamped);
      const track = currentRef.current;
      if (track) savePlaybackSession(track, contextKeyRef.current, clamped);
    } catch {
      // seek desteklenmiyorsa sessiz geç
    }
  }, []);

  const setVolume = useCallback((value: number) => {
    const el = audioRef.current;
    const clamped = Math.max(0, Math.min(1, value));
    setVolumeState(clamped);
    if (el) {
      el.volume = clamped;
      if (clamped > 0 && el.muted) {
        el.muted = false;
        setMuted(false);
      }
    }
  }, []);

  const toggleMute = useCallback(() => {
    const el = audioRef.current;
    setMuted((prev) => {
      const next = !prev;
      if (el) el.muted = next;
      return next;
    });
  }, []);

  const playableQueue = useMemo(() => queue.filter((t) => canPlayTrack(t)), [queue]);
  const playableFallbackQueue = useMemo(
    () => fallbackQueue.filter((t) => canPlayTrack(t)),
    [fallbackQueue],
  );

  const currentIndex = useMemo(() => {
    if (!currentTrack) return -1;
    return playableQueue.findIndex((t) => t.id === currentTrack.id);
  }, [playableQueue, currentTrack]);

  const fallbackIndex = useMemo(() => {
    if (!currentTrack) return -1;
    return playableFallbackQueue.findIndex((t) => t.id === currentTrack.id);
  }, [playableFallbackQueue, currentTrack]);

  const canWrapContext =
    currentTrack !== null &&
    playableQueue.some((t) => t.id !== currentTrack.id);
  /** Havuzda kuyruk disinda calinabilir parca varsa mor modun devami gelebilir. */
  const smartMayRefill = useMemo(() => {
    if (shuffleMode !== "smart") return false;
    const pool = options.pool ?? [];
    return pool.some((t) => canPlayTrack(t) && !queue.some((q) => q.id === t.id));
  }, [shuffleMode, options.pool, queue]);
  const orderedActive = orderIds !== null;
  const canGoNext = orderedActive
    ? repeatMode !== "off" || orderPos < orderIds.length - 1 || smartMayRefill
    : repeatMode === "off"
      ? (currentIndex >= 0 && currentIndex < playableQueue.length - 1) ||
        playableFallbackQueue.some((t) => t.id !== currentTrack?.id)
      : canWrapContext;
  const canGoPrev = orderedActive
    ? repeatMode !== "off" || orderPos > 0
    : repeatMode === "off"
      ? currentIndex > 0 || fallbackIndex > 0
      : canWrapContext;

  const playNext = useCallback(() => {
    if (!canGoNext) return;
    if (orderIdsRef.current) {
      stepOrdered(1);
      return;
    }
    const nextInContext = currentIndex >= 0
      ? playableQueue[currentIndex + 1]
      : undefined;
    if (nextInContext) {
      startPlayback(nextInContext, queueRef.current);
      return;
    }
    if (repeatModeRef.current !== "off") {
      const first = playableQueue.find((t) => t.id !== currentRef.current?.id);
      if (first) startPlayback(first, queueRef.current);
      return;
    }
    const candidates = fallbackIndex >= 0
      ? playableFallbackQueue.slice(fallbackIndex + 1)
      : playableFallbackQueue;
    const next =
      candidates.find((t) => t.id !== currentRef.current?.id) ??
      playableFallbackQueue.find((t) => t.id !== currentRef.current?.id);
    if (next) {
      contextKeyRef.current = "fallback";
      setContextKey("fallback");
      startPlayback(next, fallbackQueueRef.current);
    }
  }, [
    canGoNext,
    playableQueue,
    currentIndex,
    playableFallbackQueue,
    fallbackIndex,
    startPlayback,
    stepOrdered,
  ]);

  const playPrev = useCallback(() => {
    const el = audioRef.current;
    // Baştan çalınıyorsa önce başa sar.
    if (el && el.currentTime > 3) {
      seekTo(0);
      return;
    }
    if (!canGoPrev) {
      seekTo(0);
      return;
    }
    if (orderIdsRef.current) {
      stepOrdered(-1);
      return;
    }
    const prevInContext = currentIndex > 0
      ? playableQueue[currentIndex - 1]
      : undefined;
    if (prevInContext) {
      startPlayback(prevInContext, queueRef.current);
      return;
    }
    if (repeatModeRef.current !== "off") {
      const last = [...playableQueue]
        .reverse()
        .find((t) => t.id !== currentRef.current?.id);
      if (last) startPlayback(last, queueRef.current);
      return;
    }
    const prev = fallbackIndex > 0
      ? playableFallbackQueue[fallbackIndex - 1]
      : undefined;
    if (prev) startPlayback(prev, fallbackQueueRef.current);
  }, [
    canGoPrev,
    playableQueue,
    currentIndex,
    playableFallbackQueue,
    fallbackIndex,
    startPlayback,
    seekTo,
    stepOrdered,
  ]);

  const mediaActionsRef = useRef<{
    play: () => void;
    pause: () => void;
    next: () => void;
    previous: () => void;
    seek: (seconds: number) => void;
  }>({
    play: () => {},
    pause: () => {},
    next: () => {},
    previous: () => {},
    seek: () => {},
  });

  useEffect(() => {
    mediaActionsRef.current = {
      play: () => {
        const el = audioRef.current;
        if (el?.paused) toggle();
      },
      pause: () => {
        const el = audioRef.current;
        if (el && !el.paused) el.pause();
      },
      next: playNext,
      previous: playPrev,
      seek: seekTo,
    };
  }, [playNext, playPrev, seekTo, toggle]);

  // Fiziksel kulaklik/klavye tuslarini player aksiyonlarina bagla. Handler'lar
  // ref uzerinden guncel kalir; her queue degisiminde global listener kurulmaz.
  useEffect(() => {
    if (typeof navigator === "undefined" || !("mediaSession" in navigator)) return;
    const session = navigator.mediaSession;
    const setHandler = (
      action: MediaSessionAction,
      handler: MediaSessionActionHandler,
    ) => {
      try {
        session.setActionHandler(action, handler);
      } catch {
        // Tarayici Media Session'in tum aksiyonlarini desteklemek zorunda degil.
      }
    };

    setHandler("play", () => mediaActionsRef.current.play());
    setHandler("pause", () => mediaActionsRef.current.pause());
    setHandler("stop", () => mediaActionsRef.current.pause());
    setHandler("nexttrack", () => mediaActionsRef.current.next());
    setHandler("previoustrack", () => mediaActionsRef.current.previous());
    setHandler("seekbackward", (details) => {
      const offset = details.seekOffset ?? 10;
      mediaActionsRef.current.seek(currentTimeRef.current - offset);
    });
    setHandler("seekforward", (details) => {
      const offset = details.seekOffset ?? 10;
      mediaActionsRef.current.seek(currentTimeRef.current + offset);
    });
    setHandler("seekto", (details) => {
      if (typeof details.seekTime === "number") mediaActionsRef.current.seek(details.seekTime);
    });

    return () => {
      const actions: MediaSessionAction[] = [
        "play",
        "pause",
        "stop",
        "nexttrack",
        "previoustrack",
        "seekbackward",
        "seekforward",
        "seekto",
      ];
      for (const action of actions) {
        try {
          session.setActionHandler(action, null);
        } catch {
          // Desteklenmeyen aksiyon zaten kurulmamistir.
        }
      }
      try {
        session.playbackState = "none";
        session.metadata = null;
      } catch {
        // Sayfa kapanirken tarayici oturumu daha once birakmis olabilir.
      }
    };
  }, []);

  useEffect(() => {
    if (typeof navigator === "undefined" || !("mediaSession" in navigator)) return;
    const session = navigator.mediaSession;
    try {
      session.playbackState = currentTrack
        ? (isPlaying ? "playing" : "paused")
        : "none";
    } catch {
      // Playback state bildirimi desteklenmiyorsa ses yine normal calar.
    }
    if (!currentTrack || typeof MediaMetadata === "undefined") {
      try { session.metadata = null; } catch { /* yok say */ }
      return;
    }
    // Kapak goreceli yol olabilir ("/covers/demo-06.svg"); OS medya
    // bildirimi (Windows SMTC / Android) mutlak adres bekler, yoksa oturum
    // "calan medya yok" sayilip ses tuslari baska akisa gidebilir.
    const artwork = (() => {
      if (!currentTrack.cover) return undefined;
      try {
        const src = new URL(currentTrack.cover, window.location.href).href;
        return [{ src, sizes: "512x512" }];
      } catch {
        return [{ src: currentTrack.cover, sizes: "512x512" }];
      }
    })();
    const metadata = {
      title: currentTrack.title,
      artist: currentTrack.artist,
      album: currentTrack.album,
      ...(artwork ? { artwork } : {}),
    };
    try {
      session.metadata = new MediaMetadata(metadata);
    } catch {
      try {
        session.metadata = new MediaMetadata({
          title: currentTrack.title,
          artist: currentTrack.artist,
          album: currentTrack.album,
        });
      } catch {
        // Bozuk/uyumsuz artwork OS medya tuslarini devre disi birakmasin.
      }
    }
  }, [currentTrack, isPlaying]);

  useEffect(() => {
    if (typeof navigator === "undefined" || !("mediaSession" in navigator)) return;
    const session = navigator.mediaSession;
    const total = duration > 0 ? duration : (currentTrack?.duration ?? 0);
    try {
      if (!currentTrack || !Number.isFinite(total) || total <= 0) {
        session.setPositionState();
        return;
      }
      session.setPositionState({
        duration: total,
        position: Math.max(0, Math.min(currentTime, total)),
        playbackRate: remix.speed || 1,
      });
    } catch {
      // Bazi tarayicilar position state'in tamamini desteklemez.
    }
  }, [currentTime, currentTrack, duration, remix.speed]);

  useEffect(() => {
    const persist = () => {
      const track = currentRef.current;
      if (track) savePlaybackSession(track, contextKeyRef.current, currentTimeRef.current);
    };
    window.addEventListener("pagehide", persist);
    return () => window.removeEventListener("pagehide", persist);
  }, []);

  /** Gri -> yesil -> mor -> gri doner; secim saklanir, ses kesilmeden kuyruk kurulur. */
  const cycleShuffle = useCallback(() => {
    const next: ShuffleMode = shuffleModeRef.current === "off"
      ? "on"
      : shuffleModeRef.current === "on"
        ? "smart"
        : "off";
    shuffleModeRef.current = next;
    setShuffleMode(next);
    saveShuffleMode(next);
    const context = contextTracksRef.current;
    const cur = currentRef.current;
    if (!cur || context.length === 0) return;
    const built = buildEffectiveQueue(context, next);
    let nextEffective = built.queue;
    let nextIds = built.smartIds;
    // Mod dusurulurken calan oneri kuyruktan duserse ses kesilmesin diye korunur.
    if (!nextEffective.some((t) => t.id === cur.id)) {
      nextEffective = [...nextEffective, cur];
      if (smartIdsRef.current.includes(cur.id)) nextIds = [...nextIds, cur.id];
    }
    queueRef.current = nextEffective;
    setQueue(nextEffective);
    applySmartIds(nextIds);
    if (next === "off") {
      applyOrder(null, nextEffective.findIndex((t) => t.id === cur.id));
      return;
    }
    const playableIds = nextEffective.filter(canPlayTrack).map((t) => t.id);
    const order = buildShuffleOrder(playableIds, cur.id, listeningHistoryRef.current);
    applyOrder(order, Math.max(0, order.indexOf(cur.id)));
  }, [applyOrder, applySmartIds, buildEffectiveQueue]);

  const cycleRepeatMode = useCallback(() => {
    const next: RepeatMode = repeatModeRef.current === "off"
      ? "context"
      : repeatModeRef.current === "context"
        ? "one"
        : "off";
    repeatModeRef.current = next;
    setRepeatMode(next);
  }, []);

  const dismissError = useCallback(() => setPlayerError(null), []);

  const setRemix = useCallback((next: RemixSettings) => {
    const sanitized = sanitizeRemix(next);
    remixRef.current = sanitized;
    setRemixState(sanitized);
    if (!currentRef.current || !readTrackRemix(currentRef.current.id)) {
      generalRemixRef.current = sanitized;
      writeStoredRemix(sanitized);
    }
    const el = audioRef.current;
    if (el) applySpeedToElement(el, sanitized.speed);
    const chain = chainRef.current;
    if (chain) {
      try {
        chain.apply(sanitized);
      } catch {
        // yok say
      }
    }
  }, []);

  const setEq = useCallback((next: EqSettings) => {
    const sanitized = sanitizeEq(next);
    eqRef.current = sanitized;
    setEqState(sanitized);
    writeStoredEq(sanitized);
    const chain = chainRef.current;
    if (chain) {
      try {
        chain.applyEq(sanitized);
      } catch {
        // yok say
      }
    }
  }, []);

  const saveTrackRemix = useCallback((): boolean => {
    const track = currentRef.current;
    if (!track || !writeTrackRemix(track.id, remixRef.current)) return false;
    // Saving a song override must not turn its edits into the general preset.
    generalRemixRef.current = entryRemixRef.current;
    writeStoredRemix(generalRemixRef.current);
    return true;
  }, []);

  /** Kaldirilan yerel dosya queue/current'te takilip tekrar calmasin. */
  const removeTrack = useCallback((trackId: string) => {
    requestRef.current += 1;
    const nextQueue = queueRef.current.filter((t) => t.id !== trackId);
    queueRef.current = nextQueue;
    setQueue(nextQueue);
    contextTracksRef.current = contextTracksRef.current.filter((t) => t.id !== trackId);
    applySmartIds(smartIdsRef.current.filter((id) => id !== trackId));
    if (orderIdsRef.current) {
      const nextOrder = orderIdsRef.current.filter((id) => id !== trackId);
      const clamped = trackId === currentRef.current?.id
        ? 0
        : Math.min(orderPosRef.current, Math.max(0, nextOrder.length - 1));
      applyOrder(nextOrder, clamped);
    }
    const nextFallback = fallbackQueueRef.current.filter((t) => t.id !== trackId);
    fallbackQueueRef.current = nextFallback;
    setFallbackQueue(nextFallback);
    if (currentRef.current?.id === trackId) {
      // Hata bastirma icin referansi once temizle: bos-kaynak load() error'u
      // eski parcaya yazilmasin.
      currentRef.current = null;
      currentTimeRef.current = 0;
      pendingSeekRef.current = null;
      loadedTrackIdRef.current = null;
      clearPlaybackSession();
      const el = audioRef.current;
      if (el) {
        try {
          el.pause();
        } catch {
          // yok say
        }
        try {
          el.currentTime = 0;
        } catch {
          // yok say
        }
        el.removeAttribute("src");
        el.load();
      }
      setCurrentTrack(null);
      setIsPlaying(false);
      setCurrentTime(0);
      setDuration(0);
      setPlayerError(null);
    }
  }, [applyOrder, applySmartIds]);

  const removeTrackFromContext = useCallback(
    (trackId: string, contextKey: string) => {
      if (contextKeyRef.current !== contextKey) return;
      const nextQueue = queueRef.current.filter((t) => t.id !== trackId);
      queueRef.current = nextQueue;
      setQueue(nextQueue);
      contextTracksRef.current = contextTracksRef.current.filter((t) => t.id !== trackId);
      applySmartIds(smartIdsRef.current.filter((id) => id !== trackId));
      if (orderIdsRef.current) {
        const nextOrder = orderIdsRef.current.filter((id) => id !== trackId);
        applyOrder(nextOrder, Math.min(orderPosRef.current, Math.max(0, nextOrder.length - 1)));
      }
    },
    [applyOrder, applySmartIds],
  );

  return {
    listeningHistory,
    queue,
    currentTrack,
    currentTrackId: currentTrack?.id ?? null,
    isPlaying,
    currentTime,
    duration,
    volume,
    muted,
    playerError,
    isResolving,
    repeatMode,
    shuffleMode,
    smartIds,
    contextKey,
    remix,
    setRemix,
    eq,
    setEq,
    saveTrackRemix,
    canGoNext,
    canGoPrev,
    playTracks,
    toggle,
    seekTo,
    setVolume,
    toggleMute,
    playNext,
    playPrev,
    cycleRepeatMode,
    cycleShuffle,
    dismissError,
    removeTrack,
    removeTrackFromContext,
  };
}
