"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { LocalTrack } from "../lib/types";
import { LIBRARY_TRACKS } from "../data/tracks";
import { useI18n } from "../components/locale-provider";
import { stableDownloadTrackId } from "../lib/library-identity";

const LOCAL_COVERS = [
  "/covers/demo-01.svg",
  "/covers/demo-02.svg",
  "/covers/demo-03.svg",
  "/covers/demo-04.svg",
  "/covers/demo-05.svg",
  "/covers/demo-06.svg",
  "/covers/demo-07.svg",
  "/covers/demo-08.svg",
  "/covers/demo-09.svg",
  "/covers/demo-10.svg",
];

interface DiskListItem {
  duration?: number;
  fileName: string;
  title: string;
  artist: string;
  album: string;
  origin?: "spotify" | "youtube";
  coverFile?: string;
  externalId?: string;
  libraryId?: string;
  previousFileNames?: string[];
  size: number;
  modifiedAt: number;
}

interface UseDiskLibraryResult {
  tracks: LocalTrack[];
  /** Bilgi dosyasındaki arama kimlikleri; satırdaki düğme buradan grileşir. */
  downloadedExternalIds: string[];
  /** Klasördeki dosya adı kalıpları; kaydı olmayan eski indirmeler için. */
  downloadedStems: string[];
  /** Eski dosya-adi kimliklerini uzantidan bagimsiz kimliklere tasir. */
  legacyIdMapping: Record<string, string>;
  isLoading: boolean;
  error: string | null;
  reload: () => Promise<void>;
  /** Dosya listede görünene kadar sınırlı sayıda yeniden okur. */
  reloadUntilVisible: (fileName: string) => Promise<boolean>;
}

/**
 * Yedek kapak dosya adından türetilir, listedeki sıradan değil. Yeni parça
 * inince sıralama değişse bile herkesin kapağı sabit kalır.
 */
/**
 * Dosya adından indirme kalıbı: uzantı ve " (2)" türü kopya eki atılır,
 * küçük harfe çevrilir. Arama satırındaki adayla birebir aynı dönüşümden
 * geçer, böylece kaydı olmayan eski indirmeler de eşleşir.
 */
function diskStem(fileName: string): string {
  const dot = fileName.lastIndexOf(".");
  const base = dot > 0 ? fileName.slice(0, dot) : fileName;
  return base.replace(/ \(\d+\)$/, "").toLowerCase();
}

function stableCoverFor(fileName: string): string {
  let hash = 5381;
  for (let i = 0; i < fileName.length; i++) {
    hash = ((hash << 5) + hash + fileName.charCodeAt(i)) | 0;
  }
  const index = (hash >>> 0) % LOCAL_COVERS.length;
  return LOCAL_COVERS[index] ?? "/covers/demo-01.svg";
}

/**
 * Tek kaynak `Musics` klasoru: `/api/media/list` okunup `LocalTrack` dizilir.
 *
 * Id dosya adindan turetilir (`disk-...`), boylece begeni/liste kaydi sabit
 * kalir. Sure bilinmez (0); calarken `onLocalDuration` doldurur.
 */
/**
 * Katalog parcalarinin dosya adlari. Bu dosyalar da `Musics` klasorunde
 * duruyor; diskten okunan listeye eklenirse katalogla birlikte iki kez
 * gorunurler. Kataloğun kendi kaydi daha iyi (duzgun baslik, sanatci, sure),
 * o yuzden disk taramasinda bunlar atlanir.
 */
const CATALOG_FILE_NAMES = new Set(
  LIBRARY_TRACKS.map((track) => {
    const url = track.source === "library" ? track.url : "";
    const match = /[?&]f=([^&]+)/.exec(url);
    return match?.[1] ? decodeURIComponent(match[1]) : "";
  }).filter(Boolean),
);

export function useDiskLibrary(): UseDiskLibraryResult {
  const { t } = useI18n();
  const [tracks, setTracks] = useState<LocalTrack[]>([]);
  const [downloadedExternalIds, setDownloadedExternalIds] = useState<string[]>([]);
  const [downloadedStems, setDownloadedStems] = useState<string[]>([]);
  const [legacyIdMapping, setLegacyIdMapping] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const tracksRef = useRef<LocalTrack[]>([]);

  const reload = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/media/list", { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as DiskListItem[];
      const artist = t.files.localArtist;
      const album = t.files.localAlbum;
      const fresh = data.filter((item) => !CATALOG_FILE_NAMES.has(item.fileName));
      const nextMapping: Record<string, string> = {};
      // Bilgi kaydı varsa gerçek başlık/sanatçı/albüm/kaynak ve kapak ordan
      // gelir; yoksa dosya adından türetilir (elle atılan dosyalar).
      const mapped: LocalTrack[] = fresh.map((item) => {
        const id = item.libraryId
          ? stableDownloadTrackId(item.libraryId)
          : `disk-${item.fileName}`;
        if (item.libraryId) {
          nextMapping[`disk-${item.fileName}`] = id;
          for (const previousFileName of item.previousFileNames ?? []) {
            nextMapping[`disk-${previousFileName}`] = id;
          }
        }
        return {
        id,
        title: (item.title || item.fileName).slice(0, 80),
        artist: (item.artist || artist).slice(0, 80),
        album: (item.album || album).slice(0, 80),
        duration: typeof item.duration === "number" && Number.isFinite(item.duration) && item.duration > 0 ? item.duration : 0,
        cover: item.coverFile
          ? `/api/media?f=${encodeURIComponent(item.coverFile)}`
          : stableCoverFor(item.fileName),
        source: "local",
        objectUrl: `/api/media?f=${encodeURIComponent(item.fileName)}`,
        fileName: item.fileName,
        fileSize: item.size,
        ...(item.origin ? { origin: item.origin } : {}),
        ...(item.externalId ? { externalId: item.externalId } : {}),
      };});
      setTracks(mapped);
      tracksRef.current = mapped;
      setLegacyIdMapping(nextMapping);
      setDownloadedExternalIds(
        data.map((item) => item.externalId).filter((id): id is string => !!id),
      );
      setDownloadedStems(data.map((item) => diskStem(item.fileName)));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Liste alınamadı.");
      setTracks([]);
      tracksRef.current = [];
      setDownloadedExternalIds([]);
      setDownloadedStems([]);
      setLegacyIdMapping({});
    } finally {
      setIsLoading(false);
    }
  }, [t]);

  // İndirme/yükleme sonrası tek okuma yetmezse (sunucu yazısı gecikirse)
  // kısa süre izler; kullanıcı yenilemek zorunda kalmaz. Sınırlı deneme.
  const reloadUntilVisible = useCallback(async (fileName: string): Promise<boolean> => {
    for (let attempt = 0; attempt < 4; attempt++) {
      await reload();
      if (tracksRef.current.some((track) => track.fileName === fileName)) return true;
      await new Promise((resolve) => setTimeout(resolve, 1200));
    }
    return tracksRef.current.some((track) => track.fileName === fileName);
  }, [reload]);

  // Baslangicta ve dil degisince bir kez oku. Cagri zamanlayici icinden gidiyor:
  // effect govdesinde dogrudan setState React Compiler lint'ini kiriyor.
  useEffect(() => {
    const timer = setTimeout(() => {
      void reload();
    }, 0);
    return () => clearTimeout(timer);
  }, [reload]);

  return {
    tracks,
    downloadedExternalIds,
    downloadedStems,
    legacyIdMapping,
    isLoading,
    error,
    reload,
    reloadUntilVisible,
  };
}
