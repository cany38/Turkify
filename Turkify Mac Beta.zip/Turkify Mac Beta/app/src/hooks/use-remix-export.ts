"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { RemixSettings } from "../lib/audio-effects";
import type { Track } from "../lib/types";
import { buildRemixFileName, renderRemix } from "../lib/remix-export";
import { getPlayableUrl } from "./use-audio-player";

export type RemixExportStatus =
  | { phase: "idle" }
  | { phase: "rendering" }
  | { phase: "saving" }
  | { phase: "done"; name: string; dir: string }
  | { phase: "error"; message: string };

export interface RemixDirInfo {
  dir: string;
  /** false ise kullanici secmemis, isletim sisteminin indirilenler klasoru gosteriliyor. */
  custom: boolean;
  /** Klasor su an yazilamiyorsa nedeni; yoksa null. */
  problem: string | null;
}

async function readError(response: Response): Promise<string> {
  try {
    const data: unknown = await response.json();
    if (typeof data === "object" && data !== null) {
      const message = (data as Record<string, unknown>).error;
      if (typeof message === "string" && message) return message;
    }
  } catch {
    // Govde JSON degil; alttaki genel metne dus.
  }
  return `Sunucu ${response.status} döndü.`;
}

/**
 * Remix'i dosyaya dokup kullanicinin sectigi klasore yazar.
 *
 * Hedef klasor sunucuda saklaniyor; burada yalnizca okunup gosteriliyor,
 * boylece kullanici her indirmede yeniden yer secmek zorunda kalmaz.
 */
export function useRemixExport() {
  const [dirInfo, setDirInfo] = useState<RemixDirInfo | null>(null);
  const [status, setStatus] = useState<RemixExportStatus>({ phase: "idle" });
  const runningRef = useRef(false);

  useEffect(() => {
    let cancelled = false;
    void fetch("/api/download-dir", { cache: "no-store" })
      .then((response) => (response.ok ? response.json() : null))
      .then((data: unknown) => {
        if (cancelled || typeof data !== "object" || data === null) return;
        const record = data as Record<string, unknown>;
        if (typeof record.dir !== "string") return;
        setDirInfo({
          dir: record.dir,
          custom: record.custom === true,
          problem: typeof record.problem === "string" ? record.problem : null,
        });
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);

  /** Hata metnini dondurur, basarida null. */
  const changeDir = useCallback(async (next: string): Promise<string | null> => {
    let response: Response;
    try {
      response = await fetch("/api/download-dir", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dir: next }),
      });
    } catch {
      return "Sunucuya ulaşılamadı.";
    }
    if (!response.ok) return await readError(response);
    const data: unknown = await response.json().catch(() => null);
    const dir =
      typeof data === "object" && data !== null && typeof (data as Record<string, unknown>).dir === "string"
        ? ((data as Record<string, unknown>).dir as string)
        : next;
    setDirInfo({ dir, custom: true, problem: null });
    return null;
  }, []);

  const exportRemix = useCallback(
    async (track: Track, settings: RemixSettings): Promise<void> => {
      if (runningRef.current) return;
      const url = getPlayableUrl(track);
      if (!url) {
        setStatus({ phase: "error", message: "Bu parçanın ses kaynağı yok." });
        return;
      }
      runningRef.current = true;
      setStatus({ phase: "rendering" });
      try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("Ses dosyası alınamadı.");
        const audioData = await response.arrayBuffer();
        const blob = await renderRemix(audioData, settings);

        setStatus({ phase: "saving" });
        const name = buildRemixFileName(track.title, track.artist, settings);
        const saved = await fetch(`/api/remix/save?name=${encodeURIComponent(name)}`, {
          method: "POST",
          headers: { "Content-Type": "audio/wav" },
          body: blob,
        });
        if (!saved.ok) throw new Error(await readError(saved));
        const data: unknown = await saved.json();
        const record = (typeof data === "object" && data !== null ? data : {}) as Record<string, unknown>;
        const savedName = typeof record.name === "string" ? record.name : name;
        const savedDir = typeof record.dir === "string" ? record.dir : (dirInfo?.dir ?? "");
        setStatus({ phase: "done", name: savedName, dir: savedDir });
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        setStatus({ phase: "error", message: message.slice(0, 200) });
      } finally {
        runningRef.current = false;
      }
    },
    [dirInfo],
  );

  const resetStatus = useCallback(() => setStatus({ phase: "idle" }), []);

  return { dirInfo, status, changeDir, exportRemix, resetStatus };
}
