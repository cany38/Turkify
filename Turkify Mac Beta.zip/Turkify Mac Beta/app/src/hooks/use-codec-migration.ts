"use client";

import { useCallback, useEffect, useState } from "react";
import type { AudioFormat } from "../lib/audio-format";
import type { CodecMigrationFailure } from "../lib/codec-migration";

export interface CodecMigrationStatus {
  id: string;
  format: AudioFormat;
  state: "running" | "completed";
  total: number;
  completed: number;
  succeeded: number;
  skipped: number;
  failed: number;
  percent: number;
  currentTitle?: string;
  manualCount: number;
  failures: CodecMigrationFailure[];
}

async function readResponse(response: Response): Promise<CodecMigrationStatus | null> {
  const data = (await response.json()) as {
    job?: CodecMigrationStatus | null;
    error?: string;
  };
  if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
  return data.job ?? null;
}

export function useCodecMigration() {
  const [status, setStatus] = useState<CodecMigrationStatus | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async (): Promise<CodecMigrationStatus | null> => {
    const response = await fetch("/api/codec-migration", { cache: "no-store" });
    const next = await readResponse(response);
    setStatus(next);
    return next;
  }, []);

  useEffect(() => {
    let stopped = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const poll = async () => {
      let next: CodecMigrationStatus | null = null;
      try {
        next = await refresh();
        if (!stopped) setError(null);
      } catch (pollError) {
        if (!stopped) {
          setError(pollError instanceof Error ? pollError.message : "Durum alınamadı.");
        }
      }
      if (!stopped) timer = setTimeout(poll, next?.state === "running" ? 900 : 4_000);
    };
    void poll();
    return () => {
      stopped = true;
      if (timer) clearTimeout(timer);
    };
  }, [refresh]);

  const request = useCallback(
    async (body: Record<string, string>): Promise<boolean> => {
      if (busy) return false;
      setBusy(true);
      setError(null);
      try {
        const response = await fetch("/api/codec-migration", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        setStatus(await readResponse(response));
        return true;
      } catch (requestError) {
        setError(
          requestError instanceof Error ? requestError.message : "İşlem başlatılamadı.",
        );
        return false;
      } finally {
        setBusy(false);
      }
    },
    [busy],
  );

  const start = useCallback(
    (format: AudioFormat) => request({ action: "start", format }),
    [request],
  );
  const retry = useCallback(
    (id: string) => request({ action: "retry", id }),
    [request],
  );
  const dismiss = useCallback((id: string) => request({ action: "dismiss", id }), [request]);

  return { status, busy, error, start, retry, refresh, dismiss };
}
