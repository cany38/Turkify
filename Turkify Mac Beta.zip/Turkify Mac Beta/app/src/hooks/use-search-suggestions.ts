"use client";

import { useEffect, useState } from "react";

const cache = new Map<string, { values: string[]; expires: number }>();
export function useSearchSuggestions(query: string, enabled: boolean) {
  const [result, setResult] = useState<{ query: string; values: string[] }>({ query: "", values: [] });
  const q = query.trim();
  useEffect(() => {
    if (!enabled || q.length < 2) return;
    const controller = new AbortController();
    const timer = setTimeout(async () => {
      const hit = cache.get(q);
      if (hit && hit.expires > Date.now()) {
        setResult({ query: q, values: hit.values });
        return;
      }
      try {
        const response = await fetch(`/api/suggest?q=${encodeURIComponent(q)}`, { signal: controller.signal });
        const data = await response.json();
        if (controller.signal.aborted) return;
        const values = Array.isArray(data.suggestions) ? data.suggestions.filter((item: unknown) => typeof item === "string") : [];
        if (cache.size >= 100) cache.delete(cache.keys().next().value!);
        cache.set(q, { values, expires: Date.now() + 300_000 });
        setResult({ query: q, values });
      } catch { /* Suggestions must not block search. */ }
    }, cache.has(q) ? 0 : 150);
    return () => { clearTimeout(timer); controller.abort(); };
  }, [q, enabled]);
  return enabled && q.length >= 2 && result.query === q ? result.values : [];
}
