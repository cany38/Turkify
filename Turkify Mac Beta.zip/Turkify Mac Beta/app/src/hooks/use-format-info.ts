"use client";

import { useEffect, useState } from "react";
import type { ExternalTrack } from "../lib/types";
import { buildFormatCacheKey } from "../lib/audio-format";
import type { AudioFormat } from "../lib/audio-format";
import {
  readStoredFormatInfo,
  type FormatInfo,
} from "../lib/format-info-cache";
import { enqueueFormatProbes } from "../lib/format-queue";

export type { FormatInfo } from "../lib/format-info-cache";

/**
 * Sonuc listesindeki parcalarin gercek ses formatini arka planda toplar.
 *
 * Arama API'leri kodek bilgisi vermiyor, her satir icin kaynagi yoklamak
 * gerekiyor ve bu ~2-3 saniye suruyor. Butun yoklamalar tek bir modul
 * kuyruguna gider; boylece ayni anda tek fetch ucarak calma onceligi
 * korunur ve iptal tek noktadan yapilir.
 */
export function useFormatInfo(
  tracks: ExternalTrack[],
  audioFormat: AudioFormat,
): Record<string, FormatInfo | null> {
  const [infoByKey, setInfoByKey] = useState<Record<string, FormatInfo | null>>(
    () => readStoredFormatInfo(),
  );

  useEffect(() => {
    const targets = tracks.map((track) => ({ track, key: buildFormatCacheKey(audioFormat, track) }));
    const pending = targets.filter(({ key }) => !(key in infoByKey));
    if (pending.length === 0) return;

    enqueueFormatProbes(
      pending.map(({ track }) => track),
      audioFormat,
      (key, info) => {
        setInfoByKey((prev) => ({ ...prev, [key]: info }));
      },
    );
  }, [tracks, audioFormat, infoByKey]);

  const current: Record<string, FormatInfo | null> = {};
  for (const track of tracks) {
    const key = buildFormatCacheKey(audioFormat, track);
    if (key in infoByKey) current[track.id] = infoByKey[key] ?? null;
  }
  return current;
}
