"use client";

import { useCallback, useEffect, useState } from "react";
import {
  DEFAULT_AUDIO_FORMAT,
  readStoredAudioFormat,
  writeStoredAudioFormat,
} from "../lib/audio-format";
import type { AudioFormat } from "../lib/audio-format";

export function useAudioFormat() {
  const [audioFormat, setAudioFormatState] = useState<AudioFormat>(DEFAULT_AUDIO_FORMAT);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let cancelled = false;
    void Promise.resolve()
      .then(() => readStoredAudioFormat())
      .then((stored) => {
        if (cancelled) return;
        if (stored !== null) setAudioFormatState(stored);
        setHydrated(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const setAudioFormat = useCallback((format: AudioFormat): boolean => {
    if (!writeStoredAudioFormat(format)) return false;
    setAudioFormatState(format);
    return true;
  }, []);

  return { audioFormat, hydrated, setAudioFormat };
}
