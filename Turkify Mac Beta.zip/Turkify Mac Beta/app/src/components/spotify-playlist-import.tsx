"use client";

import { useState } from "react";
import type { ImportedPlaylistTrack } from "../lib/types";
import type { Locale } from "../lib/i18n";
import { useI18n } from "./locale-provider";

interface Props {
  clientId?: string;
  clientSecret?: string;
  onImport: (
    name: string,
    cover: string | undefined,
    tracks: ImportedPlaylistTrack[],
    spotifyId: string,
  ) => void;
}

interface ImportStrings {
  title: string;
  intro: string;
  urlLabel: string;
  import: string;
  importing: string;
  imported: (p: { count: number; skipped: number }) => string;
  privateHint: string;
  updateNote: string;
}

const STRINGS: Record<Locale, ImportStrings> = {
  tr: {
    title: "Spotify’dan playlist aktar",
    intro:
      "Public playlist bağlantısını yapıştır, liste adı, kapağı ve tüm şarkılar Turkify’a kaydedilir. Giriş yapman gerekmez, ses dosyaları otomatik indirilmez, sonra satırdan indirirsin.",
    urlLabel: "Playlist bağlantısı (public olmalı)",
    import: "Playlisti aktar",
    importing: "Aktarılıyor…",
    imported: (p: { count: number; skipped: number }) =>
      `${p.count} parça aktarıldı.` + (p.skipped > 0 ? ` ${p.skipped} kayıt atlandı.` : ""),
    privateHint: "Private liste aktarılamaz. Spotify’da listeyi public yapıp bağlantıyı öyle yapıştır.",
    updateNote: "Aynı Spotify listesini tekrar aktarırsan kopya oluşmaz, mevcut liste güncellenir.",
  },
  en: {
    title: "Import playlists from Spotify",
    intro:
      "Paste a public playlist link, the name, cover and all tracks are saved to Turkify. No login needed, audio files are not downloaded automatically, download them per row later.",
    urlLabel: "Playlist link (must be public)",
    import: "Import playlist",
    importing: "Importing…",
    imported: (p: { count: number; skipped: number }) =>
      `${p.count} tracks imported.` + (p.skipped > 0 ? ` ${p.skipped} entries skipped.` : ""),
    privateHint: "Private lists cannot be imported. Make the list public on Spotify, then paste the link.",
    updateNote: "Re-importing the same Spotify list updates it instead of duplicating.",
  },
  az: {
    title: "Spotify-dan pleylist idxal et",
    intro:
      "Hamı üçün açıq pleylist keçidini yapışdırın; pleylistin adı, üz qabığı və bütün mahnıları Turkify-da saxlanılacaq. Hesaba daxil olmaq lazım deyil. Audio fayllar avtomatik endirilmir, onları daha sonra ayrı-ayrılıqda endirə bilərsiniz.",
    urlLabel: "Pleylist keçidi (hamı üçün açıq olmalıdır)",
    import: "Pleylisti idxal et",
    importing: "İdxal olunur…",
    imported: (p) =>
      `${p.count} mahnı idxal olundu.` + (p.skipped > 0 ? ` ${p.skipped} qeyd ötürüldü.` : ""),
    privateHint: "Məxfi pleylisti idxal etmək mümkün deyil. Spotify-da pleylisti hamı üçün açıq edin və keçidi yenidən yapışdırın.",
    updateNote: "Eyni Spotify pleylistini yenidən idxal etdikdə surət yaradılmır, mövcud pleylist yenilənir.",
  },
};

export function SpotifyPlaylistImport({ clientId, clientSecret, onImport }: Props) {
  const { locale } = useI18n();
  const t = STRINGS[locale];
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [isError, setIsError] = useState(false);

  async function importPlaylist() {
    if (!url.trim()) return;
    setBusy(true);
    setMessage(null);
    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (clientId && clientSecret) {
        headers["x-spotify-client-id"] = clientId;
        headers["x-spotify-client-secret"] = clientSecret;
      }
      const response = await fetch("/api/spotify/playlist", {
        method: "POST",
        headers,
        body: JSON.stringify({ url }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      onImport(data.name, data.cover, data.tracks, data.id);
      setIsError(false);
      setMessage(t.imported({ count: data.tracks.length, skipped: data.skipped ?? 0 }));
    } catch (e) {
      setIsError(true);
      setMessage(e instanceof Error ? e.message : t.privateHint);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="flex max-w-2xl flex-col gap-3 border-t border-[#282828] pt-6">
      <h2 className="text-xl font-bold">{t.title}</h2>
      <p className="text-sm text-[#B3B3B3]">{t.intro}</p>
      <label htmlFor="spotify-playlist-url" className="text-sm font-medium">
        {t.urlLabel}
      </label>
      <input
        id="spotify-playlist-url"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        placeholder="https://open.spotify.com/playlist/..."
        autoComplete="off"
        spellCheck={false}
        className="min-h-[44px] rounded-lg border border-[#282828] bg-[#121212] px-3 text-sm text-white"
      />
      <div>
        <button
          type="button"
          disabled={busy || !url.trim()}
          onClick={() => void importPlaylist()}
          className="min-h-[44px] w-fit rounded-full bg-[#1DB954] px-5 text-sm font-bold text-black disabled:cursor-not-allowed disabled:opacity-40"
        >
          {busy ? t.importing : t.import}
        </button>
      </div>
      {message && (
        <p role={isError ? "alert" : "status"} className={`text-sm ${isError ? "text-[#FFB4BC]" : "text-[#B3B3B3]"}`}>
          {message}
        </p>
      )}
      <p className="text-xs text-[#8A8A8A]">{t.privateHint}</p>
      <p className="text-xs text-[#8A8A8A]">{t.updateNote}</p>
    </section>
  );
}
