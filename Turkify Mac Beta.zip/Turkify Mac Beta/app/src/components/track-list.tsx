"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { ExternalTrack, LocalTrack, Playlist, Track } from "../lib/types";
import { formatDuration } from "../data/tracks";
import { playlistArtwork } from "../lib/playlist-art";
import { CheckIcon, DownloadIcon, HeartIcon, PlusIcon, TrashIcon } from "./icons";
import { useI18n } from "./locale-provider";
import { useFormatInfo } from "../hooks/use-format-info";
import type { DownloadState } from "../hooks/use-download";
import { DEFAULT_AUDIO_FORMAT, type AudioFormat } from "../lib/audio-format";
import { TrackCover } from "./track-cover";
import type { FormatInfo } from "../lib/format-info-cache";

interface TrackListDownloadTools {
  tracks: ExternalTrack[];
  audioFormat: AudioFormat;
  downloadedIds: string[];
  downloadedFormats: Record<string, FormatInfo>;
  states: Record<string, DownloadState>;
  bulkRunning: boolean;
  download: (
    track: ExternalTrack,
    onSaved: (local: LocalTrack) => void,
    formatOverride?: AudioFormat,
  ) => Promise<boolean>;
  onDownloaded: (track: LocalTrack) => void;
}

interface TrackListProps {
  tracks: Track[];
  likedIds: string[];
  currentTrackId: string | null;
  isPlaying: boolean;
  playlists: Playlist[];
  emptyMessage: string;
  showRemove?: { playlistId: string };
  onPlay: (track: Track) => void;
  onToggleLike: (trackId: string) => void;
  onAddToPlaylist: (playlistId: string, trackId: string) => string;
  onRemoveTrack: (track: Track) => void;
  onRemoveFromPlaylist?: (playlistId: string, trackId: string) => void;
  downloadTools?: TrackListDownloadTools;
}

export function TrackList({
  tracks,
  likedIds,
  currentTrackId,
  playlists,
  emptyMessage,
  showRemove,
  onPlay,
  onToggleLike,
  onAddToPlaylist,
  onRemoveTrack,
  onRemoveFromPlaylist,
  downloadTools,
}: TrackListProps) {
  const [pickerFor, setPickerFor] = useState<string | null>(null);
  const [pickerMessage, setPickerMessage] = useState<string | null>(null);
  const [visibleFormatIds, setVisibleFormatIds] = useState<string[]>([]);
  const listRef = useRef<HTMLUListElement | null>(null);
  const { t } = useI18n();
  const downloadTracks = useMemo(
    () => downloadTools?.tracks ?? [],
    [downloadTools?.tracks],
  );
  const downloadTrackIds = useMemo(
    () => downloadTracks.map((track) => track.id),
    [downloadTracks],
  );
  const downloadById = useMemo(
    () => new Map(downloadTracks.map((track) => [track.id, track])),
    [downloadTracks],
  );
  const downloadedIds = useMemo(
    () => new Set(downloadTools?.downloadedIds ?? []),
    [downloadTools?.downloadedIds],
  );

  // Yuzlerce playlist parcasi olabilir. Tek observer yalniz gorunen satirlari
  // format kuyruguna ekler; bir kez gorulen satir cache icin listede kalir.
  useEffect(() => {
    const root = listRef.current;
    if (!root || downloadTrackIds.length === 0) return;
    const nodes = Array.from(
      root.querySelectorAll<HTMLElement>("[data-download-track-id]"),
    );
    if (typeof IntersectionObserver === "undefined") {
      const timer = window.setTimeout(() => setVisibleFormatIds(downloadTrackIds), 0);
      return () => window.clearTimeout(timer);
    }
    const observer = new IntersectionObserver(
      (entries) => {
        const entered = entries
          .filter((entry) => entry.isIntersecting)
          .map((entry) => (entry.target as HTMLElement).dataset.downloadTrackId)
          .filter((id): id is string => Boolean(id));
        if (entered.length === 0) return;
        setVisibleFormatIds((previous) => Array.from(new Set([...previous, ...entered])));
        for (const entry of entries) {
          if (entry.isIntersecting) observer.unobserve(entry.target);
        }
      },
      { rootMargin: "240px 0px" },
    );
    for (const node of nodes) observer.observe(node);
    return () => observer.disconnect();
  }, [downloadTrackIds]);

  const visibleIdSet = useMemo(() => new Set(visibleFormatIds), [visibleFormatIds]);
  const formatTargets = useMemo(
    () => downloadTracks.filter(
      (track) => visibleIdSet.has(track.id) && !downloadTools?.downloadedFormats[track.id],
    ),
    [downloadTracks, downloadTools?.downloadedFormats, visibleIdSet],
  );
  const formats = useFormatInfo(
    formatTargets,
    downloadTools?.audioFormat ?? DEFAULT_AUDIO_FORMAT,
  );

  if (tracks.length === 0) {
    return (
      <p role="status" className="py-8 text-center text-[15px] text-[#B3B3B3]">
        {emptyMessage}
      </p>
    );
  }

  return (
    <ul ref={listRef} className="flex flex-col" aria-label={t.trackList.listLabel}>
      {tracks.map((track, index) => {
        const isCurrent = currentTrackId === track.id;
        const liked = likedIds.includes(track.id);
        const pickerOpen = pickerFor === track.id;
        const downloadTrack = downloadById.get(track.id);
        const downloadState = downloadTrack ? downloadTools?.states[downloadTrack.id] : undefined;
        const isDownloading = downloadState?.stage === "downloading";
        const isDownloadError = downloadState?.stage === "error";
        const needsAacConfirmation = downloadState?.stage === "needs-aac-confirmation";
        const canRetryAsAac = needsAacConfirmation || Boolean(isDownloadError && downloadState?.aacRetryAvailable);
        const isDownloaded = Boolean(
          downloadTrack &&
            (downloadedIds.has(downloadTrack.id) || downloadState?.stage === "done"),
        );
        const format = downloadTrack
          ? downloadTools?.downloadedFormats[downloadTrack.id] ?? formats[downloadTrack.id]
          : undefined;
        const codecLabel = format
          ? `${format.codec.split(".")[0]?.toUpperCase() ?? ""}${format.bitrate ? ` ${format.bitrate}k` : ""}`
          : null;
        const codecTitle = format
          ? t.externalSearch.codecTitle({
              codec: format.codec,
              ext: format.ext || "-",
              rate: format.sampleRate ? `${Math.round(format.sampleRate / 1000)} kHz` : "-",
            })
          : undefined;
        return (
          <li
            key={track.id}
            className="flex flex-wrap"
            {...(downloadTrack ? { "data-download-track-id": downloadTrack.id } : {})}
          >
            <div
              className={`relative flex min-h-[64px] min-w-0 basis-full items-center gap-1 rounded-lg px-2 py-2 sm:gap-4 sm:px-4 ${
                isCurrent ? "bg-[#282828]" : ""
              }`}
            >
              <button
                type="button"
                onClick={() => onPlay(track)}
                title={t.trackList.playTrack({ title: track.title })}
                aria-label={t.trackList.playTrack({ title: track.title })}
                className="absolute inset-0 rounded-lg transition-colors hover:bg-[#282828]/60 focus-visible:z-20 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954]"
              />
              <span className="pointer-events-none relative z-10 hidden w-6 shrink-0 text-right text-sm text-[#B3B3B3] tabular-nums sm:block">
                {index + 1}
              </span>
              <span className="pointer-events-none relative z-10 flex min-w-0 flex-1 items-center gap-3 text-left">
              <TrackCover
                src={track.cover}
                fallbackSrc={track.fallbackCover}
                className="h-12 w-12 shrink-0 rounded"
              />
              <span className="flex min-w-0 flex-1 flex-col">
                <span className="truncate text-[15px] font-medium text-white">
                  {track.title}
                  {track.source === "local" && track.origin && (
                    <span
                      className={`ml-2 rounded px-1.5 py-0.5 align-middle text-[11px] font-medium ${
                        track.origin === "spotify"
                          ? "bg-[#1DB954]/20 text-[#1DB954]"
                          : "bg-[#FF0000]/20 text-[#FF6B6B]"
                      }`}
                    >
                      {track.origin === "spotify"
                        ? t.trackList.badgeSpotify
                        : t.trackList.badgeYoutube}
                    </span>
                  )}
                </span>
                <span className="truncate text-sm text-[#B3B3B3]">
                  {track.artist} • {track.album}
                </span>
                {downloadTrack && (
                  <span className="mt-1 min-h-4 text-[10px] text-[#8A8A8A] sm:hidden">
                    {format === undefined ? (
                      "…"
                    ) : codecLabel ? (
                      <span className="rounded border border-[#3E3E3E] px-1.5 py-0.5">
                        {codecLabel}
                      </span>
                    ) : null}
                  </span>
                )}
                {isDownloadError && !isDownloaded && downloadState?.message && (
                  <span role="alert" className="mt-1 max-w-[24rem] truncate text-[11px] text-[#FFB4BC]">
                    {t.download.failedPrefix} {downloadState.message}
                  </span>
                )}
              </span>
              </span>
              {downloadTrack && (
                <span
                  className="pointer-events-none relative z-10 hidden min-w-[72px] shrink-0 text-right text-xs text-[#8A8A8A] sm:block"
                  title={codecTitle}
                >
                  {format === undefined ? (
                    "…"
                  ) : codecLabel ? (
                    <span className="rounded border border-[#3E3E3E] px-1.5 py-0.5">
                      {codecLabel}
                    </span>
                  ) : null}
                </span>
              )}
              <span className="pointer-events-none relative z-10 hidden shrink-0 text-sm text-[#B3B3B3] tabular-nums sm:block">
                {formatDuration(track.duration)}
              </span>
              <div className="relative z-20 flex shrink-0 items-center gap-0 sm:gap-1">
              {downloadTrack && downloadTools && (
                <>
                {canRetryAsAac && (
                  <span className="mr-1 flex max-w-[18rem] items-center gap-2">
                    <span className="text-[11px] leading-tight text-[#FFCC80]">
                      {needsAacConfirmation
                        ? t.download.opusUnavailableQuestion
                        : t.download.opusFailedAacQuestion}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        void downloadTools.download(downloadTrack, downloadTools.onDownloaded, "aac");
                      }}
                      className="min-h-[32px] shrink-0 rounded-full bg-[#1DB954] px-3 text-[11px] font-bold text-black hover:scale-105 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954]"
                    >
                      {t.download.useAac}
                    </button>
                  </span>
                )}
                {!canRetryAsAac && <button
                  type="button"
                  disabled={isDownloading || isDownloaded || downloadTools.bulkRunning}
                  onClick={() => {
                    void downloadTools.download(downloadTrack, (local) => {
                      downloadTools.onDownloaded(local);
                    });
                  }}
                  aria-label={
                    isDownloaded
                      ? `${t.download.done}: ${track.title}`
                      : isDownloading
                        ? `${t.download.downloading}: ${track.title}`
                      : `${t.download.action} ${track.title}`
                  }
                  title={
                    isDownloaded
                      ? t.download.done
                      : isDownloading
                        ? t.download.downloading
                        : t.download.action
                  }
                  className={`flex h-9 w-9 min-h-[36px] min-w-[36px] items-center justify-center rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] disabled:cursor-default ${
                    isDownloaded
                      ? "text-[#1DB954]"
                      : isDownloading
                        ? "bg-[#282828] text-[#1DB954]"
                      : isDownloadError
                        ? "text-[#FF0000] hover:bg-[#282828] hover:text-[#FF6B6B]"
                        : "text-[#B3B3B3] hover:bg-[#282828] hover:text-white"
                  }`}
                >
                  {isDownloaded ? (
                    <CheckIcon className="h-5 w-5" />
                  ) : (
                    <DownloadIcon className={`h-5 w-5 ${isDownloading ? "animate-pulse" : ""}`} />
                  )}
                </button>}
                </>
              )}
              <button
                type="button"
                onClick={() => onToggleLike(track.id)}
                aria-pressed={liked}
                aria-label={
                  liked
                    ? t.trackList.unlikeTrack({ title: track.title })
                    : t.trackList.likeTrack({ title: track.title })
                }
                title={liked ? t.trackList.unlikeTitle : t.trackList.likeTitle}
                className={`flex h-11 w-11 items-center justify-center rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] hover:bg-[#282828] ${
                  liked ? "text-[#FF6B81]" : "text-[#B3B3B3] hover:text-[#FF6B81]"
                }`}
              >
                <HeartIcon className="h-5 w-5" filled={liked} />
              </button>
                <button
                  type="button"
                  onClick={() => {
                    setPickerFor(pickerOpen ? null : track.id);
                    setPickerMessage(null);
                  }}
                  aria-expanded={pickerOpen}
                  aria-label={t.trackList.addToList({ title: track.title })}
                  title={t.trackList.addToListTitle}
                  className="flex h-11 w-11 items-center justify-center rounded-full text-[#B3B3B3] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] hover:bg-[#282828] hover:text-white"
                >
                  <PlusIcon className="h-5 w-5" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (showRemove && onRemoveFromPlaylist) {
                      onRemoveFromPlaylist(showRemove.playlistId, track.id);
                    } else {
                      onRemoveTrack(track);
                    }
                  }}
                  aria-label={
                    showRemove
                      ? t.trackList.removeFromList({ title: track.title })
                      : t.trackList.removeFromLibrary({ title: track.title })
                  }
                  title={
                    showRemove
                      ? t.trackList.removeFromListTitle
                      : t.trackList.removeFromLibraryTitle
                  }
                  className="flex h-11 w-11 items-center justify-center rounded-full text-[#B3B3B3] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] hover:bg-[#282828] hover:text-white"
                >
                  <TrashIcon className="h-5 w-5" />
                </button>
              </div>
            </div>
            {pickerOpen && (
              <div className="basis-full pl-1 sm:pl-10">
                {playlists.length === 0 ? (
                  <p className="rounded-lg bg-[#181818] px-3 py-2 text-sm text-[#B3B3B3]">
                    {t.trackList.createFirst}
                  </p>
                ) : (
                  <div className="rounded-lg bg-[#181818] p-2">
                    <p className="px-2 pt-1 text-sm font-medium text-white">
                      {t.trackList.whichList}
                    </p>
                    <ul className="plk-scroll mt-1 flex max-h-64 flex-col gap-1 overflow-y-auto">
                      {playlists.map((p) => {
                        const contains = p.trackIds.includes(track.id);
                        return (
                          <li key={p.id}>
                            <button
                              type="button"
                              onClick={() => {
                                const message = onAddToPlaylist(p.id, track.id);
                                setPickerMessage(message);
                              }}
                              aria-label={`${p.name} (${t.playlistPanel.trackCount({ count: p.trackIds.length })})`}
                              className="flex min-h-[56px] w-full items-center gap-3 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-[#282828] focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                            >
                              <img
                                src={playlistArtwork(p)}
                                alt=""
                                loading="lazy"
                                className="h-10 w-10 shrink-0 rounded object-cover"
                              />
                              <span className="min-w-0 flex-1">
                                <span className="block truncate text-sm font-semibold text-white">
                                  {p.name}
                                </span>
                                <span className="block text-xs text-[#B3B3B3]">
                                  {t.playlistPanel.trackCount({ count: p.trackIds.length })}
                                </span>
                              </span>
                              {contains ? (
                                <CheckIcon className="h-5 w-5 shrink-0 text-[#1DB954]" />
                              ) : (
                                <PlusIcon className="h-5 w-5 shrink-0 text-[#B3B3B3]" />
                              )}
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                    {pickerMessage && (
                      <p role="status" className="px-2 pb-1 pt-1 text-sm text-[#B3B3B3]">
                        {pickerMessage}
                      </p>
                    )}
                  </div>
                )}
              </div>
            )}
          </li>
        );
      })}
    </ul>
  );
}
