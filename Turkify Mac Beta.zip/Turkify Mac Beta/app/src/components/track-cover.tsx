"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";

const MAX_CONCURRENT_COVERS = 2;
const COVER_TIMEOUT_MS = 2_000;

interface CoverJob {
  cancelled: boolean;
  key: string;
  urls: string[];
  onReady: (url: string) => void;
}

const pendingJobs: CoverJob[] = [];
const resolvedCovers = new Map<string, string>();
let activeJobs = 0;

function preloadCover(url: string): Promise<boolean> {
  return new Promise((resolve) => {
    const image = new window.Image();
    let settled = false;
    const finish = (ok: boolean) => {
      if (settled) return;
      settled = true;
      window.clearTimeout(timer);
      image.onload = null;
      image.onerror = null;
      if (!ok) image.src = "";
      resolve(ok);
    };
    const timer = window.setTimeout(() => finish(false), COVER_TIMEOUT_MS);
    image.decoding = "async";
    image.fetchPriority = "low";
    image.onload = () => finish(true);
    image.onerror = () => finish(false);
    image.src = url;
  });
}

function pumpCoverQueue(): void {
  while (activeJobs < MAX_CONCURRENT_COVERS && pendingJobs.length > 0) {
    // Yeni görünür olan satırlar, hızlı scroll sırasında eski kuyrukların önüne geçer.
    const job = pendingJobs.pop();
    if (!job || job.cancelled) continue;
    activeJobs += 1;
    void (async () => {
      for (const url of job.urls) {
        if (job.cancelled) return;
        if (await preloadCover(url)) {
          resolvedCovers.set(job.key, url);
          if (!job.cancelled) job.onReady(url);
          return;
        }
      }
    })().finally(() => {
      activeJobs -= 1;
      pumpCoverQueue();
    });
  }
}

function enqueueCover(
  primary: string,
  fallback: string | undefined,
  onReady: (url: string) => void,
): () => void {
  const urls = Array.from(new Set([primary, fallback].filter((url): url is string => Boolean(url))));
  const key = urls.join("\n");
  const cached = resolvedCovers.get(key);
  if (cached) {
    const timer = window.setTimeout(() => onReady(cached), 0);
    return () => window.clearTimeout(timer);
  }
  const job: CoverJob = { cancelled: false, key, urls, onReady };
  pendingJobs.push(job);
  pumpCoverQueue();
  return () => {
    job.cancelled = true;
  };
}

interface TrackCoverProps {
  src: string;
  fallbackSrc?: string;
  className: string;
}

/** Kapak isteklerini sınırlar; ses isteği browser connection kuyruğunda beklemez. */
export function TrackCover({ src, fallbackSrc, className }: TrackCoverProps) {
  const hostRef = useRef<HTMLSpanElement | null>(null);
  const [visible, setVisible] = useState(false);
  const coverKey = `${src}\n${fallbackSrc ?? ""}`;
  const [ready, setReady] = useState<{ key: string; src: string } | null>(null);
  const readySrc = ready?.key === coverKey ? ready.src : null;

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    if (typeof IntersectionObserver === "undefined") {
      const timer = window.setTimeout(() => setVisible(true), 0);
      return () => window.clearTimeout(timer);
    }
    const observer = new IntersectionObserver(
      (entries) => {
        if (!entries.some((entry) => entry.isIntersecting)) return;
        setVisible(true);
        observer.disconnect();
      },
      { rootMargin: "160px 0px" },
    );
    observer.observe(host);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!visible || !src) return;
    return enqueueCover(src, fallbackSrc, (url) => setReady({ key: coverKey, src: url }));
  }, [coverKey, fallbackSrc, src, visible]);

  return (
    <span ref={hostRef} aria-hidden="true" className={`block bg-[#242424] ${className}`}>
      {readySrc ? (
        <Image
          src={readySrc}
          alt=""
          aria-hidden="true"
          width={48}
          height={48}
          fetchPriority="low"
          unoptimized
          onError={() => {
            if (fallbackSrc && readySrc !== fallbackSrc) {
              setReady({ key: coverKey, src: fallbackSrc });
            }
          }}
          className="h-full w-full rounded object-cover"
        />
      ) : null}
    </span>
  );
}
