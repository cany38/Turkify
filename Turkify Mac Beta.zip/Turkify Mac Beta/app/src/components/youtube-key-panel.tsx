"use client";

import { useState } from "react";
import type { YoutubeKey } from "../lib/types";
import { isValidYoutubeApiKey } from "../lib/youtube-key";
import {
  YT_VERIFY_STEP_ORDER,
  isYtVerifyEvent,
  type YtVerifyStatus,
  type YtVerifyStepId,
} from "../lib/youtube-verify";
import { useI18n } from "./locale-provider";

interface YoutubeKeyPanelProps {
  initialKey: string;
  keyFailed: boolean;
  onSave: (key: YoutubeKey) => void;
}

/** Yesil onay bir an gorunsun diye kayit kisa bir gecikmeyle yapilir. */
const SAVE_DELAY_MS = 1200;

type StatusMap = Record<YtVerifyStepId, YtVerifyStatus>;

const IDLE_STATUSES: StatusMap = { format: "pending", key: "pending" };

function StatusMark({ status, label }: { status: YtVerifyStatus; label: string }) {
  const base = "flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[11px] font-bold";
  if (status === "ok") {
    return (
      <span role="img" aria-label={label} className={`${base} bg-[#1DB954] text-black`}>
        ✓
      </span>
    );
  }
  if (status === "fail") {
    return (
      <span role="img" aria-label={label} className={`${base} bg-[#E22134] text-white`}>
        ✕
      </span>
    );
  }
  if (status === "running") {
    return (
      <span
        role="img"
        aria-label={label}
        className={`${base} animate-spin border-2 border-[#B3B3B3] border-t-transparent`}
      />
    );
  }
  return <span role="img" aria-label={label} className={`${base} border border-[#535353]`} />;
}

export function YoutubeKeyPanel({ initialKey, keyFailed, onSave }: YoutubeKeyPanelProps) {
  const { t } = useI18n();
  const [apiKey, setApiKey] = useState(initialKey);
  const [error, setError] = useState<string | null>(null);
  const [statuses, setStatuses] = useState<StatusMap>(IDLE_STATUSES);
  const [isVerifying, setIsVerifying] = useState(false);
  const [saved, setSaved] = useState(false);

  const stepLabels: Record<YtVerifyStepId, string> = {
    format: t.youtubeKey.stepFormat,
    key: t.youtubeKey.stepKey,
  };

  const statusLabels: Record<YtVerifyStatus, string> = {
    pending: t.youtubeKey.statusPending,
    running: t.youtubeKey.statusRunning,
    ok: t.youtubeKey.statusOk,
    fail: t.youtubeKey.statusFail,
  };

  async function handleVerifyAndSave() {
    const key: YoutubeKey = { apiKey: apiKey.trim() };
    setError(null);
    setSaved(false);
    setIsVerifying(true);
    setStatuses({ format: "running", key: "pending" });

    // 1) Bicim: aga cikmadan once yanlis kopyalamayi yakala.
    if (!isValidYoutubeApiKey(key.apiKey)) {
      setStatuses({ format: "fail", key: "pending" });
      setError(t.youtubeKey.invalidKey);
      setIsVerifying(false);
      return;
    }
    setStatuses({ format: "ok", key: "pending" });

    // 2) Sunucu adimi NDJSON olarak akar; satir geldikce isaretle.
    try {
      const res = await fetch("/api/youtube/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(key),
      });
      if (!res.ok || !res.body) {
        throw new Error(t.youtubeKey.verifyRequestFailed({ status: res.status }));
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      const seen: StatusMap = { format: "ok", key: "pending" };
      let buffer = "";
      let failure: string | null = null;

      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.trim()) continue;
          let parsed: unknown;
          try {
            parsed = JSON.parse(line);
          } catch {
            continue;
          }
          if (!isYtVerifyEvent(parsed)) continue;
          seen[parsed.step] = parsed.status;
          setStatuses({ ...seen });
          if (parsed.status === "fail") {
            failure = parsed.message ?? t.youtubeKey.keyFailed;
          }
        }
      }

      if (failure || seen.key !== "ok") {
        setError(failure ?? t.youtubeKey.keyFailed);
        setIsVerifying(false);
        return;
      }

      setSaved(true);
      setIsVerifying(false);
      setTimeout(() => onSave(key), SAVE_DELAY_MS);
    } catch (err) {
      setStatuses((current) => ({
        format: current.format,
        key: current.key === "running" ? "fail" : current.key,
      }));
      setError(err instanceof Error ? err.message : t.youtubeKey.keyFailed);
      setIsVerifying(false);
    }
  }

  return (
    <div className="flex flex-col gap-4 rounded-lg bg-[#181818] p-4 sm:p-6">
      <h2 id="youtube-key-title" className="text-xl font-bold sm:text-2xl">
        {t.youtubeKey.title}
      </h2>
      <p className="text-[15px] text-[#B3B3B3]">{t.youtubeKey.intro}</p>
      <ol className="flex list-decimal flex-col gap-2 pl-6 text-[15px] text-white">
        {t.youtubeKey.steps.map((step, i) => (
          <li key={i}>{step}</li>
        ))}
      </ol>
      <div className="flex max-w-xl flex-col gap-3">
        <div className="flex flex-col gap-1">
          <label htmlFor="youtube-api-key" className="text-sm font-medium text-white">
            {t.youtubeKey.apiKeyLabel}
          </label>
          <input
            id="youtube-api-key"
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder={t.youtubeKey.apiKeyPlaceholder}
            autoComplete="off"
            spellCheck={false}
            className="min-h-[44px] rounded-lg border border-[#282828] bg-[#121212] px-3 text-sm text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
          />
        </div>

        <div className="flex flex-col gap-2 rounded-lg border border-[#282828] bg-[#121212] p-3">
          <p className="text-sm font-medium text-white">{t.youtubeKey.verifyTitle}</p>
          <ul className="flex flex-col gap-2" aria-live="polite">
            {YT_VERIFY_STEP_ORDER.map((id) => (
              <li key={id} className="flex items-center gap-2 text-sm">
                <StatusMark status={statuses[id]} label={statusLabels[statuses[id]]} />
                <span className={statuses[id] === "pending" ? "text-[#6A6A6A]" : "text-white"}>
                  {stepLabels[id]}
                </span>
              </li>
            ))}
          </ul>
          <p className="text-xs text-[#8A8A8A]">{t.youtubeKey.verifyNotice}</p>
        </div>

        {keyFailed && !error && !saved && (
          <p role="alert" className="text-sm text-white">
            {t.youtubeKey.keyFailed}
          </p>
        )}
        {error && (
          <p role="alert" className="text-sm text-white">
            {error}
          </p>
        )}
        {saved && (
          <p role="status" className="text-sm font-medium text-[#1DB954]">
            {t.youtubeKey.verifiedSaved}
          </p>
        )}
        <div>
          <button
            type="button"
            onClick={() => void handleVerifyAndSave()}
            disabled={isVerifying}
            className="flex min-h-[44px] items-center justify-center rounded-full bg-white px-6 text-sm font-bold text-black transition-transform hover:scale-105 focus-visible:outline-2 focus-visible:outline-[#1DB954] disabled:cursor-not-allowed disabled:opacity-60 disabled:hover:scale-100"
          >
            {isVerifying ? t.youtubeKey.verifying : t.youtubeKey.verifyAndSave}
          </button>
        </div>
      </div>
    </div>
  );
}
