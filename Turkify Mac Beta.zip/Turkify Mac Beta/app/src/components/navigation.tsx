"use client";

import type { MainView, Playlist } from "../lib/types";
import { formatTotalDuration } from "../data/tracks";
import { HomeIcon, SearchIcon, LibraryIcon, HeartIcon, PauseIcon, PlayIcon, SettingsIcon, TurkifyLogo } from "./icons";
import { playlistArtwork } from "../lib/playlist-art";
import { useI18n } from "./locale-provider";

interface NavigationProps {
  view: MainView;
  playlists: Playlist[];
  selectedPlaylistId: string | null;
  likedCount: number;
  onNavigate: (view: MainView, playlistId?: string | null) => void;
  activePlaylistId: string | null;
  isPlaying: boolean;
  playablePlaylistIds: Set<string>;
  onTogglePlaylist: (playlistId: string) => void;
  playlistTotalSeconds: Map<string, number>;
}

export function Navigation({
  view,
  playlists,
  selectedPlaylistId,
  likedCount,
  onNavigate,
  activePlaylistId,
  isPlaying,
  playablePlaylistIds,
  onTogglePlaylist,
  playlistTotalSeconds,
}: NavigationProps) {
  const { locale, t } = useI18n();
  const mainItems: { id: MainView; label: string; mobileLabel: string; Icon: typeof HomeIcon }[] = [
    { id: "home", label: t.nav.home, mobileLabel: t.nav.mobileShort.home, Icon: HomeIcon },
    { id: "search", label: t.nav.search, mobileLabel: t.nav.mobileShort.search, Icon: SearchIcon },
    { id: "library", label: t.nav.library, mobileLabel: t.nav.mobileShort.library, Icon: LibraryIcon },
    { id: "liked", label: t.nav.liked, mobileLabel: t.nav.mobileShort.liked, Icon: HeartIcon },
    { id: "settings", label: t.nav.settings, mobileLabel: t.nav.mobileShort.settings, Icon: SettingsIcon },
  ];
  return (
    <>
      {/* Desktop sidebar */}
      <nav
        aria-label={t.nav.mainNavLabel}
        className="plk-scroll hidden w-[240px] shrink-0 flex-col gap-6 bg-[#181818] p-6 md:sticky md:top-0 md:flex md:h-[calc(100dvh-5rem)] md:self-start md:overflow-x-hidden md:overflow-y-auto"
      >
        <p className="flex items-center gap-2 text-xl font-bold tracking-tight text-white">
          <TurkifyLogo className="h-8 w-8 shrink-0" />
          <span className="whitespace-nowrap">Turkify</span>
        </p>
        <ul className="flex flex-col gap-1">
          {mainItems.map(({ id, label, Icon }) => {
            const active = view === id;
            return (
              <li key={id}>
                <button
                  type="button"
                  onClick={() => onNavigate(id)}
                  aria-current={active ? "page" : undefined}
                  className={`flex min-h-[44px] w-full items-center gap-3 rounded-lg px-3 text-left text-[15px] font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] ${
                    active
                      ? "bg-[#282828] text-white"
                      : "text-[#B3B3B3] hover:bg-[#282828] hover:text-white"
                  }`}
                >
                  <Icon className="h-5 w-5 shrink-0" />
                  <span>{label}</span>
                  {id === "liked" && likedCount > 0 && (
                    <span aria-hidden="true" className="ml-auto rounded-full bg-[#282828] px-2 py-0.5 text-xs font-medium text-[#B3B3B3]">
                      {likedCount}
                    </span>
                  )}
                </button>
              </li>
            );
          })}
        </ul>
        <div className="flex flex-col gap-2">
          <h2 className="px-3 text-xs font-semibold tracking-wider text-[#B3B3B3] uppercase">
            {t.nav.listsHeading}
          </h2>
          {playlists.length === 0 ? (
            <p className="px-3 text-sm text-[#B3B3B3]">
              {t.nav.noLists}
            </p>
          ) : (
            <ul className="plk-scroll grid max-h-80 grid-cols-2 gap-2 overflow-y-auto">
              {playlists.map((p) => {
                const active = view === "playlist" && selectedPlaylistId === p.id;
                const playing = activePlaylistId === p.id && isPlaying;
                const totalDuration = formatTotalDuration(playlistTotalSeconds.get(p.id) ?? 0, locale);
                return (
                  <li key={p.id} className="group relative min-w-0">
                    <button
                      type="button"
                      onClick={() => onNavigate("playlist", p.id)}
                      aria-current={active ? "page" : undefined}
                      title={p.name}
                      className={`flex w-full flex-col gap-1.5 rounded-lg p-1.5 text-left transition-colors focus-visible:outline-2 focus-visible:outline-[#1DB954] ${
                        active ? "bg-[#282828]" : "hover:bg-[#282828]/60"
                      }`}
                    >
                      <img
                        src={playlistArtwork(p)}
                        alt=""
                        loading="lazy"
                        className="aspect-square w-full rounded object-cover"
                      />
                      <span className="min-w-0">
                        <span className="block truncate text-xs font-semibold text-white">
                          {p.name}
                        </span>
                        <span className="block text-[11px] text-[#B3B3B3]">
                          {t.playlistPanel.trackCount({ count: p.trackIds.length })}
                          {totalDuration && (
                            <>
                              <span aria-hidden="true"> • </span>
                              {totalDuration}
                            </>
                          )}
                        </span>
                      </span>
                    </button>
                    {playablePlaylistIds.has(p.id) && (
                      <button
                        type="button"
                        onClick={() => onTogglePlaylist(p.id)}
                        aria-label={playing ? t.playlistView.pausePlaylist({ name: p.name }) : t.playlistView.playPlaylist({ name: p.name })}
                        title={playing ? t.playlistView.pausePlaylist({ name: p.name }) : t.playlistView.playPlaylist({ name: p.name })}
                        className="absolute inset-x-1.5 top-1.5 flex aspect-square items-center justify-center rounded bg-black/40 opacity-0 pointer-events-none transition-opacity group-hover:pointer-events-auto group-hover:opacity-100 focus-visible:pointer-events-auto focus-visible:opacity-100"
                      >
                        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-black/60 text-white transition-transform hover:scale-105">
                          {playing ? (
                            <PauseIcon className="h-4 w-4" />
                          ) : (
                            <PlayIcon className="h-4 w-4" />
                          )}
                        </span>
                      </button>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </nav>

      {/* Mobile bottom navigation */}
      <nav
        aria-label={t.nav.mobileNavLabel}
        className="fixed inset-x-0 bottom-0 z-30 box-border h-[57px] border-t border-[#282828] bg-[#181818]/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden"
      >
        <ul className="grid grid-cols-5">
          {mainItems.map(({ id, mobileLabel, Icon }) => {
            const active = view === id;
            return (
              <li key={id}>
                <button
                  type="button"
                  onClick={() => onNavigate(id)}
                  aria-current={active ? "page" : undefined}
                  aria-pressed={active}
                  className={`flex min-h-[56px] w-full flex-col items-center justify-center gap-1 text-[11px] font-medium focus-visible:outline-2 focus-visible:outline-[#1DB954] ${
                    active ? "text-white" : "text-[#B3B3B3]"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span>{mobileLabel}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
    </>
  );
}
