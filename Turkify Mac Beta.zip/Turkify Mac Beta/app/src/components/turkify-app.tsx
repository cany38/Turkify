"use client";

import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import Image from "next/image";
import type { ExternalTrack, LocalTrack, MainView, Playlist, SpotifyKeys, Track, YoutubeKey } from "../lib/types";
import type { AudioFormat } from "../lib/audio-format";
import { getTimeBasedGreeting } from "../lib/i18n";
import { LIBRARY_TRACKS, formatTotalDuration, textIncludes, toLocaleLower } from "../data/tracks";
import { useLibrary } from "../hooks/use-library";
import { useAudioPlayer, canPlayTrack } from "../hooks/use-audio-player";
import { LocaleSwitcher, useI18n } from "./locale-provider";
import { Navigation } from "./navigation";
import { TrackList } from "./track-list";
import { ExternalResults } from "./external-results";
import { SpotifyKeysPanel } from "./spotify-keys-panel";
import { YoutubeKeyPanel } from "./youtube-key-panel";
import { ConfirmDialog } from "./confirm-dialog";
import { Player } from "./player";
import { PlaylistAddSongs, PlaylistEditForm, PlaylistPanel } from "./playlist-panel";
import { BackIcon, CheckIcon, CloseIcon, DownloadIcon, MusicIcon, PauseIcon, PencilIcon, PlayIcon, PlusIcon, SearchIcon, TurkifyLogo, UploadIcon } from "./icons";
import { useMusicSearch } from "../hooks/use-music-search";
import { useDiskLibrary } from "../hooks/use-disk-library";
import { syncTrackToMusics } from "../lib/musics-sync";
import { clearSpotifyKeys, loadSpotifyKeys, saveSpotifyKeys } from "../lib/spotify-keys";
import { clearYoutubeKey, loadYoutubeKey, saveYoutubeKey } from "../lib/youtube-key";
import { selectHomeTracks, type HomeTab } from "../lib/home-tabs";
import { useAudioFormat } from "../hooks/use-audio-format";
import { CodecSettings } from "./codec-settings";
import EqSettingsPanel from "./eq-settings";
import { useSearchSuggestions } from "../hooks/use-search-suggestions";
import { rankFeaturedItems } from "../lib/listening-history";
import { SMART_RECENT_MS } from "../lib/smart-queue";
import { playlistArtwork } from "../lib/playlist-art";
import { SpotifyPlaylistImport } from "./spotify-playlist-import";
import { YoutubePlaylistImport } from "./youtube-playlist-import";
import { useDownload } from "../hooks/use-download";
import {
  importedTrackToExternalTrack,
  pendingPlaylistDownloads,
} from "../lib/playlist-download";
import { inferDownloadedFormatInfo, type FormatInfo } from "../lib/format-info-cache";

interface PlaylistBulkDownloadState {
  playlistId: string;
  running: boolean;
  stopRequested: boolean;
  completed: number;
  total: number;
  failed: number;
  outcome: "done" | "stopped" | "cancelled";
  currentTitle?: string;
}

const LOCAL_COVERS = [
  "/covers/demo-01.svg",
  "/covers/demo-02.svg",
  "/covers/demo-03.svg",
  "/covers/demo-04.svg",
  "/covers/demo-05.svg",
  "/covers/demo-06.svg",
  "/covers/demo-07.svg",
  "/covers/demo-08.svg",
  "/covers/demo-09.svg",
  "/covers/demo-10.svg",
];

const AUDIO_EXT = /\.(mp3|wav|ogg|oga|m4a|aac|flac|webm|opus)$/i;

/**
 * Kütüphane parçaları kök-göreli `url` taşır (`/audio/...`). Çalar hook'u
 * kapsam dışı olduğu için ses kaynağını `objectUrl` alanından okur; bu yüzden
 * oynatma sınırında kütüphane kaydı, aynı ses baytlarına işaret eden bir
 * `objectUrl` görünümüne çevrilir. Bayt kopyası yok, revoke yok (blob değil,
 * kalıcı yol). Yerel dosyalar aynen geçer.
 */
function toPlayerTrack(track: Track): Track {
  if (track.source === "local") return track;
  const { url, ...rest } = track;
  return { ...rest, source: "local" as const, objectUrl: url };
}

/**
 * İndirilmemiş harici kaydın stream adresi. YouTube'da video kimliği kesin,
 * Spotify'da başlık+sanatçı araması çözülür. İndirme gerektirmez.
 */
function externalStreamUrl(track: ExternalTrack, format: AudioFormat): string {
  if (track.source === "youtube") {
    return `/api/stream?v=${encodeURIComponent(track.videoId)}&format=${format}`;
  }
  // Sure biliniyorsa gonderilir: eslesmede yanlis surum (remix, canli, uzun
  // edit) yerine dogru uzunluktaki kayit secilsin.
  const durationParam = track.duration > 0 ? `&duration=${Math.round(track.duration)}` : "";
  return `/api/stream?q=${encodeURIComponent(`${track.title} ${track.artist}`)}&title=${encodeURIComponent(track.title)}&artist=${encodeURIComponent(track.artist)}&format=${format}${durationParam}`;
}

/** Harici kaydı çalınabilir oturumluk parçaya çevirir; id ham harici id'dir. */
function externalToStreamedTrack(track: ExternalTrack, format: AudioFormat): LocalTrack {
  return {
    id: track.id,
    title: track.title,
    artist: track.artist,
    album: track.album,
    duration: track.duration,
    cover: track.cover,
    source: "local",
    objectUrl: externalStreamUrl(track, format),
    origin: track.source,
  };
}

/** Harici kimliği korur ama ses baytlarını indirilmiş yerel dosyadan okur. */
function externalToDownloadedTrack(track: ExternalTrack, local: LocalTrack): LocalTrack {
  const catalogCover = track.cover.trim();
  return {
    ...local,
    id: track.id,
    title: track.title,
    artist: track.artist,
    album: track.album,
    duration: track.duration || local.duration,
    // Playlistteki yüzlerce kapağı sesle aynı yerel bağlantı kuyruğuna sokma.
    // Katalog kapağı hızlı yol; diskteki kapak ağ hatasında yedek kalır.
    cover: catalogCover || local.cover,
    ...(catalogCover && catalogCover !== local.cover
      ? { fallbackCover: local.cover }
      : {}),
    source: "local",
    origin: track.source,
    externalId: track.id,
  };
}

/**
 * Aynı id iki kez geçerse React key çakışması listeyi karıştırır
 * (yinelenen/atlanan satırlar, yanlış numaralar). İlki korunur.
 */
function uniqueTracksById<T extends { id: string }>(tracks: T[]): T[] {
  const seen = new Set<string>();
  return tracks.filter((track) => {
    if (seen.has(track.id)) return false;
    seen.add(track.id);
    return true;
  });
}

function subscribeGreetingHour(onStoreChange: () => void): () => void {
  const handleVisibility = () => {
    if (document.visibilityState === "visible") {
      onStoreChange();
    }
  };
  document.addEventListener("visibilitychange", handleVisibility);
  return () => {
    document.removeEventListener("visibilitychange", handleVisibility);
  };
}

function getGreetingHourSnapshot(): number {
  return new Date().getHours();
}

function getGreetingHourServerSnapshot(): null {
  return null;
}

export function TurkifyApp() {
  const { locale, t } = useI18n();
  const [view, setView] = useState<MainView>("home");
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(null);
  // Ana sayfada varsayilan gorunum begenilenler; kullanici tum kutuphaneye gecebilir.
  const [homeTab, setHomeTab] = useState<HomeTab>("liked");
  const [spotifyKeys, setSpotifyKeys] = useState<SpotifyKeys | null>(null);
  const [youtubeKey, setYoutubeKey] = useState<YoutubeKey | null>(null);
  const [keysReady, setKeysReady] = useState(false);
  const [searchSources, setSearchSources] = useState({ local: true, youtube: true, spotify: true });
  const externalSources = [searchSources.spotify ? "spotify" : "", searchSources.youtube ? "youtube" : ""].filter(Boolean).join(",");
  const musicSearch = useMusicSearch(spotifyKeys, youtubeKey, externalSources);
  const codecPreference = useAudioFormat();
  const playlistDownloader = useDownload(codecPreference.audioFormat);
  // Arama indirmeleri de app seviyesinde yasar; sonuc sayfasindan ayrilinsa
  // bile indirme surer, donunce satir guncel durumu gosterir.
  const searchDownloader = useDownload(codecPreference.audioFormat);
  const query = musicSearch.query;
  const setQuery = musicSearch.setQuery;
  const [suggestionsOpen, setSuggestionsOpen] = useState(false);
  const [activeSuggestion, setActiveSuggestion] = useState(-1);
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const suggestions = useSearchSuggestions(query, suggestionsOpen);
  const suggestionItems = query.trim() ? suggestions : searchHistory;
  const readSearchHistory = () => {
    try {
      const value = JSON.parse(localStorage.getItem("turkify:search-history:v1") ?? "[]");
      setSearchHistory(Array.isArray(value) ? value.filter((item) => typeof item === "string" && item.length <= 200).slice(0, 10) : []);
    } catch { setSearchHistory([]); }
  };
  const submitSearch = (value: string) => {
    const trimmed = value.trim();
    if (trimmed.length < 2) return;
    const next = [trimmed, ...searchHistory.filter((item) => toLocaleLower(item, locale) !== toLocaleLower(trimmed, locale))].slice(0, 10);
    setSearchHistory(next);
    try { localStorage.setItem("turkify:search-history:v1", JSON.stringify(next)); } catch { /* Keep session history. */ }
    setSuggestionsOpen(false);
    setActiveSuggestion(-1);
    musicSearch.submitSearch(trimmed);
  };
  // Tek kaynak: Musics klasoru. Liste diskten okunur, IndexedDB ses tutmaz.
  const diskLibrary = useDiskLibrary();
  const localTracks = diskLibrary.tracks;
  const [recentDownloadedTracks, setRecentDownloadedTracks] = useState<Record<string, LocalTrack>>({});
  const reloadDisk = diskLibrary.reload;
  const [fileFeedback, setFileFeedback] = useState<string | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [removeError, setRemoveError] = useState<string | null>(null);
  const [downloadFeedback, setDownloadFeedback] = useState<string | null>(null);
  const [playlistEditOpen, setPlaylistEditOpen] = useState(false);
  const [playlistSearch, setPlaylistSearch] = useState("");
  const [playlistAddOpen, setPlaylistAddOpen] = useState(false);
  const [playlistViewFeedback, setPlaylistViewFeedback] = useState<string | null>(null);
  const [playlistBulkDownload, setPlaylistBulkDownload] = useState<PlaylistBulkDownloadState | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const localUrlsRef = useRef(new Map<string, string>());
  const appliedIdentityMappingRef = useRef("");
  const playlistBulkRunningRef = useRef(false);
  // Durdur: siradakiler baslamaz, o anki biter. Iptal: o anki de durur, yarim is silinir.
  const bulkStopRef = useRef(false);
  const bulkCancelRef = useRef(false);
  const bulkCurrentIdRef = useRef<string | null>(null);
  const bulkQueueRef = useRef<ExternalTrack[]>([]);
  const bulkNextIndexRef = useRef(0);

  // Spotify anahtarlari yalniz tarayicida durur; okuma bitmeden yazma yok.
  useEffect(() => {
    let cancelled = false;
    void Promise.resolve()
      .then(() => ({ spotifyStored: loadSpotifyKeys(), youtubeStored: loadYoutubeKey() }))
      .then(({ spotifyStored, youtubeStored }) => {
        if (cancelled) return;
        if (spotifyStored) setSpotifyKeys(spotifyStored);
        if (youtubeStored) setYoutubeKey(youtubeStored);
        setKeysReady(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const library = useLibrary();
  const libraryHydrated = library.hydrated;
  const remapTrackIds = library.remapTrackIds;

  useEffect(() => {
    if (!libraryHydrated) return;
    const entries = Object.entries(diskLibrary.legacyIdMapping).sort(([a], [b]) =>
      a.localeCompare(b),
    );
    if (entries.length === 0) return;
    const signature = JSON.stringify(entries);
    if (appliedIdentityMappingRef.current === signature) return;
    if (remapTrackIds(diskLibrary.legacyIdMapping)) {
      appliedIdentityMappingRef.current = signature;
    }
  }, [diskLibrary.legacyIdMapping, libraryHydrated, remapTrackIds]);

  const visibleLibraryTracks = useMemo(
    () =>
      LIBRARY_TRACKS.filter(
        (track) => !library.removedTrackIds.includes(track.id),
      ),
    [library.removedTrackIds],
  );

  const handleDownloaded = useCallback((track: LocalTrack) => {
    // Sunucu dosyayi Musics klasorune yazdi; dosya listede görünene kadar
    // izle ki sayfayi yenilemek gerekmesin.
    if (track.fileName) void diskLibrary.reloadUntilVisible(track.fileName);
    else void reloadDisk();
    if (track.externalId) {
      setRecentDownloadedTracks((previous) => ({
        ...previous,
        [track.externalId!]: track,
      }));
    }
    setDownloadFeedback(t.download.added({ title: track.title }));
    window.setTimeout(() => setDownloadFeedback(null), 4000);
  }, [t, diskLibrary, reloadDisk]);

  const handleSaveKeys = useCallback((keys: SpotifyKeys) => {
    if (saveSpotifyKeys(keys)) setSpotifyKeys(keys);
  }, []);

  // Silme onay penceresi: hangi servis icin acildiysa o.
  const [pendingRemoval, setPendingRemoval] = useState<"spotify" | "youtube" | null>(null);
  // Toplu indirme iptal onayi.
  const [pendingBulkCancel, setPendingBulkCancel] = useState(false);

  /** Durdur: o an inen biter, kuyruk durur. Tekrar baslat kaldigi yerden devam eder. */
  const handleStopBulkDownload = useCallback(() => {
    if (!playlistBulkRunningRef.current) return;
    bulkStopRef.current = true;
    setPlaylistBulkDownload((previous) =>
      previous?.running ? { ...previous, stopRequested: true } : previous,
    );
  }, []);

  /** Iptal (onayli): o an inen durur, yarim dosya silinir, inenler kalir. */
  const handleCancelBulkDownload = useCallback(() => {
    if (!playlistBulkRunningRef.current) return;
    bulkCancelRef.current = true;
    const currentId = bulkCurrentIdRef.current;
    if (currentId) playlistDownloader.cancelDownload(currentId);
    setPendingBulkCancel(false);
  }, [playlistDownloader]);

  const handleConfirmRemoval = useCallback(() => {
    if (pendingRemoval === "spotify") {
      clearSpotifyKeys();
      setSpotifyKeys(null);
    } else if (pendingRemoval === "youtube") {
      clearYoutubeKey();
      setYoutubeKey(null);
    }
    setPendingRemoval(null);
  }, [pendingRemoval]);

  const handleSaveYoutubeKey = useCallback((key: YoutubeKey) => {
    if (saveYoutubeKey(key)) setYoutubeKey(key);
  }, []);

  // Sure calarken ogreniliyor; diskten gelen listede kalici olarak tutulmuyor.
  const handleLocalDuration = useCallback(() => {}, []);

  const allTracks = useMemo<Track[]>(
    () => [...visibleLibraryTracks, ...localTracks],
    [visibleLibraryTracks, localTracks],
  );

  const player = useAudioPlayer({
    onLocalDuration: handleLocalDuration,
    likedIds: library.likedIds,
    playlists: library.playlists,
    pool: allTracks,
    restoreReady: libraryHydrated && !diskLibrary.isLoading,
  });

  // Sekmeye gore gosterilecek liste; calma baglami da bu listeden kurulur.
  const homeTracks = useMemo(
    () => selectHomeTracks(allTracks, library.likedIds, homeTab),
    [allTracks, library.likedIds, homeTab],
  );

  const tracksById = useMemo(() => {
    const map = new Map<string, Track>();
    for (const t of allTracks) map.set(t.id, t);
    return map;
  }, [allTracks]);

  const downloadedLocalByExternalId = useMemo(() => {
    const map = new Map<string, LocalTrack>();
    for (const local of Object.values(recentDownloadedTracks)) {
      if (local.externalId) map.set(local.externalId, local);
    }
    for (const local of localTracks) {
      if (local.externalId) map.set(local.externalId, local);
    }
    return map;
  }, [localTracks, recentDownloadedTracks]);
  const downloadedFormatsByExternalId = useMemo(() => {
    const formats: Record<string, FormatInfo> = {};
    for (const local of [...Object.values(recentDownloadedTracks), ...localTracks]) {
      if (!local.externalId || !local.fileName) continue;
      const format = inferDownloadedFormatInfo(
        local.fileName,
        local.fileSize,
        local.duration,
      );
      if (format) formats[local.externalId] = format;
    }
    return formats;
  }, [localTracks, recentDownloadedTracks]);
  // En cok dinlenenler karisik: cok dinlenen liste one gecer, listeden cok
  // dinlenen sarki varsa sarki one gecer.
  const featuredItems = useMemo(
    () => rankFeaturedItems(allTracks, library.playlists, player.listeningHistory),
    [allTracks, library.playlists, player.listeningHistory],
  );
  const featuredTracks = useMemo(
    () => featuredItems.flatMap((item) => (item.kind === "track" ? [item.track] : [])),
    [featuredItems],
  );

  // Oturumluk object URL'leri registry ile takip edip kapatirken temizle.
  useEffect(() => {
    const registry = localUrlsRef.current;
    return () => {
      for (const url of registry.values()) {
        try {
          URL.revokeObjectURL(url);
        } catch {
          // yok say
        }
      }
      registry.clear();
    };
  }, []);

  const handleNavigate = useCallback((next: MainView, playlistId?: string | null) => {
    setView(next);
    if (next === "playlist") {
      setSelectedPlaylistId(playlistId ?? null);
    }
    // Gezinmede duzenleme ve sarki ekleme panelleri kapanir, acilmamis gibi olur.
    setPlaylistEditOpen(false);
    setPlaylistAddOpen(false);
    setPlaylistViewFeedback(null);
    setPlaylistSearch("");
  }, []);

  // Kutuphane satirlarindan secim tam liste ekranina gider; paneller kapanir.
  const handleSelectPlaylist = useCallback((playlistId: string | null) => {
    setSelectedPlaylistId(playlistId);
    setView("playlist");
    setPlaylistEditOpen(false);
    setPlaylistAddOpen(false);
    setPlaylistViewFeedback(null);
    setPlaylistSearch("");
  }, []);

  const handleFiles = useCallback((files: FileList | null) => {
    setFileFeedback(null);
    setFileError(null);
    if (!files || files.length === 0) return;
    const added: LocalTrack[] = [];
    const filesToSave: { track: LocalTrack; blob: Blob }[] = [];
    const rejected: string[] = [];
    const base = Date.now();
    Array.from(files).forEach((file, i) => {
      const typeOk = file.type ? file.type.startsWith("audio/") : AUDIO_EXT.test(file.name);
      if (!typeOk) {
        rejected.push(file.name);
        return;
      }
      const title = file.name.replace(/\.[^.]+$/, "").trim() || t.files.untitled;
      const track: LocalTrack = {
        id: `local-${base}-${i}-${Math.floor(Math.random() * 10000)}`,
        title: title.slice(0, 80),
        artist: t.files.localArtist,
        album: t.files.localAlbum,
        duration: 0,
        cover: LOCAL_COVERS[(localTracks.length + added.length) % LOCAL_COVERS.length] ?? "/covers/demo-01.svg",
        source: "local",
        objectUrl: "",
        fileName: file.name,
      };
      added.push(track);
      filesToSave.push({ track, blob: file });
    });
    if (added.length > 0) {
      // Dosyalar dogrudan Musics klasorune yaziliyor; hepsi bitince liste tazelenir.
      void Promise.all(
        filesToSave.map((item) =>
          syncTrackToMusics(
            item.track.id,
            item.track.fileName ?? item.track.title,
            item.blob,
          ),
        ),
      ).then(async (results) => {
        const savedCount = results.filter(Boolean).length;
        const failedNames = filesToSave
          .filter((_, index) => !results[index])
          .map((item) => item.track.fileName ?? item.track.title);
        if (savedCount > 0) setFileFeedback(t.files.added({ count: savedCount }));
        if (failedNames.length > 0) {
          const message = t.files.saveFailed({ names: failedNames.slice(0, 3).join(", ") });
          setFileError((previous) => previous ? `${previous} ${message}` : message);
        }
        await reloadDisk();
      });
    }
    if (rejected.length > 0) {
      setFileError(
        t.files.unsupported({ names: rejected.slice(0, 3).join(", ") }),
      );
    }
    if (fileInputRef.current) fileInputRef.current.value = "";
  }, [t, reloadDisk, localTracks.length]);

  const handleRemoveLocal = useCallback(
    async (trackId: string) => {
      setRemoveError(null);
      // Tek kaynak klasor: parca listeden kalkiyorsa dosya da silinmeli.
      const fileName = localTracks.find((t) => t.id === trackId)?.fileName;
      if (fileName) {
        try {
          const response = await fetch("/api/media/delete", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ fileName }),
          });
          if (!response.ok) throw new Error(`HTTP ${response.status}`);
          player.removeTrack(trackId);
          library.detachTrackEverywhere(trackId);
          await reloadDisk();
        } catch {
          const title = localTracks.find((track) => track.id === trackId)?.title ?? fileName;
          setRemoveError(t.files.removeFailed({ title }));
        }
      }
    },
    [library, player, localTracks, reloadDisk, t],
  );

  const handleRemoveTrack = useCallback(
    (track: Track) => {
      if (track.source === "local") {
        handleRemoveLocal(track.id);
        return;
      }
      player.removeTrack(track.id);
      library.removeLibraryTrack(track.id);
    },
    [handleRemoveLocal, library, player],
  );

  const handleRemoveFromPlaylist = useCallback(
    (playlistId: string, trackId: string) => {
      library.removeTrackFromPlaylist(playlistId, trackId);
      player.removeTrackFromContext(trackId, `playlist:${playlistId}`);
    },
    [library, player],
  );

  /**
   * Beğeni/liste kopyalarının id → harici kayıt eşlemesi. Satırlar stream
   * kopyayla renderlandığı için kalp/silme, ham id üzerinden doğru kayda gider.
   */
  const externalSnapshotById = useMemo(() => {
    const map = new Map<string, ExternalTrack>();
    for (const track of library.externalTracks) map.set(track.id, track);
    for (const playlist of library.playlists) {
      for (const imported of playlist.importedTracks ?? []) {
        if (!map.has(imported.id)) map.set(imported.id, importedTrackToExternalTrack(imported));
      }
    }
    return map;
  }, [library.externalTracks, library.playlists]);

  /** Kütüphane satırlarındaki kalp: harici kopyaysa anlık görüntüyü de işletir. */
  const handleToggleLike = useCallback(
    (id: string) => {
      const snapshot = externalSnapshotById.get(id);
      if (snapshot) library.toggleExternalLike(snapshot);
      else library.toggleLike(id);
    },
    [externalSnapshotById, library],
  );

  /** Beğenilenler görünümündeki çöp: harici kopyayı beğeniden düşürür. */
  const handleRemoveLiked = useCallback(
    (track: Track) => {
      const snapshot = externalSnapshotById.get(track.id);
      if (snapshot) {
        player.removeTrack(track.id);
        if (library.isLiked(track.id)) library.toggleExternalLike(snapshot);
        return;
      }
      handleRemoveTrack(track);
    },
    [externalSnapshotById, handleRemoveTrack, library, player],
  );

  const playInContext = useCallback(
    (context: Track[], track: Track, contextKey: string) => {
      player.playTracks(
        context.map(toPlayerTrack),
        track.id,
        allTracks.map(toPlayerTrack),
        contextKey,
      );
    },
    [allTracks, player],
  );

  /**
   * Harici sonucu indirmeyi beklemeden calar. `/api/stream` yalnizca dogrudan
   * ses adresini cozup baytlari aktarir; kutuphaneye kaydetmek hala Indir'in isi.
   */
  const handlePlayExternal = useCallback(
    (track: ExternalTrack) => {
      const local = downloadedLocalByExternalId.get(track.id);
      const playable = local
        ? externalToDownloadedTrack(track, local)
        : externalToStreamedTrack(track, codecPreference.audioFormat);
      player.playTracks([playable], playable.id, [playable], local ? `local:${track.id}` : `stream:${track.id}`);
    },
    [player, codecPreference.audioFormat, downloadedLocalByExternalId],
  );

  const addToPlaylistMessage = useCallback(
    (playlistId: string, trackId: string): string => {
      const result = library.addTrackToPlaylist(playlistId, trackId);
      return result.message;
    },
    [library],
  );

  const addExternalToPlaylistMessage = useCallback(
    (playlistId: string, track: ExternalTrack): string => {
      const result = library.addExternalToPlaylist(playlistId, track);
      return result.message;
    },
    [library],
  );

  const searchResults = useMemo(() => {
    if (musicSearch.submittedQuery.trim().length === 0) return null;
    return allTracks.filter((tr) =>
      textIncludes(`${tr.title} ${tr.artist}`, musicSearch.submittedQuery),
    );
  }, [musicSearch.submittedQuery, allTracks]);

  const likedTracks = useMemo(
    () =>
      uniqueTracksById(
        library.likedIds
          .map((id) => {
            const local = tracksById.get(id);
            if (local) return local;
            const snapshot = externalSnapshotById.get(id);
            if (!snapshot) return undefined;
            const downloaded = downloadedLocalByExternalId.get(snapshot.id);
            return downloaded
              ? externalToDownloadedTrack(snapshot, downloaded)
              : externalToStreamedTrack(snapshot, codecPreference.audioFormat);
          })
          .filter((t): t is Track => t !== undefined),
      ),
    [library.likedIds, externalSnapshotById, tracksById, codecPreference.audioFormat, downloadedLocalByExternalId],
  );

  const selectedPlaylist = useMemo(
    () => library.playlists.find((p) => p.id === selectedPlaylistId) ?? null,
    [library.playlists, selectedPlaylistId],
  );

  const playlistDownloadTracks = useMemo(
    () => (selectedPlaylist?.importedTracks ?? []).map(importedTrackToExternalTrack),
    [selectedPlaylist],
  );

  const pendingPlaylistDownloadTracks = useMemo(
    () =>
      selectedPlaylist
        ? pendingPlaylistDownloads(
            selectedPlaylist.importedTracks ?? [],
            diskLibrary.downloadedExternalIds,
          )
        : [],
    [selectedPlaylist, diskLibrary.downloadedExternalIds],
  );

  const handleDownloadSelectedPlaylist = useCallback(async () => {
    if (!selectedPlaylist || playlistBulkRunningRef.current) return;
    const canResume =
      playlistBulkDownload?.playlistId === selectedPlaylist.id &&
      playlistBulkDownload.outcome === "stopped" &&
      bulkQueueRef.current.length > bulkNextIndexRef.current;
    const queue = canResume
      ? bulkQueueRef.current
      : pendingPlaylistDownloads(
          selectedPlaylist.importedTracks ?? [],
          diskLibrary.downloadedExternalIds,
        );
    if (queue.length === 0) {
      setPlaylistViewFeedback(t.download.nothingPending);
      return;
    }

    playlistBulkRunningRef.current = true;
    bulkStopRef.current = false;
    bulkCancelRef.current = false;
    bulkCurrentIdRef.current = null;
    if (!canResume) {
      bulkQueueRef.current = queue;
      bulkNextIndexRef.current = 0;
    }
    let completed = canResume ? playlistBulkDownload.completed : 0;
    let failed = canResume ? playlistBulkDownload.failed : 0;
    setPlaylistViewFeedback(null);
    setPlaylistBulkDownload({
      playlistId: selectedPlaylist.id,
      running: true,
      stopRequested: false,
      completed,
      total: queue.length,
      failed,
      outcome: "done",
      currentTitle: queue[bulkNextIndexRef.current]?.title,
    });

    try {
      for (let index = bulkNextIndexRef.current; index < queue.length; index += 1) {
        const track = queue[index]!;
        // Durdur: o an inen biter, siradakiler baslamaz. Iptal: o anki de durur.
        if (bulkStopRef.current || bulkCancelRef.current) break;
        setPlaylistBulkDownload((previous) =>
          previous && previous.playlistId === selectedPlaylist.id
            ? { ...previous, currentTitle: track.title }
            : previous,
        );
        bulkCurrentIdRef.current = track.id;
        const ok = await playlistDownloader.download(track, (local) => {
          handleDownloaded(local);
        });
        bulkCurrentIdRef.current = null;
        if (bulkCancelRef.current || playlistDownloader.isCancelled(track.id)) {
          break;
        }
        completed += 1;
        if (!ok) failed += 1;
        bulkNextIndexRef.current = index + 1;
        setPlaylistBulkDownload({
          playlistId: selectedPlaylist.id,
          running: true,
          stopRequested: bulkStopRef.current,
          completed,
          total: queue.length,
          failed,
          outcome: "done",
          ...(queue[index + 1]?.title
            ? { currentTitle: queue[index + 1]!.title }
            : {}),
        });
      }
    } finally {
      playlistBulkRunningRef.current = false;
      const outcome = bulkCancelRef.current ? "cancelled" : bulkStopRef.current ? "stopped" : "done";
      bulkStopRef.current = false;
      bulkCancelRef.current = false;
      bulkCurrentIdRef.current = null;
      if (outcome !== "stopped") {
        bulkQueueRef.current = [];
        bulkNextIndexRef.current = 0;
      }
      setPlaylistBulkDownload({
        playlistId: selectedPlaylist.id,
        running: false,
        stopRequested: false,
        completed,
        total: queue.length,
        failed,
        outcome,
      });
    }
  }, [
    selectedPlaylist,
    playlistBulkDownload,
    diskLibrary.downloadedExternalIds,
    playlistDownloader,
    handleDownloaded,
    t,
  ]);

  // Listenin calinabilir parcalari: baslik kapagi, Most played ve menu
  // ayni cozumu kullanir, tek kaynaktan beslenir.
  const resolvePlaylistTracks = useCallback((playlist: Playlist): Track[] => {
    const locals = playlist.trackIds
      .map((id) => tracksById.get(id))
      .filter((t): t is Track => t !== undefined);
    const imported: LocalTrack[] = (playlist.importedTracks ?? [])
      .filter((track) => !tracksById.has(track.id))
      .map((track) => {
        const external = importedTrackToExternalTrack(track);
        const downloaded = downloadedLocalByExternalId.get(external.id);
        return downloaded
          ? externalToDownloadedTrack(external, downloaded)
          : externalToStreamedTrack(external, codecPreference.audioFormat);
      });
    return uniqueTracksById([...locals, ...imported]);
  }, [tracksById, codecPreference.audioFormat, downloadedLocalByExternalId]);

  const selectedPlaylistTracks = useMemo(() => {
    if (!selectedPlaylist) return [];
    return resolvePlaylistTracks(selectedPlaylist);
  }, [selectedPlaylist, resolvePlaylistTracks]);

  const selectedPlaylistSeconds = useMemo(
    () => selectedPlaylistTracks.reduce((sum, track) => sum + (track.duration || 0), 0),
    [selectedPlaylistTracks],
  );

  const selectedPlaylistTotal = useMemo(
    () => formatTotalDuration(selectedPlaylistSeconds, locale),
    [selectedPlaylistSeconds, locale],
  );

  // Liste ici arama: baslik + sanatcidan filtreler, bos sorguda tam liste.
  const playlistSearchResults = useMemo(() => {
    if (!playlistSearch.trim()) return selectedPlaylistTracks;
    return selectedPlaylistTracks.filter((track) =>
      textIncludes(`${track.title} ${track.artist}`, playlistSearch),
    );
  }, [playlistSearch, selectedPlaylistTracks]);

  // Liste kartlarindaki toplam sureler: sayi kadar sure de tek haritadan gelir.
  const playlistTotalSeconds = useMemo(() => {
    const map = new Map<string, number>();
    for (const playlist of library.playlists) {
      map.set(
        playlist.id,
        resolvePlaylistTracks(playlist).reduce((sum, track) => sum + (track.duration || 0), 0),
      );
    }
    return map;
  }, [library.playlists, resolvePlaylistTracks]);

  // Kapaktaki oynat/duraklat: listedeki ilk calinabilir parca baslar; calan
  // parca bu listedense dugme duraklatir, degilse listeyi bastan acar.
  // Kart satirlarindaki toplam sure metni; sure yoksa null doner.
  const playlistTotalText = (playlistId: string): string | null =>
    formatTotalDuration(playlistTotalSeconds.get(playlistId) ?? 0, locale);

  const firstPlaylistTrack = useMemo(
    () => selectedPlaylistTracks.find((track) => canPlayTrack(track)),
    [selectedPlaylistTracks],
  );
  const isPlaylistPlaying = selectedPlaylist !== null &&
    player.isPlaying &&
    player.contextKey === `playlist:${selectedPlaylist.id}`;
  // Karistirma aciksa liste bastan degil rastgele bir sarkidan baslar.
  // Baslangic icin son 24 saatte dinlenmemis parca tercih edilir.
  const pickPlaylistStart = useCallback((tracks: Track[], first: Track): Track => {
    if (player.shuffleMode === "off") return first;
    const playable = tracks.filter((track) => canPlayTrack(track));
    if (playable.length <= 1) return first;
    const now = Date.now();
    const fresh = playable.filter((track) => {
      const record = player.listeningHistory[track.id];
      return !record || now - record.lastPlayed >= SMART_RECENT_MS;
    });
    const pool = fresh.length > 0 ? fresh : playable;
    return pool[Math.floor(Math.random() * pool.length)] ?? first;
  }, [player]);

  // Herhangi bir listeyi kapaktan oynatir/duraklatir: calan baglam bu
  // listeyse duraklatir/devam ettirir, degilse listeyi baslatir. Sarki
  // uyeligine bakilmaz; ayni sarki iki listede de olsa dogru liste calar.
  const togglePlaylistPlaybackById = useCallback((playlistId: string) => {
    const playlist = library.playlists.find((p) => p.id === playlistId);
    if (!playlist) return;
    if (player.contextKey === `playlist:${playlistId}`) {
      player.toggle();
      return;
    }
    const tracks = resolvePlaylistTracks(playlist);
    const first = tracks.find((track) => canPlayTrack(track));
    if (!first) return;
    playInContext(tracks, pickPlaylistStart(tracks, first), `playlist:${playlistId}`);
  }, [library.playlists, player, resolvePlaylistTracks, pickPlaylistStart, playInContext]);

  const togglePlaylistPlayback = useCallback(() => {
    if (!selectedPlaylist || !firstPlaylistTrack) return;
    togglePlaylistPlaybackById(selectedPlaylist.id);
  }, [selectedPlaylist, firstPlaylistTrack, togglePlaylistPlaybackById]);

  // Calan baglamdaki liste (menu ve kartlardaki duraklat simgesi icin).
  // Sarki uyeligiyle degil baglamla bulunur; ayni sarki baska listede de
  // olsa yanlis liste duraklatilmaz.
  const activePlaylistId = useMemo(() => {
    const key = player.contextKey;
    if (!key.startsWith("playlist:")) return null;
    const id = key.slice("playlist:".length);
    return library.playlists.some((playlist) => playlist.id === id) ? id : null;
  }, [player.contextKey, library.playlists]);

  // Kapagi tiklanabilir liste kumesi: en az bir calinabilir parcasi olanlar.
  const playablePlaylistIds = useMemo(() => {
    const ids = new Set<string>();
    for (const playlist of library.playlists) {
      if (resolvePlaylistTracks(playlist).some((track) => canPlayTrack(track))) {
        ids.add(playlist.id);
      }
    }
    return ids;
  }, [library.playlists, resolvePlaylistTracks]);

  // Hydration guvenligi: ilk render notr selamlama gosterir; cihazin yerel
  // saati istemcide okunup uygulanir.
  const greetingHour = useSyncExternalStore(
    subscribeGreetingHour,
    getGreetingHourSnapshot,
    getGreetingHourServerSnapshot,
  );

  const greeting =
    greetingHour === null
      ? t.home.greeting.neutral
      : getTimeBasedGreeting(t, greetingHour);

  // Uc nokta menusu: calan parcanin satir aksiyonlari. Harici parca
  // indirilememisse ilk sirada yesil tik durur.
  const menuSnapshot = player.currentTrackId
    ? externalSnapshotById.get(player.currentTrackId)
    : undefined;
  const menuDownloadState = menuSnapshot ? searchDownloader.states[menuSnapshot.id] : undefined;
  const menuDownloaded = menuSnapshot
    ? diskLibrary.downloadedExternalIds.includes(menuSnapshot.id) ||
      menuDownloadState?.stage === "done"
    : true;

  return (
    <div className="flex min-h-dvh bg-[#121212] text-white">
      <Navigation
        view={view}
        playlists={library.playlists}
        selectedPlaylistId={selectedPlaylistId}
        likedCount={library.likedIds.length}
        onNavigate={handleNavigate}
        activePlaylistId={activePlaylistId}
        isPlaying={player.isPlaying}
        playablePlaylistIds={playablePlaylistIds}
        onTogglePlaylist={togglePlaylistPlaybackById}
        playlistTotalSeconds={playlistTotalSeconds}
               />

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Mobil üst bar */}
        <header className="sticky top-0 z-20 flex items-center gap-2 bg-[#121212]/95 px-4 pt-[env(safe-area-inset-top)] backdrop-blur md:hidden">
          <p className="flex min-h-[56px] items-center gap-2 text-lg font-bold">
            <TurkifyLogo className="h-6 w-6 shrink-0" />
            Turkify
          </p>
        </header>

        <main className="mx-auto w-full max-w-6xl min-w-0 flex-1 px-4 pt-4 pb-48 sm:px-6 sm:pt-8 md:pb-32">
          {removeError && <p role="alert" className="mb-4 text-sm text-[#FFB4BC]">{removeError}</p>}
          {view === "home" && (
            <div className="flex flex-col gap-8">
              <section aria-labelledby="home-title">
                <p className="text-sm text-[#B3B3B3]">
                  {t.home.eyebrow}
                </p>
                <h1
                  id="home-title"
                  className="mt-1 text-3xl font-bold tracking-tight sm:text-4xl"
                >
                  {greeting}
                </h1>
                <h2 className="mt-6 text-xl font-bold sm:text-2xl">{t.home.featured}</h2>
                <ul className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
                  {featuredItems.map((item) =>
                    item.kind === "track" ? (
                      <li key={`track:${item.track.id}`}>
                        <div className="group relative rounded-lg p-2 transition-colors hover:bg-[#282828]/60">
                          <button
                            type="button"
                            onClick={() =>
                              playInContext(featuredTracks, item.track, "featured")
                            }
                            aria-label={t.home.playTrack({ title: item.track.title })}
                            title={t.home.playTrack({ title: item.track.title })}
                            className="flex w-full flex-col gap-2 text-left focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                          >
                            <Image
                              src={item.track.cover}
                              alt={t.home.coverAlt({ album: item.track.album })}
                              width={300}
                              height={300}
                              unoptimized
                              className="aspect-square w-full rounded-lg object-cover"
                            />
                            <span className="truncate text-[15px] font-medium">{item.track.title}</span>
                            <span className="truncate text-sm text-[#B3B3B3]">{item.track.artist}</span>
                          </button>
                          {canPlayTrack(item.track) && (
                            <button
                              type="button"
                              onClick={() => {
                                if (player.currentTrackId === item.track.id) player.toggle();
                                else playInContext(featuredTracks, item.track, "featured");
                              }}
                              aria-label={player.currentTrackId === item.track.id && player.isPlaying ? t.player.pause : t.home.playTrack({ title: item.track.title })}
                              title={player.currentTrackId === item.track.id && player.isPlaying ? t.player.pause : t.home.playTrack({ title: item.track.title })}
                              className="absolute inset-x-2 top-2 flex aspect-square items-center justify-center rounded-lg bg-black/40 opacity-0 pointer-events-none transition-opacity group-hover:pointer-events-auto group-hover:opacity-100 focus-visible:pointer-events-auto focus-visible:opacity-100"
                            >
                              <span className="flex h-14 w-14 items-center justify-center rounded-full bg-black/60 text-white transition-transform hover:scale-105">
                                {player.currentTrackId === item.track.id && player.isPlaying ? (
                                  <PauseIcon className="h-6 w-6" />
                                ) : (
                                  <PlayIcon className="h-6 w-6" />
                                )}
                              </span>
                            </button>
                          )}
                        </div>
                      </li>
                    ) : (
                      <li key={`playlist:${item.playlist.id}`}>
                        <div className="group relative rounded-lg p-2 transition-colors hover:bg-[#282828]/60">
                          <button
                            type="button"
                            onClick={() => handleSelectPlaylist(item.playlist.id)}
                            aria-label={t.home.openPlaylist({ name: item.playlist.name })}
                            title={t.home.openPlaylist({ name: item.playlist.name })}
                            className="flex w-full flex-col gap-2 text-left focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                          >
                            <span className="relative block aspect-square w-full overflow-hidden rounded-lg">
                              <Image
                                src={playlistArtwork(item.playlist)}
                                alt={t.home.playlistCoverAlt({ name: item.playlist.name })}
                                width={300}
                                height={300}
                                unoptimized
                                className="aspect-square w-full rounded-lg object-cover"
                              />
                              <span className="absolute top-2 left-2 rounded-full bg-black/70 px-2.5 py-1 text-xs font-bold text-white">
                                {t.home.playlistBadge}
                              </span>
                            </span>
                            <span className="truncate text-[15px] font-medium">{item.playlist.name}</span>
                            <span className="truncate text-sm text-[#B3B3B3]">
                              {t.playlistPanel.trackCount({
                                count: new Set([
                                  ...item.playlist.trackIds,
                                  ...(item.playlist.importedTracks ?? []).map((t) => t.id),
                                ]).size,
                              })}
                              {playlistTotalText(item.playlist.id) && (
                                <>
                                  <span aria-hidden="true"> • </span>
                                  {playlistTotalText(item.playlist.id)}
                                </>
                              )}
                            </span>
                          </button>
                          {playablePlaylistIds.has(item.playlist.id) && (
                            <button
                              type="button"
                              onClick={() => togglePlaylistPlaybackById(item.playlist.id)}
                              aria-label={activePlaylistId === item.playlist.id && player.isPlaying ? t.playlistView.pausePlaylist({ name: item.playlist.name }) : t.playlistView.playPlaylist({ name: item.playlist.name })}
                              title={activePlaylistId === item.playlist.id && player.isPlaying ? t.playlistView.pausePlaylist({ name: item.playlist.name }) : t.playlistView.playPlaylist({ name: item.playlist.name })}
                              className="absolute inset-x-2 top-2 flex aspect-square items-center justify-center rounded-lg bg-black/40 opacity-0 pointer-events-none transition-opacity group-hover:pointer-events-auto group-hover:opacity-100 focus-visible:pointer-events-auto focus-visible:opacity-100"
                            >
                              <span className="flex h-14 w-14 items-center justify-center rounded-full bg-black/60 text-white transition-transform hover:scale-105">
                                {activePlaylistId === item.playlist.id && player.isPlaying ? (
                                  <PauseIcon className="h-6 w-6" />
                                ) : (
                                  <PlayIcon className="h-6 w-6" />
                                )}
                              </span>
                            </button>
                          )}
                        </div>
                      </li>
                    ),
                  )}
                </ul>
              </section>

              <section aria-labelledby="home-all-title">
                <h2 id="home-all-title" className="sr-only">
                  {homeTab === "liked" ? t.liked.title : t.home.allTracks}
                </h2>
                <div role="tablist" aria-label={t.home.allTracks} className="flex flex-wrap items-baseline gap-5">
                  {([
                    { key: "liked" as const, label: t.liked.title },
                    { key: "all" as const, label: t.home.allTracks },
                  ]).map((tab) => {
                    const active = homeTab === tab.key;
                    return (
                      <button
                        key={tab.key}
                        type="button"
                        role="tab"
                        aria-selected={active}
                        onClick={() => setHomeTab(tab.key)}
                        className={`bg-transparent px-0 text-xl font-bold transition-colors focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#1DB954] sm:text-2xl ${
                          active ? "text-white" : "text-[#B3B3B3] hover:text-white"
                        }`}
                      >
                        {tab.label}
                      </button>
                    );
                  })}
                </div>
                <div className="mt-2">
                  {/* Katalog ve kullanicinin kendi dosyalari tek listede; ayrim yok. */}
                  <TrackList
                    tracks={homeTracks}
                    likedIds={library.likedIds}
                    currentTrackId={player.currentTrackId}
                    isPlaying={player.isPlaying}
                    playlists={library.playlists}
                    emptyMessage={homeTab === "liked" ? t.liked.empty : t.home.allEmpty}
                    onPlay={(t) => playInContext(homeTracks, t, homeTab === "liked" ? "home:liked" : "all")}
                    onToggleLike={handleToggleLike}
                    onAddToPlaylist={addToPlaylistMessage}
                    onRemoveTrack={handleRemoveTrack}
                  />
                </div>
              </section>
            </div>
          )}

          {view === "search" && (
            <div className="flex flex-col gap-6">
              <section aria-labelledby="search-title">
                <h1 id="search-title" className="text-3xl font-bold tracking-tight sm:text-4xl">
                  {t.search.title}
                </h1>
                <div className="relative max-w-xl" onBlur={(event) => {
                  if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setSuggestionsOpen(false);
                }}>
                <form
                  role="search"
                  onSubmit={(e) => { e.preventDefault(); submitSearch(suggestionItems[activeSuggestion] ?? query); }}
                  className="mt-4 flex max-w-xl items-center gap-2 rounded-full border border-[#282828] bg-[#181818] px-4 focus-within:border-[#B3B3B3]"
                >
                  <SearchIcon className="h-5 w-5 shrink-0 text-[#B3B3B3]" />
                  <label htmlFor="search-input" className="sr-only">
                    {t.search.inputLabel}
                  </label>
                  <input
                    id="search-input"
                    type="search"
                    role="combobox"
                    aria-autocomplete="list"
                    aria-expanded={suggestionsOpen && suggestionItems.length > 0}
                    aria-controls="search-suggestions"
                    aria-activedescendant={suggestionsOpen && activeSuggestion >= 0 && activeSuggestion < suggestionItems.length ? `suggestion-${activeSuggestion}` : undefined}
                    onFocus={() => { readSearchHistory(); setSuggestionsOpen(true); setActiveSuggestion(-1); }}
                    onKeyDown={(event) => {
                      if (event.key === "Escape") { setSuggestionsOpen(false); setActiveSuggestion(-1); }
                      if ((event.key === "ArrowDown" || event.key === "ArrowUp") && suggestionItems.length) {
                        event.preventDefault();
                        setSuggestionsOpen(true);
                        setActiveSuggestion((previous) => (previous + (event.key === "ArrowDown" ? 1 : -1) + suggestionItems.length) % suggestionItems.length);
                      }
                    }}
                    value={query}
                    onChange={(e) => { setQuery(e.target.value); setSuggestionsOpen(true); setActiveSuggestion(-1); }}
                    placeholder={t.search.placeholder}
                    autoComplete="off"
                    className="min-h-[44px] min-w-0 flex-1 bg-transparent text-[15px] text-white placeholder:text-[#B3B3B3]/70 focus:outline-none"
                  />
                  {query.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setQuery("")}
                      aria-label={t.search.clearSearch}
                      className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full text-sm text-[#B3B3B3] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                    >
                      {t.search.clear}
                    </button>
                  )}
                </form>
                {suggestionsOpen && suggestionItems.length > 0 && (
                  <ul id="search-suggestions" role="listbox" aria-label={query.trim() ? t.search.suggestionsLabel : t.search.recentSearchesLabel} className="plk-scroll absolute inset-x-0 top-full z-40 mt-1 max-h-80 overflow-y-auto rounded-lg border border-[#383838] bg-[#202020] py-1 shadow-xl">
                    {suggestionItems.map((item, index) => (
                      <li key={item} id={`suggestion-${index}`} role="option" aria-selected={activeSuggestion === index} onMouseDown={(event) => event.preventDefault()} onClick={() => submitSearch(item)} className={`cursor-pointer break-words px-4 py-3 text-sm hover:bg-[#383838] ${activeSuggestion === index ? "bg-[#383838]" : ""}`}>
                        {item}
                      </li>
                    ))}
                  </ul>
                )}
                </div>
                <div className="mt-3 flex flex-wrap gap-4">
                  {(["local", "youtube", "spotify"] as const).map((source) => (
                    <label key={source} className="flex min-h-11 cursor-pointer items-center gap-2 text-sm">
                      <input type="checkbox" checked={searchSources[source]} onChange={(event) => setSearchSources((previous) => ({ ...previous, [source]: event.target.checked }))} className="h-4 w-4 accent-[#1DB954]" />
                      {source === "local" ? t.search.localSource : source === "youtube" ? "YouTube" : "Spotify"}
                    </label>
                  ))}
                </div>
                <p className="mt-2 text-sm text-[#B3B3B3]">{t.externalSearch.mixedHint}</p>
              </section>
              {searchSources.local && <section aria-labelledby="search-results-title">
                <h2 id="search-results-title" className="text-xl font-bold sm:text-2xl">
                  {searchResults === null
                    ? t.search.promptTitle
                    : t.search.resultsCount({ count: searchResults.length })}
                </h2>
                {searchResults === null ? (
                  <p className="mt-2 flex items-center gap-2 text-[15px] text-[#B3B3B3]">
                    <MusicIcon className="h-5 w-5 shrink-0" />
                    {t.search.hint}
                  </p>
                ) : (
                  <div className="mt-2">
                    <TrackList
                      tracks={searchResults}
                      likedIds={library.likedIds}
                      currentTrackId={player.currentTrackId}
                      isPlaying={player.isPlaying}
                      playlists={library.playlists}
                      emptyMessage={t.search.noResults({ query: query.trim() })}
                      onPlay={(tr) =>
                        playInContext(searchResults, tr, `search:${query.trim()}`)
                      }
                      onToggleLike={handleToggleLike}
                      onAddToPlaylist={addToPlaylistMessage}
                      onRemoveTrack={handleRemoveTrack}
                    />
                  </div>
                )}
              </section>}
              {externalSources && <section aria-live="polite">
                {musicSearch.hasSearched && (
                  <h2 id="search-external-title" className="text-xl font-bold sm:text-2xl">
                    {t.search.resultsCount({ count: musicSearch.results.length })}
                  </h2>
                )}
                <div className="mt-2">
                  <ExternalResults
                    tracks={musicSearch.results.filter((track) => searchSources[track.source])}
                    isLoading={musicSearch.isLoading}
                    error={musicSearch.error}
                    warnings={musicSearch.warnings}
                    query={musicSearch.submittedQuery}
                    hasSearched={musicSearch.hasSearched}
                    onDownloaded={handleDownloaded}
                    onFeedback={setDownloadFeedback}
                    onPlay={handlePlayExternal}
                    onLoadMore={musicSearch.loadMore}
                    isLoadingMore={musicSearch.isLoadingMore}
                    hasMore={musicSearch.hasMore}
                    downloadedIds={diskLibrary.downloadedExternalIds}
                    downloadedStems={diskLibrary.downloadedStems}
                    downloadedFormats={downloadedFormatsByExternalId}
                    audioFormat={codecPreference.audioFormat}
                    youtubeQuotaExceeded={musicSearch.youtubeQuotaExceeded}
                    likedIds={library.likedIds}
                    playlists={library.playlists}
                    onToggleLike={library.toggleExternalLike}
                    onAddToPlaylist={addExternalToPlaylistMessage}
                    downloadStates={searchDownloader.states}
                    onDownloadTrack={searchDownloader.download}
                    onClearDownloadTrackError={searchDownloader.clearError}
                  />
                </div>
                {downloadFeedback && (
                  <p role="status" className="mt-2 rounded-lg bg-[#1DB954] px-4 py-2 text-sm font-medium text-black">
                    {downloadFeedback}
                  </p>
                )}
              </section>}
              {searchSources.spotify && keysReady && (!spotifyKeys || musicSearch.needsSpotifyKeys) && (
                <section aria-labelledby="spotify-keys-title" className="mt-2">
                  <SpotifyKeysPanel
                    initialId={spotifyKeys?.clientId ?? ""}
                    initialSecret={spotifyKeys?.clientSecret ?? ""}
                    authFailed={spotifyKeys !== null && musicSearch.needsSpotifyKeys}
                    onSave={handleSaveKeys}
                  />
                </section>
              )}
              {searchSources.youtube && keysReady && (!youtubeKey || musicSearch.needsYoutubeKey) && (
                <section aria-labelledby="youtube-key-title" className="mt-2">
                  <YoutubeKeyPanel
                    initialKey={youtubeKey?.apiKey ?? ""}
                    keyFailed={youtubeKey !== null && musicSearch.needsYoutubeKey}
                    onSave={handleSaveYoutubeKey}
                  />
                </section>
              )}
            </div>
          )}

          {view === "library" && (
            <div className="flex flex-col gap-8">
              <section aria-labelledby="library-title">
                <h1 id="library-title" className="text-3xl font-bold tracking-tight sm:text-4xl">
                  {t.library.title}
                </h1>
                <p className="mt-2 max-w-2xl text-[15px] text-[#B3B3B3]">
                  {t.library.description}
                </p>
                <div className="mt-4 flex flex-col gap-2">
                  <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                    <label
                      htmlFor="local-files"
                      className="inline-flex min-h-[44px] cursor-pointer items-center justify-center gap-2 rounded-full bg-white px-6 text-sm font-bold text-black transition-transform hover:scale-105 focus-within:outline-2 focus-within:outline-offset-2 focus-within:outline-[#1DB954]"
                    >
                      <UploadIcon className="h-5 w-5" />
                      {t.library.chooseFile}
                    </label>
                    <input
                      ref={fileInputRef}
                      id="local-files"
                      type="file"
                      accept="audio/*"
                      multiple
                      onChange={(e) => handleFiles(e.target.files)}
                      className="sr-only"
                    />
                    <span className="text-sm text-[#B3B3B3]">
                      {t.library.multiHint}
                    </span>
                  </div>
                  {fileFeedback && (
                    <p role="status" className="text-sm text-[#1DB954]">
                      {fileFeedback}
                    </p>
                  )}
                  {fileError && (
                    <p role="alert" className="text-sm text-white">
                      {fileError}
                    </p>
                  )}
                </div>
              </section>

              <PlaylistPanel
                playlists={library.playlists}
                selectedPlaylistId={selectedPlaylistId}
                tracksById={tracksById}
                playlistTotalSeconds={playlistTotalSeconds}
                onSelect={handleSelectPlaylist}
                onCreate={(name, cover) => {
                  const result = library.createPlaylist(name, cover);
                  return result.message;
                }}
                onDelete={library.deletePlaylist}
                onAddToPlaylist={addToPlaylistMessage}
              />

              <section aria-labelledby="library-local-title">
                <h2 id="library-local-title" className="text-xl font-bold sm:text-2xl">
                  {t.library.deviceTitle({ count: localTracks.length })}
                </h2>
                {localTracks.length === 0 ? (
                  <p className="mt-2 text-[15px] text-[#B3B3B3]">
                    {t.library.deviceEmpty}
                  </p>
                ) : (
                  <div className="mt-2">
                    <TrackList
                      tracks={localTracks}
                      likedIds={library.likedIds}
                      currentTrackId={player.currentTrackId}
                      isPlaying={player.isPlaying}
                      playlists={library.playlists}
                      emptyMessage={t.library.noFiles}
                      onPlay={(t) => playInContext(localTracks, t, "local")}
                      onToggleLike={handleToggleLike}
                      onAddToPlaylist={addToPlaylistMessage}
                      onRemoveTrack={handleRemoveTrack}
                    />
                  </div>
                )}
              </section>

            </div>
          )}

          {view === "liked" && (
            <div className="flex flex-col gap-6">
              <section aria-labelledby="liked-title">
                <h1 id="liked-title" className="text-3xl font-bold tracking-tight sm:text-4xl">
                  {t.liked.title}
                </h1>
                <p className="mt-2 text-[15px] text-[#B3B3B3]">
                  {t.liked.subtitle({ count: likedTracks.length })}
                </p>
                <div className="mt-4">
                  <TrackList
                    tracks={likedTracks}
                    likedIds={library.likedIds}
                    currentTrackId={player.currentTrackId}
                    isPlaying={player.isPlaying}
                    playlists={library.playlists}
                    emptyMessage={t.liked.empty}
                    onPlay={(t) => playInContext(likedTracks, t, "liked")}
                    onToggleLike={handleToggleLike}
                    onAddToPlaylist={addToPlaylistMessage}
                    onRemoveTrack={handleRemoveLiked}
                  />
                </div>
              </section>
            </div>
          )}

          {view === "playlist" && (
            <div className="flex flex-col gap-6">
              <section aria-labelledby="playlist-view-title">
                <div className="flex items-center gap-4 sm:gap-5">
                  <button
                    type="button"
                    onClick={() => handleNavigate("library")}
                    aria-label={t.playlistView.backToLibrary}
                    title={t.playlistView.backToLibrary}
                    className="flex h-9 w-9 min-h-[36px] min-w-[36px] shrink-0 items-center justify-center rounded-full text-[#B3B3B3] transition-colors hover:bg-[#282828] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                  >
                    <BackIcon className="h-5 w-5" />
                  </button>
                  {selectedPlaylist && (
                    <div className="group relative shrink-0">
                      <img
                        src={playlistArtwork(selectedPlaylist)}
                        alt={t.playlistView.coverAlt({ name: selectedPlaylist.name })}
                        className="h-24 w-24 rounded-lg object-cover sm:h-32 sm:w-32"
                      />
                      {firstPlaylistTrack && (
                        <button
                          type="button"
                          onClick={togglePlaylistPlayback}
                          aria-label={isPlaylistPlaying ? t.playlistView.pausePlaylist({ name: selectedPlaylist.name }) : t.playlistView.playPlaylist({ name: selectedPlaylist.name })}
                          title={isPlaylistPlaying ? t.playlistView.pausePlaylist({ name: selectedPlaylist.name }) : t.playlistView.playPlaylist({ name: selectedPlaylist.name })}
                          className="absolute inset-0 flex items-center justify-center rounded-lg bg-black/40 opacity-0 pointer-events-none transition-opacity group-hover:pointer-events-auto group-hover:opacity-100 focus-visible:pointer-events-auto focus-visible:opacity-100"
                        >
                          <span className="flex h-14 w-14 items-center justify-center rounded-full bg-black/60 text-white transition-transform hover:scale-105">
                            {isPlaylistPlaying ? (
                              <PauseIcon className="h-6 w-6" />
                            ) : (
                              <PlayIcon className="h-6 w-6" />
                            )}
                          </span>
                        </button>
                      )}
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-3">
                  <h1 id="playlist-view-title" className="text-3xl font-bold tracking-tight sm:text-4xl">
                    {selectedPlaylist ? selectedPlaylist.name : t.playlistView.fallbackTitle}
                  </h1>
                  {selectedPlaylist && !playlistEditOpen && (
                    <button
                      type="button"
                      onClick={() => {
                        setPlaylistEditOpen(true);
                        setPlaylistViewFeedback(null);
                      }}
                      aria-label={t.playlistPanel.editList}
                      title={t.playlistPanel.editList}
                      className="flex h-9 w-9 min-h-[36px] min-w-[36px] items-center justify-center rounded-full text-[#B3B3B3] transition-colors hover:bg-[#282828] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                    >
                      <PencilIcon className="h-5 w-5" />
                    </button>
                  )}
                  {selectedPlaylist && !playlistAddOpen && (
                    <button
                      type="button"
                      onClick={() => {
                        setPlaylistAddOpen(true);
                        setPlaylistViewFeedback(null);
                      }}
                      aria-expanded={playlistAddOpen}
                      aria-label={`${t.playlistPanel.addSongs}: ${selectedPlaylist.name}`}
                      title={t.playlistPanel.addSongs}
                      className="flex h-9 w-9 min-h-[36px] min-w-[36px] items-center justify-center rounded-full text-[#B3B3B3] transition-colors hover:bg-[#282828] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                    >
                      <PlusIcon className="h-5 w-5" />
                    </button>
                  )}
                  {/* Indirme baslayinca bu dugme kaybolur: yerini durdur/iptal
                      dugmeleri alir, devre disi bir dugme orada durmaz. */}
                  {selectedPlaylist &&
                    playlistDownloadTracks.length > 0 &&
                    !(
                      playlistBulkDownload?.playlistId === selectedPlaylist.id &&
                      (playlistBulkDownload.running || playlistBulkDownload.outcome === "stopped")
                    ) && (
                    <button
                      type="button"
                      onClick={() => void handleDownloadSelectedPlaylist()}
                      disabled={pendingPlaylistDownloadTracks.length === 0}
                      aria-label={t.download.allForPlaylist({ name: selectedPlaylist.name })}
                      title={
                        pendingPlaylistDownloadTracks.length === 0
                          ? t.download.nothingPending
                          : t.download.allAction
                      }
                      className={`flex h-9 w-9 min-h-[36px] min-w-[36px] items-center justify-center rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] disabled:cursor-default ${
                        pendingPlaylistDownloadTracks.length === 0
                          ? "text-[#1DB954]"
                          : "text-[#B3B3B3] hover:bg-[#282828] hover:text-white"
                      }`}
                    >
                      {pendingPlaylistDownloadTracks.length === 0 ? (
                        <CheckIcon className="h-5 w-5" />
                      ) : (
                        <DownloadIcon className="h-5 w-5" />
                      )}
                    </button>
                  )}
                  {selectedPlaylist &&
                    playlistBulkDownload?.playlistId === selectedPlaylist.id &&
                    playlistBulkDownload.running && (
                      <>
                        <button
                          type="button"
                          onClick={handleStopBulkDownload}
                          disabled={playlistBulkDownload.stopRequested}
                          aria-label={playlistBulkDownload.stopRequested ? t.download.bulkResume : t.download.bulkStop}
                          title={playlistBulkDownload.stopRequested ? t.download.bulkPausing : t.download.bulkStopHint}
                          className="flex h-9 w-9 min-h-[36px] min-w-[36px] items-center justify-center rounded-full text-[#B3B3B3] transition-colors hover:bg-[#282828] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954] disabled:cursor-wait disabled:text-[#1DB954]"
                        >
                          {playlistBulkDownload.stopRequested ? (
                            <PlayIcon className="h-5 w-5" />
                          ) : (
                            <PauseIcon className="h-5 w-5" />
                          )}
                        </button>
                        <button
                          type="button"
                          onClick={() => setPendingBulkCancel(true)}
                          aria-label={t.download.bulkCancel}
                          title={t.download.bulkCancelHint}
                          className="flex h-9 w-9 min-h-[36px] min-w-[36px] items-center justify-center rounded-full text-[#B3B3B3] transition-colors hover:bg-[#282828] hover:text-[#E22134] focus-visible:outline-2 focus-visible:outline-[#E22134]"
                        >
                          <CloseIcon className="h-5 w-5" />
                        </button>
                      </>
                    )}
                  {selectedPlaylist &&
                    playlistBulkDownload?.playlistId === selectedPlaylist.id &&
                    !playlistBulkDownload.running &&
                    playlistBulkDownload.outcome === "stopped" && (
                      <button
                        type="button"
                        onClick={() => void handleDownloadSelectedPlaylist()}
                        aria-label={t.download.bulkResume}
                        title={t.download.bulkResumeHint}
                        className="flex h-9 w-9 min-h-[36px] min-w-[36px] items-center justify-center rounded-full text-[#1DB954] transition-colors hover:bg-[#282828] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                      >
                        <PlayIcon className="h-5 w-5" />
                      </button>
                    )}
                    </div>
                  </div>
                </div>
                {selectedPlaylist && playlistAddOpen && (
                  <div className="mt-3 max-w-2xl">
                    <PlaylistAddSongs
                      key={selectedPlaylist.id}
                      playlist={selectedPlaylist}
                      allTracks={allTracks}
                      onAddToPlaylist={addToPlaylistMessage}
                      onAdded={(message) => setPlaylistViewFeedback(message)}
                      onClose={() => setPlaylistAddOpen(false)}
                    />
                  </div>
                )}
                {selectedPlaylist && playlistEditOpen && (
                  <PlaylistEditForm
                    key={selectedPlaylist.id}
                    playlist={selectedPlaylist}
                    idPrefix="view-edit"
                    onSubmit={(playlistId, patch) =>
                      library.updatePlaylist(playlistId, patch).message
                    }
                    onSaved={(message) => {
                      setPlaylistViewFeedback(message);
                      setPlaylistEditOpen(false);
                    }}
                    onCancel={() => setPlaylistEditOpen(false)}
                  />
                )}
                {playlistViewFeedback && (
                  <p role="status" className="mt-2 text-sm text-[#B3B3B3]">
                    {playlistViewFeedback}
                  </p>
                )}
                {!selectedPlaylist ? (
                  <p className="mt-2 text-[15px] text-[#B3B3B3]">
                    {t.playlistView.notFound}
                  </p>
                ) : (
                  <>
                    <p className="mt-2 text-[15px] text-[#B3B3B3]">
                      {t.playlistView.trackCount({ count: selectedPlaylistTracks.length })}
                      {selectedPlaylistTotal && (
                        <>
                          <span aria-hidden="true"> • </span>
                          {selectedPlaylistTotal}
                        </>
                      )}
                    </p>
                    {selectedPlaylistTracks.length > 0 && (
                      <div className="mt-3 max-w-xl">
                        <input
                          type="search"
                          value={playlistSearch}
                          onChange={(e) => setPlaylistSearch(e.target.value)}
                          placeholder={t.playlistView.searchPlaceholder}
                          aria-label={t.playlistView.searchPlaceholder}
                          autoComplete="off"
                          className="min-h-[44px] w-full rounded-lg border border-[#282828] bg-[#181818] px-3 text-sm text-white placeholder:text-[#B3B3B3]/70 focus:outline-3 focus:outline-[#444444] focus:ring-0"
                        />
                      </div>
                    )}
                    {playlistBulkDownload?.playlistId === selectedPlaylist.id && (
                      <div className="mt-3 max-w-xl" aria-live="polite">
                        {playlistBulkDownload.running ? (
                          <>
                            <div className="mb-1.5 flex items-center justify-between gap-4 text-xs text-[#B3B3B3]">
                              <span className="min-w-0 truncate">
                                {playlistBulkDownload.currentTitle
                                  ? playlistBulkDownload.stopRequested
                                    ? t.download.bulkPausing
                                    : t.download.bulkCurrent({ title: playlistBulkDownload.currentTitle })
                                  : t.download.downloading}
                              </span>
                              <span className="flex shrink-0 items-baseline gap-2">
                                <span className="tabular-nums text-white">
                                  {t.download.bulkProgress({
                                    completed: playlistBulkDownload.completed,
                                    total: playlistBulkDownload.total,
                                  })}
                                </span>
                                {/* Basarisiz parcalar sayaca dahil; kac tanesinin
                                    inmedigi anlik olarak sagda gorunur. */}
                                {playlistBulkDownload.failed > 0 && (
                                  <span className="tabular-nums text-[#FFB4BC]">
                                    {t.download.bulkProgressFailed({
                                      failed: playlistBulkDownload.failed,
                                    })}
                                  </span>
                                )}
                              </span>
                            </div>
                            <div
                              role="progressbar"
                              aria-label={t.download.bulkProgressLabel}
                              aria-valuemin={0}
                              aria-valuemax={playlistBulkDownload.total}
                              aria-valuenow={playlistBulkDownload.completed}
                              className="h-1.5 overflow-hidden rounded-full bg-[#333333]"
                            >
                              <span
                                className="block h-full rounded-full bg-[#1DB954] transition-[width] duration-300"
                                style={{
                                  width: `${playlistBulkDownload.total > 0 ? (playlistBulkDownload.completed / playlistBulkDownload.total) * 100 : 0}%`,
                                }}
                              />
                            </div>
                          </>
                        ) : (
                          <p role="status" className={playlistBulkDownload.outcome === "done" ? (playlistBulkDownload.failed > 0 ? "text-sm text-[#FFB4BC]" : "text-sm text-[#1DB954]") : "text-sm text-[#B3B3B3]"}>
                            {playlistBulkDownload.outcome === "cancelled"
                              ? t.download.bulkCancelled({ completed: playlistBulkDownload.completed })
                              : playlistBulkDownload.outcome === "stopped"
                                ? t.download.bulkStopped({ completed: playlistBulkDownload.completed, total: playlistBulkDownload.total })
                              : playlistBulkDownload.failed > 0
                                ? t.download.bulkDoneWithErrors({
                                    count: playlistBulkDownload.completed - playlistBulkDownload.failed,
                                    failed: playlistBulkDownload.failed,
                                  })
                                : t.download.bulkDone({ count: playlistBulkDownload.completed })}
                          </p>
                        )}
                      </div>
                    )}
                    <div className="mt-4">
                      <TrackList
                        tracks={playlistSearchResults}
                        likedIds={library.likedIds}
                        currentTrackId={player.currentTrackId}
                        isPlaying={player.isPlaying}
                        playlists={library.playlists}
                        emptyMessage={playlistSearch.trim() ? t.search.noResults({ query: playlistSearch.trim() }) : t.playlistView.empty}
                        showRemove={{ playlistId: selectedPlaylist.id }}
                        onPlay={(t) =>
                          playInContext(
                            playlistSearchResults,
                            t,
                            `playlist:${selectedPlaylist.id}`,
                          )
                        }
                        onToggleLike={handleToggleLike}
                        onAddToPlaylist={addToPlaylistMessage}
                        onRemoveTrack={handleRemoveTrack}
                        onRemoveFromPlaylist={handleRemoveFromPlaylist}
                        downloadTools={{
                          tracks: playlistDownloadTracks,
                          audioFormat: codecPreference.audioFormat,
                          downloadedIds: diskLibrary.downloadedExternalIds,
                          downloadedFormats: downloadedFormatsByExternalId,
                          states: playlistDownloader.states,
                          bulkRunning:
                            playlistBulkDownload?.playlistId === selectedPlaylist.id &&
                            playlistBulkDownload.running,
                          download: playlistDownloader.download,
                          onDownloaded: handleDownloaded,
                        }}
                      />
                    </div>
                  </>
                )}
              </section>
            </div>
          )}

          {view === "settings" && (
            <div className="flex flex-col gap-6">
              <section aria-labelledby="settings-title">
                <h1 id="settings-title" className="text-3xl font-bold tracking-tight sm:text-4xl">
                  {t.settings.title}
                </h1>
                <h2 className="mt-6 text-xl font-bold sm:text-2xl">
                  {t.settings.languageTitle}
                </h2>
                <p className="mt-2 text-[15px] text-[#B3B3B3]">
                  {t.settings.languageDescription}
                </p>
                <div className="mt-4">
                  <LocaleSwitcher />
                </div>
              </section>

              <CodecSettings
                audioFormat={codecPreference.audioFormat}
                hydrated={codecPreference.hydrated}
                setAudioFormat={codecPreference.setAudioFormat}
                onLibraryChanged={reloadDisk}
              />

              <EqSettingsPanel eq={player.eq} onEq={player.setEq} />

               <section aria-labelledby="settings-connections-title">
                <h2 id="settings-connections-title" className="text-xl font-bold sm:text-2xl">
                  {t.settings.connectionsTitle}
                </h2>
                <p className="mt-2 max-w-2xl text-[15px] text-[#B3B3B3]">
                  {t.settings.connectionsDescription}
                </p>
                <ul className="mt-4 flex max-w-2xl flex-col gap-3">
                  {([
                    { key: "spotify" as const, label: t.settings.spotifyLabel, connected: spotifyKeys !== null },
                    { key: "youtube" as const, label: t.settings.youtubeLabel, connected: youtubeKey !== null },
                  ]).map((service) => (
                    <li
                      key={service.key}
                      className="flex flex-wrap items-center justify-between gap-3 rounded-lg bg-[#181818] px-4 py-3"
                    >
                      <span className="flex min-w-0 flex-col">
                        <span className="text-[15px] font-medium text-white">{service.label}</span>
                        <span
                          className={`text-sm ${service.connected ? "text-[#1DB954]" : "text-[#B3B3B3]"}`}
                        >
                          {service.connected
                            ? t.settings.statusConnected
                            : t.settings.statusNotConnected}
                        </span>
                      </span>
                      <button
                        type="button"
                        disabled={!service.connected}
                        onClick={() => setPendingRemoval(service.key)}
                        className="flex min-h-[44px] items-center justify-center rounded-full bg-[#282828] px-5 text-sm font-bold text-white transition-colors hover:bg-[#E22134] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E22134] disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-[#282828]"
                      >
                        {t.settings.removeKeys}
                      </button>
                    </li>
                  ))}
                </ul>
               </section>

                {keysReady && (
                  <SpotifyPlaylistImport
                    clientId={spotifyKeys?.clientId ?? ""}
                    clientSecret={spotifyKeys?.clientSecret ?? ""}
                    onImport={(name, cover, tracks, spotifyId) => library.importSpotifyPlaylist(name, cover, tracks, spotifyId)}
                  />
                )}

                {keysReady && (
                  <YoutubePlaylistImport
                    onImport={(name, cover, tracks, youtubeId) => library.importYoutubePlaylist(name, cover, tracks, youtubeId)}
                  />
                )}


            </div>
          )}
        </main>
      </div>

      {pendingRemoval && (
        <ConfirmDialog
          title={t.settings.removeConfirmTitle({
            service: pendingRemoval === "spotify" ? t.settings.spotifyLabel : t.settings.youtubeLabel,
          })}
          message={t.settings.removeConfirmMessage}
          confirmLabel={t.settings.removeConfirm}
          cancelLabel={t.settings.removeCancel}
          onConfirm={handleConfirmRemoval}
          onCancel={() => setPendingRemoval(null)}
        />
      )}

      {pendingBulkCancel && (
        <ConfirmDialog
          title={t.download.bulkCancelTitle}
          message={t.download.bulkCancelMessage}
          confirmLabel={t.download.bulkCancelConfirm}
          cancelLabel={t.download.bulkCancelKeep}
          onConfirm={handleCancelBulkDownload}
          onCancel={() => setPendingBulkCancel(false)}
        />
      )}

      <Player
        currentTrack={player.currentTrack}
        isPlaying={player.isPlaying}
        currentTime={player.currentTime}
        duration={player.duration}
        volume={player.volume}
        muted={player.muted}
        playerError={player.playerError}
        isResolving={player.isResolving}
        canGoNext={player.canGoNext}
        canGoPrev={player.canGoPrev}
        repeatMode={player.repeatMode}
        onToggle={player.toggle}
        onSeek={player.seekTo}
        onVolume={player.setVolume}
        onToggleMute={player.toggleMute}
        onNext={player.playNext}
        onPrev={player.playPrev}
        onCycleRepeat={player.cycleRepeatMode}
        onCycleShuffle={player.cycleShuffle}
        shuffleMode={player.shuffleMode}
        isSmartSuggestion={
          player.currentTrack !== null && player.smartIds.includes(player.currentTrack.id)
        }
        navKey={view}
        isLiked={player.currentTrackId !== null && library.likedIds.includes(player.currentTrackId)}
        onToggleLike={() => {
          if (player.currentTrackId) handleToggleLike(player.currentTrackId);
        }}
        menuPlaylists={library.playlists}
        playlistDurations={playlistTotalSeconds}
        onAddToPlaylist={addToPlaylistMessage}
        onRemoveCurrent={() => {
          const track = player.currentTrack;
          if (track) handleRemoveLiked(track);
        }}
        menuDownloadable={menuSnapshot !== undefined}
        menuDownloaded={menuDownloaded}
        menuDownloading={menuDownloadState?.stage === "downloading"}
        menuDownloadError={
          menuDownloadState?.stage === "error" ? (menuDownloadState.message ?? null) : null
        }
        onDownloadCurrent={() => {
          if (menuSnapshot) void searchDownloader.download(menuSnapshot, (local) => handleDownloaded(local));
        }}
        onDismissError={player.dismissError}
        remix={player.remix}
        onRemix={player.setRemix}
        onSaveTrackRemix={player.saveTrackRemix}
      />
    </div>
  );
}
