"use client";

import { useEffect, useRef, useState } from "react";

import {
  DEFAULT_EQ,
  EQ_FREQUENCIES,
  EQ_MAX_DB,
  EQ_PRESETS,
  isDefaultEq,
  type EqSettings,
} from "../lib/audio-effects";
import { formatFrequency, gainColor, gainPosition } from "../lib/eq-color";
import { EqIcon } from "./icons";
import { useI18n } from "./locale-provider";

interface EqSettingsPanelProps {
  eq: EqSettings;
  onEq: (next: EqSettings) => void;
}

/**
 * Dikey bantlardan olusan esitleyici. Bant yuksekligi -20..+20 dB arasinda
 * 1 dB adimla degisir; ok tuslari 1 dB, Shift ile 3 dB oynatir. Renk kazanca
 * gore kirmizidan koyu yesile gider; hem kanali dolduran dolgu hem de slider
 * oku ayni rengi tasir.
 */
export default function EqSettingsPanel({ eq, onEq }: EqSettingsPanelProps) {
  const { t } = useI18n();
  const [preview, setPreview] = useState<number | null>(null);
  const trackRef = useRef<HTMLDivElement | null>(null);
  const draggingRef = useRef<number | null>(null);
  const activeCount = eq.filter((value) => Math.abs(value) >= 0.001).length;
  const flat = isDefaultEq(eq);
  const bandGap = "gap-1.5 sm:gap-3";

  const setBand = (index: number, value: number) => {
    const next = [...eq];
    next[index] = Math.round(Math.min(EQ_MAX_DB, Math.max(-EQ_MAX_DB, value)) * 10) / 10;
    onEq(next);
  };

  /** Dik konumdan (clientY) bant kazancini hesaplar; ust = boost. */
  const valueFromClientY = (clientY: number): number => {
    const rect = trackRef.current?.getBoundingClientRect();
    if (!rect || rect.height <= 0) return 0;
    const ratio = (rect.bottom - clientY) / rect.height;
    return (Math.min(1, Math.max(0, ratio)) * 2 - 1) * EQ_MAX_DB;
  };

  const onPointerDown = (index: number) => (event: React.PointerEvent<HTMLDivElement>) => {
    event.preventDefault();
    draggingRef.current = index;
    event.currentTarget.setPointerCapture(event.pointerId);
    setBand(index, valueFromClientY(event.clientY));
  };

  const onPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const index = draggingRef.current;
    if (index === null) return;
    setBand(index, valueFromClientY(event.clientY));
  };

  const endDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    draggingRef.current = null;
    try {
      event.currentTarget.releasePointerCapture(event.pointerId);
    } catch {
      // yok say
    }
  };

  // Mouse tekerlegi: imlecin uzerindeki banti 1 dB oynatir, sayfa kaymaz.
  // React wheel'i pasif bagladigi icin preventDefault etmez; bu yuzden native
  // dinleyici `passive: false` ile eklenir (player.tsx ile ayni desen).
  useEffect(() => {
    const root = trackRef.current;
    if (!root) return;
    const onWheel = (e: WheelEvent) => {
      const target = e.target as HTMLElement | null;
      const band = target?.closest?.("[data-eq-band]") as HTMLElement | null;
      if (!band) return;
      const index = Number(band.dataset.eqBand);
      if (!Number.isInteger(index)) return;
      e.preventDefault();
      const step = e.shiftKey ? 3 : 1;
      const current = eq[index] ?? 0;
      setBand(index, current + (e.deltaY < 0 ? step : -step));
    };
    root.addEventListener("wheel", onWheel, { passive: false });
    return () => root.removeEventListener("wheel", onWheel);
  }, [eq]);

  const presetLabels: Record<string, string> = {
    flat: t.eq.presetFlat,
    "bass-boost": t.eq.presetBassBoost,
    vocal: t.eq.presetVocal,
    "pastel-ghost": t.eq.presetPastelGhost,
    treble: t.eq.presetTreble,
  };

  const activePreset = EQ_PRESETS.find((preset) =>
    preset.value.every((gain, index) => gain === (eq[index] ?? 0)),
  );

  return (
    <section aria-labelledby="settings-eq-title" className="max-w-2xl">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <EqIcon className="h-5 w-5 text-[#1DB954]" />
          <h2 id="settings-eq-title" className="text-xl font-bold sm:text-2xl">
            {t.eq.title}
          </h2>
        </div>
        <span
          className={`rounded-full px-3 py-1 text-xs font-bold ${
            flat ? "bg-[#282828] text-[#B3B3B3]" : "bg-[#1DB954]/15 text-[#1DB954]"
          }`}
        >
          {flat ? t.eq.flat : t.eq.activeBands({ count: activeCount })}
        </span>
      </div>
      <p className="mt-2 text-[15px] leading-6 text-[#B3B3B3]">{t.eq.description}</p>

      <div className="mt-5 border-t border-[#2A2A2A] pt-5">
        <div className="mb-4 flex flex-wrap gap-2" role="group" aria-label={t.eq.presetsLabel}>
          {EQ_PRESETS.map((preset) => {
            const active = activePreset?.id === preset.id;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => onEq([...preset.value])}
                aria-pressed={active}
                className={`min-h-[44px] rounded-full px-4 text-xs font-bold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] ${
                  active
                    ? "bg-white text-black"
                    : "bg-[#181818] text-[#B3B3B3] hover:text-white"
                }`}
              >
                {presetLabels[preset.id] ?? preset.id}
              </button>
            );
          })}
        </div>
        <div className="flex gap-3">
          {/* dB ekseni; track alanina hizali */}
          <div className="relative w-7 shrink-0" aria-hidden="true">
            <span className="absolute top-0 right-0 -translate-y-1/2 text-[10px] font-medium text-[#6A6A6A]">
              +20
            </span>
            <span className="absolute top-1/2 right-0 -translate-y-1/2 text-[10px] font-medium text-[#6A6A6A]">
              0
            </span>
            <span className="absolute bottom-0 right-0 translate-y-1/2 text-[10px] font-medium text-[#6A6A6A]">
              -20
            </span>
          </div>

          <div className="min-w-0 flex-1">
            {/* Track alani: ızgara + bantlar */}
            <div
              ref={trackRef}
              className={`relative flex h-[15rem] items-stretch ${bandGap}`}
            >
              <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-[#333333]" aria-hidden="true" />
              <div className="pointer-events-none absolute inset-x-0 top-1/2 h-px bg-[#2E2E2E]" aria-hidden="true" />
              <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-[#333333]" aria-hidden="true" />

              {EQ_FREQUENCIES.map((frequency, index) => {
                const value = eq[index] ?? 0;
                const pos = gainPosition(value); // 0 alt, 1 ust
                const fill = gainColor(value, 0.9);
                const showTip = preview === index;
                return (
                  <div
                    key={frequency}
                    role="slider"
                    tabIndex={0}
                    aria-label={t.eq.bandLabel({ frequency: String(frequency) })}
                    aria-orientation="vertical"
                    aria-valuemin={-20}
                    aria-valuemax={20}
                    data-eq-band={index}
                    aria-valuenow={Math.round(value * 10) / 10}
                    aria-valuetext={t.eq.valueDb({ value: value.toFixed(1) })}
                    onPointerDown={onPointerDown(index)}
                    onPointerMove={onPointerMove}
                    onPointerUp={endDrag}
                    onPointerCancel={endDrag}
                    onMouseEnter={() => setPreview(index)}
                    onMouseLeave={() => setPreview((p) => (p === index ? null : p))}
                    onFocus={() => setPreview(index)}
                    onBlur={() => setPreview((p) => (p === index ? null : p))}
                    onKeyDown={(e) => {
                      const step = e.shiftKey ? 3 : 1;
                      if (e.key === "ArrowUp" || e.key === "ArrowRight") {
                        e.preventDefault();
                        setBand(index, value + step);
                      } else if (e.key === "ArrowDown" || e.key === "ArrowLeft") {
                        e.preventDefault();
                        setBand(index, value - step);
                      } else if (e.key === "Home") {
                        e.preventDefault();
                        setBand(index, -EQ_MAX_DB);
                      } else if (e.key === "End") {
                        e.preventDefault();
                        setBand(index, EQ_MAX_DB);
                      }
                    }}
                    className="group relative min-w-0 flex-1 cursor-ns-resize rounded-full focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954]"
                  >
                    {/* Dolgu: tabandan mevcut konuma; kirmizidan mevcut renge */}
                    <span
                      aria-hidden="true"
                      className="absolute bottom-0 left-1/2 w-2 -translate-x-1/2 rounded-full transition-[height] duration-75"
                      style={{
                        height: `${Math.max(pos * 100, 3)}%`,
                        background: `linear-gradient(to top, ${gainColor(-EQ_MAX_DB, 0.35)}, ${fill})`,
                      }}
                    />
                    {/* Slider oku */}
                    <span
                      aria-hidden="true"
                      className="absolute left-1/2 h-2.5 w-6 -translate-x-1/2 rounded-full transition-[bottom] duration-75"
                      style={{
                        bottom: `calc(${pos * 100}% - 0.3125rem)`,
                        background: fill,
                        boxShadow: `0 0 0 2px #181818, 0 0 10px ${gainColor(value, 0.6)}`,
                      }}
                    />
                    {showTip && (
                      <span
                        aria-hidden="true"
                        className="absolute left-1/2 -translate-x-1/2 rounded-full px-2 py-0.5 text-[10px] font-bold whitespace-nowrap text-black tabular-nums"
                        style={{
                          bottom: `calc(${pos * 100}% + 1.1rem)`,
                          background: fill,
                        }}
                      >
                        {value > 0 ? "+" : ""}
                        {value.toFixed(1)} dB
                      </span>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Frekans etiketleri; bantlarla ayni genislik/gap ile hizali */}
            <div className={`mt-2 flex ${bandGap}`} aria-hidden="true">
              {EQ_FREQUENCIES.map((frequency) => (
                <span
                  key={frequency}
                  className="min-w-0 flex-1 text-center text-[11px] font-medium text-[#8A8A8A] tabular-nums"
                >
                  {formatFrequency(frequency)}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-5 flex items-center justify-end">
          <button
            type="button"
            disabled={flat}
            onClick={() => onEq([...DEFAULT_EQ])}
            className="min-h-[44px] rounded-full bg-[#282828] px-5 text-sm font-bold text-white transition-colors hover:bg-[#3E3E3E] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] disabled:cursor-not-allowed disabled:opacity-40"
          >
            {t.eq.reset}
          </button>
        </div>
      </div>
    </section>
  );
}
