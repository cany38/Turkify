"use client";

import { useEffect, useRef } from "react";

interface ConfirmDialogProps {
  title: string;
  message: string;
  confirmLabel: string;
  cancelLabel: string;
  onConfirm: () => void;
  onCancel: () => void;
}

/**
 * Geri alinamayan islemler icin onay penceresi.
 *
 * Odak acilista Vazgec dugmesine gider ve Escape kapatir; yani yanlislikla
 * dokunan biri Enter'a bassa bile silme calismaz.
 */
export function ConfirmDialog({
  title,
  message,
  confirmLabel,
  cancelLabel,
  onConfirm,
  onCancel,
}: ConfirmDialogProps) {
  const cancelRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    cancelRef.current?.focus();
  }, []);

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onCancel();
    };
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, [onCancel]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <button
        type="button"
        aria-label={cancelLabel}
        onClick={onCancel}
        className="absolute inset-0 cursor-default bg-black/70"
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="confirm-dialog-title"
        aria-describedby="confirm-dialog-message"
        className="relative z-10 w-[min(28rem,100%)] rounded-lg border border-[#282828] bg-[#181818] p-6 shadow-xl"
      >
        <h2 id="confirm-dialog-title" className="text-xl font-bold text-white">
          {title}
        </h2>
        <p id="confirm-dialog-message" className="mt-2 text-[15px] text-[#B3B3B3]">
          {message}
        </p>
        <div className="mt-6 flex flex-wrap justify-end gap-3">
          <button
            ref={cancelRef}
            type="button"
            onClick={onCancel}
            className="flex min-h-[44px] items-center justify-center rounded-full bg-[#282828] px-5 text-sm font-bold text-white transition-colors hover:bg-[#3E3E3E] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954]"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="flex min-h-[44px] items-center justify-center rounded-full bg-[#E22134] px-5 text-sm font-bold text-white transition-transform hover:scale-105 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E22134]"
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
