"use client";

import { useEffect, useRef, useState } from "react";

import type { AudioFormat } from "../lib/audio-format";
import { useCodecMigration } from "../hooks/use-codec-migration";
import { useI18n } from "./locale-provider";

interface CodecSettingsProps {
  audioFormat: AudioFormat;
  hydrated: boolean;
  setAudioFormat: (format: AudioFormat) => boolean;
  onLibraryChanged: () => void | Promise<void>;
}

export function CodecSettings({
  audioFormat,
  hydrated,
  setAudioFormat,
  onLibraryChanged,
}: CodecSettingsProps) {
  const { t } = useI18n();
  const migration = useCodecMigration();
  const [pendingFormat, setPendingFormat] = useState<AudioFormat | null>(null);
  const safeChoiceRef = useRef<HTMLButtonElement | null>(null);
  const refreshedJobRef = useRef<string | null>(null);

  useEffect(() => {
    if (!pendingFormat) return;
    safeChoiceRef.current?.focus();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setPendingFormat(null);
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [pendingFormat]);

  useEffect(() => {
    if (migration.status?.state === "running") {
      refreshedJobRef.current = null;
      return;
    }
    if (migration.status?.state !== "completed") return;
    if (refreshedJobRef.current === migration.status.id) return;
    refreshedJobRef.current = migration.status.id;
    void onLibraryChanged();
  }, [migration.status, onLibraryChanged]);

  const chooseFormat = (format: AudioFormat) => {
    if (!hydrated || format === audioFormat || migration.status?.state === "running") return;
    setPendingFormat(format);
  };

  const keepExisting = () => {
    if (!pendingFormat) return;
    setAudioFormat(pendingFormat);
    setPendingFormat(null);
  };

  const migrateExisting = async () => {
    if (!pendingFormat) return;
    const format = pendingFormat;
    if (!setAudioFormat(format)) return;
    setPendingFormat(null);
    await migration.start(format);
  };

  const options: Array<{
    format: AudioFormat;
    title: string;
    description: string;
    badge: string;
  }> = [
    {
      format: "opus",
      title: t.settings.opusLabel,
      description: t.settings.opusDescription,
      badge: t.settings.opusBadge,
    },
    {
      format: "aac",
      title: t.settings.aacLabel,
      description: t.settings.aacDescription,
      badge: t.settings.aacBadge,
    },
  ];

  return (
    <section aria-labelledby="settings-codec-title" className="max-w-2xl">
      <h2 id="settings-codec-title" className="text-xl font-bold sm:text-2xl">
        {t.settings.codecTitle}
      </h2>
      <p className="mt-2 text-[15px] leading-6 text-[#B3B3B3]">
        {t.settings.codecDescription}
      </p>

      <div role="radiogroup" aria-label={t.settings.codecTitle} className="mt-4 grid gap-3 sm:grid-cols-2">
        {options.map((option) => {
          const selected = option.format === audioFormat;
          return (
            <button
              key={option.format}
              type="button"
              role="radio"
              aria-checked={selected}
              disabled={!hydrated || migration.status?.state === "running"}
              onClick={() => chooseFormat(option.format)}
              className={`min-h-[132px] rounded-xl p-4 text-left transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] disabled:cursor-not-allowed disabled:opacity-60 ${
                selected
                  ? "bg-[#1DB954] text-black"
                  : "bg-[#181818] text-white hover:bg-[#242424]"
              }`}
            >
              <span className="flex items-start justify-between gap-3">
                <span className="text-lg font-bold">{option.title}</span>
                <span
                  className={`rounded-full px-2.5 py-1 text-xs font-bold ${
                    selected ? "bg-black/15 text-black" : "bg-[#282828] text-[#D8D8D8]"
                  }`}
                >
                  {selected ? t.settings.codecSelected : option.badge}
                </span>
              </span>
              <span className={`mt-3 block text-sm leading-5 ${selected ? "text-black/75" : "text-[#B3B3B3]"}`}>
                {option.description}
              </span>
            </button>
          );
        })}
      </div>

      {migration.error ? (
        <p role="alert" className="mt-4 rounded-lg bg-[#3A171B] px-4 py-3 text-sm text-[#FFB4BC]">
          {migration.error}
        </p>
      ) : null}

      {migration.status ? (
        <div className="mt-5 rounded-xl bg-[#181818] p-4" aria-live="polite">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <h3 className="font-bold text-white">{t.settings.migrationTitle}</h3>
            <span className="text-sm font-bold tabular-nums text-white">
              {migration.status.percent}%
            </span>
          </div>
          <div
            role="progressbar"
            aria-label={t.settings.migrationTitle}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={migration.status.percent}
            className="mt-3 h-2 overflow-hidden rounded-full bg-[#333333]"
          >
            <div
              className="h-full rounded-full bg-[#1DB954] transition-[width] duration-300 motion-reduce:transition-none"
              style={{ width: `${migration.status.percent}%` }}
            />
          </div>
          <p className="mt-3 text-sm text-[#D8D8D8]">
            {t.settings.migrationProgress({
              completed: migration.status.completed,
              total: migration.status.total,
            })}
          </p>
          {migration.status.currentTitle ? (
            <p className="mt-1 truncate text-sm text-[#B3B3B3]" title={migration.status.currentTitle}>
              {t.settings.migrationCurrent({ title: migration.status.currentTitle })}
            </p>
          ) : null}
          <p className="mt-3 text-sm leading-5 text-[#B3B3B3]">
            {t.settings.manualUploadNote({ count: migration.status.manualCount })}
          </p>

          {migration.status.failures.length > 0 ? (
            <div className="mt-4 border-t border-[#2A2A2A] pt-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h4 className="font-bold text-[#FFB4BC]">
                  {t.settings.failedTracks({ count: migration.status.failures.length })}
                </h4>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    disabled={migration.busy || migration.status.state === "running"}
                    onClick={() => void migration.retry(migration.status!.id)}
                    className="min-h-[44px] rounded-full bg-white px-4 text-sm font-bold text-black transition-transform hover:scale-[1.03] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {migration.busy ? t.settings.retrying : t.settings.retryFailed}
                  </button>
                  {migration.status.state !== "running" ? (
                    <button
                      type="button"
                      disabled={migration.busy}
                      onClick={() => void migration.dismiss(migration.status!.id)}
                      className="min-h-[44px] rounded-full bg-[#282828] px-5 text-sm font-bold text-white hover:bg-[#3E3E3E] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {t.settings.dismissFailed}
                    </button>
                  ) : null}
                </div>
              </div>
              <ul className="mt-3 space-y-2">
                {migration.status.failures.map((failure) => (
                  <li key={failure.libraryId} className="min-w-0 rounded-lg bg-[#25191B] px-3 py-2">
                    <p className="truncate text-sm font-semibold text-white" title={failure.title}>
                      {failure.title}
                    </p>
                    <p className="mt-0.5 text-sm leading-5 text-[#FFB4BC]">{failure.message}</p>
                  </li>
                ))}
              </ul>
            </div>
          ) : migration.status.state !== "running" ? (
            <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
              {migration.status.state === "completed" ? (
                <p className="text-sm font-semibold text-[#1DB954]">
                  {t.settings.migrationCompleted}
                </p>
              ) : null}
              <button
                type="button"
                disabled={migration.busy}
                onClick={() => void migration.dismiss(migration.status!.id)}
                className="min-h-[44px] rounded-full bg-[#282828] px-5 text-sm font-bold text-white hover:bg-[#3E3E3E] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {t.settings.dismissSummary}
              </button>
            </div>
          ) : null}
        </div>
      ) : null}

      {pendingFormat ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <button
            type="button"
            aria-label={t.settings.codecCancel}
            onClick={() => setPendingFormat(null)}
            className="absolute inset-0 cursor-default bg-black/75"
          />
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="codec-dialog-title"
            aria-describedby="codec-dialog-message"
            className="relative z-10 w-[min(32rem,100%)] rounded-xl bg-[#181818] p-6 shadow-2xl"
          >
            <h2 id="codec-dialog-title" className="text-xl font-bold text-white">
              {t.settings.codecChangeTitle({ codec: pendingFormat === "opus" ? "Opus" : "AAC" })}
            </h2>
            <p id="codec-dialog-message" className="mt-2 text-[15px] leading-6 text-[#B3B3B3]">
              {t.settings.codecChangeMessage}
            </p>
            <p className="mt-3 text-sm leading-5 text-[#B3B3B3]">
              {t.settings.manualUploadDialogNote}
            </p>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:justify-end">
              <button
                type="button"
                onClick={() => setPendingFormat(null)}
                className="min-h-[44px] rounded-full px-5 text-sm font-bold text-[#D8D8D8] hover:bg-[#282828] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954]"
              >
                {t.settings.codecCancel}
              </button>
              <button
                ref={safeChoiceRef}
                type="button"
                onClick={keepExisting}
                className="min-h-[44px] rounded-full bg-[#282828] px-5 text-sm font-bold text-white hover:bg-[#3A3A3A] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954]"
              >
                {t.settings.futureOnly}
              </button>
              <button
                type="button"
                disabled={migration.busy}
                onClick={() => void migrateExisting()}
                className="min-h-[44px] rounded-full bg-[#1DB954] px-5 text-sm font-bold text-black transition-transform hover:scale-[1.03] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {migration.busy ? t.settings.migrationStarting : t.settings.migrateExisting}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </section>
  );
}
