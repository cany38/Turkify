"use client";

import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type ChangeEvent,
  type FormEvent,
  type KeyboardEvent,
} from "react";
import type { Playlist, Track } from "../lib/types";
import { formatTotalDuration, textIncludes } from "../data/tracks";
import { playlistArtwork } from "../lib/playlist-art";
import { CheckIcon, PlusIcon, TrashIcon } from "./icons";
import { useI18n } from "./locale-provider";

interface PlaylistPanelProps {
  playlists: Playlist[];
  selectedPlaylistId: string | null;
  tracksById: Map<string, Track>;
  playlistTotalSeconds: Map<string, number>;
  onSelect: (playlistId: string | null) => void;
  onCreate: (name: string, cover?: string) => string;
  onDelete: (playlistId: string) => void;
  onAddToPlaylist: (playlistId: string, trackId: string) => string;
}

export interface PlaylistPatch {
  name?: string;
  cover?: string;
  removeCover?: boolean;
}

interface PlaylistEditFormProps {
  playlist: Playlist;
  /** Ayni sayfada iki form acik kalabilecegi icin input kimlikleri one eklenir. */
  idPrefix: string;
  onSubmit: (playlistId: string, patch: PlaylistPatch) => string;
  onSaved: (message: string) => void;
  onCancel: () => void;
}

/** Liste duzenleme formu; kutuphane detayi ve liste gorunumu ortak kullanir. */
export function PlaylistEditForm({
  playlist,
  idPrefix,
  onSubmit,
  onSaved,
  onCancel,
}: PlaylistEditFormProps) {
  const { t } = useI18n();
  const [editName, setEditName] = useState(playlist.name);
  const [editCover, setEditCover] = useState<string | null>(null);
  const [editRemoveCover, setEditRemoveCover] = useState(false);
  const [editFeedback, setEditFeedback] = useState<string | null>(null);

  const handleEditCoverChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setEditCover(reader.result);
        setEditRemoveCover(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleEditSubmit = (e: FormEvent) => {
    e.preventDefault();
    const patch: PlaylistPatch = {};
    if (editName.trim() !== playlist.name) patch.name = editName;
    if (editRemoveCover) patch.removeCover = true;
    else if (editCover !== null) patch.cover = editCover;
    if (Object.keys(patch).length === 0) {
      onCancel();
      return;
    }
    const message = onSubmit(playlist.id, patch);
    if (
      message === t.playlists.emptyName ||
      message === t.playlists.duplicateName
    ) {
      setEditFeedback(message);
      return;
    }
    onSaved(message);
  };

  const coverInputId = `${idPrefix}-playlist-cover`;
  const nameInputId = `${idPrefix}-playlist-name`;
  return (
    <div
      role="dialog"
      aria-label={t.playlistPanel.editMenuTitle}
      className="mt-3 w-full max-w-md rounded-lg border border-[#282828] bg-[#282828] p-4 shadow-xl"
    >
      <p className="text-sm font-bold text-white">
        {t.playlistPanel.editMenuTitle}
      </p>
      <div className="mt-3 flex items-center gap-3">
        <img
          src={playlistArtwork({
            id: playlist.id,
            cover: editCover ?? (editRemoveCover ? undefined : playlist.cover),
          })}
          alt=""
          className="h-16 w-16 shrink-0 rounded object-cover"
        />
        <div className="flex min-w-0 flex-1 flex-col gap-2">
          <span className="text-sm text-[#B3B3B3]">
            {t.playlistPanel.coverLabel}
          </span>
          <label
            htmlFor={coverInputId}
            className="inline-flex min-h-[44px] cursor-pointer items-center justify-center rounded-lg border border-[#282828] bg-[#181818] px-3 text-sm text-[#B3B3B3] hover:text-white focus-within:outline-2 focus-within:outline-[#1DB954]"
          >
            {t.playlistPanel.coverChoose}
          </label>
          <input
            id={coverInputId}
            type="file"
            accept="image/*"
            onChange={handleEditCoverChange}
            className="sr-only"
          />
          {playlist.cover && !editRemoveCover && editCover === null && (
            <button
              type="button"
              onClick={() => setEditRemoveCover(true)}
              className="text-left text-sm text-[#B3B3B3] underline hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
            >
              {t.playlistPanel.removeCover}
            </button>
          )}
        </div>
      </div>
      <form onSubmit={handleEditSubmit} className="mt-3 flex flex-col gap-2">
        <label htmlFor={nameInputId} className="text-sm text-[#B3B3B3]">
          {t.playlistPanel.nameLabel}
        </label>
        <input
          id={nameInputId}
          type="text"
          value={editName}
          maxLength={60}
          onChange={(e) => setEditName(e.target.value)}
          placeholder={t.playlistPanel.namePlaceholder}
          autoComplete="off"
          className="min-h-[44px] min-w-0 flex-1 rounded-lg border border-[#282828] bg-[#181818] px-3 text-[15px] text-white placeholder:text-[#B3B3B3]/70 focus-visible:outline-2 focus-visible:outline-[#1DB954]"
        />
        {editFeedback && (
          <p role="status" className="text-sm text-[#B3B3B3]">
            {editFeedback}
          </p>
        )}
        <div className="mt-1 flex gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="flex min-h-[44px] flex-1 items-center justify-center rounded-full px-4 text-sm text-[#B3B3B3] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
          >
            {t.playlistPanel.cancel}
          </button>
          <button
            type="submit"
            className="flex min-h-[44px] flex-1 items-center justify-center rounded-full bg-white px-4 text-sm font-bold text-black transition-transform hover:scale-105 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954]"
          >
            {t.playlistPanel.save}
          </button>
        </div>
      </form>
    </div>
  );
}

interface PlaylistAddSongsProps {
  playlist: Playlist;
  allTracks: Track[];
  onAddToPlaylist: (playlistId: string, trackId: string) => string;
  onAdded: (message: string) => void;
  onClose: () => void;
}

/** Toplu sarki ekleme paneli; kutuphane satiri ve liste gorunumu ortak kullanir. */
export function PlaylistAddSongs({
  playlist,
  allTracks,
  onAddToPlaylist,
  onAdded,
  onClose,
}: PlaylistAddSongsProps) {
  const { t } = useI18n();
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<string[]>([]);

  const toggle = (trackId: string) => {
    setSelected((prev) =>
      prev.includes(trackId) ? prev.filter((id) => id !== trackId) : [...prev, trackId],
    );
  };

  const candidates = query.trim()
    ? allTracks.filter((track) => textIncludes(`${track.title} ${track.artist}`, query))
    : allTracks;
  const knownIds = useMemo(() => new Set(allTracks.map((track) => track.id)), [allTracks]);

  const commit = () => {
    const fresh = selected.filter(
      (id) => knownIds.has(id) && !playlist.trackIds.includes(id),
    );
    for (const id of fresh) onAddToPlaylist(playlist.id, id);
    onAdded(t.playlistPanel.addedBulk({ name: playlist.name, count: fresh.length }));
    onClose();
  };

  return (
    <div className="rounded-lg bg-[#181818] p-3">
      <input
        type="search"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder={t.playlistPanel.addSongsSearch}
        aria-label={t.playlistPanel.addSongsSearch}
        autoComplete="off"
        className="min-h-[44px] w-full rounded-lg border border-[#282828] bg-[#121212] px-3 text-sm text-white placeholder:text-[#B3B3B3]/70 focus:outline-3 focus:outline-[#444444] focus:ring-0"
      />
      {candidates.length === 0 ? (
        <p className="px-1 py-3 text-sm text-[#B3B3B3]">
          {t.playlistPanel.addSongsEmpty}
        </p>
      ) : (
        <ul className="plk-scroll mt-2 flex max-h-64 flex-col gap-1 overflow-y-auto">
          {candidates.map((track) => {
            const contained = playlist.trackIds.includes(track.id);
            const checked = contained || selected.includes(track.id);
            return (
              <li key={track.id}>
                <label className={`plk-check flex min-h-[56px] w-full cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-[#282828] ${contained ? "opacity-60" : ""}`}>
                  <input
                    type="checkbox"
                    checked={checked}
                    disabled={contained}
                    onChange={() => toggle(track.id)}
                    aria-label={track.title}
                    className="sr-only"
                  />
                  <span aria-hidden="true" className="plk-check-box">
                    <CheckIcon className="h-4 w-4 text-black" />
                  </span>
                  {track.cover ? (
                    <img
                      src={track.cover}
                      alt=""
                      loading="lazy"
                      className="h-10 w-10 shrink-0 rounded object-cover"
                    />
                  ) : null}
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-semibold text-white">
                      {track.title}
                    </span>
                    <span className="block truncate text-xs text-[#B3B3B3]">
                      {track.artist}
                    </span>
                  </span>
                </label>
              </li>
            );
          })}
        </ul>
      )}
      <div className="mt-2 flex gap-2">
        <button
          type="button"
          onClick={onClose}
          className="flex min-h-[44px] flex-1 items-center justify-center rounded-full px-4 text-sm text-[#B3B3B3] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
        >
          {t.playlistPanel.cancel}
        </button>
        <button
          type="button"
          disabled={selected.length === 0}
          onClick={commit}
          className="flex min-h-[44px] flex-1 items-center justify-center rounded-full bg-white px-4 text-sm font-bold text-black transition-transform hover:scale-105 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:scale-100"
        >
          {t.playlistPanel.addSongsAdd({ count: selected.length })}
        </button>
      </div>
    </div>
  );
}

export function PlaylistPanel({
  playlists,
  selectedPlaylistId,
  tracksById,
  playlistTotalSeconds,
  onSelect,
  onCreate,
  onDelete,
  onAddToPlaylist,
}: PlaylistPanelProps) {
  const [name, setName] = useState("");
  const [feedback, setFeedback] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [coverPreview, setCoverPreview] = useState<string | null>(null);
  const [addSongsFor, setAddSongsFor] = useState<string | null>(null);
  const { locale, t } = useI18n();
  const nameInputRef = useRef<HTMLInputElement | null>(null);

  const allTracks = useMemo(() => [...tracksById.values()], [tracksById]);

  const openAddSongs = (playlistId: string) => {
    setAddSongsFor((prev) => (prev === playlistId ? null : playlistId));
  };

  // Menu acilinca odagi ad girisine tasi (ref'e atama yok, sadece oku).
  useEffect(() => {
    if (menuOpen) {
      nameInputRef.current?.focus();
    }
  }, [menuOpen]);

  const closeMenu = () => {
    setMenuOpen(false);
    setName("");
    setCoverPreview(null);
    setFeedback(null);
  };

  const handleToggleMenu = () => {
    if (menuOpen) {
      closeMenu();
    } else {
      setMenuOpen(true);
      setFeedback(null);
    }
  };

  const handleCoverChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setCoverPreview(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleMenuKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Escape") {
      closeMenu();
    }
  };

  const handleMenuSubmit = (e: FormEvent) => {
    e.preventDefault();
    const message = onCreate(name, coverPreview ?? undefined);
    if (
      message === t.playlists.emptyName ||
      message === t.playlists.duplicateName
    ) {
      setFeedback(message);
      return;
    }
    // Basarili olusturmada menuyu kapat, girilenleri sifirla;
    // bilgi mesaji liste basliginin altinda gorunur.
    setFeedback(message);
    setMenuOpen(false);
    setName("");
    setCoverPreview(null);
  };

  return (
    <div className="flex flex-col gap-6">
      <section aria-labelledby="playlist-list-title">
        <div>
          <div className="flex items-center gap-2">
            <h2
              id="playlist-list-title"
              className="text-xl font-bold text-white sm:text-2xl"
            >
              {t.playlistPanel.listTitle({ count: playlists.length })}
            </h2>
            <button
              type="button"
              onClick={handleToggleMenu}
              aria-label={t.playlistPanel.newPlaylist}
              aria-expanded={menuOpen}
              className="flex h-9 w-9 min-h-[36px] min-w-[36px] items-center justify-center rounded-full bg-white text-black transition-transform hover:scale-105 focus-visible:outline-2 focus-visible:outline-[#1DB954]"
            >
              <PlusIcon className="h-5 w-5" />
            </button>
          </div>
          {menuOpen && (
            <div
              role="dialog"
              aria-label={t.playlistPanel.menuTitle}
              onKeyDown={handleMenuKeyDown}
              className="mt-2 w-full max-w-md rounded-lg border border-[#282828] bg-[#282828] p-4 shadow-xl"
            >
              <p className="text-sm font-bold text-white">
                {t.playlistPanel.menuTitle}
              </p>
              <div className="mt-3 flex flex-col gap-2">
                <span className="text-sm text-[#B3B3B3]">
                  {t.playlistPanel.coverLabel}
                </span>
                <label
                  htmlFor="new-playlist-cover"
                  className="inline-flex min-h-[44px] cursor-pointer items-center justify-center rounded-lg border border-[#282828] bg-[#181818] px-3 text-sm text-[#B3B3B3] hover:text-white focus-within:outline-2 focus-within:outline-[#1DB954]"
                >
                  {t.playlistPanel.coverChoose}
                </label>
                <input
                  id="new-playlist-cover"
                  type="file"
                  accept="image/*"
                  onChange={handleCoverChange}
                  className="sr-only"
                />
                {coverPreview && (
                  <img
                    src={coverPreview}
                    alt=""
                    className="h-16 w-16 rounded object-cover"
                  />
                )}
              </div>
              <form
                onSubmit={handleMenuSubmit}
                className="mt-3 flex flex-col gap-2"
              >
                <label
                  htmlFor="new-playlist-name"
                  className="text-sm text-[#B3B3B3]"
                >
                  {t.playlistPanel.nameLabel}
                </label>
                <input
                  ref={nameInputRef}
                  id="new-playlist-name"
                  type="text"
                  value={name}
                  maxLength={60}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={t.playlistPanel.namePlaceholder}
                  autoComplete="off"
                  className="min-h-[44px] min-w-0 flex-1 rounded-lg border border-[#282828] bg-[#181818] px-3 text-[15px] text-white placeholder:text-[#B3B3B3]/70 focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                />
                {feedback && (
                  <p role="status" className="text-sm text-[#B3B3B3]">
                    {feedback}
                  </p>
                )}
                <div className="mt-1 flex gap-2">
                  <button
                    type="button"
                    onClick={closeMenu}
                    className="flex min-h-[44px] flex-1 items-center justify-center rounded-full px-4 text-sm text-[#B3B3B3] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                  >
                    {t.playlistPanel.cancel}
                  </button>
                  <button
                    type="submit"
                    className="flex min-h-[44px] flex-1 items-center justify-center rounded-full bg-white px-4 text-sm font-bold text-black transition-transform hover:scale-105 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954]"
                  >
                    {t.playlistPanel.create}
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
        {!menuOpen && feedback && (
          <p role="status" className="mt-2 text-sm text-[#B3B3B3]">
            {feedback}
          </p>
        )}
        {playlists.length === 0 ? (
          <p className="mt-2 text-[15px] text-[#B3B3B3]">
            {t.playlistPanel.emptyLists}
          </p>
        ) : (
          <ul className="mt-4 flex flex-col gap-2">
            {playlists.map((p) => {
              const active = p.id === selectedPlaylistId;
              const confirming = confirmDeleteId === p.id;
              const adding = addSongsFor === p.id;
              const totalDuration = formatTotalDuration(playlistTotalSeconds.get(p.id) ?? 0, locale);
              return (
                <li
                  key={p.id}
                  className={`flex flex-col rounded-lg px-3 py-2 transition-colors ${
                    active ? "bg-[#282828]" : "hover:bg-[#282828]/60"
                  }`}
                >
                  <div className="flex min-h-[64px] items-center gap-3">
                    <button
                      type="button"
                      onClick={() => onSelect(p.id)}
                      aria-current={active ? "page" : undefined}
                      className="flex min-w-0 flex-1 items-center gap-3 text-left focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                    >
                      <img
                        src={playlistArtwork(p)}
                        alt=""
                        loading="lazy"
                        className="h-12 w-12 shrink-0 rounded object-cover"
                      />
                      <span className="flex min-w-0 flex-1 flex-col">
                        <span className="truncate text-[15px] font-medium text-white">
                          {p.name}
                        </span>
                        <span className="truncate text-sm text-[#B3B3B3]">
                          {t.playlistPanel.trackCount({ count: p.trackIds.length })}
                          {totalDuration && (
                            <>
                              <span aria-hidden="true"> • </span>
                              {totalDuration}
                            </>
                          )}
                        </span>
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => openAddSongs(p.id)}
                      aria-expanded={adding}
                      aria-label={`${t.playlistPanel.addSongs}: ${p.name}`}
                      title={t.playlistPanel.addSongs}
                      className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[#B3B3B3] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] hover:bg-[#282828] hover:text-white"
                    >
                      <PlusIcon className="h-5 w-5" />
                    </button>
                    {confirming ? (
                      <span className="flex shrink-0 items-center gap-2">
                        <span className="text-xs text-[#B3B3B3]">{t.playlistPanel.confirmDelete}</span>
                        <button
                          type="button"
                          onClick={() => {
                            onDelete(p.id);
                            setConfirmDeleteId(null);
                          }}
                          className="min-h-[44px] rounded-full bg-[#E22134] px-4 text-xs font-bold text-white transition-transform hover:scale-105 focus-visible:outline-2 focus-visible:outline-[#E22134]"
                        >
                          {t.playlistPanel.confirmYes}
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(null)}
                          className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full text-sm text-[#B3B3B3] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                        >
                          {t.playlistPanel.confirmCancel}
                        </button>
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(p.id)}
                        aria-label={t.playlistPanel.deleteList({ name: p.name })}
                        title={t.playlistPanel.deleteListTitle}
                        className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[#B3B3B3] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                      >
                        <TrashIcon className="h-5 w-5" />
                      </button>
                    )}
                  </div>
                  {adding && (
                    <div className="mt-2">
                      <PlaylistAddSongs
                        key={p.id}
                        playlist={p}
                        allTracks={allTracks}
                        onAddToPlaylist={onAddToPlaylist}
                        onAdded={(message) => setFeedback(message)}
                        onClose={() => setAddSongsFor(null)}
                      />
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}
