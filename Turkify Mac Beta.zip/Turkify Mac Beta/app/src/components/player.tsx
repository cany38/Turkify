"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import type { Playlist, RepeatMode, Track } from "../lib/types";
import type { ShuffleMode } from "../lib/smart-queue";
import { playlistArtwork } from "../lib/playlist-art";
import type { RemixSettings } from "../lib/audio-effects";
import { DEFAULT_REMIX, isDefaultRemix, readTrackRemix } from "../lib/audio-effects";
import { formatDuration, formatTotalDuration } from "../data/tracks";
import {
  CheckIcon,
  CloseIcon,
  DotsIcon,
  DownloadIcon,
  HeartIcon,
  MuteIcon,
  NextIcon,
  PauseIcon,
  PlayIcon,
  PlusIcon,
  PrevIcon,
  RepeatIcon,
  RemixIcon,
  ShuffleIcon,
  TrashIcon,
  VolumeIcon,
} from "./icons";
import { useI18n } from "./locale-provider";
import { useRemixExport } from "../hooks/use-remix-export";

interface PlayerProps {
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  muted: boolean;
  playerError: string | null;
  /** Uzak kaynagin adresi cozuluyor; ses henuz baslamadi. */
  isResolving: boolean;
  canGoNext: boolean;
  canGoPrev: boolean;
  repeatMode: RepeatMode;
  onToggle: () => void;
  onSeek: (seconds: number) => void;
  onVolume: (value: number) => void;
  onToggleMute: () => void;
  onNext: () => void;
  onPrev: () => void;
  onCycleRepeat: () => void;
  onCycleShuffle: () => void;
  shuffleMode: ShuffleMode;
  isSmartSuggestion: boolean;
  /** Sayfa degisiminde acik menuyu kapatmak icin gezinme anahtari. */
  navKey: string;
  isLiked: boolean;
  onToggleLike: () => void;
  menuPlaylists: Playlist[];
  playlistDurations: Map<string, number>;
  onAddToPlaylist: (playlistId: string, trackId: string) => string;
  onRemoveCurrent: () => void;
  menuDownloadable: boolean;
  menuDownloaded: boolean;
  menuDownloading: boolean;
  menuDownloadError: string | null;
  onDownloadCurrent: () => void;
  onDismissError: () => void;
  remix: RemixSettings;
  onRemix: (next: RemixSettings) => void;
  onSaveTrackRemix: () => boolean;
}

export function Player({
  currentTrack,
  isPlaying,
  currentTime,
  duration,
  volume,
  muted,
  playerError,
  isResolving,
  canGoNext,
  canGoPrev,
  repeatMode,
  onToggle,
  onSeek,
  onVolume,
  onToggleMute,
  onNext,
  onPrev,
  onCycleRepeat,
  onCycleShuffle,
  shuffleMode,
  isSmartSuggestion,
  navKey,
  isLiked,
  onToggleLike,
  menuPlaylists,
  playlistDurations,
  onAddToPlaylist,
  onRemoveCurrent,
  menuDownloadable,
  menuDownloaded,
  menuDownloading,
  menuDownloadError,
  onDownloadCurrent,
  onDismissError,
  remix,
  onRemix,
  onSaveTrackRemix,
}: PlayerProps) {
  const { locale, t } = useI18n();
  const max =
    duration > 0 ? duration : Math.max(0, currentTrack?.duration ?? 0);

  const [remixOpen, setRemixOpen] = useState(false);
  const [remixSaveResult, setRemixSaveResult] = useState<{ trackId: string; ok: boolean } | null>(null);
  const remixExport = useRemixExport();
  const [folderEditing, setFolderEditing] = useState(false);
  const [folderDraft, setFolderDraft] = useState("");
  const [folderError, setFolderError] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [menuKeyAtOpen, setMenuKeyAtOpen] = useState("");
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerMessage, setPickerMessage] = useState<string | null>(null);
  // Menu, acildigi sayfa+parca ile eslesirse gorunur; gezinme ya da parca
  // degisimi efektsiz kapatir (anahtar uyusmazligi gizler).
  const menuKey = `${navKey}:${currentTrack?.id ?? "none"}`;
  const menuVisible = menuOpen && menuKeyAtOpen === menuKey;
  const toggleMenu = () => {
    if (!menuVisible) {
      setMenuKeyAtOpen(menuKey);
      setPickerOpen(false);
      setPickerMessage(null);
      setMenuOpen(true);
      return;
    }
    setMenuOpen(false);
  };
  const remixButtonRef = useRef<HTMLButtonElement | null>(null);
  const remixPanelRef = useRef<HTMLDivElement | null>(null);
  const menuButtonRef = useRef<HTMLButtonElement | null>(null);
  const menuPanelRef = useRef<HTMLDivElement | null>(null);
  const slidersRef = useRef<HTMLDivElement | null>(null);
  const volumeWrapRef = useRef<HTMLDivElement | null>(null);
  const remixActive = !isDefaultRemix(remix);
  const exportStatus = remixExport.status;
  const exportBusy = exportStatus.phase === "rendering" || exportStatus.phase === "saving";
  const exportDir = remixExport.dirInfo;
  // Kaydet dugmesi yalnizca is degisince gorunur: o anki ayar, parcanin
  // kayitli varsayilanindan farkliysa (kayit yoksa fabrika ayari) gosterilir,
  // kaydedince esitlenir ve gizlenir.
  const trackDefault = currentTrack
    ? (readTrackRemix(currentTrack.id) ?? DEFAULT_REMIX)
    : null;
  const showSaveDefault = currentTrack !== null &&
    trackDefault !== null &&
    (remix.speed !== trackDefault.speed ||
      remix.reverb !== trackDefault.reverb ||
      remix.bass !== trackDefault.bass);

  useEffect(() => {
    if (!remixOpen) return;
    const onPointerDown = (e: PointerEvent) => {
      const target = e.target as Node | null;
      if (!target) return;
      if (
        remixPanelRef.current?.contains(target) ||
        remixButtonRef.current?.contains(target)
      ) {
        return;
      }
      setRemixOpen(false);
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setRemixOpen(false);
        remixButtonRef.current?.focus();
      }
    };
    document.addEventListener("pointerdown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [remixOpen]);

  useEffect(() => {
    if (!menuOpen) return;
    const onPointerDown = (e: PointerEvent) => {
      const target = e.target as Node | null;
      if (!target) return;
      if (
        menuPanelRef.current?.contains(target) ||
        menuButtonRef.current?.contains(target)
      ) {
        return;
      }
      setMenuOpen(false);
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMenuOpen(false);
        menuButtonRef.current?.focus();
      }
    };
    document.addEventListener("pointerdown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [menuOpen]);

  useEffect(() => {
    const el = volumeWrapRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      // Ses cubugu uzerinde tekerlek: sayfa kaymadan ses degisir.
      e.preventDefault();
      const step = e.deltaY < 0 ? 0.05 : -0.05;
      const base = muted ? 0 : volume;
      onVolume(base + step);
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => {
      el.removeEventListener("wheel", onWheel);
    };
  }, [volume, muted, onVolume]);

  useEffect(() => {
    if (!remixOpen) return;
    const root = slidersRef.current;
    if (!root) return;
    const onWheel = (e: WheelEvent) => {
      const target = e.target as HTMLElement | null;
      const input = target?.closest?.('input[type="range"]') as HTMLInputElement | null;
      if (!input || input.disabled) return;
      // Ses cubuguyla ayni his: tekerlek kaydirir, sayfa kaymaz.
      e.preventDefault();
      const step = Number(input.step) > 0 ? Number(input.step) : 0.05;
      const min = Number(input.min);
      const max = Number(input.max);
      const raw = Number(input.value) + (e.deltaY < 0 ? step : -step);
      const value = Math.round(Math.min(max, Math.max(min, raw)) * 100) / 100;
      if (input.id === "remix-speed") onRemix({ ...remix, speed: value });
      else if (input.id === "remix-reverb") onRemix({ ...remix, reverb: value });
      else if (input.id === "remix-bass") onRemix({ ...remix, bass: value });
    };
    root.addEventListener("wheel", onWheel, { passive: false });
    return () => {
      root.removeEventListener("wheel", onWheel);
    };
  }, [remixOpen, onRemix, remix]);

  const presets: { label: string; value: RemixSettings }[] = [
    { label: t.remix.presetNormal, value: { speed: 1, reverb: 0, bass: 0 } },
    {
      label: t.remix.presetSlowed,
      value: { speed: 0.8, reverb: 0.3, bass: 0.1 },
    },
    {
      label: t.remix.presetSpedUp,
      value: { speed: 1.15, reverb: 0.1, bass: 0 },
    },
  ];
  const isPresetActive = (value: RemixSettings): boolean =>
    remix.speed === value.speed &&
    remix.reverb === value.reverb &&
    remix.bass === value.bass;

  const speedText = t.remix.speedValue({
    value: String(Math.round(remix.speed * 100) / 100),
  });
  const reverbText = t.remix.percentValue({
    value: Math.round(remix.reverb * 100),
  });
  const bassText = t.remix.percentValue({
    value: Math.round(remix.bass * 100),
  });

  return (
    <div
      role="region"
      aria-label={t.player.regionLabel}
      className="fixed inset-x-0 bottom-[57px] z-30 border-t border-[#282828] bg-[#181818] px-4 pt-2 pb-[calc(0.5rem+env(safe-area-inset-bottom))] md:bottom-0 md:h-20 md:py-0"
    >
      {playerError && (
        <div
          role="alert"
          className="absolute inset-x-4 bottom-[calc(100%+0.5rem)] mx-auto flex max-w-3xl items-center gap-2 rounded-lg bg-[#282828] px-3 py-2 text-sm text-white shadow-xl"
        >
          <p className="flex-1">{playerError}</p>
          <button
            type="button"
            onClick={onDismissError}
            aria-label={t.player.dismissError}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[#B3B3B3] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
          >
            <CloseIcon className="h-4 w-4" />
          </button>
        </div>
      )}
      {remixOpen && (
        <div
          ref={remixPanelRef}
          role="dialog"
          aria-labelledby="remix-title"
          className="absolute bottom-[calc(100%+0.5rem)] left-1/2 z-40 max-h-[calc(100vh-8rem)] w-[min(19rem,calc(100vw-2rem))] -translate-x-1/2 overflow-y-auto rounded-lg border border-[#282828] bg-[#282828] p-4 shadow-xl"
        >
          <h2 id="remix-title" className="text-sm font-bold text-white">
            {t.remix.title}
          </h2>
          <div className="mt-2 flex flex-wrap gap-2">
            {presets.map((preset) => {
              const active = isPresetActive(preset.value);
              return (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => onRemix({ ...preset.value })}
                  aria-pressed={active}
                  className={`flex min-h-[44px] items-center justify-center rounded-full px-3 text-xs font-bold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] ${
                    active
                      ? "bg-white text-black"
                      : "bg-[#181818] text-[#B3B3B3] hover:text-white"
                  }`}
                >
                  {preset.label}
                </button>
              );
            })}
          </div>
          <div ref={slidersRef} className="mt-3 flex flex-col gap-3">
            <div>
              <div className="flex items-center justify-between gap-2">
                <label
                  htmlFor="remix-speed"
                  className="text-sm text-[#B3B3B3]"
                >
                  {t.remix.speedLabel}
                </label>
                <span
                  aria-hidden="true"
                  className="text-sm text-white tabular-nums"
                >
                  {speedText}
                </span>
              </div>
              <input
                id="remix-speed"
                type="range"
                min={0.5}
                max={1.5}
                step={0.05}
                value={remix.speed}
                onChange={(e) =>
                  onRemix({ ...remix, speed: Number(e.target.value) })
                }
                aria-valuetext={speedText}
                className="h-[22px] w-full accent-[#1DB954] focus-visible:outline-2 focus-visible:outline-[#1DB954]"
              />
            </div>
            <div>
              <div className="flex items-center justify-between gap-2">
                <label
                  htmlFor="remix-reverb"
                  className="text-sm text-[#B3B3B3]"
                >
                  {t.remix.reverbLabel}
                </label>
                <span
                  aria-hidden="true"
                  className="text-sm text-white tabular-nums"
                >
                  {reverbText}
                </span>
              </div>
              <input
                id="remix-reverb"
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={remix.reverb}
                onChange={(e) =>
                  onRemix({ ...remix, reverb: Number(e.target.value) })
                }
                aria-valuetext={reverbText}
                className="h-[22px] w-full accent-[#1DB954] focus-visible:outline-2 focus-visible:outline-[#1DB954]"
              />
            </div>
            <div>
              <div className="flex items-center justify-between gap-2">
                <label
                  htmlFor="remix-bass"
                  className="text-sm text-[#B3B3B3]"
                >
                  {t.remix.bassLabel}
                </label>
                <span
                  aria-hidden="true"
                  className="text-sm text-white tabular-nums"
                >
                  {bassText}
                </span>
              </div>
              <input
                id="remix-bass"
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={remix.bass}
                onChange={(e) =>
                  onRemix({ ...remix, bass: Number(e.target.value) })
                }
                aria-valuetext={bassText}
                className="h-[22px] w-full accent-[#1DB954] focus-visible:outline-2 focus-visible:outline-[#1DB954]"
              />
            </div>
          </div>
          <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onRemix({ ...DEFAULT_REMIX })}
            className="mt-1 flex min-h-[44px] w-full items-center justify-center rounded-full px-4 text-sm font-bold text-[#B3B3B3] transition-colors hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
          >
            {t.remix.reset}
          </button>
          {showSaveDefault && (
            <button
              type="button"
              onClick={() => {
                if (currentTrack) setRemixSaveResult({ trackId: currentTrack.id, ok: onSaveTrackRemix() });
              }}
              className="min-h-[44px] w-full rounded-full px-3 text-sm font-bold text-[#1DB954] focus-visible:outline-2 focus-visible:outline-[#1DB954]"
            >
              {t.remix.saveTrackDefault}
            </button>
          )}
          </div>
          {remixSaveResult?.trackId === currentTrack?.id && remixSaveResult && (
            <p role="status" className="text-center text-xs text-[#B3B3B3]">
              {remixSaveResult.ok ? t.remix.trackDefaultSaved : t.remix.trackDefaultFailed}
            </p>
          )}
          {/* Indirme yalnizca gercekten bir remix varken anlamli; varsayilan
              ayarda dosya orijinalin kopyasi olurdu. */}
          {remixActive && currentTrack && (
            <div className="mt-3 space-y-2 border-t border-[#181818] pt-3">
              <button
                type="button"
                onClick={() => void remixExport.exportRemix(currentTrack, remix)}
                disabled={exportBusy}
                className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-full bg-[#1DB954] px-4 text-sm font-bold text-black transition-opacity hover:opacity-90 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white disabled:opacity-60"
              >
                <DownloadIcon className="h-4 w-4" />
                {exportBusy
                  ? exportStatus.phase === "rendering"
                    ? t.remixExport.rendering
                    : t.remixExport.saving
                  : t.remixExport.buttonLabel}
              </button>
              <p className="text-[11px] text-[#B3B3B3]">{t.remixExport.hint}</p>
              {folderEditing ? (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    void remixExport.changeDir(folderDraft).then((error) => {
                      setFolderError(error);
                      if (!error) setFolderEditing(false);
                    });
                  }}
                  className="flex flex-col gap-1.5"
                >
                  <input
                    type="text"
                    value={folderDraft}
                    onChange={(e) => setFolderDraft(e.target.value)}
                    placeholder={t.remixExport.folderPlaceholder}
                    aria-label={t.remixExport.folderLabel}
                    autoComplete="off"
                    spellCheck={false}
                    className="min-h-[36px] w-full rounded border border-[#404040] bg-[#181818] px-2 text-[11px] text-white placeholder:text-[#B3B3B3]/60 focus:outline-2 focus:outline-[#1DB954]"
                  />
                  <div className="flex gap-2">
                    <button
                      type="submit"
                      className="min-h-[36px] flex-1 rounded-full bg-[#181818] px-3 text-[11px] font-bold text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                    >
                      {t.remixExport.folderSave}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setFolderEditing(false);
                        setFolderError(null);
                      }}
                      className="min-h-[36px] flex-1 rounded-full px-3 text-[11px] font-bold text-[#B3B3B3] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                    >
                      {t.remixExport.folderCancel}
                    </button>
                  </div>
                </form>
              ) : (
                <div className="flex items-center gap-2 text-[11px] text-[#B3B3B3]">
                  <span className="shrink-0">{t.remixExport.folderLabel}:</span>
                  <span className="min-w-0 flex-1 truncate text-white" title={exportDir?.dir ?? ""}>
                    {exportDir ? exportDir.dir : "…"}
                    {exportDir && !exportDir.custom && ` (${t.remixExport.folderDefaultHint})`}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setFolderDraft(exportDir?.dir ?? "");
                      setFolderError(null);
                      setFolderEditing(true);
                    }}
                    className="shrink-0 font-bold text-[#1DB954] hover:underline focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                  >
                    {t.remixExport.folderChange}
                  </button>
                </div>
              )}
              {(folderError ?? exportDir?.problem) && (
                <p role="alert" className="text-[11px] text-[#FFB4BC]">
                  {t.remixExport.errorPrefix} {folderError ?? exportDir?.problem}
                </p>
              )}
              {exportStatus.phase === "done" && (
                <p role="status" className="text-[11px] text-[#1DB954]">
                  {t.remixExport.saved({ name: exportStatus.name })}
                </p>
              )}
              {exportStatus.phase === "error" && (
                <p role="alert" className="text-[11px] text-[#FFB4BC]">
                  {t.remixExport.errorPrefix} {exportStatus.message}
                </p>
              )}
            </div>
          )}
        </div>
      )}
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 md:h-20 md:gap-4">
        <div className="flex min-w-0 flex-1 items-center gap-3 md:max-w-xs">
          {currentTrack ? (
            <>
              <Image
                src={currentTrack.cover}
                alt=""
                width={48}
                height={48}
                unoptimized
                onError={(event) => {
                  if (!currentTrack.fallbackCover) return;
                  const fallback = new URL(currentTrack.fallbackCover, window.location.href).href;
                  if (event.currentTarget.src !== fallback) event.currentTarget.src = fallback;
                }}
                className="h-12 w-12 shrink-0 rounded object-cover"
              />
              <div className="min-w-0">
                <p className="flex min-w-0 items-center gap-2 truncate text-sm font-medium text-white">
                  <span className="truncate">{currentTrack.title}</span>
                  {isSmartSuggestion && (
                    <span className="shrink-0 rounded-full bg-[#A855F7]/20 px-2 py-0.5 text-[11px] font-bold text-[#A855F7]">
                      {t.player.smartBadge}
                    </span>
                  )}
                </p>
                <p className="truncate text-xs text-[#B3B3B3]">
                  {/* Cozumleme 2-3 saniye surebiliyor; sessiz bekleme
                      "calmiyor" gibi gorunmesin diye durum yaziliyor. */}
                  {isResolving ? t.player.resolving : currentTrack.artist}
                </p>
              </div>
            </>
          ) : (
            <p className="truncate text-sm text-[#B3B3B3]">
              {t.player.emptyHint}
            </p>
          )}
        </div>

        <div className="flex flex-col items-center gap-1 md:flex-1">
          <div className="flex items-center gap-1 sm:gap-2">
            <button
              ref={remixButtonRef}
              type="button"
              onClick={() => {
                remixExport.resetStatus();
                setFolderEditing(false);
                setFolderError(null);
                setRemixOpen((open) => !open);
              }}
              aria-haspopup="dialog"
              aria-expanded={remixOpen}
              aria-label={t.remix.buttonLabel}
              title={t.remix.buttonLabel}
              className={`flex h-11 w-11 items-center justify-center rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-[#1DB954] ${
                remixActive
                  ? "text-[#1DB954]"
                  : "text-[#B3B3B3] hover:text-white"
              }`}
            >
              <RemixIcon className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={onCycleShuffle}
              aria-label={
                shuffleMode === "off"
                  ? t.player.shuffleOff
                  : shuffleMode === "on"
                    ? t.player.shuffleOn
                    : t.player.smartShuffle
              }
              title={
                shuffleMode === "off"
                  ? t.player.shuffleOff
                  : shuffleMode === "on"
                    ? t.player.shuffleOn
                    : t.player.smartShuffle
              }
              className={`flex h-11 w-11 items-center justify-center rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] ${
                shuffleMode === "off"
                  ? "text-[#B3B3B3] hover:text-white"
                  : shuffleMode === "on"
                    ? "text-[#1DB954]"
                    : "text-[#A855F7]"
              }`}
            >
              <ShuffleIcon className="h-5 w-5" smart={shuffleMode === "smart"} />
            </button>
            <button
              type="button"
              onClick={onPrev}
              disabled={!currentTrack || !canGoPrev}
              aria-label={t.player.prevTrack}
              title={canGoPrev ? t.player.prevTrack : t.player.noPrevTrack}
              className="flex h-11 w-11 items-center justify-center rounded-full text-[#B3B3B3] transition-colors hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954] disabled:cursor-not-allowed disabled:opacity-40"
            >
              <PrevIcon className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={onToggle}
              disabled={!currentTrack}
              aria-label={
                !currentTrack
                  ? t.player.noTrack
                  : isPlaying
                    ? t.player.pause
                    : t.player.play
              }
              title={!currentTrack ? t.player.selectFirst : isPlaying ? t.player.pause : t.player.play}
              className="flex h-11 w-11 items-center justify-center rounded-full bg-white text-black transition-transform hover:scale-105 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] disabled:cursor-not-allowed disabled:opacity-40"
            >
              {isPlaying ? (
                <PauseIcon className="h-5 w-5" />
              ) : (
                <PlayIcon className="h-5 w-5" />
              )}
            </button>
            <button
              type="button"
              onClick={onNext}
              disabled={!currentTrack || !canGoNext}
              aria-label={t.player.nextTrack}
              title={canGoNext ? t.player.nextTrack : t.player.noNextTrack}
              className="flex h-11 w-11 items-center justify-center rounded-full text-[#B3B3B3] transition-colors hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954] disabled:cursor-not-allowed disabled:opacity-40"
            >
              <NextIcon className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={onCycleRepeat}
              data-repeat-mode={repeatMode}
              aria-label={
                repeatMode === "off"
                  ? t.player.repeatOff
                  : repeatMode === "context"
                    ? t.player.repeatContext
                    : t.player.repeatOne
              }
              title={
                repeatMode === "off"
                  ? t.player.repeatOff
                  : repeatMode === "context"
                    ? t.player.repeatContext
                    : t.player.repeatOne
              }
              className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] ${
                repeatMode === "off"
                  ? "text-[#B3B3B3] hover:text-white"
                  : repeatMode === "context"
                    ? "text-[#1DB954]"
                    : "text-[#A855F7]"
              }`}
            >
              <RepeatIcon className="h-5 w-5" one={repeatMode === "one"} />
            </button>
            <div className="relative">
              <button
                ref={menuButtonRef}
                type="button"
                disabled={!currentTrack}
                onClick={toggleMenu}
                aria-haspopup="dialog"
                aria-expanded={menuVisible}
                aria-label={t.player.trackMenu}
                title={t.player.trackMenu}
                className={`flex h-11 w-11 items-center justify-center rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-[#1DB954] disabled:cursor-not-allowed disabled:opacity-40 ${
                  menuVisible ? "text-white" : "text-[#B3B3B3] hover:text-white"
                }`}
              >
                <DotsIcon className="h-5 w-5" />
              </button>
              {menuVisible && currentTrack && (
                <div
                  ref={menuPanelRef}
                  role="dialog"
                  aria-label={t.player.trackMenu}
                  className="absolute bottom-[calc(100%+0.5rem)] left-1/2 z-40 w-max -translate-x-1/2 rounded-lg border border-[#282828] bg-[#282828] p-1 shadow-xl"
                >
                  <div className="flex flex-col items-center gap-1">
                    {menuDownloadable && !menuDownloaded ? (
                      <button
                        type="button"
                        disabled={menuDownloading}
                        onClick={onDownloadCurrent}
                        aria-label={menuDownloading ? `${t.download.downloading}: ${currentTrack.title}` : `${t.download.action} ${currentTrack.title}`}
                        title={menuDownloading ? t.download.downloading : menuDownloadError ?? t.download.action}
                        className={`flex h-11 w-11 items-center justify-center rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-[#1DB954] disabled:cursor-default ${
                          menuDownloading
                            ? "bg-[#181818] text-[#1DB954]"
                            : menuDownloadError
                              ? "text-[#FF0000] hover:text-[#FF6B6B]"
                              : "text-[#B3B3B3] hover:text-white"
                        }`}
                      >
                        <DownloadIcon className={`h-5 w-5 ${menuDownloading ? "animate-pulse" : ""}`} />
                      </button>
                    ) : (
                      <button
                        type="button"
                        disabled
                        aria-label={`${t.download.done}: ${currentTrack.title}`}
                        title={t.download.done}
                        className="flex h-11 w-11 cursor-default items-center justify-center rounded-full text-[#1DB954]"
                      >
                        <CheckIcon className="h-5 w-5" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={onToggleLike}
                      aria-pressed={isLiked}
                      aria-label={isLiked ? t.trackList.unlikeTrack({ title: currentTrack.title }) : t.trackList.likeTrack({ title: currentTrack.title })}
                      title={isLiked ? t.trackList.unlikeTitle : t.trackList.likeTitle}
                      className={`flex h-11 w-11 items-center justify-center rounded-full transition-colors hover:bg-[#181818] focus-visible:outline-2 focus-visible:outline-[#1DB954] ${
                        isLiked ? "text-[#FF6B81]" : "text-[#B3B3B3] hover:text-[#FF6B81]"
                      }`}
                    >
                      <HeartIcon className="h-5 w-5" filled={isLiked} />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPickerOpen((open) => !open);
                        setPickerMessage(null);
                      }}
                      aria-expanded={pickerOpen}
                      aria-label={t.trackList.addToList({ title: currentTrack.title })}
                      title={t.trackList.addToListTitle}
                      className="flex h-11 w-11 items-center justify-center rounded-full text-[#B3B3B3] transition-colors hover:bg-[#181818] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                    >
                      <PlusIcon className="h-5 w-5" />
                    </button>
                    {pickerOpen && (
                      menuPlaylists.length === 0 ? (
                        <p className="w-64 rounded-lg bg-[#181818] px-3 py-2 text-center text-sm text-[#B3B3B3]">
                          {t.trackList.createFirst}
                        </p>
                      ) : (
                        <div className="w-64 rounded-lg bg-[#181818] p-2">
                          <ul className="plk-scroll flex max-h-64 flex-col gap-1 overflow-y-auto">
                            {menuPlaylists.map((p) => {
                              const contains = p.trackIds.includes(currentTrack.id);
                              const totalDuration = formatTotalDuration(playlistDurations.get(p.id) ?? 0, locale);
                              return (
                                <li key={p.id}>
                                  <button
                                    type="button"
                                    onClick={() => setPickerMessage(onAddToPlaylist(p.id, currentTrack.id))}
                                    className="flex min-h-[56px] w-full items-center gap-3 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-[#282828] focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                                  >
                                    <img
                                      src={playlistArtwork(p)}
                                      alt=""
                                      loading="lazy"
                                      className="h-10 w-10 shrink-0 rounded object-cover"
                                    />
                                    <span className="min-w-0 flex-1">
                                      <span className="block truncate text-sm font-semibold text-white">
                                        {p.name}
                                      </span>
                                      <span className="block text-xs text-[#B3B3B3]">
                                        {t.playlistPanel.trackCount({ count: p.trackIds.length })}
                                        {totalDuration && (
                                          <>
                                            <span aria-hidden="true"> • </span>
                                            {totalDuration}
                                          </>
                                        )}
                                      </span>
                                    </span>
                                    {contains ? (
                                      <CheckIcon className="h-5 w-5 shrink-0 text-[#1DB954]" />
                                    ) : (
                                      <PlusIcon className="h-5 w-5 shrink-0 text-[#B3B3B3]" />
                                    )}
                                  </button>
                                </li>
                              );
                            })}
                          </ul>
                          {pickerMessage && (
                            <p role="status" className="px-2 pt-1 text-sm text-[#B3B3B3]">
                              {pickerMessage}
                            </p>
                          )}
                        </div>
                      )
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        onRemoveCurrent();
                        setMenuOpen(false);
                      }}
                      aria-label={t.trackList.removeFromLibrary({ title: currentTrack.title })}
                      title={t.trackList.removeFromLibraryTitle}
                      className="flex h-11 w-11 items-center justify-center rounded-full text-[#B3B3B3] transition-colors hover:bg-[#181818] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                    >
                      <TrashIcon className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
          <div className="hidden w-full max-w-xl items-center gap-2 sm:flex">
            <span className="w-10 shrink-0 text-right text-xs text-[#B3B3B3] tabular-nums">
              {formatDuration(currentTime)}
            </span>
            <label htmlFor="seek" className="sr-only">
              {t.player.seekLabel}
            </label>
            <input
              id="seek"
              type="range"
              min={0}
              max={Math.max(1, Math.floor(max))}
              step={1}
              value={Math.floor(Math.min(currentTime, Math.max(1, Math.floor(max))))}
              disabled={!currentTrack || max <= 0}
              onChange={(e) => onSeek(Number(e.target.value))}
              className="player-range h-[22px] min-w-0 flex-1 accent-[#1DB954] focus-visible:outline-2 focus-visible:outline-[#1DB954]"
            />
            <span className="w-10 shrink-0 text-xs text-[#B3B3B3] tabular-nums">
              {formatDuration(max)}
            </span>
          </div>
        </div>

        <div
          ref={volumeWrapRef}
          className="hidden min-w-0 flex-1 items-center justify-end gap-2 md:flex md:max-w-xs"
        >
          <button
            type="button"
            onClick={onToggleMute}
            aria-pressed={muted}
            aria-label={muted ? t.player.unmute : t.player.mute}
            title={muted ? t.player.unmute : t.player.mute}
            className="flex h-11 w-11 items-center justify-center rounded-full text-[#B3B3B3] hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
          >
            {muted || volume === 0 ? (
              <MuteIcon className="h-5 w-5" />
            ) : (
              <VolumeIcon className="h-5 w-5" />
            )}
          </button>
          <label htmlFor="volume" className="sr-only">
            {t.player.volumeLabel}
          </label>
          <input
            id="volume"
            type="range"
            min={0}
            max={100}
            step={1}
            value={Math.round((muted ? 0 : volume) * 100)}
            onChange={(e) => onVolume(Number(e.target.value) / 100)}
            className="h-[22px] w-24 accent-[#1DB954] focus-visible:outline-2 focus-visible:outline-[#1DB954]"
          />
        </div>
      </div>
      {/* Mobilde seek satırı */}
      <div className="mx-auto flex max-w-6xl items-center gap-2 pb-1 sm:hidden">
        <span className="w-10 shrink-0 text-right text-xs text-[#B3B3B3] tabular-nums">
          {formatDuration(currentTime)}
        </span>
        <label htmlFor="seek-mobile" className="sr-only">
          {t.player.seekLabel}
        </label>
        <input
          id="seek-mobile"
          type="range"
          min={0}
          max={Math.max(1, Math.floor(max))}
          step={1}
          value={Math.floor(Math.min(currentTime, Math.max(1, Math.floor(max))))}
          disabled={!currentTrack || max <= 0}
          onChange={(e) => onSeek(Number(e.target.value))}
          className="h-[22px] min-w-0 flex-1 accent-[#1DB954] focus-visible:outline-2 focus-visible:outline-[#1DB954]"
        />
        <span className="w-10 shrink-0 text-xs text-[#B3B3B3] tabular-nums">
          {formatDuration(max)}
        </span>
      </div>
    </div>
  );
}
