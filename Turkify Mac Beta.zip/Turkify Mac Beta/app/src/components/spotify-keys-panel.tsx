"use client";

import { useState } from "react";
import type { SpotifyKeys } from "../lib/types";
import { isValidSpotifyKeys } from "../lib/spotify-keys";
import {
  VERIFY_STEP_ORDER,
  isVerifyEvent,
  type VerifyStatus,
  type VerifyStepId,
} from "../lib/spotify-verify";
import { useI18n } from "./locale-provider";

interface SpotifyKeysPanelProps {
  initialId: string;
  initialSecret: string;
  authFailed: boolean;
  onSave: (keys: SpotifyKeys) => void;
}

const CLIENT_ID_RE = /^[0-9a-f]{32}$/i;

/** Yesil onaylar bir an gorunsun diye kayit kisa bir gecikmeyle yapilir. */
const SAVE_DELAY_MS = 1200;

type StatusMap = Record<VerifyStepId, VerifyStatus>;

const IDLE_STATUSES: StatusMap = { format: "pending", token: "pending", search: "pending" };

function StatusMark({ status, label }: { status: VerifyStatus; label: string }) {
  const base = "flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[11px] font-bold";
  if (status === "ok") {
    return (
      <span role="img" aria-label={label} className={`${base} bg-[#1DB954] text-black`}>
        ✓
      </span>
    );
  }
  if (status === "fail") {
    return (
      <span role="img" aria-label={label} className={`${base} bg-[#E22134] text-white`}>
        ✕
      </span>
    );
  }
  if (status === "running") {
    return (
      <span
        role="img"
        aria-label={label}
        className={`${base} animate-spin border-2 border-[#B3B3B3] border-t-transparent`}
      />
    );
  }
  return <span role="img" aria-label={label} className={`${base} border border-[#535353]`} />;
}

export function SpotifyKeysPanel({ initialId, initialSecret, authFailed, onSave }: SpotifyKeysPanelProps) {
  const { t } = useI18n();
  const [clientId, setClientId] = useState(initialId);
  const [clientSecret, setClientSecret] = useState(initialSecret);
  const [error, setError] = useState<string | null>(null);
  const [statuses, setStatuses] = useState<StatusMap>(IDLE_STATUSES);
  const [isVerifying, setIsVerifying] = useState(false);
  const [saved, setSaved] = useState(false);

  const stepLabels: Record<VerifyStepId, string> = {
    format: t.spotifyKeys.stepFormat,
    token: t.spotifyKeys.stepToken,
    search: t.spotifyKeys.stepSearch,
  };

  const statusLabels: Record<VerifyStatus, string> = {
    pending: t.spotifyKeys.statusPending,
    running: t.spotifyKeys.statusRunning,
    ok: t.spotifyKeys.statusOk,
    fail: t.spotifyKeys.statusFail,
  };

  async function handleVerifyAndSave() {
    const keys: SpotifyKeys = { clientId: clientId.trim(), clientSecret: clientSecret.trim() };
    setError(null);
    setSaved(false);
    setIsVerifying(true);
    setStatuses({ format: "running", token: "pending", search: "pending" });

    // 1) Bicim: aga cikmadan once yanlis kopyalamayi yakala.
    if (!CLIENT_ID_RE.test(keys.clientId)) {
      setStatuses({ format: "fail", token: "pending", search: "pending" });
      setError(t.spotifyKeys.invalidId);
      setIsVerifying(false);
      return;
    }
    if (!isValidSpotifyKeys(keys)) {
      setStatuses({ format: "fail", token: "pending", search: "pending" });
      setError(t.spotifyKeys.invalidSecret);
      setIsVerifying(false);
      return;
    }
    setStatuses({ format: "ok", token: "pending", search: "pending" });

    // 2) + 3) Sunucu adimlari NDJSON olarak akar; her satir geldiginde isaretle.
    try {
      const res = await fetch("/api/spotify/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(keys),
      });
      if (!res.ok || !res.body) {
        throw new Error(t.spotifyKeys.verifyRequestFailed({ status: res.status }));
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      const seen: StatusMap = { format: "ok", token: "pending", search: "pending" };
      let buffer = "";
      let failure: string | null = null;

      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.trim()) continue;
          let parsed: unknown;
          try {
            parsed = JSON.parse(line);
          } catch {
            continue;
          }
          if (!isVerifyEvent(parsed)) continue;
          seen[parsed.step] = parsed.status;
          setStatuses({ ...seen });
          if (parsed.status === "fail") {
            failure = parsed.message ?? t.spotifyKeys.authFailed;
          }
        }
      }

      if (failure || seen.token !== "ok" || seen.search !== "ok") {
        setError(failure ?? t.spotifyKeys.authFailed);
        setIsVerifying(false);
        return;
      }

      setSaved(true);
      setIsVerifying(false);
      setTimeout(() => onSave(keys), SAVE_DELAY_MS);
    } catch (err) {
      setStatuses((current) => ({
        format: current.format,
        token: current.token === "running" ? "fail" : current.token,
        search: current.search === "running" ? "fail" : current.search,
      }));
      setError(err instanceof Error ? err.message : t.spotifyKeys.authFailed);
      setIsVerifying(false);
    }
  }

  return (
    <div className="flex flex-col gap-4 rounded-lg bg-[#181818] p-4 sm:p-6">
      <h2 id="spotify-keys-title" className="text-xl font-bold sm:text-2xl">
        {t.spotifyKeys.title}
      </h2>
      <p className="text-[15px] text-[#B3B3B3]">{t.spotifyKeys.intro}</p>
      <ol className="flex list-decimal flex-col gap-2 pl-6 text-[15px] text-white">
        {t.spotifyKeys.steps.map((step, i) => (
          <li key={i}>{step}</li>
        ))}
      </ol>
      <div className="flex max-w-xl flex-col gap-3">
        <div className="flex flex-col gap-1">
          <label htmlFor="spotify-client-id" className="text-sm font-medium text-white">
            {t.spotifyKeys.clientIdLabel}
          </label>
          <input
            id="spotify-client-id"
            type="text"
            value={clientId}
            onChange={(e) => setClientId(e.target.value)}
            placeholder={t.spotifyKeys.clientIdPlaceholder}
            autoComplete="off"
            spellCheck={false}
            className="min-h-[44px] rounded-lg border border-[#282828] bg-[#121212] px-3 text-sm text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label htmlFor="spotify-client-secret" className="text-sm font-medium text-white">
            {t.spotifyKeys.clientSecretLabel}
          </label>
          <input
            id="spotify-client-secret"
            type="password"
            value={clientSecret}
            onChange={(e) => setClientSecret(e.target.value)}
            placeholder={t.spotifyKeys.clientSecretPlaceholder}
            autoComplete="off"
            spellCheck={false}
            className="min-h-[44px] rounded-lg border border-[#282828] bg-[#121212] px-3 text-sm text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
          />
        </div>

        <div className="flex flex-col gap-2 rounded-lg border border-[#282828] bg-[#121212] p-3">
          <p className="text-sm font-medium text-white">{t.spotifyKeys.verifyTitle}</p>
          <ul className="flex flex-col gap-2" aria-live="polite">
            {VERIFY_STEP_ORDER.map((id) => (
              <li key={id} className="flex items-center gap-2 text-sm">
                <StatusMark status={statuses[id]} label={statusLabels[statuses[id]]} />
                <span className={statuses[id] === "pending" ? "text-[#6A6A6A]" : "text-white"}>
                  {stepLabels[id]}
                </span>
              </li>
            ))}
          </ul>
          <p className="text-xs text-[#8A8A8A]">{t.spotifyKeys.verifyNotice}</p>
        </div>

        {authFailed && !error && !saved && (
          <p role="alert" className="text-sm text-white">
            {t.spotifyKeys.authFailed}
          </p>
        )}
        {error && (
          <p role="alert" className="text-sm text-white">
            {error}
          </p>
        )}
        {saved && (
          <p role="status" className="text-sm font-medium text-[#1DB954]">
            {t.spotifyKeys.verifiedSaved}
          </p>
        )}
        <div>
          <button
            type="button"
            onClick={() => void handleVerifyAndSave()}
            disabled={isVerifying}
            className="flex min-h-[44px] items-center justify-center rounded-full bg-white px-6 text-sm font-bold text-black transition-transform hover:scale-105 focus-visible:outline-2 focus-visible:outline-[#1DB954] disabled:cursor-not-allowed disabled:opacity-60 disabled:hover:scale-100"
          >
            {isVerifying ? t.spotifyKeys.verifying : t.spotifyKeys.verifyAndSave}
          </button>
        </div>
      </div>
    </div>
  );
}
