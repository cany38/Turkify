"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import type { ExternalTrack, LocalTrack, Playlist } from "../lib/types";
import { formatDuration } from "../data/tracks";
import { playlistArtwork } from "../lib/playlist-art";
import { CheckIcon, HeartIcon, PlusIcon } from "./icons";
import { useI18n } from "./locale-provider";
import type { DownloadState } from "../hooks/use-download";
import { useFormatInfo } from "../hooks/use-format-info";
import { decodeHtmlEntities } from "../lib/html-entities";
import type { AudioFormat } from "../lib/audio-format";
import type { FormatInfo } from "../lib/format-info-cache";

interface ExternalResultsProps {
  tracks: ExternalTrack[];
  isLoading: boolean;
  error: string | null;
  warnings: string[];
  query: string;
  hasSearched: boolean;
  onDownloaded?: (track: LocalTrack) => void;
  onFeedback?: (message: string) => void;
  onPlay?: (track: ExternalTrack) => void;
  onLoadMore?: () => void;
  isLoadingMore?: boolean;
  hasMore?: boolean;
  /** Bilgi dosyasındaki indirilmiş arama kimlikleri; düğme buradan grileşir. */
  downloadedIds?: string[];
  /** Klasördeki dosya adı kalıpları; kaydı olmayan eski indirmeler için. */
  downloadedStems?: string[];
  /** İndirilmiş satırların Musics dosyasından anında türetilen gerçek formatı. */
  downloadedFormats?: Record<string, FormatInfo>;
  audioFormat: AudioFormat;
  /** YouTube 429: ham hata yerine kısa kırmızı kota uyarısı gösterilir. */
  youtubeQuotaExceeded?: boolean;
  /** Beğeni durumu satırdaki kalpten okunur; indirme gerekmez. */
  likedIds: string[];
  /** + düğmesinin liste seçicisi için. */
  playlists: Playlist[];
  onToggleLike: (track: ExternalTrack) => void;
  /** İndirmeden listeye ekler; sonuç mesajı seçicide gösterilir. */
  onAddToPlaylist: (playlistId: string, track: ExternalTrack) => string;
  /**
   * İndirme durumu app seviyesinde yaşar; sayfa değişse de indirme sürer,
   * satırlar geri dönünce kaldığı durumu gösterir.
   */
  downloadStates: Record<string, DownloadState>;
  onDownloadTrack: (
    track: ExternalTrack,
    onSaved: (local: LocalTrack) => void,
    formatOverride?: AudioFormat,
  ) => Promise<boolean>;
  onClearDownloadTrackError: (trackId: string) => void;
}

function SpotifyBadge({ label }: { label: string }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-[#1DB954] px-2 py-0.5 text-[10px] font-extrabold tracking-wide text-black">
      <span aria-hidden>♫</span> {label}
    </span>
  );
}

function YoutubeBadge({ label }: { label: string }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-[#FF0000] px-2 py-0.5 text-[10px] font-extrabold tracking-wide text-white">
      <span aria-hidden>▶</span> {label}
    </span>
  );
}

const PAGE_SIZE = 10;

/**
 * Arama satırından indirince oluşacak dosya adı kalıbı. Sunucudaki
 * `displayBase` ile aynı dönüşüm: "başlık - sanatçı", 80 karakter, dosya
 * adı temizliği, küçük harf. Klasördeki eski indirmelerle eşleşir.
 */
function candidateStem(track: ExternalTrack): string {
  const title = decodeHtmlEntities(track.title);
  const artist = decodeHtmlEntities(track.artist);
  const joined = [title, artist].filter(Boolean).join(" - ").slice(0, 80);
  const cleaned = joined.replace(/[\\/:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
  return (cleaned || "parca").toLowerCase();
}

/**
 * YouTube günlük kotası Pasifik saatiyle gece yarısı sıfırlanır; kalan
 * süreyi yukarı yuvarlayıp saat olarak verir (en az 1, en çok 24).
 */
function hoursUntilQuotaReset(now = new Date()): number {
  try {
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone: "America/Los_Angeles",
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      hour12: false,
    }).formatToParts(now);
    const get = (type: string) => Number(parts.find((p) => p.type === type)?.value ?? 0);
    const elapsed = get("hour") * 3600 + get("minute") * 60 + get("second");
    return Math.min(24, Math.max(1, Math.ceil((24 * 3600 - elapsed) / 3600)));
  } catch {
    return 24;
  }
}

export function ExternalResults({ tracks, isLoading, error, warnings, query, hasSearched, onDownloaded, onFeedback, onPlay, onLoadMore, isLoadingMore = false, hasMore = false, downloadedIds, downloadedStems, downloadedFormats, audioFormat, youtubeQuotaExceeded = false, likedIds, playlists, onToggleLike, onAddToPlaylist, downloadStates: states, onDownloadTrack: download, onClearDownloadTrackError: clearError }: ExternalResultsProps) {
  const { t } = useI18n();
  const [pickerFor, setPickerFor] = useState<string | null>(null);
  const [pickerMessage, setPickerMessage] = useState<string | null>(null);
  // Diziler her render değişebilir; Set kimliklere göre ezberlenir.
  const downloadedIdSet = useMemo(() => new Set(downloadedIds ?? []), [downloadedIds]);
  const downloadedStemSet = useMemo(() => new Set(downloadedStems ?? []), [downloadedStems]);
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [prevQuery, setPrevQuery] = useState(query);
  // Yeni sorguda sayac basa doner; effect yerine render sirasinda duzeltme
  // (effect govdesinde setState yok, mevcut lint desenine uygun).
  if (prevQuery !== query) {
    setPrevQuery(query);
    setVisibleCount(PAGE_SIZE);
  }
  const visibleTracks = useMemo(() => tracks.slice(0, visibleCount), [tracks, visibleCount]);
  const [visibleFormatIds, setVisibleFormatIds] = useState<string[]>([]);
  const listRef = useRef<HTMLUListElement | null>(null);
  // Hiz kazanci: gorunmeyen satirlar icin yt-dlp yoklamasi baslatma.
  useEffect(() => {
    const root = listRef.current;
    if (!root) return;
    const nodes = Array.from(
      root.querySelectorAll<HTMLElement>("[data-format-track-id]"),
    );
    if (typeof IntersectionObserver === "undefined") {
      const timer = window.setTimeout(
        () => setVisibleFormatIds(visibleTracks.map((track) => track.id)),
        0,
      );
      return () => window.clearTimeout(timer);
    }
    const observer = new IntersectionObserver(
      (entries) => {
        const entered = entries
          .filter((entry) => entry.isIntersecting)
          .map((entry) => (entry.target as HTMLElement).dataset.formatTrackId)
          .filter((id): id is string => Boolean(id));
        if (entered.length === 0) return;
        setVisibleFormatIds((previous) => Array.from(new Set([...previous, ...entered])));
        for (const entry of entries) {
          if (entry.isIntersecting) observer.unobserve(entry.target);
        }
      },
      { rootMargin: "240px 0px" },
    );
    for (const node of nodes) observer.observe(node);
    return () => observer.disconnect();
  }, [visibleTracks]);
  const visibleIdSet = useMemo(() => new Set(visibleFormatIds), [visibleFormatIds]);
  const formatTargets = useMemo(
    () =>
      visibleTracks.filter(
        (track) => visibleIdSet.has(track.id) && !downloadedFormats?.[track.id],
      ),
    [visibleTracks, visibleIdSet, downloadedFormats],
  );
  const formats = useFormatInfo(formatTargets, audioFormat);
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") return;
    const observer = new IntersectionObserver((entries) => {
      if (!entries[0]?.isIntersecting) return;
      // Havuzda gosterilmemis parca varsa isteksiz ac; havuz bittiyse sayfa cek.
      if (visibleCount < tracks.length) {
        setVisibleCount((c) => c + PAGE_SIZE);
      } else if (hasMore && !isLoadingMore) {
        void onLoadMore?.();
      }
    });
    observer.observe(el);
    return () => {
      observer.disconnect();
    };
  }, [visibleCount, tracks.length, hasMore, isLoadingMore, onLoadMore]);

  if (isLoading) {
    return (
      <p role="status" className="py-8 text-center text-[15px] text-[#B3B3B3]">
        {t.externalSearch.loading}
      </p>
    );
  }

  if (error) {
    return (
      <p role="alert" className="rounded-lg bg-[#282828] px-4 py-3 text-sm text-white">
        {t.externalSearch.errorPrefix} {error}
      </p>
    );
  }

  if (!hasSearched) {
    return null;
  }

  if (tracks.length === 0) {
    return (
      <div className="flex flex-col gap-2">
        {youtubeQuotaExceeded && (
          <p role="alert" className="rounded-lg bg-[#3A171B] px-4 py-3 text-sm text-[#FFB4BC]">
            {t.externalSearch.youtubeQuota({ hours: hoursUntilQuotaReset() })}
          </p>
        )}
        <p role="status" className="py-4 text-center text-[15px] text-[#B3B3B3]">
          {t.search.noResults({ query: query.trim() })}
        </p>
        {warnings.length > 0 && (
          <p className="rounded-lg bg-[#282828] px-4 py-2 text-xs text-[#B3B3B3]">{warnings.join(" • ")}</p>
        )}
      </div>
    );
  }

  const poolExhausted = visibleCount >= tracks.length;

  return (
    <div className="flex flex-col gap-2">
      {youtubeQuotaExceeded && (
        <p role="alert" className="rounded-lg bg-[#3A171B] px-4 py-3 text-sm text-[#FFB4BC]">
          {t.externalSearch.youtubeQuota({ hours: hoursUntilQuotaReset() })}
        </p>
      )}
      {warnings.length > 0 && (
        <p className="rounded-lg bg-[#282828] px-4 py-2 text-xs text-[#B3B3B3]">{warnings.join(" • ")}</p>
      )}
      <ul ref={listRef} className="flex flex-col" aria-label={t.trackList.listLabel}>
        {visibleTracks.map((track, index) => {
          const isSpotify = track.source === "spotify";
          const badgeLabel = isSpotify ? t.externalSearch.badgeSpotify : t.externalSearch.badgeYoutube;
          // Indir dugmesi rozetle ayni rengi tasisin: Spotify yesil, YouTube kirmizi.
          const accent = isSpotify
            ? { fill: "bg-[#1DB954] text-black", ring: "focus-visible:outline-[#1DB954]" }
            : { fill: "bg-[#FF0000] text-white", ring: "focus-visible:outline-[#FF0000]" };
          const st = states[track.id];
          const isDownloading = st?.stage === "downloading";
          const isDone = st?.stage === "done";
          const isError = st?.stage === "error";
          const needsAacConfirmation = st?.stage === "needs-aac-confirmation";
          const canRetryAsAac = needsAacConfirmation || Boolean(isError && st?.aacRetryAvailable);
          // Klasörde kaydı varsa yeniden indirme yok; düğme grileşir.
          // Kimlik yoksa (eski indirme) dosya adı kalıbına bakılır.
          const alreadyDownloaded = downloadedIdSet.has(track.id)
            || downloadedStemSet.has(candidateStem(track));
          // Dosya diskteyse eski hata mesaji gosterilmez; gercek durum inmisliktir.
          const showError = isError && !alreadyDownloaded && !isDone;
          const liked = likedIds.includes(track.id);
          const pickerOpen = pickerFor === track.id;
          return (
            <li
              key={track.id}
              className="flex flex-wrap"
              data-format-track-id={track.id}
            >
              <div className="relative flex min-h-[72px] min-w-0 basis-full items-center gap-3 rounded-lg px-2 py-2 sm:gap-4 sm:px-4">
              {/* Ortu dugme: satirin her yeri caliyor, indirme beklenmiyor. */}
              <button
                type="button"
                onClick={() => onPlay?.(track)}
                title={t.externalSearch.playTrack({ title: track.title })}
                aria-label={t.externalSearch.playTrack({ title: track.title })}
                className="absolute inset-0 rounded-lg transition-colors hover:bg-[#181818] focus-visible:z-20 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954]"
              />
              <span className="pointer-events-none relative z-10 hidden w-6 shrink-0 text-right text-sm text-[#B3B3B3] tabular-nums sm:block">
                {index + 1}
              </span>
              <Image
                src={track.cover}
                alt=""
                aria-hidden="true"
                width={48}
                height={48}
                unoptimized
                className="pointer-events-none relative z-10 h-12 w-12 shrink-0 rounded object-cover"
              />
              <span className="pointer-events-none relative z-10 flex min-w-0 flex-1 flex-col text-left">
                <span className="truncate text-[15px] font-medium text-white">{track.title}</span>
                <span className="truncate text-sm text-[#B3B3B3]">
                  {track.artist} • {track.album}
                </span>
                {showError && st?.message && (
                  <span role="alert" className="mt-1 max-w-[28rem] truncate text-xs text-white">
                    {t.download.failedPrefix} {st.message.slice(0, 200)}
                  </span>
                )}
                {isDone && (
                  <span role="status" className="mt-1 text-xs font-medium text-[#1DB954]">
                    {t.download.done}
                  </span>
                )}
              </span>
              <span className="pointer-events-none relative z-10 hidden shrink-0 text-xs text-[#8A8A8A] sm:block">
                {(() => {
                  const fmt = downloadedFormats?.[track.id] ?? formats[track.id];
                  if (fmt === undefined) return <span className="opacity-50">…</span>;
                  if (fmt === null) return null;
                  const codec = fmt.codec.split(".")[0]?.toUpperCase() ?? "";
                  return (
                    <span
                      className="rounded border border-[#3E3E3E] px-1.5 py-0.5"
                      title={t.externalSearch.codecTitle({
                        codec: fmt.codec,
                        ext: fmt.ext || "-",
                        rate: fmt.sampleRate ? `${Math.round(fmt.sampleRate / 1000)} kHz` : "-",
                      })}
                    >
                      {codec}
                      {fmt.bitrate ? ` ${fmt.bitrate}k` : ""}
                    </span>
                  );
                })()}
              </span>
              <span className="pointer-events-none relative z-10 hidden shrink-0 text-sm tabular-nums text-[#B3B3B3] sm:block">
                {formatDuration(track.duration)}
              </span>
              <button
                type="button"
                onClick={() => onToggleLike(track)}
                aria-pressed={liked}
                aria-label={
                  liked
                    ? t.trackList.unlikeTrack({ title: track.title })
                    : t.trackList.likeTrack({ title: track.title })
                }
                title={liked ? t.trackList.unlikeTitle : t.trackList.likeTitle}
                className={`relative z-10 flex h-9 w-9 min-h-[36px] min-w-[36px] shrink-0 items-center justify-center rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] hover:bg-[#282828] ${
                  liked ? "text-[#FF6B81]" : "text-[#B3B3B3] hover:text-[#FF6B81]"
                }`}
              >
                <HeartIcon className="h-5 w-5" filled={liked} />
              </button>
              <button
                type="button"
                onClick={() => {
                  setPickerFor(pickerOpen ? null : track.id);
                  setPickerMessage(null);
                }}
                aria-expanded={pickerOpen}
                aria-label={t.trackList.addToList({ title: track.title })}
                title={t.trackList.addToListTitle}
                className="relative z-10 flex h-9 w-9 min-h-[36px] min-w-[36px] shrink-0 items-center justify-center rounded-full text-[#B3B3B3] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] hover:bg-[#282828] hover:text-white"
              >
                <PlusIcon className="h-5 w-5" />
              </button>
              <span className="relative z-10 flex shrink-0 flex-col items-end gap-2">
                {isSpotify ? <SpotifyBadge label={badgeLabel} /> : <YoutubeBadge label={badgeLabel} />}
                <span className="flex items-center gap-1">
                {canRetryAsAac ? (
                  <div className="flex max-w-[25rem] items-center gap-2">
                    <div
                      role="progressbar"
                      aria-label={t.download.downloading}
                      aria-valuemin={0}
                      aria-valuemax={100}
                      aria-valuenow={st.percent ?? 0}
                      className="relative h-2 w-16 shrink-0 overflow-hidden rounded-full bg-[#333333]"
                    >
                      <span
                        className="absolute inset-y-0 left-0 bg-[#16883F]"
                        style={{ width: `${st.percent ?? 0}%` }}
                      />
                    </div>
                    <span className="text-[11px] leading-tight text-[#FFCC80]">
                      {needsAacConfirmation
                        ? t.download.opusUnavailableQuestion
                        : t.download.opusFailedAacQuestion}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        void download(track, (local) => {
                          onDownloaded?.(local);
                          onFeedback?.(t.download.added({ title: local.title }));
                        }, "aac");
                      }}
                      className="min-h-[32px] shrink-0 rounded-full bg-[#1DB954] px-3 text-[11px] font-bold text-black hover:scale-105 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954]"
                    >
                      {t.download.useAac}
                    </button>
                  </div>
                ) : isDownloading && st.phase === "matching" ? (
                  <div role="progressbar" aria-label={t.download.matching} className="relative flex h-9 w-28 items-center justify-center overflow-hidden rounded-full bg-[#333333] text-xs font-bold text-white">
                    <span className="absolute inset-y-0 left-0 w-full animate-pulse bg-[#16883F]/60" />
                    <span className="relative">{t.download.matching}</span>
                  </div>
                ) : isDownloading ? (
                  <div role="progressbar" aria-label={t.download.downloading} aria-valuemin={0} aria-valuemax={100} aria-valuenow={st.percent ?? 0} className="relative flex h-9 w-28 items-center justify-center overflow-hidden rounded-full bg-[#333333] text-xs font-bold text-white">
                    <span className="absolute inset-y-0 left-0 bg-[#16883F] transition-[width]" style={{ width: `${st.percent ?? 0}%` }} />
                    <span className="relative">{st.percent ?? 0}%</span>
                  </div>
                ) : <button
                  type="button"
                  disabled={alreadyDownloaded || isDone}
                  onClick={async () => {
                    await download(track, (local) => {
                      onDownloaded?.(local);
                      onFeedback?.(t.download.added({ title: local.title }));
                    });
                  }}
                  aria-label={alreadyDownloaded || isDone ? `${t.download.done}: ${track.title}` : `${t.download.action} ${track.title}`}
                  className={`flex min-h-[36px] items-center justify-center rounded-full px-4 text-xs font-bold transition-colors focus-visible:outline-2 ${accent.ring} ${
                    showError
                      ? "bg-[#FF0000] text-white hover:bg-[#FF6B6B] hover:text-black"
                      : alreadyDownloaded || isDone
                        ? "cursor-default bg-[#3A3A3A] text-[#B3B3B3]"
                        : `${accent.fill} hover:scale-105 disabled:opacity-60`
                  }`}
                >
                  {alreadyDownloaded || isDone ? t.download.done : t.download.action}
                </button>}
                {showError && (
                  <button
                    type="button"
                    onClick={() => clearError(track.id)}
                    className="text-[11px] text-[#B3B3B3] underline hover:text-white focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                  >
                    Kapat
                  </button>
                )}
                </span>
              </span>
              </div>
              {pickerOpen && (
                <div className="min-w-0 basis-full pl-1 sm:pl-10">
                  {playlists.length === 0 ? (
                    <p className="rounded-lg bg-[#181818] px-3 py-2 text-sm text-[#B3B3B3]">
                      {t.trackList.createFirst}
                    </p>
                  ) : (
                    <div className="rounded-lg bg-[#181818] p-2">
                      <p className="px-2 pt-1 text-sm font-medium text-white">
                        {t.trackList.whichList}
                      </p>
                      <ul className="plk-scroll mt-1 flex max-h-64 flex-col gap-1 overflow-y-auto">
                        {playlists.map((p) => {
                          const contains =
                            p.trackIds.includes(track.id) ||
                            (p.importedTracks ?? []).some((imp) => imp.id === track.id);
                          return (
                            <li key={p.id}>
                              <button
                                type="button"
                                onClick={() => {
                                  const message = onAddToPlaylist(p.id, track);
                                  setPickerMessage(message);
                                }}
                                aria-label={`${p.name} (${t.playlistPanel.trackCount({ count: p.trackIds.length })})`}
                                className="flex min-h-[56px] w-full items-center gap-3 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-[#282828] focus-visible:outline-2 focus-visible:outline-[#1DB954]"
                              >
                                <img
                                  src={playlistArtwork(p)}
                                  alt=""
                                  loading="lazy"
                                  className="h-10 w-10 shrink-0 rounded object-cover"
                                />
                                <span className="min-w-0 flex-1">
                                  <span className="block truncate text-sm font-semibold text-white">
                                    {p.name}
                                  </span>
                                  <span className="block text-xs text-[#B3B3B3]">
                                    {t.playlistPanel.trackCount({ count: p.trackIds.length })}
                                  </span>
                                </span>
                                {contains ? (
                                  <CheckIcon className="h-5 w-5 shrink-0 text-[#1DB954]" />
                                ) : (
                                  <PlusIcon className="h-5 w-5 shrink-0 text-[#B3B3B3]" />
                                )}
                              </button>
                            </li>
                          );
                        })}
                      </ul>
                      {pickerMessage && (
                        <p role="status" className="px-2 pb-1 pt-1 text-sm text-[#B3B3B3]">
                          {pickerMessage}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              )}
            </li>
          );
        })}
      </ul>
      <div ref={sentinelRef} className="min-h-[4px]">
        {isLoadingMore ? (
          <p role="status" className="py-4 text-center text-[15px] text-[#B3B3B3]">
            {t.externalSearch.loadingMore}
          </p>
        ) : !hasMore && poolExhausted ? (
          <p className="px-2 pb-2 text-center text-xs text-[#8A8A8A] sm:px-4">{t.externalSearch.noMoreResults}</p>
        ) : null}
      </div>
      <p className="px-2 pb-2 text-xs text-[#8A8A8A] sm:px-4">{t.externalSearch.previewNotice}</p>
    </div>
  );
}
