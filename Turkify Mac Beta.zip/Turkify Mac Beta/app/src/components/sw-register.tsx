"use client";

import { useEffect } from "react";

/** Service worker kaydeder; kurulabilir uygulama (PWA) icin gerekli. */
export function SwRegister() {
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {
        // Kayit basarisizsa uygulama normal sekmede calismaya devam eder.
      });
    }
  }, []);
  return null;
}
