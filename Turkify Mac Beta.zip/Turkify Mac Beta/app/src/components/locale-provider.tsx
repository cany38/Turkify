"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import type { ReactNode } from "react";
import {
  DEFAULT_LOCALE,
  MESSAGES,
  readStoredLocale,
  writeStoredLocale,
} from "../lib/i18n";
import type { Locale, Messages } from "../lib/i18n";

interface I18nContextValue {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  /** O anki dilin sozlugu. */
  t: Messages;
}

const I18nContext = createContext<I18nContextValue | null>(null);

export function LocaleProvider({ children }: { children: ReactNode }) {
  // Ilk render her zaman varsayilan dille olur (hydration guvenligi);
  // depolanmis tercih mount sonrasi okunup uygulanir.
  const [locale, setLocaleState] = useState<Locale>(DEFAULT_LOCALE);

  // Tek seferlik okuma; hicbir otomatik yazma effect'i yok, bu yuzden
  // okuma bitmeden depolanmis tercih ezilemez. Iptal edilebilir async
  // init, StrictMode replay'de gecikmis yazmanin state'i bozmasini onler.
  useEffect(() => {
    let cancelled = false;
    void Promise.resolve()
      .then(() => readStoredLocale())
      .then((stored) => {
        if (cancelled) return;
        if (stored !== null) setLocaleState(stored);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Dil degisince belgenin dilini guncelle.
  useEffect(() => {
    document.documentElement.lang = locale;
  }, [locale]);

  // Yazma yalnizca kullanici secimiyle olur (okuma-yazma yarisi yok).
  const setLocale = useCallback((next: Locale) => {
    setLocaleState(next);
    writeStoredLocale(next);
  }, []);

  const value = useMemo<I18nContextValue>(
    () => ({ locale, setLocale, t: MESSAGES[locale] }),
    [locale, setLocale],
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nContextValue {
  const ctx = useContext(I18nContext);
  if (!ctx) {
    throw new Error("useI18n yalnizca LocaleProvider icinde cagrilabilir.");
  }
  return ctx;
}

const LOCALES: Locale[] = ["tr", "az", "en"];

const LOCALE_SHORT: Record<Locale, string> = { tr: "TR", en: "EN", az: "AZ" };

/**
 * Kucuk, olculu dil kontrolu. Mevcut paleti kullanir
 * (`#282828` zemin, aktifde beyaz hap); yeni renk/gradient yok.
 * 44px dokunma hedefi ve gorunur `focus-visible` korunur.
 */
export function LocaleSwitcher() {
  const { locale, setLocale, t } = useI18n();
  const names: Record<Locale, string> = {
    tr: t.locale.turkish,
    en: t.locale.english,
    az: t.locale.azerbaijani,
  };
  return (
    <div
      role="group"
      aria-label={t.locale.label}
      className="inline-flex items-center gap-1 rounded-full bg-[#282828] p-1"
    >
      {LOCALES.map((l) => {
        const active = l === locale;
        return (
          <button
            key={l}
            type="button"
            onClick={() => {
              if (!active) setLocale(l);
            }}
            aria-pressed={active}
            aria-label={names[l]}
            title={names[l]}
            className={`flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full px-3 text-xs font-bold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1DB954] ${
              active
                ? "bg-white text-black"
                : "text-[#B3B3B3] hover:text-white"
            }`}
          >
            {LOCALE_SHORT[l]}
          </button>
        );
      })}
    </div>
  );
}
