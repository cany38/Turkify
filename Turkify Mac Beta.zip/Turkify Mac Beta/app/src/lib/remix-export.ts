import {
  DEFAULT_REMIX,
  createRemixChain,
  isDefaultRemix,
  sanitizeRemix,
} from "./audio-effects";
import type { RemixSettings } from "./audio-effects";
import { encodeWav } from "./wav";

/**
 * Remix'i dosyaya dokme katmani.
 *
 * Calarken efektler gercek zamanli uygulaniyor; burada ayni zincir bir
 * `OfflineAudioContext` icinde kuruluyor, yani indirilen dosya kullanicinin
 * duydugu seyin ta kendisi - ikinci bir efekt uygulamasi degil.
 *
 * Hiz de calarken oldugu gibi yeniden orneklemeyle uygulanir: oynatici
 * `preservesPitch = false` kullaniyor, `playbackRate` da ayni sekilde perdeyi
 * kaydirir. Bu yuzden slowed/sped up sonucu birebir ortusur.
 */

/** Reverb kuyrugu ortadan kesilmesin diye rendere eklenen ek sure (sn). */
export const REVERB_TAIL_SECONDS = 2;

/** Dosya adinda kullanilan sabit etiketler; dil degisince ad degismesin diye
 *  ceviriden gelmez. Degerler `player.tsx` icindeki hazir ayarlarla birebir. */
const PRESET_LABELS: { value: RemixSettings; label: string }[] = [
  { value: { speed: 0.8, reverb: 0.3, bass: 0.1 }, label: "Slowed + Reverb" },
  { value: { speed: 1.15, reverb: 0.1, bass: 0 }, label: "Sped Up" },
];

function sameSettings(a: RemixSettings, b: RemixSettings): boolean {
  return a.speed === b.speed && a.reverb === b.reverb && a.bass === b.bass;
}

/**
 * Ayarlarin insan okur etiketi.
 *
 * Hazir bir ayarsa onun adi; degilse hangi parametrenin degistigi yazilir,
 * boylece iki farkli remix ayni dosya adina dusmez.
 */
export function remixLabel(settings: RemixSettings): string {
  const config = sanitizeRemix(settings);
  if (isDefaultRemix(config)) return "Normal";
  const preset = PRESET_LABELS.find((entry) => sameSettings(entry.value, config));
  if (preset) return preset.label;
  const parts: string[] = [];
  if (config.speed !== DEFAULT_REMIX.speed) {
    parts.push(`${Math.round(config.speed * 100) / 100}x`);
  }
  if (config.reverb > 0) parts.push(`reverb ${Math.round(config.reverb * 100)}`);
  if (config.bass > 0) parts.push(`bass ${Math.round(config.bass * 100)}`);
  return parts.length > 0 ? parts.join(" ") : "Remix";
}

/**
 * Onerilen dosya adi. Sunucu ayrica kendi temizligini yapar; buradaki
 * kirpma yalnizca yol ayraci gibi bariz karakterleri disarida tutmak icin.
 */
export function buildRemixFileName(
  title: string,
  artist: string,
  settings: RemixSettings,
): string {
  const clean = (value: string): string =>
    value.replace(/[\\/:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim();
  const name = clean(artist) ? `${clean(artist)} - ${clean(title)}` : clean(title);
  const stem = name || "parca";
  return `${stem} (${remixLabel(settings)}).wav`;
}

/**
 * Render edilecek kare sayisi.
 *
 * Hiz kaynagi kisaltir ya da uzatir; reverb acikken kuyrugun sigmasi icin
 * sona sabit bir pay eklenir, yoksa son akor aniden kesilir.
 */
export function remixFrameCount(
  sourceFrames: number,
  speed: number,
  sampleRate: number,
  reverb: number,
): number {
  const rate = speed > 0 && Number.isFinite(speed) ? speed : 1;
  const base = Math.ceil(sourceFrames / rate);
  const tail = reverb > 0 ? Math.ceil(REVERB_TAIL_SECONDS * sampleRate) : 0;
  return Math.max(1, base + tail);
}

/**
 * Ses baytlarini remix ayarlariyla WAV'a cevirir. Yalnizca tarayicida
 * calisir; `OfflineAudioContext` gerektirir.
 */
export async function renderRemix(
  audioData: ArrayBuffer,
  settings: RemixSettings,
): Promise<Blob> {
  const config = sanitizeRemix(settings);
  const AudioCtor = window.AudioContext;
  const OfflineCtor = window.OfflineAudioContext;
  if (typeof AudioCtor !== "function" || typeof OfflineCtor !== "function") {
    throw new Error("Bu tarayici ses islemeyi desteklemiyor.");
  }

  // Cozumleme, calarkenki baglamla ayni ornekleme hizinda yapilir; boylece
  // dosyaya yazilan sey oynaticinin urettiginden farkli bir yeniden
  // orneklemeden gecmez.
  const decodeCtx = new AudioCtor();
  let decoded: AudioBuffer;
  try {
    decoded = await decodeCtx.decodeAudioData(audioData);
  } finally {
    void decodeCtx.close().catch(() => undefined);
  }

  const frames = remixFrameCount(
    decoded.length,
    config.speed,
    decoded.sampleRate,
    config.reverb,
  );
  const offline = new OfflineCtor(decoded.numberOfChannels, frames, decoded.sampleRate);
  const source = offline.createBufferSource();
  source.buffer = decoded;
  source.playbackRate.value = config.speed;

  const chain = createRemixChain(offline);
  chain.apply(config);
  source.connect(chain.input);
  chain.output.connect(offline.destination);
  source.start(0);

  const rendered = await offline.startRendering();
  chain.dispose();

  const channels: Float32Array[] = [];
  for (let ch = 0; ch < rendered.numberOfChannels; ch += 1) {
    channels.push(rendered.getChannelData(ch));
  }
  return new Blob([encodeWav(channels, rendered.sampleRate)], { type: "audio/wav" });
}
