/**
 * YouTube Data API basliklari HTML kacisli donuyor ("Howl&#39;s"). Hem ekranda
 * hem dosya adinda ham haliyle gorunmesin diye cozuluyor.
 *
 * Sunucu ve betik tarafinda ortak kullanim icin tasindi; Node'a ozel
 * hicbir sey (`fs`, `path`) icermez.
 */
export function decodeHtmlEntities(value: string): string {
  return value
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCharCode(parseInt(code, 10)))
    .replace(/&#x([0-9a-f]+);/gi, (_, code: string) => String.fromCharCode(parseInt(code, 16)))
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&");
}
