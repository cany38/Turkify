import { spawn } from "child_process";
import path from "path";
import { resolveScriptsDir } from "./data-dir";
import type { ImportedPlaylistTrack } from "./types";
import type { FetchedPlaylist, FetchedPlaylistTrack } from "./spotify-playlist-source";

// 1000 parcalik liste icin bol tutulur; yt-dlp tek cagrida sayfalar.
const FETCH_TIMEOUT_MS = 90_000;

/** Tam URL ya da ciplak kimlikten YouTube playlist kimligini cikarir. */
export function extractYoutubePlaylistId(value: string): string | null {
  const text = (value ?? "").trim();
  if (!text) return null;
  const match = text.match(/[?&]list=([A-Za-z0-9_-]+)/);
  if (match?.[1]) return match[1];
  if (/^(?:PL|RD|OL|UU|LL|FL)[A-Za-z0-9_-]{8,}$/.test(text)) return text;
  return null;
}

/** Betik stdout'unu `FetchedPlaylist`e cevirir; bozuksa okunabilir hata atar. */
export function parseYoutubePlaylistOutput(stdout: string): FetchedPlaylist {
  let parsed: unknown;
  try {
    // Betik tek satir JSON yazar; sondaki bos satir ayiklanir.
    parsed = JSON.parse(stdout.trim().split("\n").filter(Boolean).pop() ?? "");
  } catch {
    throw new Error("Liste okunamadı: python veya yt-dlp çalıştırılamadı.");
  }
  if (typeof parsed !== "object" || parsed === null) {
    throw new Error("Liste okunamadı: python veya yt-dlp çalıştırılamadı.");
  }
  const record = parsed as { ok?: unknown; error?: unknown };
  if (record.ok !== true) {
    const detail =
      typeof record.error === "string" && record.error.trim()
        ? record.error.trim().slice(0, 200)
        : "YouTube playlist okunamadı.";
    throw new Error(`Liste okunamadı: ${detail}`);
  }
  const body = record as {
    name?: unknown;
    cover?: unknown;
    tracks?: unknown;
  };
  const tracks = Array.isArray(body.tracks) ? body.tracks : [];
  return {
    name: typeof body.name === "string" && body.name ? body.name : "YouTube playlist",
    cover: typeof body.cover === "string" ? body.cover : "",
    tracks: tracks.filter((t): t is FetchedPlaylistTrack => isFetchedYoutubeTrack(t)),
  };
}

/** Ham kaydın beklenen sekilde olup olmadigini denetler. */
function isFetchedYoutubeTrack(value: unknown): value is FetchedPlaylistTrack {
  if (typeof value !== "object" || value === null) return false;
  const v = value as Record<string, unknown>;
  return (
    typeof v.id === "string" &&
    typeof v.title === "string" &&
    typeof v.artist === "string" &&
    typeof v.album === "string" &&
    typeof v.duration === "number" &&
    typeof v.url === "string"
  );
}

/**
 * Betik ciktisini arayuzun kullandigi ize donusturur; saf fonksiyondur.
 * Eksik kapak liste kapagına (o da yoksa varsayilana) duser.
 */
export function mapFetchedYoutubeTracks(
  tracks: FetchedPlaylistTrack[],
  playlistCover: string,
): ImportedPlaylistTrack[] {
  const fallbackCover = playlistCover || "/covers/demo-01.svg";
  const mapped: ImportedPlaylistTrack[] = [];
  for (const track of tracks) {
    if (!track.id || !track.title) continue;
    mapped.push({
      id: `youtube-${track.id}`,
      source: "youtube",
      youtubeId: track.id,
      youtubeUrl: track.url || `https://www.youtube.com/watch?v=${track.id}`,
      title: track.title,
      artist: track.artist || "Bilinmeyen sanatçı",
      album: track.album || "YouTube",
      duration: Math.round(track.duration),
      cover: track.cover || fallbackCover,
    });
  }
  return mapped;
}

/** Betigi `python` ile calistirip JSON ciktisini cozer. */
export function fetchYoutubePlaylist(playlistId: string): Promise<FetchedPlaylist> {
  return new Promise((resolve, reject) => {
    const scriptPath = path.join(resolveScriptsDir(), "youtube-playlist.py");
    const child = spawn(process.env.TURKIFY_PYTHON || "python3", [scriptPath, playlistId], { windowsHide: true });
    let stdout = "";
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      try {
        child.kill();
      } catch {
        // yok say
      }
    }, FETCH_TIMEOUT_MS);

    child.stdout?.on("data", (d: Buffer) => {
      stdout += d.toString("utf8");
      // Asiri buyuk cikti bellegi sismesin; sinir asilirsa erken bitir.
      if (stdout.length > 20_000_000) {
        try {
          child.kill();
        } catch {
          // yok say
        }
      }
    });
    child.on("error", () => {
      clearTimeout(timer);
      reject(new Error("Liste okunamadı: python veya yt-dlp çalıştırılamadı."));
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      if (timedOut) {
        reject(new Error("Liste okunamadı: işlem zaman aşımına uğradı."));
        return;
      }
      if (code !== 0 && !stdout.trim()) {
        reject(new Error("Liste okunamadı: python veya yt-dlp çalıştırılamadı."));
        return;
      }
      try {
        resolve(parseYoutubePlaylistOutput(stdout));
      } catch (error) {
        reject(error instanceof Error ? error : new Error("Liste okunamadı."));
      }
    });
  });
}
