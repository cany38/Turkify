/**
 * Turkify remix ses motoru: hiz / reverb / bass boost.
 *
 * UI yok; bu dosya yalnizca veri + Web Audio zinciri kurar.
 * - Yeniden kodlama / yeniden orneklemeleme yok: her sey gercek zamanli grafikte.
 * - Varsayilan ayarlarda remix yolu seffaf gain bypass'indan gecer.
 * - Hiz bu grafikte degil, HTMLAudioElement.playbackRate ile uygulanir.
 */

export interface RemixSettings {
  speed: number;
  reverb: number;
  bass: number;
}

export const DEFAULT_REMIX: RemixSettings = { speed: 1, reverb: 0, bass: 0 };

export const REMIX_STORAGE_KEY = "turkify:remix:v1";
export const TRACK_REMIX_STORAGE_KEY = "turkify:track-remix:v1";

export function readTrackRemix(trackId: string): RemixSettings | null {
  try {
    const records = JSON.parse(window.localStorage.getItem(TRACK_REMIX_STORAGE_KEY) ?? "{}");
    if (!records || !Object.hasOwn(records, trackId)) return null;
    const value = records[trackId];
    if (!value || ![value.speed, value.reverb, value.bass].every((n) => typeof n === "number" && Number.isFinite(n))) return null;
    return sanitizeRemix(value);
  } catch {
    return null;
  }
}

export function writeTrackRemix(trackId: string, settings: RemixSettings): boolean {
  try {
    const raw = window.localStorage.getItem(TRACK_REMIX_STORAGE_KEY);
    const records = raw ? JSON.parse(raw) : {};
    if (!records || typeof records !== "object" || Array.isArray(records)) return false;
    window.localStorage.setItem(TRACK_REMIX_STORAGE_KEY, JSON.stringify({ ...records, [trackId]: sanitizeRemix(settings) }));
    return true;
  } catch {
    return false;
  }
}

const SPEED_MIN = 0.5;
const SPEED_MAX = 1.5;
const AMOUNT_MIN = 0;
const AMOUNT_MAX = 1;
/** bass = 1 iken lowshelf kazanci; uzerine cikilmaz. */
const BASS_MAX_DB = 9;
/** Kod icinde uretilen impulse response suresi (sn). */
const IR_SECONDS = 1.8;
/** Kuru sesten sonra reverb kuyruğunun baslamasina kadar gecen sure (sn). */
const IR_PREDELAY_SECONDS = 0.024;
/** Islak yol trimi (lineer kazanc): IR kanal basina birim enerjiye normalize
 * edildigi ve `convolver.normalize = false` oldugu icin islak yol zaten kuru
 * yolla ayni seviyededir; bu trim yogun kayitlarda kuyruga headroom birakir. */
const WET_MAKEUP = 0.72;
/** Parametre gecislerini tik/pat'siz yapan yumusatma suresi (sn). */
const SMOOTHING_TIME = 0.02;
/** 4x oversampling payiyla efektli yolun son tavani: yaklasik -1 dBFS. */
const EFFECT_CEILING = 0.88;

function clamp(value: number, min: number, max: number): number {
  if (value < min) return min;
  if (value > max) return max;
  return value;
}

function toFiniteNumber(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

/** Gelen degerleri sinirlarina kirpar; NaN/Infinity/yanlis tipe dayaniklidir. */
export function sanitizeRemix(input: unknown): RemixSettings {
  if (typeof input !== "object" || input === null) return { ...DEFAULT_REMIX };
  const record = input as Record<string, unknown>;
  const speed = toFiniteNumber(record.speed);
  const reverb = toFiniteNumber(record.reverb);
  const bass = toFiniteNumber(record.bass);
  return {
    speed: clamp(speed ?? DEFAULT_REMIX.speed, SPEED_MIN, SPEED_MAX),
    reverb: clamp(reverb ?? DEFAULT_REMIX.reverb, AMOUNT_MIN, AMOUNT_MAX),
    bass: clamp(bass ?? DEFAULT_REMIX.bass, AMOUNT_MIN, AMOUNT_MAX),
  };
}

/** Ayarlar varsayilanla ayni mi (bypass kosulu). */
export function isDefaultRemix(settings: RemixSettings): boolean {
  return (
    settings.speed === DEFAULT_REMIX.speed &&
    settings.reverb === DEFAULT_REMIX.reverb &&
    settings.bass === DEFAULT_REMIX.bass
  );
}

/** Gecersiz/eksik alanda null doner; bozuk degeri sessizce kabul etmez. */
export function readStoredRemix(): RemixSettings | null {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return null;
    const raw = window.localStorage.getItem(REMIX_STORAGE_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (typeof parsed !== "object" || parsed === null) return null;
    const record = parsed as Record<string, unknown>;
    const speed = toFiniteNumber(record.speed);
    const reverb = toFiniteNumber(record.reverb);
    const bass = toFiniteNumber(record.bass);
    if (speed === null || reverb === null || bass === null) return null;
    return sanitizeRemix({ speed, reverb, bass });
  } catch {
    // Bozuk kayit / erisim engeli uygulamayi cokertmesin; yok say.
    return null;
  }
}

export function writeStoredRemix(settings: RemixSettings): boolean {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return false;
    const payload = sanitizeRemix(settings);
    window.localStorage.setItem(REMIX_STORAGE_KEY, JSON.stringify(payload));
    return true;
  } catch {
    // Kota dolmasi / erisim engeli sessizce yok sayilir.
    return false;
  }
}

/** 8 bantli esitleyicinin merkez frekanslari (Hz). Ilk ve son bant shelf'tir. */
export const EQ_FREQUENCIES = [60, 170, 310, 600, 1000, 3000, 6000, 12000] as const;
export const EQ_BAND_COUNT = EQ_FREQUENCIES.length;
/** Bant basina kazanc siniri (dB). */
export const EQ_MAX_DB = 20;
/** Bant kazanclari (dB), sira `EQ_FREQUENCIES` ile aynidir. 0 = notr. */
export type EqSettings = number[];
export const DEFAULT_EQ: EqSettings = EQ_FREQUENCIES.map(() => 0);

/** Ekolayzer hazir profili: kimlik + 8 bantlik kazanc dizisi. */
export interface EqPreset {
  id: string;
  value: EqSettings;
}

/** Hazir ekolayzer profilleri; UI'daki sirayla. */
export const EQ_PRESETS: EqPreset[] = [
  { id: "flat", value: EQ_FREQUENCIES.map(() => 0) },
  { id: "bass-boost", value: [10, 9, 5, 2, 0, 0, 0, 0] },
  { id: "vocal", value: [-4, -3, 0, 5, 6, 5, 2, 0] },
  {
    id: "pastel-ghost",
    value: [5, 6, 3, -1, -6, -10, -17, -20],
  },
  { id: "treble", value: [0, 0, 0, 0, 2, 5, 8, 10] },
];
export const EQ_STORAGE_KEY = "turkify:eq:v1";

/** Her banda sonlu, sinir icinde bir dB degeri yazar; dizi girdisini kabul eder. */
export function sanitizeEq(input: unknown): EqSettings {
  const source = Array.isArray(input) ? input : [];
  return EQ_FREQUENCIES.map((_, index) => clamp(toFiniteNumber(source[index]) ?? 0, -EQ_MAX_DB, EQ_MAX_DB));
}

/** Butun bantlar notr mi (gorsel "duz" durumu). */
export function isDefaultEq(eq: EqSettings): boolean {
  return eq.every((value) => Math.abs(value) < 0.001);
}

export function readStoredEq(): EqSettings | null {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return null;
    const raw = window.localStorage.getItem(EQ_STORAGE_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return null;
    return sanitizeEq(parsed);
  } catch {
    // Bozuk kayit / erisim engeli uygulamayi cokertmesin; yok say.
    return null;
  }
}

export function writeStoredEq(eq: EqSettings): boolean {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return false;
    window.localStorage.setItem(EQ_STORAGE_KEY, JSON.stringify(sanitizeEq(eq)));
    return true;
  } catch {
    // Kota dolmasi / erisim engeli sessizce yok sayilir.
    return false;
  }
}

/** Ayni seed ile her seferinde ayni kuyruğu ureten kucuk PRNG. */
function createSeededNoise(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    return (state >>> 0) / 0x1_0000_0000;
  };
}

/** Kod icinde uretilen stereo impulse response: predelay + yumusak sonum. */
function buildImpulseResponse(ctx: BaseAudioContext): AudioBuffer {
  const rate = ctx.sampleRate;
  const length = Math.max(1, Math.floor(rate * IR_SECONDS));
  const predelayFrames = Math.min(length - 1, Math.floor(rate * IR_PREDELAY_SECONDS));
  const tailLength = Math.max(1, length - predelayFrames);
  const buffer = ctx.createBuffer(2, length, rate);
  const energies: number[] = [];
  for (let ch = 0; ch < buffer.numberOfChannels; ch += 1) {
    const data = buffer.getChannelData(ch);
    const noise = createSeededNoise(0x51f15e + ch * 0x9e3779b9);
    let channelEnergy = 0;
    let smoothedNoise = 0;
    for (let i = predelayFrames; i < length; i += 1) {
      const tailFrame = i - predelayFrames;
      const t = tailFrame / tailLength;
      const attack = Math.min(1, tailFrame / Math.max(1, rate * 0.012));
      const decay = Math.exp(-4.2 * t);
      smoothedNoise = smoothedNoise * 0.58 + (noise() * 2 - 1) * 0.42;
      const sample = smoothedNoise * attack * decay;
      data[i] = sample;
      channelEnergy += sample * sample;
    }
    energies.push(channelEnergy);
  }
  // Kanal basina enerji normalizasyonu: her kanal kendi enerjisine gore birim
  // enerjiye (1.0) olceklenir; boylece konvolusyon genis bantli sinyal icin
  // yaklasik RMS-koruyucu olur. Kanallarin enerjisi toplanmaz.
  for (let ch = 0; ch < buffer.numberOfChannels; ch += 1) {
    const channelEnergy = energies[ch];
    if (channelEnergy > 0) {
      const scale = 1 / Math.sqrt(channelEnergy);
      const data = buffer.getChannelData(ch);
      for (let i = 0; i < length; i += 1) {
        data[i] = data[i] * scale;
      }
    }
  }
  return buffer;
}

export interface RemixChain {
  input: AudioNode;
  output: AudioNode;
  apply(settings: RemixSettings): void;
  applyEq(eq: EqSettings): void;
  dispose(): void;
}

/**
 * Gercek zamanli efekt zinciri kurar. `BaseAudioContext` alir, boylece
 * `OfflineAudioContext` ile de kurulup kirpma olculebilir.
 *
 * Grafik (efekt modunda):
 * input -> bass filtresi -> kuru yol + (convolver -> islak filtreler) -> limiter -> output
 */
export function createRemixChain(ctx: BaseAudioContext): RemixChain {
  const input = ctx.createGain();
  const output = ctx.createGain();

  // Esitleyici: giris ile geri kalan zincir arasina seri bagli, her zaman
  // aktiftir (remix bypass olsa da EQ uygulanir). Butun bantlar 0 dB iken
  // pratikte seffaftir; bu yuzden ayri bir bypass anahtari gerekmez.
  const eqFilters = EQ_FREQUENCIES.map((frequency, index) => {
    const filter = ctx.createBiquadFilter();
    if (index === 0) filter.type = "lowshelf";
    else if (index === EQ_FREQUENCIES.length - 1) filter.type = "highshelf";
    else filter.type = "peaking";
    filter.frequency.value = frequency;
    if (filter.type === "peaking") filter.Q.value = 1.1;
    filter.gain.value = 0;
    return filter;
  });
  // Kurgu dugumu: EQ cikisinin baglandigi tek nokta; bypass/efekt anahtari
  // buradan sonrasini yonetir.
  const preFx = ctx.createGain();
  const eqHead = eqFilters[0];
  const eqTail = eqFilters[eqFilters.length - 1];
  if (eqHead && eqTail) {
    input.connect(eqHead);
    for (let i = 0; i < eqFilters.length - 1; i += 1) {
      const current = eqFilters[i];
      const next = eqFilters[i + 1];
      if (current && next) current.connect(next);
    }
    eqTail.connect(preFx);
  } else {
    input.connect(preFx);
  }

  const bassFilter = ctx.createBiquadFilter();
  bassFilter.type = "lowshelf";
  bassFilter.frequency.value = 120;

  const dryGain = ctx.createGain();
  const wetGain = ctx.createGain();
  const masterGain = ctx.createGain();
  const wetHighPass = ctx.createBiquadFilter();
  const wetLowPass = ctx.createBiquadFilter();
  const bypassGain = ctx.createGain();
  const effectGain = ctx.createGain();
  const limiter = ctx.createDynamicsCompressor();
  const safetyClipper = ctx.createWaveShaper();
  const ceilingGain = ctx.createGain();

  const convolver = ctx.createConvolver();
  convolver.normalize = false;
  convolver.buffer = buildImpulseResponse(ctx);
  wetHighPass.type = "highpass";
  wetHighPass.frequency.value = 180;
  wetHighPass.Q.value = 0.7;
  wetLowPass.type = "lowpass";
  wetLowPass.frequency.value = 7_600;
  wetLowPass.Q.value = 0.7;

  dryGain.gain.value = 1;
  wetGain.gain.value = 0;
  masterGain.gain.value = 1;
  bypassGain.gain.value = 1;
  effectGain.gain.value = 0;
  limiter.threshold.value = -1;
  limiter.knee.value = 0;
  limiter.ratio.value = 20;
  limiter.attack.value = 0.003;
  limiter.release.value = 0.12;
  safetyClipper.curve = new Float32Array([-1, 1]);
  safetyClipper.oversample = "4x";
  ceilingGain.gain.value = EFFECT_CEILING;

  // Iki yol surekli bagli kalir; gain crossfade ani connect/disconnect tiklarini onler.
  preFx.connect(bypassGain);
  bypassGain.connect(output);
  preFx.connect(bassFilter);
  bassFilter.connect(dryGain);
  dryGain.connect(masterGain);
  bassFilter.connect(convolver);
  convolver.connect(wetHighPass);
  wetHighPass.connect(wetLowPass);
  wetLowPass.connect(wetGain);
  wetGain.connect(masterGain);
  masterGain.connect(limiter);
  limiter.connect(safetyClipper);
  safetyClipper.connect(ceilingGain);
  ceilingGain.connect(effectGain);
  effectGain.connect(output);
  let firstApply = true;

  function apply(settings: RemixSettings): void {
    const next = sanitizeRemix(settings);
    const now = ctx.currentTime;
    const bassDb = next.bass * BASS_MAX_DB;
    // Esit guclu kuru/islak karisim: toplam seviye reverb ile sismesin. IR
    // kanal basina birim enerjiye normalize edildigi icin islak yol zaten
    // kuru yolla ayni seviyededir; WET_MAKEUP islak kuyruga headroom birakir.
    const dry = Math.cos(next.reverb * (Math.PI / 2));
    const wet = Math.sin(next.reverb * (Math.PI / 2)) * WET_MAKEUP;
    // Bass telafisi: shelf kazancinin ucde ikisini (dB) geri alir; net +3 dB
    // bas artisi kalir.
    const master = Math.pow(10, -bassDb / 30);
    const shouldBypass = isDefaultRemix(next);
    const bypassTarget = shouldBypass ? 1 : 0;
    const effectTarget = shouldBypass ? 0 : 1;
    if (firstApply) {
      bassFilter.gain.setValueAtTime(bassDb, now);
      dryGain.gain.setValueAtTime(dry, now);
      wetGain.gain.setValueAtTime(wet, now);
      masterGain.gain.setValueAtTime(master, now);
      bypassGain.gain.setValueAtTime(bypassTarget, now);
      effectGain.gain.setValueAtTime(effectTarget, now);
      firstApply = false;
    } else {
      bassFilter.gain.setTargetAtTime(bassDb, now, SMOOTHING_TIME);
      dryGain.gain.setTargetAtTime(dry, now, SMOOTHING_TIME);
      wetGain.gain.setTargetAtTime(wet, now, SMOOTHING_TIME);
      masterGain.gain.setTargetAtTime(master, now, SMOOTHING_TIME);
      bypassGain.gain.setTargetAtTime(bypassTarget, now, SMOOTHING_TIME);
      effectGain.gain.setTargetAtTime(effectTarget, now, SMOOTHING_TIME);
    }
  }

  /** Bant kazanclarini yumusatarak uygular; cagri sikligi onemsiz. */
  function applyEq(eq: EqSettings): void {
    const next = sanitizeEq(eq);
    const now = ctx.currentTime;
    for (let i = 0; i < eqFilters.length; i += 1) {
      const filter = eqFilters[i];
      if (filter) filter.gain.setTargetAtTime(next[i] ?? 0, now, SMOOTHING_TIME);
    }
  }

  function dispose(): void {
    try {
      input.disconnect();
    } catch {
      // yok say
    }
    for (const filter of eqFilters) {
      try {
        filter.disconnect();
      } catch {
        // yok say
      }
    }
    try {
      preFx.disconnect();
    } catch {
      // yok say
    }
    try {
      bassFilter.disconnect();
    } catch {
      // yok say
    }
    try {
      dryGain.disconnect();
    } catch {
      // yok say
    }
    try {
      wetGain.disconnect();
    } catch {
      // yok say
    }
    try {
      convolver.disconnect();
    } catch {
      // yok say
    }
    try {
      wetHighPass.disconnect();
      wetLowPass.disconnect();
    } catch {
      // yok say
    }
    try {
      masterGain.disconnect();
    } catch {
      // yok say
    }
    try {
      bypassGain.disconnect();
      effectGain.disconnect();
      limiter.disconnect();
      safetyClipper.disconnect();
      ceilingGain.disconnect();
    } catch {
      // yok say
    }
    try {
      output.disconnect();
    } catch {
      // yok say
    }
  }

  return { input, output, apply, applyEq, dispose };
}
