/**
 * Turkify i18n çekirdeği: harici kutuphane yok, elle cozum.
 *
 * Sozlesme (2. dilim dahil herkes uyar):
 * - `Messages` tek dogruluk kaynagidir; duz metinler `string`,
 *   parametreli metinler fonksiyondur.
 * - `MESSAGES` `Record<Locale, Messages>` tipindedir: bir dile anahtar
 *   eklenip digerine eklenmemesi derleme hatasi verir. `Partial`, `any`,
 *   index signature veya opsiyonel alan kullanma.
 * - Turkce metinler bit bazinda sabittir (QA regression bu metinlere gore
 *   secici kullanir); Turkce tarafta tek karakter bile degistirme.
 * - 2. dilim kendi anahtarlarini (player, track-list, playlist-panel,
 *   hook mesajlari) ayni `Messages` arayuzune yeni alan gruplari olarak
 *   ekler; mevcut gruplara dokunmaz.
 */

export type Locale = "tr" | "en" | "az";

export const DEFAULT_LOCALE: Locale = "en";

export const LOCALE_STORAGE_KEY = "turkify:locale:v1";

/** `toLocaleLowerCase` gibi yerel duyarli islemler icin BCP 47 etiketi. */
export function localeTag(locale: Locale): string {
  if (locale === "tr") return "tr-TR";
  if (locale === "az") return "az-AZ";
  return "en-US";
}

/** Gecersiz/bilinmeyen degerde `null` doner, sessizce bozuk deger dondurmez. */
export function readStoredLocale(): Locale | null {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return null;
    const raw = window.localStorage.getItem(LOCALE_STORAGE_KEY);
    if (raw === "tr" || raw === "en" || raw === "az") return raw;
    return null;
  } catch {
    // Bozuk kayit / erisim engeli uygulamayi cokertmesin; yok say.
    return null;
  }
}

export function writeStoredLocale(locale: Locale): boolean {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return false;
    window.localStorage.setItem(LOCALE_STORAGE_KEY, locale);
    return true;
  } catch {
    // Kota dolmasi / erisim engeli sessizce yok sayilir.
    return false;
  }
}

export interface Messages {
  locale: {
    /** Secici grup etiketi. */
    label: string;
    /** Dil adlari (secici `title`/`aria-label` icin). */
    turkish: string;
    english: string;
    azerbaijani: string;
  };
  nav: {
    home: string;
    search: string;
    library: string;
    liked: string;
    settings: string;
    mobileShort: {
      home: string;
      search: string;
      library: string;
      liked: string;
      settings: string;
    };
    mainNavLabel: string;
    mobileNavLabel: string;
    listsHeading: string;
    noLists: string;
  };
  home: {
    eyebrow: string;
    greeting: {
      morning: string;
      afternoon: string;
      evening: string;
      neutral: string;
    };
    featured: string;
    allTracks: string;
    allEmpty: string;
    playTrack: (p: { title: string }) => string;
    coverAlt: (p: { album: string }) => string;
    openPlaylist: (p: { name: string }) => string;
    playlistBadge: string;
    playlistCoverAlt: (p: { name: string }) => string;
  };
  search: {
    title: string;
    inputLabel: string;
    placeholder: string;
    clearSearch: string;
    clear: string;
    suggestionsLabel: string;
    recentSearchesLabel: string;
    localSource: string;
    promptTitle: string;
    resultsCount: (p: { count: number }) => string;
    hint: string;
    noResults: (p: { query: string }) => string;
  };
  library: {
    title: string;
    description: string;
    chooseFile: string;
    multiHint: string;
    deviceTitle: (p: { count: number }) => string;
    deviceEmpty: string;
    noFiles: string;
    manageLabel: string;
    sessionRow: (p: { name: string }) => string;
    removeFile: (p: { title: string }) => string;
    remove: string;
  };
  files: {
    untitled: string;
    localArtist: string;
    localAlbum: string;
    added: (p: { count: number }) => string;
    saveFailed: (p: { names: string }) => string;
    removeFailed: (p: { title: string }) => string;
    unsupported: (p: { names: string }) => string;
  };
  liked: {
    title: string;
    subtitle: (p: { count: number }) => string;
    empty: string;
  };
  settings: {
    title: string;
    languageTitle: string;
    languageDescription: string;
    codecTitle: string;
    codecDescription: string;
    opusLabel: string;
    opusDescription: string;
    opusBadge: string;
    aacLabel: string;
    aacDescription: string;
    aacBadge: string;
    codecSelected: string;
    codecChangeTitle: (p: { codec: string }) => string;
    codecChangeMessage: string;
    manualUploadDialogNote: string;
    codecCancel: string;
    futureOnly: string;
    migrateExisting: string;
    migrationStarting: string;
    migrationTitle: string;
    migrationProgress: (p: { completed: number; total: number }) => string;
    migrationCurrent: (p: { title: string }) => string;
    manualUploadNote: (p: { count: number }) => string;
    failedTracks: (p: { count: number }) => string;
    retryFailed: string;
    retrying: string;
    dismissFailed: string;
    dismissSummary: string;
    migrationCompleted: string;
    connectionsTitle: string;
    connectionsDescription: string;
    spotifyLabel: string;
    youtubeLabel: string;
    statusConnected: string;
    statusNotConnected: string;
    removeKeys: string;
    removeConfirmTitle: (p: { service: string }) => string;
    removeConfirmMessage: string;
    removeConfirm: string;
    removeCancel: string;
    serverTitle: string;
    serverDescription: string;
    serverRunning: string;
    serverStopped: string;
    serverAddress: string;
    serverUptime: string;
    serverVersion: (p: { version: string }) => string;
    serverStop: string;
    serverStopTitle: string;
    serverStopMessage: string;
    serverStopConfirm: string;
    serverCancel: string;
    serverStopping: string;
    serverUnreachable: string;
    serverJustNow: string;
    serverUptimeMinutes: (p: { count: number }) => string;
    serverUptimeHours: (p: { count: number }) => string;
    serverUptimeDays: (p: { count: number }) => string;
  };
  playlistView: {
    fallbackTitle: string;
    notFound: string;
    trackCount: (p: { count: number }) => string;
    empty: string;
    backToLibrary: string;
    playPlaylist: (p: { name: string }) => string;
    pausePlaylist: (p: { name: string }) => string;
    coverAlt: (p: { name: string }) => string;
    searchPlaceholder: string;
  };
  player: {
    regionLabel: string;
    dismissError: string;
    resolving: string;
    emptyHint: string;
    prevTrack: string;
    noPrevTrack: string;
    noTrack: string;
    play: string;
    pause: string;
    selectFirst: string;
    nextTrack: string;
    noNextTrack: string;
    repeatOff: string;
    repeatContext: string;
    repeatOne: string;
    shuffleOff: string;
    shuffleOn: string;
    smartShuffle: string;
    smartBadge: string;
    trackMenu: string;
    seekLabel: string;
    mute: string;
    unmute: string;
    volumeLabel: string;
  };
  trackList: {
    listLabel: string;
    coverAlt: (p: { album: string }) => string;
    badgeSpotify: string;
    badgeYoutube: string;
    playTrack: (p: { title: string }) => string;
    unlikeTrack: (p: { title: string }) => string;
    likeTrack: (p: { title: string }) => string;
    unlikeTitle: string;
    likeTitle: string;
    removeFromList: (p: { title: string }) => string;
    removeFromListTitle: string;
    removeFromLibrary: (p: { title: string }) => string;
    removeFromLibraryTitle: string;
    addToList: (p: { title: string }) => string;
    addToListTitle: string;
    createFirst: string;
    whichList: string;
    chooseList: string;
  };
  playlistPanel: {
    newPlaylist: string;
    menuTitle: string;
    coverLabel: string;
    coverChoose: string;
    coverTooLarge: string;
    nameLabel: string;
    namePlaceholder: string;
    cancel: string;
    create: string;
    listTitle: (p: { count: number }) => string;
    emptyLists: string;
    trackCount: (p: { count: number }) => string;
    confirmDelete: string;
    confirmYes: string;
    confirmCancel: string;
    deleteList: (p: { name: string }) => string;
    deleteListTitle: string;
    addSongs: string;
    addSongsSearch: string;
    addSongsAdd: (p: { count: number }) => string;
    addSongsEmpty: string;
    addedBulk: (p: { name: string; count: number }) => string;
    editList: string;
    editMenuTitle: string;
    save: string;
    removeCover: string;
    updated: (p: { name: string }) => string;
  };
  playerErrors: {
    corruptFile: string;
    noAudio: string;
    missingSource: string;
    blocked: string;
    startFailed: string;
  };
  playlists: {
    emptyName: string;
    duplicateName: string;
    created: (p: { name: string }) => string;
    notFound: string;
    alreadyInList: string;
    addedToList: (p: { name: string }) => string;
  };
  remix: {
    buttonLabel: string;
    title: string;
    presetNormal: string;
    presetSlowed: string;
    presetSpedUp: string;
    speedLabel: string;
    reverbLabel: string;
    bassLabel: string;
    reset: string;
    saveTrackDefault: string;
    trackDefaultSaved: string;
    trackDefaultFailed: string;
    speedValue: (p: { value: string }) => string;
    percentValue: (p: { value: number }) => string;
  };
  remixExport: {
    buttonLabel: string;
    hint: string;
    rendering: string;
    saving: string;
    saved: (p: { name: string }) => string;
    folderLabel: string;
    folderDefaultHint: string;
    folderChange: string;
    folderPlaceholder: string;
    folderSave: string;
    folderCancel: string;
    errorPrefix: string;
  };
  eq: {
    buttonLabel: string;
    title: string;
    description: string;
    reset: string;
    flat: string;
    presetFlat: string;
    presetBassBoost: string;
    presetVocal: string;
    presetPastelGhost: string;
    presetTreble: string;
    presetsLabel: string;
    activeBands: (p: { count: number }) => string;
    bandLabel: (p: { frequency: string }) => string;
    valueDb: (p: { value: string }) => string;
  };
  externalSearch: {
    mixedHint: string;
    loading: string;
    loadingMore: string;
    noMoreResults: string;
    youtubeQuota: (p: { hours: number }) => string;
    errorPrefix: string;
    previewNotice: string;
    playTrack: (p: { title: string }) => string;
    codecTitle: (p: { codec: string; ext: string; rate: string }) => string;
    badgeSpotify: string;
    badgeYoutube: string;
  };
  download: {
    action: string;
    downloading: string;
    matching: string;
    done: string;
    failedPrefix: string;
    opusUnavailableQuestion: string;
    opusFailedAacQuestion: string;
    useAac: string;
    added: (p: { title: string }) => string;
    allAction: string;
    allForPlaylist: (p: { name: string }) => string;
    bulkProgressLabel: string;
    bulkProgress: (p: { completed: number; total: number }) => string;
    bulkProgressFailed: (p: { failed: number }) => string;
    bulkCurrent: (p: { title: string }) => string;
    bulkDone: (p: { count: number }) => string;
    bulkDoneWithErrors: (p: { count: number; failed: number }) => string;
    bulkStopped: (p: { completed: number; total: number }) => string;
    bulkPausing: string;
    bulkResume: string;
    bulkResumeHint: string;
    bulkCancelled: (p: { completed: number }) => string;
    bulkStop: string;
    bulkStopHint: string;
    bulkCancel: string;
    bulkCancelHint: string;
    bulkCancelTitle: string;
    bulkCancelMessage: string;
    bulkCancelConfirm: string;
    bulkCancelKeep: string;
    nothingPending: string;
  };
  spotifyKeys: {
    title: string;
    intro: string;
    steps: string[];
    clientIdLabel: string;
    clientIdPlaceholder: string;
    clientSecretLabel: string;
    clientSecretPlaceholder: string;
    verifyAndSave: string;
    verifying: string;
    verifiedSaved: string;
    verifyTitle: string;
    verifyNotice: string;
    stepFormat: string;
    stepToken: string;
    stepSearch: string;
    statusPending: string;
    statusRunning: string;
    statusOk: string;
    statusFail: string;
    verifyRequestFailed: (p: { status: number }) => string;
    invalidId: string;
    invalidSecret: string;
    authFailed: string;
  };
  youtubeKey: {
    title: string;
    intro: string;
    steps: string[];
    apiKeyLabel: string;
    apiKeyPlaceholder: string;
    verifyAndSave: string;
    verifying: string;
    verifiedSaved: string;
    verifyTitle: string;
    verifyNotice: string;
    stepFormat: string;
    stepKey: string;
    statusPending: string;
    statusRunning: string;
    statusOk: string;
    statusFail: string;
    verifyRequestFailed: (p: { status: number }) => string;
    invalidKey: string;
    keyFailed: string;
  };
}

const TR: Messages = {
  locale: {
    label: "Dil",
    turkish: "Türkçe",
    english: "İngilizce",
    azerbaijani: "Azerbaycan Türkçesi",
  },
  nav: {
    home: "Ana Sayfa",
    search: "Ara",
    library: "Kitaplığım",
    liked: "Beğendiklerim",
    settings: "Ayarlar",
    mobileShort: {
      home: "Ana Sayfa",
      search: "Ara",
      library: "Kitaplığım",
      liked: "Beğeniler",
      settings: "Ayarlar",
    },
    mainNavLabel: "Ana gezinti",
    mobileNavLabel: "Mobil gezinti",
    listsHeading: "Listelerim",
    noLists: "Henüz liste yok. Kitaplıktan oluştur.",
  },
  home: {
    eyebrow: "Yerel kütüphane • kendi müzik dosyalarından oluşuyor",
    greeting: {
      morning: "Günaydın",
      afternoon: "İyi günler",
      evening: "İyi akşamlar",
      neutral: "Hoş geldin",
    },
    featured: "En çok dinlediklerin",
    allTracks: "Tüm parçalar",
    allEmpty: "Parça yok.",
    playTrack: (p) => `${p.title} parçasını çal`,
    coverAlt: (p) => `${p.album} kapağı`,
    openPlaylist: (p) => `${p.name} listesini aç`,
    playlistBadge: "Liste",
    playlistCoverAlt: (p) => `${p.name} liste kapağı`,
  },
  search: {
    title: "Ara",
    inputLabel: "Parça ya da sanatçı ara",
    placeholder: "Parça ya da sanatçı yaz…",
    clearSearch: "Aramayı temizle",
    clear: "Temizle",
    suggestionsLabel: "Arama önerileri",
    recentSearchesLabel: "Geçmiş aramalar",
    localSource: "Yerel",
    promptTitle: "Ne dinlemek istersin?",
    resultsCount: (p) => `${p.count} sonuç`,
    hint: "Sevdiğin parçayı ya da sanatçıyı yaz, listeden seçip dinle.",
    noResults: (p) => `“${p.query}” için sonuç yok. Başka bir parça ya da sanatçı dene.`,
  },
  library: {
    title: "Kitaplığım",
    description:
      "Kendi ses dosyalarını bu cihaza ekle. Dosyalar dışarı gönderilmez; sayfayı yenileyince listeden kalkar, tekrar seçmen gerekir. İndirilenler ise kalıcıdır ve yerlerinde kalır.",
    chooseFile: "Ses dosyası seç",
    multiHint: "Birden fazla dosya seçebilirsin.",
    deviceTitle: (p) => `Cihazımdaki dosyalar (${p.count})`,
    deviceEmpty: "Henüz dosya yok. Yukarıdan seç, liste burada görünsün.",
    noFiles: "Henüz dosya yok.",
    manageLabel: "Yerel dosya yönetimi",
    sessionRow: (p) => `${p.name} • yerel kayıt`,
    removeFile: (p) => `${p.title} dosyasını kaldır`,
    remove: "Kaldır",
  },
  files: {
    untitled: "Adsız kayıt",
    saveFailed: (p) => `Kaydedilemeyen dosyalar: ${p.names}. Tekrar dene.`,
    removeFailed: (p) => `${p.title} silinemedi. Beğeni ve listeler korundu.`,
    localArtist: "Yerel dosya",
    localAlbum: "Cihazımdan",
    added: (p) => `${p.count} ses dosyası eklendi. Liste “Kitaplığım” bölümünde.`,
    unsupported: (p) =>
      `Desteklenmeyen dosya: ${p.names}. Yalnızca ses dosyası seç.`,
  },
  liked: {
    title: "Beğendiklerim",
    subtitle: (p) => `${p.count} parça • beğeniler bu cihazda saklanır`,
    empty: "Henüz beğendiğin parça yok. Kalp simgesine dokunarak ekle.",
  },
  settings: {
    title: "Ayarlar",
    languageTitle: "Dil",
    languageDescription:
      "Uygulama dilini buradan seç. Seçimin bu cihazda saklanır.",
    codecTitle: "Ses formatı",
    codecDescription:
      "Dinleme ve bundan sonra indireceğin şarkılar seçtiğin codec ile gelir.",
    opusLabel: "Opus",
    opusDescription:
      "Aynı dosya boyutunda genellikle daha yüksek ses kalitesi sunar.",
    opusBadge: "Daha yüksek kalite",
    aacLabel: "AAC",
    aacDescription:
      "iPhone, iPad ve diğer Apple cihazları için en uyumlu seçimdir.",
    aacBadge: "Apple için en uygun",
    codecSelected: "Seçili",
    codecChangeTitle: (p) => `Ses formatı ${p.codec} olarak değişsin mi?`,
    codecChangeMessage:
      "Yeni seçim bundan sonraki dinleme ve indirmelerde hemen kullanılır. Mevcut indirilmiş şarkıları da yeniden indirebilirsin.",
    manualUploadDialogNote:
      "Elle yüklediğin şarkılar hiçbir durumda değiştirilmez.",
    codecCancel: "Vazgeç",
    futureOnly: "Yalnızca bundan sonra",
    migrateExisting: "Mevcut şarkıları da dönüştür",
    migrationStarting: "Başlatılıyor…",
    migrationTitle: "Şarkılar dönüştürülüyor",
    migrationProgress: (p) => `${p.completed} / ${p.total} şarkı tamamlandı`,
    migrationCurrent: (p) => `Şu an: ${p.title}`,
    manualUploadNote: (p) =>
      p.count > 0
        ? `${p.count} elle yüklenen şarkıya dokunulmayacak.`
        : "Elle yüklenen şarkılar bu işleme dahil edilmez.",
    failedTracks: (p) => `${p.count} şarkı dönüştürülemedi`,
    retryFailed: "Başarısızları tekrar dene",
    retrying: "Tekrar deneniyor…",
    dismissFailed: "Bunları geç",
    dismissSummary: "Özeti kapat",
    migrationCompleted: "Dönüştürme tamamlandı.",
    connectionsTitle: "Servis bağlantıları",
    connectionsDescription:
      "Kayıtlı API anahtarların. Anahtarlar yalnız bu tarayıcıda durur. Kaldırırsan arama çalışmaz ve anahtarı yeniden girmen gerekir; Spotify ya da Google hesabındaki anahtar silinmez.",
    spotifyLabel: "Spotify",
    youtubeLabel: "YouTube",
    statusConnected: "Bağlı",
    statusNotConnected: "Bağlı değil",
    removeKeys: "Kaldır",
    removeConfirmTitle: (p) => `${p.service} anahtarı kaldırılsın mı?`,
    removeConfirmMessage:
      "Anahtar bu tarayıcıdan silinecek ve arama çalışmayı bırakacak. Geri almak için anahtarı yeniden girmen gerekir.",
    removeConfirm: "Evet, kaldır",
    removeCancel: "Vazgeç",
    serverTitle: "Sunucu",
    serverDescription:
      "Müziklerin bu bilgisayardaki Turkify sunucusundan gelir. Pencere görmezsin; her şey arka planda çalışır.",
    serverRunning: "Çalışıyor",
    serverStopped: "Durdu",
    serverAddress: "Adres",
    serverUptime: "Çalışma süresi",
    serverVersion: (p) => `Sürüm ${p.version}`,
    serverStop: "Sunucuyu durdur",
    serverStopTitle: "Sunucu durdurulsun mu?",
    serverStopMessage:
      "Müzik çalma durur ve uygulama açılmaz. Tekrar açmak için Turkify kısayolunu çalıştırman gerekir.",
    serverStopConfirm: "Evet, durdur",
    serverCancel: "Vazgeç",
    serverStopping: "Durduruluyor…",
    serverUnreachable: "Sunucuya ulaşılamıyor",
    serverJustNow: "az önce başladı",
    serverUptimeMinutes: (p) => `${p.count} dk`,
    serverUptimeHours: (p) => `${p.count} sa`,
    serverUptimeDays: (p) => `${p.count} gün`,
  },
  playlistView: {
    fallbackTitle: "Liste",
    notFound: "Liste bulunamadı. Kitaplıktan bir liste seç.",
    trackCount: (p) => `${p.count} parça`,
    empty: "Bu liste boş. Parça satırlarındaki + düğmesiyle ekle.",
    backToLibrary: "Kitaplığa dön",
    playPlaylist: (p) => `${p.name} listesini çal`,
    pausePlaylist: (p) => `${p.name} listesini duraklat`,
    coverAlt: (p) => `${p.name} liste kapağı`,
    searchPlaceholder: "Listede şarkı ara…",
  },
  player: {
    regionLabel: "Çalar",
    dismissError: "Hata bildirimini kapat",
    resolving: "Kaynak hazırlanıyor…",
    emptyHint: "Çalmak için bir parça seç",
    prevTrack: "Önceki parça",
    noPrevTrack: "Önceki parça yok",
    noTrack: "Çalınacak parça yok",
    play: "Çal",
    pause: "Duraklat",
    selectFirst: "Önce bir parça seç",
    nextTrack: "Sonraki parça",
    noNextTrack: "Sonraki parça yok",
    repeatOff: "Döngü kapalı; liste döngüsünü aç",
    repeatContext: "Liste döngüsü açık; bu parçayı döngüye al",
    repeatOne: "Bu parça döngüde; döngüyü kapat",
    shuffleOff: "Karıştırma kapalı; listeyi karıştır",
    shuffleOn: "Liste karışık çalıyor; akıllı karıştırmayı aç",
    smartShuffle: "Akıllı karıştırma açık; kapat",
    smartBadge: "Öneri",
    trackMenu: "Parça seçenekleri",
    seekLabel: "Parça konumu",
    mute: "Sessize al",
    unmute: "Sesi aç",
    volumeLabel: "Ses düzeyi",
  },
  trackList: {
    listLabel: "Parça listesi",
    coverAlt: (p) => `${p.album} kapağı`,
    badgeSpotify: "Spotify",
    badgeYoutube: "YouTube",
    playTrack: (p) => `${p.title} parçasını çal`,
    unlikeTrack: (p) => `${p.title} beğenisini kaldır`,
    likeTrack: (p) => `${p.title} parçasını beğen`,
    unlikeTitle: "Beğeniyi kaldır",
    likeTitle: "Beğen",
    removeFromList: (p) => `${p.title} parçasını listeden çıkar`,
    removeFromListTitle: "Listeden çıkar",
    removeFromLibrary: (p) => `${p.title} parçasını kitaplıktan kaldır`,
    removeFromLibraryTitle: "Kitaplıktan kaldır",
    addToList: (p) => `${p.title} parçasını listeye ekle`,
    addToListTitle: "Listeye ekle",
    createFirst: "Önce Kitaplıktan bir liste oluştur.",
    whichList: "Hangi listeye eklensin?",
    chooseList: "Liste seç…",
  },
  playlistPanel: {
    newPlaylist: "Yeni liste oluştur",
    menuTitle: "Yeni liste oluştur",
    coverLabel: "Liste görseli",
    coverChoose: "Görsel seç",
    coverTooLarge:
      "Görsel 50 MB'dan büyük olduğu için liste kapaksız oluşturuldu.",
    nameLabel: "Liste adı",
    namePlaceholder: "Örn. Sabah koşusu",
    cancel: "İptal",
    create: "Oluştur",
    listTitle: (p) => `Listelerim (${p.count})`,
    emptyLists: "Henüz liste oluşturmadın. Yukarıdaki formu kullan.",
    trackCount: (p) => `${p.count} parça`,
    confirmDelete: "Silinsin mi?",
    confirmYes: "Evet",
    confirmCancel: "Vazgeç",
    deleteList: (p) => `${p.name} listesini sil`,
    deleteListTitle: "Listeyi sil",
    addSongs: "Şarkı ekle",
    addSongsSearch: "Şarkı ara…",
    addSongsAdd: (p) => `Ekle (${p.count})`,
    addSongsEmpty: "Bu aramayla eşleşen şarkı yok.",
    addedBulk: (p) => `"${p.name}" listesine ${p.count} parça eklendi.`,
    editList: "Listeyi düzenle",
    editMenuTitle: "Listeyi düzenle",
    save: "Kaydet",
    removeCover: "Görseli kaldır",
    updated: (p) => `"${p.name}" güncellendi.`,
  },
  playerErrors: {
    corruptFile:
      "Bu ses dosyası çalınamadı. Dosya bozuk ya da desteklenmeyen biçimde olabilir.",
    noAudio: "Bu kayıt için çalınabilir ses bulunamadı.",
    missingSource:
      "Bu dosya için ses kaynağı bulunamadı. Dosyayı yeniden seç.",
    blocked: "Tarayıcı çalmayı engelledi. Tekrar dene.",
    startFailed: "Çalma başlatılamadı. Tekrar dene.",
  },
  playlists: {
    emptyName: "Liste adı boş olamaz.",
    duplicateName: "Bu adda bir liste zaten var.",
    created: (p) => `"${p.name}" oluşturuldu.`,
    notFound: "Liste bulunamadı.",
    alreadyInList: "Bu parça zaten listede.",
    addedToList: (p) => `"${p.name}" listesine eklendi.`,
  },
  remix: {
    buttonLabel: "Remix ayarları",
    title: "Remix",
    presetNormal: "Normal",
    presetSlowed: "Slowed + Reverb",
    presetSpedUp: "Sped Up",
    speedLabel: "Hız",
    reverbLabel: "Reverb",
    bassLabel: "Bass boost",
    reset: "Sıfırla",
    saveTrackDefault: "Varsayılan yap",
    trackDefaultSaved: "Bu şarkı için kaydedildi.",
    trackDefaultFailed: "Ayar kaydedilemedi. Tekrar dene.",
    speedValue: (p) => `${p.value}x`,
    percentValue: (p) => `%${p.value}`,
  },
  remixExport: {
    buttonLabel: "Remix'i indir",
    hint: "Şu anki ayarlarla WAV olarak kaydedilir.",
    rendering: "Hazırlanıyor...",
    saving: "Kaydediliyor...",
    saved: (p) => `Kaydedildi: ${p.name}`,
    folderLabel: "İnecek klasör",
    folderDefaultHint: "varsayılan",
    folderChange: "Değiştir",
    folderPlaceholder: "/Users/you/Downloads",
    folderSave: "Kaydet",
    folderCancel: "Vazgeç",
    errorPrefix: "Hata:",
  },
  eq: {
    buttonLabel: "Ekolayzer ayarları",
    title: "Ekolayzer",
    description:
      "Aşağı çektiğin bandı zayıflatır, yukarı çektiğin bandı güçlendirir. Ayar cihazda saklanır ve tüm şarkılara uygulanır.",
    reset: "Düzle",
    flat: "Düz",
    presetFlat: "Düz",
    presetBassBoost: "Bass Boost",
    presetVocal: "Vokal",
    presetPastelGhost: "Pastel Ghost",
    presetTreble: "Tiz",
    presetsLabel: "Hazır profiller",
    activeBands: (p) => `${p.count} bant`,
    bandLabel: (p) => `${p.frequency} Hz bandı`,
    valueDb: (p) => `${p.value} dB`,
  },
  externalSearch: {
    mixedHint: "Spotify ve YouTube birlikte aranır; kartın sağındaki rozet kaynağı gösterir.",
    loading: "Aranıyor...",
    loadingMore: "Daha fazla yükleniyor...",
    noMoreResults: "Başka sonuç yok.",
    youtubeQuota: (p) => `YouTube günlük arama kotası doldu. ${p.hours} saat sonra tekrar deneyin.`,
    errorPrefix: "Arama hatası:",
    previewNotice: "Satıra tıklayınca parça hemen çalar; indirmeyi beklemen gerekmez. İndir düğmesi parçayı kütüphanene kaydeder.",
    playTrack: (p) => `${p.title} parçasını çal`,
    codecTitle: (p) => `Ses kodeği: ${p.codec} • kap: ${p.ext} • örnekleme: ${p.rate}`,
    badgeSpotify: "Spotify",
    badgeYoutube: "YouTube",
  },
  download: {
    action: "İndir",
    downloading: "İndiriliyor...",
    matching: "Eşleşiyor…",
    done: "İndirildi",
    failedPrefix: "İndirme hatası:",
    opusUnavailableQuestion: "Opus yok. Bu parça AAC olarak indirilsin mi?",
    opusFailedAacQuestion: "Opus ile indirilemedi. AAC ile tekrar denensin mi?",
    useAac: "AAC kullan",
    added: (p) => `"${p.title}" indirildi ve Kitaplığına eklendi.`,
    allAction: "Tümünü indir",
    allForPlaylist: (p) => `Tüm listeyi indir: ${p.name}`,
    bulkProgressLabel: "Liste indiriliyor",
    bulkProgress: (p) => `${p.completed} / ${p.total}`,
    bulkProgressFailed: (p) => `${p.failed} hata`,
    bulkCurrent: (p) => `Şimdi indiriliyor: ${p.title}`,
    bulkDone: (p) => `${p.count} parça indirildi.`,
    bulkDoneWithErrors: (p) => `${p.count} parça indirildi, ${p.failed} parça başarısız oldu.`,
    bulkStopped: (p) => `İndirme duraklatıldı: ${p.completed} / ${p.total} parça indi.`,
    bulkPausing: "İndirme duraklatılıyor…",
    bulkResume: "Devam et",
    bulkResumeHint: "Kalan parçaları indirmeye devam et",
    bulkCancelled: (p) => `İptal edildi: ${p.completed} parça indi, yarım kalan silindi.`,
    bulkStop: "Durdur",
    bulkStopHint: "O an inen biter, sıradakiler başlamaz",
    bulkCancel: "İndirmeyi iptal et",
    bulkCancelHint: "O an inen dahil kuyruğu iptal et",
    bulkCancelTitle: "İndirme iptal edilsin mi?",
    bulkCancelMessage: "Tamamlanan parçalar kalır. O an inen parça durur, yarım dosyası silinir, kuyruk iptal olur.",
    bulkCancelConfirm: "Evet, iptal et",
    bulkCancelKeep: "Vazgeç",
    nothingPending: "Listedeki tüm Spotify parçaları zaten indirilmiş.",
  },
  spotifyKeys: {
    title: "Spotify bağlantısı",
    intro: "Spotify ve YouTube araması için Spotify anahtarları gerekli. Anahtarlar yalnız bu tarayıcıda saklanır, başka bir yere kaydedilmez.",
    steps: [
      "developer.spotify.com/dashboard adresine git ve Spotify hesabınla giriş yap.",
      "Create app düğmesine bas.",
      "Uygulama adı yaz (örnek: Turkify), kısa bir açıklama ekle.",
      "Redirect URI kutusuna http://127.0.0.1:3400/callback yaz ve Add düğmesine bas. Bu adres bu akışta hiç kullanılmıyor, Spotify sadece dolu olmasını istiyor; ama http ile yalnız 127.0.0.1 kabul edilir, localhost reddedilir.",
      "Kullanım koşullarını onayla ve Save ile uygulamayı oluştur.",
      "Dashboard'a dönünce listeden uygulamanın adına tıkla. Settings düğmesi ana sayfada değil, uygulamanın kendi sayfasının sağ üstündedir.",
      "Settings sayfasında Client ID düz yazı olarak görünür, kopyala. Hemen altındaki View client secret bağlantısına basınca Client Secret açılır, onu da kopyala.",
      "İkisini aşağıdaki kutulara yapıştır ve Doğrula ve kaydet düğmesine bas.",
    ],
    clientIdLabel: "Client ID",
    clientIdPlaceholder: "Spotify Client ID",
    clientSecretLabel: "Client Secret",
    clientSecretPlaceholder: "Spotify Client Secret",
    verifyAndSave: "Doğrula ve kaydet",
    verifying: "Doğrulanıyor…",
    verifiedSaved: "Anahtarlar Spotify tarafından doğrulandı ve bu tarayıcıya kaydedildi.",
    verifyTitle: "Doğrulama",
    verifyNotice: "Anahtarlar önce Spotify'a sorulur; üç adım da geçmeden kaydedilmez.",
    stepFormat: "Biçim kontrolü",
    stepToken: "Spotify anahtarları tanıyor mu",
    stepSearch: "Arama izni çalışıyor mu",
    statusPending: "bekliyor",
    statusRunning: "sürüyor",
    statusOk: "başarılı",
    statusFail: "başarısız",
    verifyRequestFailed: (p) => `Doğrulama isteği başarısız oldu (${p.status}).`,
    invalidId: "Client ID hatalı görünüyor. 32 karakter olmalı, Settings sayfasından kopyala.",
    invalidSecret: "Client Secret hatalı görünüyor. View client secret ile bakıp yeniden yapıştır.",
    authFailed: "Bu anahtarlar Spotify tarafından kabul edilmedi. Kopyalarken boşluk kalmadığını kontrol edip yeniden dene.",
  },
  youtubeKey: {
    title: "YouTube bağlantısı",
    intro: "YouTube araması için YouTube API anahtarı gerekli. Anahtar yalnız bu tarayıcıda saklanır, başka bir yere kaydedilmez.",
    steps: [
      "console.cloud.google.com adresine git ve yeni bir proje oluştur.",
      "APIs & Services > Library yolunu aç.",
      "“YouTube Data API v3” araması yap ve Enable ile etkinleştir.",
      "APIs & Services > Credentials bölümünden Create credentials > API key seç.",
      "Açılan pencerede bir isim yaz (örnek: Turkify). “Authenticate API calls through a service account” kutusunu İŞARETLEME; o seçenek Vertex/Gemini içindir, YouTube'da anahtarı bozar.",
      "API restrictions bölümünde YouTube Data API v3 seçili kalsın. Application restrictions bölümünde None seç: çağrıyı tarayıcı değil kendi sunucun yapıyor, Websites seçersen referrer olmadığı için 403 alırsın.",
      "Create düğmesine bas, çıkan anahtarı kopyala, aşağıdaki kutuya yapıştır ve Doğrula ve kaydet.",
    ],
    apiKeyLabel: "API anahtarı",
    apiKeyPlaceholder: "YouTube API anahtarı",
    verifyAndSave: "Doğrula ve kaydet",
    verifying: "Doğrulanıyor…",
    verifiedSaved: "Anahtar YouTube tarafından doğrulandı ve bu tarayıcıya kaydedildi.",
    verifyTitle: "Doğrulama",
    verifyNotice: "Doğrulama 1 kota birimlik videos.list çağrısıyla yapılır; gerçek arama denemesi 100 birim yakacağı için bilerek atlanır.",
    stepFormat: "Biçim kontrolü",
    stepKey: "Google anahtarı kabul ediyor mu",
    statusPending: "bekliyor",
    statusRunning: "sürüyor",
    statusOk: "başarılı",
    statusFail: "başarısız",
    verifyRequestFailed: (p) => `Doğrulama isteği başarısız oldu (${p.status}).`,
    invalidKey: "API anahtarı hatalı görünüyor. “AIza” ile başlayan 39 karakter olmalı, Credentials sayfasından kopyala.",
    keyFailed: "Bu anahtar YouTube tarafından kabul edilmedi. Kopyalarken boşluk kalmadığını kontrol edip yeniden dene.",
  },
};

const EN: Messages = {
  locale: {
    label: "Language",
    turkish: "Turkish",
    english: "English",
    azerbaijani: "Azerbaijani",
  },
  nav: {
    home: "Home",
    search: "Search",
    library: "Your Library",
    liked: "Liked",
    settings: "Settings",
    mobileShort: {
      home: "Home",
      search: "Search",
      library: "Library",
      liked: "Liked",
      settings: "Settings",
    },
    mainNavLabel: "Main navigation",
    mobileNavLabel: "Mobile navigation",
    listsHeading: "Playlists",
    noLists: "No playlists yet. Create one from your library.",
  },
  home: {
    eyebrow: "Local library • built from your own music files",
    greeting: {
      morning: "Good morning",
      afternoon: "Good afternoon",
      evening: "Good evening",
      neutral: "Welcome",
    },
    featured: "Most played",
    allTracks: "All songs",
    allEmpty: "No songs.",
    playTrack: (p) => `Play ${p.title}`,
    coverAlt: (p) => `${p.album} cover`,
    openPlaylist: (p) => `Open ${p.name} playlist`,
    playlistBadge: "Playlist",
    playlistCoverAlt: (p) => `${p.name} playlist cover`,
  },
  search: {
    title: "Search",
    inputLabel: "Search songs or artists",
    placeholder: "Search songs or artists…",
    clearSearch: "Clear search",
    clear: "Clear",
    suggestionsLabel: "Suggestions",
    recentSearchesLabel: "Recent searches",
    localSource: "Local",
    promptTitle: "What do you want to listen to?",
    resultsCount: (p) => (p.count === 1 ? "1 result" : `${p.count} results`),
    hint: "Type a song or artist you love, then pick from the list to play.",
    noResults: (p) => `No results for “${p.query}”. Try another song or artist.`,
  },
  library: {
    title: "Your Library",
    description:
      "Add your own audio files on this device. Files are never uploaded, they are stored securely in your browser and stay saved across sessions.",
    chooseFile: "Choose audio files",
    multiHint: "You can select multiple files.",
    deviceTitle: (p) => `Files on this device (${p.count})`,
    deviceEmpty: "No files yet. Pick some above and they will show up here.",
    noFiles: "No files yet.",
    manageLabel: "Local file management",
    sessionRow: (p) => `${p.name} • local recording`,
    removeFile: (p) => `Remove ${p.title} file`,
    remove: "Remove",
  },
  files: {
    untitled: "Untitled recording",
    saveFailed: (p) => `Files could not be saved: ${p.names}. Try again.`,
    removeFailed: (p) => `${p.title} could not be deleted. Likes and playlists were preserved.`,
    localArtist: "Local file",
    localAlbum: "From this device",
    added: (p) =>
      p.count === 1
        ? "1 audio file added. Find it under “Your Library”."
        : `${p.count} audio files added. Find them under “Your Library”.`,
    unsupported: (p) =>
      `Unsupported file: ${p.names}. Please choose audio files only.`,
  },
  liked: {
    title: "Liked",
    subtitle: (p) =>
      p.count === 1
        ? "1 song • likes are stored on this device"
        : `${p.count} songs • likes are stored on this device`,
    empty: "No liked songs yet. Tap the heart icon to add some.",
  },
  settings: {
    title: "Settings",
    languageTitle: "Language",
    languageDescription:
      "Choose the app language here. Your choice is stored on this device.",
    codecTitle: "Audio format",
    codecDescription:
      "Playback and future downloads use the codec you select here.",
    opusLabel: "Opus",
    opusDescription:
      "Usually provides higher audio quality at the same file size.",
    opusBadge: "Higher quality",
    aacLabel: "AAC",
    aacDescription:
      "The most compatible choice for iPhone, iPad, and other Apple devices.",
    aacBadge: "Best for Apple",
    codecSelected: "Selected",
    codecChangeTitle: (p) => `Switch the audio format to ${p.codec}?`,
    codecChangeMessage:
      "The new choice is used immediately for playback and future downloads. You can also download existing songs again in the new format.",
    manualUploadDialogNote:
      "Songs you uploaded manually are never changed.",
    codecCancel: "Cancel",
    futureOnly: "Future downloads only",
    migrateExisting: "Convert existing songs too",
    migrationStarting: "Starting…",
    migrationTitle: "Converting songs",
    migrationProgress: (p) => `${p.completed} of ${p.total} songs completed`,
    migrationCurrent: (p) => `Now: ${p.title}`,
    manualUploadNote: (p) =>
      p.count > 0
        ? `${p.count} manually uploaded songs will remain unchanged.`
        : "Manually uploaded songs are excluded from this process.",
    failedTracks: (p) =>
      p.count === 1 ? "1 song could not be converted" : `${p.count} songs could not be converted`,
    retryFailed: "Retry failed songs",
    retrying: "Retrying…",
    dismissFailed: "Skip these",
    dismissSummary: "Dismiss summary",
    migrationCompleted: "Conversion completed.",
    connectionsTitle: "Service connections",
    connectionsDescription:
      "Your saved API keys. They live only in this browser. Removing one stops search from working and you will have to enter the key again; nothing is deleted from your Spotify or Google account.",
    spotifyLabel: "Spotify",
    youtubeLabel: "YouTube",
    statusConnected: "Connected",
    statusNotConnected: "Not connected",
    removeKeys: "Remove",
    removeConfirmTitle: (p) => `Remove the ${p.service} key?`,
    removeConfirmMessage:
      "The key will be deleted from this browser and search will stop working. To undo this you will have to enter the key again.",
    removeConfirm: "Yes, remove",
    removeCancel: "Cancel",
    serverTitle: "Server",
    serverDescription:
      "Your music comes from the Turkify server on this computer. You never see a window; everything runs in the background.",
    serverRunning: "Running",
    serverStopped: "Stopped",
    serverAddress: "Address",
    serverUptime: "Uptime",
    serverVersion: (p) => `Version ${p.version}`,
    serverStop: "Stop the server",
    serverStopTitle: "Stop the server?",
    serverStopMessage:
      "Playback stops and the app will not open. To start again, run the Turkify shortcut.",
    serverStopConfirm: "Yes, stop",
    serverCancel: "Cancel",
    serverStopping: "Stopping…",
    serverUnreachable: "Cannot reach the server",
    serverJustNow: "just started",
    serverUptimeMinutes: (p) => `${p.count} min`,
    serverUptimeHours: (p) => `${p.count} h`,
    serverUptimeDays: (p) => `${p.count} d`,
  },
  playlistView: {
    fallbackTitle: "Playlist",
    notFound: "Playlist not found. Pick a playlist from your library.",
    trackCount: (p) => (p.count === 1 ? "1 song" : `${p.count} songs`),
    empty: "This playlist is empty. Add songs with the + button on a track row.",
    backToLibrary: "Back to library",
    playPlaylist: (p) => `Play ${p.name} playlist`,
    pausePlaylist: (p) => `Pause ${p.name} playlist`,
    coverAlt: (p) => `${p.name} playlist cover`,
    searchPlaceholder: "Search this playlist…",
  },
  player: {
    regionLabel: "Player",
    dismissError: "Dismiss error notification",
    resolving: "Preparing source…",
    emptyHint: "Pick a song to play",
    prevTrack: "Previous track",
    noPrevTrack: "No previous track",
    noTrack: "No track to play",
    play: "Play",
    pause: "Pause",
    selectFirst: "Pick a song first",
    nextTrack: "Next track",
    noNextTrack: "No next track",
    repeatOff: "Repeat is off; turn on playlist repeat",
    repeatContext: "Playlist repeat is on; repeat this track",
    repeatOne: "This track is repeating; turn repeat off",
    shuffleOff: "Shuffle is off; shuffle the playlist",
    shuffleOn: "Shuffling the playlist; turn on Smart Shuffle",
    smartShuffle: "Smart Shuffle is on; turn it off",
    smartBadge: "Suggested",
    trackMenu: "Song options",
    seekLabel: "Track position",
    mute: "Mute",
    unmute: "Unmute",
    volumeLabel: "Volume",
  },
  trackList: {
    listLabel: "Track list",
    coverAlt: (p) => `${p.album} cover`,
    badgeSpotify: "Spotify",
    badgeYoutube: "YouTube",
    playTrack: (p) => `Play ${p.title}`,
    unlikeTrack: (p) => `Remove ${p.title} from likes`,
    likeTrack: (p) => `Like ${p.title}`,
    unlikeTitle: "Unlike",
    likeTitle: "Like",
    removeFromList: (p) => `Remove ${p.title} from playlist`,
    removeFromListTitle: "Remove from playlist",
    removeFromLibrary: (p) => `Remove ${p.title} from library`,
    removeFromLibraryTitle: "Remove from library",
    addToList: (p) => `Add ${p.title} to a playlist`,
    addToListTitle: "Add to playlist",
    createFirst: "Create a playlist from Your Library first.",
    whichList: "Which playlist should it go to?",
    chooseList: "Choose a playlist…",
  },
  playlistPanel: {
    newPlaylist: "Create a new playlist",
    menuTitle: "Create a new playlist",
    coverLabel: "Playlist cover",
    coverChoose: "Choose image",
    coverTooLarge:
      "Image is larger than 50 MB, so the playlist was created without a cover.",
    nameLabel: "Playlist name",
    namePlaceholder: "E.g. Morning run",
    cancel: "Cancel",
    create: "Create",
    listTitle: (p) => `Playlists (${p.count})`,
    emptyLists: "You have not created any playlists yet. Use the form above.",
    trackCount: (p) => (p.count === 1 ? "1 song" : `${p.count} songs`),
    confirmDelete: "Delete it?",
    confirmYes: "Yes",
    confirmCancel: "Cancel",
    deleteList: (p) => `Delete ${p.name} playlist`,
    deleteListTitle: "Delete playlist",
    addSongs: "Add songs",
    addSongsSearch: "Search songs…",
    addSongsAdd: (p) => `Add (${p.count})`,
    addSongsEmpty: "No songs match this search.",
    addedBulk: (p) => `${p.count} songs added to "${p.name}".`,
    editList: "Edit playlist",
    editMenuTitle: "Edit playlist",
    save: "Save",
    removeCover: "Remove image",
    updated: (p) => `"${p.name}" updated.`,
  },
  playerErrors: {
    corruptFile:
      "This audio file could not be played. It may be damaged or in an unsupported format.",
    noAudio: "No playable audio found for this recording.",
    missingSource:
      "Audio source missing for this file. Please pick the file again.",
    blocked: "The browser blocked playback. Try again.",
    startFailed: "Playback could not start. Try again.",
  },
  playlists: {
    emptyName: "Playlist name cannot be empty.",
    duplicateName: "A playlist with this name already exists.",
    created: (p) => `"${p.name}" created.`,
    notFound: "Playlist not found.",
    alreadyInList: "This song is already in the playlist.",
    addedToList: (p) => `Added to "${p.name}".`,
  },
  remix: {
    buttonLabel: "Remix settings",
    title: "Remix",
    presetNormal: "Normal",
    presetSlowed: "Slowed + Reverb",
    presetSpedUp: "Sped Up",
    speedLabel: "Speed",
    reverbLabel: "Reverb",
    bassLabel: "Bass boost",
    reset: "Reset",
    saveTrackDefault: "Set as default",
    trackDefaultSaved: "Saved for this song.",
    trackDefaultFailed: "Could not save. Try again.",
    speedValue: (p) => `${p.value}x`,
    percentValue: (p) => `${p.value}%`,
  },
  remixExport: {
    buttonLabel: "Download remix",
    hint: "Saved as WAV with the current settings.",
    rendering: "Preparing...",
    saving: "Saving...",
    saved: (p) => `Saved: ${p.name}`,
    folderLabel: "Download folder",
    folderDefaultHint: "default",
    folderChange: "Change",
    folderPlaceholder: "/Users/you/Downloads",
    folderSave: "Save",
    folderCancel: "Cancel",
    errorPrefix: "Error:",
  },
  eq: {
    buttonLabel: "Equalizer settings",
    title: "Equalizer",
    description:
      "Pulling a band down cuts it, pushing it up boosts it. The setting is stored on this device and applies to every song.",
    reset: "Flatten",
    flat: "Flat",
    presetFlat: "Flat",
    presetBassBoost: "Bass Boost",
    presetVocal: "Vocal",
    presetPastelGhost: "Pastel Ghost",
    presetTreble: "Treble",
    presetsLabel: "Presets",
    activeBands: (p) => (p.count === 1 ? "1 band" : `${p.count} bands`),
    bandLabel: (p) => `${p.frequency} Hz band`,
    valueDb: (p) => `${p.value} dB`,
  },
  externalSearch: {
    mixedHint: "Spotify and YouTube are searched together; the badge on the right shows the source.",
    loading: "Searching...",
    loadingMore: "Loading more...",
    noMoreResults: "No more results.",
    youtubeQuota: (p) => `YouTube daily search quota exceeded. Try again in ${p.hours} hours.`,
    errorPrefix: "Search error:",
    previewNotice: "Click a row to play it right away, no need to wait for a download. The Download button saves it to your library.",
    playTrack: (p) => `Play ${p.title}`,
    codecTitle: (p) => `Audio codec: ${p.codec} • container: ${p.ext} • sample rate: ${p.rate}`,
    badgeSpotify: "Spotify",
    badgeYoutube: "YouTube",
  },
  download: {
    action: "Download",
    downloading: "Downloading...",
    matching: "Matching…",
    done: "Downloaded",
    failedPrefix: "Download error:",
    opusUnavailableQuestion: "Opus is unavailable. Download this track as AAC?",
    opusFailedAacQuestion: "The Opus download failed. Retry this track as AAC?",
    useAac: "Use AAC",
    added: (p) => `"${p.title}" downloaded and added to your library.`,
    allAction: "Download all",
    allForPlaylist: (p) => `Download entire playlist: ${p.name}`,
    bulkProgressLabel: "Playlist download in progress",
    bulkProgress: (p) => `${p.completed} / ${p.total}`,
    bulkProgressFailed: (p) => `${p.failed} failed`,
    bulkCurrent: (p) => `Downloading now: ${p.title}`,
    bulkDone: (p) => `${p.count} tracks downloaded.`,
    bulkDoneWithErrors: (p) => `${p.count} tracks downloaded, ${p.failed} failed.`,
    bulkStopped: (p) => `Download paused: ${p.completed} / ${p.total} tracks downloaded.`,
    bulkPausing: "Pausing download…",
    bulkResume: "Resume",
    bulkResumeHint: "Continue downloading the remaining tracks",
    bulkCancelled: (p) => `Cancelled: ${p.completed} tracks downloaded, the partial file was deleted.`,
    bulkStop: "Stop",
    bulkStopHint: "The current track finishes, the rest of the queue stops",
    bulkCancel: "Cancel the download",
    bulkCancelHint: "Cancel the queue including the current track",
    bulkCancelTitle: "Cancel the download?",
    bulkCancelMessage: "Finished tracks stay. The current track stops, its partial file is deleted, the queue is cancelled.",
    bulkCancelConfirm: "Yes, cancel it",
    bulkCancelKeep: "Keep going",
    nothingPending: "All Spotify tracks in this playlist are already downloaded.",
  },
  spotifyKeys: {
    title: "Spotify connection",
    intro: "Spotify keys are needed for Spotify and YouTube search. Keys are stored only in this browser and never saved anywhere else.",
    steps: [
      "Go to developer.spotify.com/dashboard and sign in with your Spotify account.",
      "Press the Create app button.",
      "Type an app name (for example: Turkify) and add a short description.",
      "Type http://127.0.0.1:3400/callback into the Redirect URI box and press Add. This address is never used in this flow, Spotify only requires it to be filled in; note that over http only 127.0.0.1 is accepted, localhost is rejected.",
      "Accept the terms and create the app with Save.",
      "Back on the dashboard, click your app's name in the list. The Settings button is not on the dashboard itself, it is at the top right of the app's own page.",
      "On the Settings page the Client ID is shown as plain text, copy it. Press the View client secret link right below it to reveal the Client Secret, and copy that too.",
      "Paste both into the boxes below and press Verify and save.",
    ],
    clientIdLabel: "Client ID",
    clientIdPlaceholder: "Spotify Client ID",
    clientSecretLabel: "Client Secret",
    clientSecretPlaceholder: "Spotify Client Secret",
    verifyAndSave: "Verify and save",
    verifying: "Verifying…",
    verifiedSaved: "Keys verified by Spotify and saved in this browser.",
    verifyTitle: "Verification",
    verifyNotice: "The keys are checked against Spotify first; nothing is saved until all three steps pass.",
    stepFormat: "Format check",
    stepToken: "Does Spotify recognise the keys",
    stepSearch: "Does search access work",
    statusPending: "pending",
    statusRunning: "running",
    statusOk: "passed",
    statusFail: "failed",
    verifyRequestFailed: (p) => `Verification request failed (${p.status}).`,
    invalidId: "The Client ID looks wrong. It must be 32 characters; copy it from the Settings page.",
    invalidSecret: "The Client Secret looks wrong. Reveal it with View client secret and paste again.",
    authFailed: "Spotify rejected these keys. Check for extra spaces and try again.",
  },
  youtubeKey: {
    title: "YouTube connection",
    intro: "A YouTube API key is needed for YouTube search. The key is stored only in this browser and never saved anywhere else.",
    steps: [
      "Go to console.cloud.google.com and create a new project.",
      "Open the APIs & Services > Library page.",
      "Search for “YouTube Data API v3” and enable it with Enable.",
      "Choose Create credentials > API key from APIs & Services > Credentials.",
      "In the dialog, give it a name (for example: Turkify). Do NOT tick “Authenticate API calls through a service account”; that option is for Vertex/Gemini and breaks the key for YouTube.",
      "Under API restrictions keep YouTube Data API v3 selected. Under Application restrictions pick None: the call is made by your own server, not the browser, so Websites would fail with 403 for a missing referrer.",
      "Press Create, copy the generated key, paste it into the box below and press Verify and save.",
    ],
    apiKeyLabel: "API key",
    apiKeyPlaceholder: "YouTube API key",
    verifyAndSave: "Verify and save",
    verifying: "Verifying…",
    verifiedSaved: "Key verified by YouTube and saved in this browser.",
    verifyTitle: "Verification",
    verifyNotice: "Verification uses a 1-quota-unit videos.list call; a real search trial is deliberately skipped because it would cost 100 units.",
    stepFormat: "Format check",
    stepKey: "Does Google accept the key",
    statusPending: "pending",
    statusRunning: "running",
    statusOk: "passed",
    statusFail: "failed",
    verifyRequestFailed: (p) => `Verification request failed (${p.status}).`,
    invalidKey: "The API key looks wrong. It must be 39 characters starting with “AIza”; copy it from the Credentials page.",
    keyFailed: "YouTube rejected this key. Check for extra spaces and try again.",
  },
};

const AZ: Messages = {
  locale: {
    label: "Dil",
    turkish: "Türkcə",
    english: "İngiliscə",
    azerbaijani: "Azərbaycanca",
  },
  nav: {
    home: "Ana səhifə",
    search: "Axtar",
    library: "Kitabxanam",
    liked: "Bəyəndiklərim",
    settings: "Parametrlər",
    mobileShort: {
      home: "Ana səhifə",
      search: "Axtar",
      library: "Kitabxanam",
      liked: "Bəyənilənlər",
      settings: "Parametrlər",
    },
    mainNavLabel: "Əsas naviqasiya",
    mobileNavLabel: "Mobil naviqasiya",
    listsHeading: "Pleylistlərim",
    noLists: "Hələ pleylist yoxdur. Kitabxanada yaradın.",
  },
  home: {
    eyebrow: "Yerli kitabxana • öz musiqi fayllarınızdan ibarətdir",
    greeting: {
      morning: "Sabahınız xeyir",
      afternoon: "Günortanız xeyir",
      evening: "Axşamınız xeyir",
      neutral: "Xoş gəlmisiniz",
    },
    featured: "Ən çox dinlədikləriniz",
    allTracks: "Bütün mahnılar",
    allEmpty: "Mahnı yoxdur.",
    playTrack: (p) => `${p.title} mahnısını oxut`,
    coverAlt: (p) => `${p.album} albomunun üz qabığı`,
    openPlaylist: (p) => `${p.name} pleylistini aç`,
    playlistBadge: "Pleylist",
    playlistCoverAlt: (p) => `${p.name} pleylistinin üz qabığı`,
  },
  search: {
    title: "Axtar",
    inputLabel: "Mahnı və ya ifaçı axtarın",
    placeholder: "Mahnı və ya ifaçı yazın…",
    clearSearch: "Axtarışı təmizlə",
    clear: "Təmizlə",
    suggestionsLabel: "Axtarış təklifləri",
    recentSearchesLabel: "Son axtarışlar",
    localSource: "Yerli",
    promptTitle: "Nə dinləmək istəyirsiniz?",
    resultsCount: (p) => `${p.count} nəticə`,
    hint: "Sevdiyiniz mahnını və ya ifaçını yazın, siyahıdan seçib dinləyin.",
    noResults: (p) => `“${p.query}” üçün nəticə yoxdur. Başqa mahnı və ya ifaçı sınayın.`,
  },
  library: {
    title: "Kitabxanam",
    description:
      "Öz audio fayllarınızı bu cihaza əlavə edin. Fayllar heç yerə göndərilmir; səhifəni yenilədikdə siyahıdan silinir və onları yenidən seçmək lazım gəlir. Endirilənlər isə daimi saxlanılır.",
    chooseFile: "Audio fayl seçin",
    multiHint: "Birdən çox fayl seçə bilərsiniz.",
    deviceTitle: (p) => `Cihazımdakı fayllar (${p.count})`,
    deviceEmpty: "Hələ fayl yoxdur. Yuxarıdan seçin, siyahı burada görünsün.",
    noFiles: "Hələ fayl yoxdur.",
    manageLabel: "Yerli faylların idarəsi",
    sessionRow: (p) => `${p.name} • yerli qeyd`,
    removeFile: (p) => `${p.title} faylını sil`,
    remove: "Sil",
  },
  files: {
    untitled: "Adsız qeyd",
    localArtist: "Yerli fayl",
    localAlbum: "Cihazımdan",
    added: (p) => `${p.count} audio fayl əlavə olundu. Siyahı “Kitabxanam” bölməsindədir.`,
    saveFailed: (p) => `Saxlanılmayan fayllar: ${p.names}. Yenidən sınayın.`,
    removeFailed: (p) => `${p.title} silinmədi. Bəyənmələr və pleylistlər qorundu.`,
    unsupported: (p) => `Dəstəklənməyən fayl: ${p.names}. Yalnız audio fayl seçin.`,
  },
  liked: {
    title: "Bəyəndiklərim",
    subtitle: (p) => `${p.count} mahnı • bəyənmələr bu cihazda saxlanılır`,
    empty: "Hələ bəyəndiyiniz mahnı yoxdur. Ürək işarəsinə toxunaraq əlavə edin.",
  },
  settings: {
    title: "Parametrlər",
    languageTitle: "Dil",
    languageDescription: "Tətbiqin dilini buradan seçin. Seçiminiz bu cihazda saxlanılır.",
    codecTitle: "Audio format",
    codecDescription: "Dinləmə zamanı və bundan sonra endirəcəyiniz mahnılar üçün seçdiyiniz kodekdən istifadə olunur.",
    opusLabel: "Opus",
    opusDescription: "Eyni fayl ölçüsündə adətən daha yüksək səs keyfiyyəti verir.",
    opusBadge: "Daha yüksək keyfiyyət",
    aacLabel: "AAC",
    aacDescription: "iPhone, iPad və digər Apple cihazları üçün ən uyğun seçimdir.",
    aacBadge: "Apple üçün ən uyğun",
    codecSelected: "Seçilib",
    codecChangeTitle: (p) => `Audio format ${p.codec} olaraq dəyişdirilsin?`,
    codecChangeMessage:
      "Yeni seçim dinləmə və gələcək endirmələr üçün dərhal tətbiq olunur. Mövcud mahnıları da yeni formatda yenidən endirə bilərsiniz.",
    manualUploadDialogNote: "Əl ilə yüklədiyiniz mahnılar heç vaxt dəyişdirilmir.",
    codecCancel: "Ləğv et",
    futureOnly: "Yalnız bundan sonrakılar",
    migrateExisting: "Mövcud mahnıları da çevir",
    migrationStarting: "Başladılır…",
    migrationTitle: "Mahnılar çevrilir",
    migrationProgress: (p) => `${p.completed} / ${p.total} mahnı tamamlandı`,
    migrationCurrent: (p) => `Hazırda: ${p.title}`,
    manualUploadNote: (p) =>
      p.count > 0
        ? `Əl ilə yüklənmiş ${p.count} mahnı dəyişdirilməyəcək.`
        : "Əl ilə yüklənmiş mahnılar bu prosesə daxil edilmir.",
    failedTracks: (p) => `${p.count} mahnını çevirmək mümkün olmadı`,
    retryFailed: "Uğursuz mahnıları yenidən sına",
    retrying: "Yenidən sınanır…",
    dismissFailed: "Bunları keç",
    dismissSummary: "Xülasəni bağla",
    migrationCompleted: "Çevirmə tamamlandı.",
    connectionsTitle: "Xidmət bağlantıları",
    connectionsDescription:
      "Saxlanmış API açarlarınız. Açarlar yalnız bu brauzerdə saxlanılır. Açarı silsəniz, axtarış işləməyəcək və onu yenidən daxil etməli olacaqsınız; Spotify və ya Google hesabınızdakı açar silinmir.",
    spotifyLabel: "Spotify",
    youtubeLabel: "YouTube",
    statusConnected: "Qoşulub",
    statusNotConnected: "Qoşulmayıb",
    removeKeys: "Sil",
    removeConfirmTitle: (p) => `${p.service} açarı silinsin?`,
    removeConfirmMessage:
      "Açar bu brauzerdən silinəcək və axtarış dayanacaq. Geri qaytarmaq üçün açarı yenidən daxil etməlisiniz.",
    removeConfirm: "Bəli, sil",
    removeCancel: "Ləğv et",
    serverTitle: "Server",
    serverDescription:
      "Mahnılarınız bu kompüterdəki Turkify serverindən gəlir. Heç bir pəncərə görmürsünüz; hər şey arxada işləyir.",
    serverRunning: "İşləyir",
    serverStopped: "Dayanıb",
    serverAddress: "Ünvan",
    serverUptime: "İşləmə müddəti",
    serverVersion: (p) => `Versiya ${p.version}`,
    serverStop: "Serveri dayandır",
    serverStopTitle: "Server dayandırılsın?",
    serverStopMessage:
      "Musiqi dayanır və tətbiq açılmır. Yenidən başlatmaq üçün Turkify qısayolunu işlədin.",
    serverStopConfirm: "Bəli, dayandır",
    serverCancel: "Ləğv et",
    serverStopping: "Dayandırılır…",
    serverUnreachable: "Serverə çatmaq olmur",
    serverJustNow: "indi başlayıb",
    serverUptimeMinutes: (p) => `${p.count} dəq`,
    serverUptimeHours: (p) => `${p.count} saat`,
    serverUptimeDays: (p) => `${p.count} gün`,
  },
  playlistView: {
    fallbackTitle: "Pleylist",
    notFound: "Pleylist tapılmadı. Kitabxanadan bir pleylist seçin.",
    trackCount: (p) => `${p.count} mahnı`,
    empty: "Bu pleylist boşdur. Mahnı sətrindəki + düyməsi ilə əlavə edin.",
    backToLibrary: "Kitabxanaya qayıt",
    playPlaylist: (p) => `${p.name} pleylistini oxut`,
    pausePlaylist: (p) => `${p.name} pleylistinə fasilə ver`,
    coverAlt: (p) => `${p.name} pleylistinin üz qabığı`,
    searchPlaceholder: "Pleylistdə mahnı axtarın…",
  },
  player: {
    regionLabel: "Pleyer",
    dismissError: "Xəta bildirişini bağla",
    resolving: "Mənbə hazırlanır…",
    emptyHint: "Oxutmaq üçün mahnı seçin",
    prevTrack: "Əvvəlki mahnı",
    noPrevTrack: "Əvvəlki mahnı yoxdur",
    noTrack: "Oxudulacaq mahnı yoxdur",
    play: "Oxut",
    pause: "Fasilə ver",
    selectFirst: "Əvvəlcə mahnı seçin",
    nextTrack: "Növbəti mahnı",
    noNextTrack: "Növbəti mahnı yoxdur",
    repeatOff: "Təkrarlama söndürülüb; pleylist təkrarını aktivləşdir",
    repeatContext: "Pleylist təkrarı aktivdir; bu mahnını təkrarla",
    repeatOne: "Bu mahnı təkrarlanır; təkrarlamanı söndür",
    shuffleOff: "Qarışıq oxutma söndürülüb; pleylisti qarışdır",
    shuffleOn: "Pleylist qarışıq oxudulur; ağıllı qarışdırmanı aktivləşdir",
    smartShuffle: "Ağıllı qarışdırma aktivdir; söndür",
    smartBadge: "Tövsiyə",
    trackMenu: "Mahnı seçimləri",
    seekLabel: "Mahnıdakı mövqe",
    mute: "Səsi söndür",
    unmute: "Səsi aç",
    volumeLabel: "Səs səviyyəsi",
  },
  trackList: {
    listLabel: "Mahnı siyahısı",
    coverAlt: (p) => `${p.album} albomunun üz qabığı`,
    badgeSpotify: "Spotify",
    badgeYoutube: "YouTube",
    playTrack: (p) => `${p.title} mahnısını oxut`,
    unlikeTrack: (p) => `${p.title} mahnısını bəyənilənlərdən çıxar`,
    likeTrack: (p) => `${p.title} mahnısını bəyən`,
    unlikeTitle: "Bəyənməni ləğv et",
    likeTitle: "Bəyən",
    removeFromList: (p) => `${p.title} mahnısını pleylistdən çıxar`,
    removeFromListTitle: "Pleylistdən çıxar",
    removeFromLibrary: (p) => `${p.title} mahnısını kitabxanadan sil`,
    removeFromLibraryTitle: "Kitabxanadan sil",
    addToList: (p) => `${p.title} mahnısını pleylistə əlavə et`,
    addToListTitle: "Pleylistə əlavə et",
    createFirst: "Əvvəlcə Kitabxanada pleylist yaradın.",
    whichList: "Hansı pleylistə əlavə edilsin?",
    chooseList: "Pleylist seçin…",
  },
  playlistPanel: {
    newPlaylist: "Yeni pleylist yarat",
    menuTitle: "Yeni pleylist yarat",
    coverLabel: "Pleylist üz qabığı",
    coverChoose: "Şəkil seç",
    coverTooLarge: "Şəkil 50 MB-dan böyük olduğu üçün pleylist üz qabığı olmadan yaradıldı.",
    nameLabel: "Pleylistin adı",
    namePlaceholder: "Məsələn, Səhər qaçışı",
    cancel: "Ləğv et",
    create: "Yarat",
    listTitle: (p) => `Pleylistlərim (${p.count})`,
    emptyLists: "Hələ pleylist yaratmamısınız. Yuxarıdakı formadan istifadə edin.",
    trackCount: (p) => `${p.count} mahnı`,
    confirmDelete: "Silinsin?",
    confirmYes: "Bəli",
    confirmCancel: "Ləğv et",
    deleteList: (p) => `${p.name} pleylistini sil`,
    deleteListTitle: "Pleylisti sil",
    addSongs: "Mahnı əlavə et",
    addSongsSearch: "Mahnı axtarın…",
    addSongsAdd: (p) => `Əlavə et (${p.count})`,
    addSongsEmpty: "Bu axtarışa uyğun mahnı yoxdur.",
    addedBulk: (p) => `“${p.name}” pleylistinə ${p.count} mahnı əlavə olundu.`,
    editList: "Pleylisti redaktə et",
    editMenuTitle: "Pleylisti redaktə et",
    save: "Yadda saxla",
    removeCover: "Şəkli sil",
    updated: (p) => `“${p.name}” yeniləndi.`,
  },
  playerErrors: {
    corruptFile: "Bu audio faylı oxutmaq mümkün olmadı. Fayl zədələnmiş və ya dəstəklənməyən formatda ola bilər.",
    noAudio: "Bu qeyd üçün oxudula bilən audio tapılmadı.",
    missingSource: "Bu fayl üçün audio mənbə tapılmadı. Faylı yenidən seçin.",
    blocked: "Brauzer oxutmanı blokladı. Yenidən sınayın.",
    startFailed: "Oxutmanı başlatmaq mümkün olmadı. Yenidən sınayın.",
  },
  playlists: {
    emptyName: "Pleylistin adı boş ola bilməz.",
    duplicateName: "Bu adda pleylist artıq mövcuddur.",
    created: (p) => `“${p.name}” yaradıldı.`,
    notFound: "Pleylist tapılmadı.",
    alreadyInList: "Bu mahnı artıq pleylistdədir.",
    addedToList: (p) => `“${p.name}” pleylistinə əlavə olundu.`,
  },
  remix: {
    buttonLabel: "Remiks parametrləri",
    title: "Remiks",
    presetNormal: "Normal",
    presetSlowed: "Slowed + Reverb",
    presetSpedUp: "Sped Up",
    speedLabel: "Sürət",
    reverbLabel: "Reverb",
    bassLabel: "Bas gücləndirməsi",
    reset: "Sıfırla",
    saveTrackDefault: "Standart et",
    trackDefaultSaved: "Bu mahnı üçün saxlanıldı.",
    trackDefaultFailed: "Parametri saxlamaq mümkün olmadı. Yenidən sınayın.",
    speedValue: (p) => `${p.value}x`,
    percentValue: (p) => `%${p.value}`,
  },
  remixExport: {
    buttonLabel: "Remiksi endir",
    hint: "Cari parametrlərlə WAV formatında saxlanılır.",
    rendering: "Hazırlanır...",
    saving: "Saxlanılır...",
    saved: (p) => `Saxlanıldı: ${p.name}`,
    folderLabel: "Endirmə qovluğu",
    folderDefaultHint: "standart",
    folderChange: "Dəyişdir",
    folderPlaceholder: "/Users/you/Downloads",
    folderSave: "Yadda saxla",
    folderCancel: "Ləğv et",
    errorPrefix: "Xəta:",
  },
  eq: {
    buttonLabel: "Ekvalayzer parametrləri",
    title: "Ekvalayzer",
    description:
      "Zolağı aşağı çəkmək həmin tezliyi zəiflədir, yuxarı çəkmək isə gücləndirir. Parametr cihazda saxlanılır və bütün mahnılara tətbiq olunur.",
    reset: "Sıfırla",
    flat: "Düz",
    presetFlat: "Düz",
    presetBassBoost: "Bass Boost",
    presetVocal: "Vokal",
    presetPastelGhost: "Pastel Ghost",
    presetTreble: "Yüksək tezliklər",
    presetsLabel: "Hazır profillər",
    activeBands: (p) => `${p.count} zolaq`,
    bandLabel: (p) => `${p.frequency} Hz zolağı`,
    valueDb: (p) => `${p.value} dB`,
  },
  externalSearch: {
    mixedHint: "Spotify və YouTube birlikdə axtarılır; sağdakı nişan mənbəni göstərir.",
    loading: "Axtarılır...",
    loadingMore: "Daha çox nəticə yüklənir...",
    noMoreResults: "Başqa nəticə yoxdur.",
    youtubeQuota: (p) => `YouTube-un gündəlik axtarış limiti bitib. ${p.hours} saat sonra yenidən sınayın.`,
    errorPrefix: "Axtarış xətası:",
    previewNotice: "Sətrə kliklədikdə mahnı dərhal oxudulur; endirməni gözləməyə ehtiyac yoxdur. Endir düyməsi mahnını kitabxananızda saxlayır.",
    playTrack: (p) => `${p.title} mahnısını oxut`,
    codecTitle: (p) => `Audio kodek: ${p.codec} • konteyner: ${p.ext} • diskretləşdirmə tezliyi: ${p.rate}`,
    badgeSpotify: "Spotify",
    badgeYoutube: "YouTube",
  },
  download: {
    action: "Endir",
    downloading: "Endirilir...",
    matching: "Uyğun nəticə tapılır…",
    done: "Endirildi",
    failedPrefix: "Endirmə xətası:",
    opusUnavailableQuestion: "Opus mövcud deyil. Bu mahnı AAC formatında endirilsin?",
    opusFailedAacQuestion: "Opus formatında endirmək alınmadı. Mahnı AAC formatında yenidən endirilsin?",
    useAac: "AAC istifadə et",
    added: (p) => `“${p.title}” endirildi və Kitabxananıza əlavə olundu.`,
    allAction: "Hamısını endir",
    allForPlaylist: (p) => `Bütün pleylisti endir: ${p.name}`,
    bulkProgressLabel: "Pleylist endirilir",
    bulkProgress: (p) => `${p.completed} / ${p.total}`,
    bulkProgressFailed: (p) => `${p.failed} uğursuz`,
    bulkCurrent: (p) => `Hazırda endirilir: ${p.title}`,
    bulkDone: (p) => `${p.count} mahnı endirildi.`,
    bulkDoneWithErrors: (p) => `${p.count} mahnı endirildi, ${p.failed} mahnını endirmək mümkün olmadı.`,
    bulkStopped: (p) => `Endirməyə fasilə verildi: ${p.completed} / ${p.total} mahnı endirilib.`,
    bulkPausing: "Endirməyə fasilə verilir…",
    bulkResume: "Davam et",
    bulkResumeHint: "Qalan mahnıları endirməyə davam et",
    bulkCancelled: (p) => `Ləğv edildi: ${p.completed} mahnı endirildi, yarımçıq fayl silindi.`,
    bulkStop: "Dayandır",
    bulkStopHint: "Cari mahnı tamamlanır, növbədəkilər başlamır",
    bulkCancel: "Endirməni ləğv et",
    bulkCancelHint: "Cari mahnı daxil olmaqla növbəni ləğv et",
    bulkCancelTitle: "Endirmə ləğv edilsin?",
    bulkCancelMessage: "Tamamlanan mahnılar qalır. Cari mahnı dayandırılır, yarımçıq fayl silinir və növbə ləğv olunur.",
    bulkCancelConfirm: "Bəli, ləğv et",
    bulkCancelKeep: "Davam et",
    nothingPending: "Bu pleylistdəki bütün Spotify mahnıları artıq endirilib.",
  },
  spotifyKeys: {
    title: "Spotify bağlantısı",
    intro: "Spotify və YouTube axtarışı üçün Spotify açarları tələb olunur. Açarlar yalnız bu brauzerdə saxlanılır və başqa yerə yazılmır.",
    steps: [
      "developer.spotify.com/dashboard ünvanına keçin və Spotify hesabınıza daxil olun.",
      "Create app düyməsini basın.",
      "Tətbiq adı yazın (məsələn, Turkify) və qısa təsvir əlavə edin.",
      "Redirect URI xanasına http://127.0.0.1:3400/callback yazın və Add düyməsini basın. Bu ünvan bu prosesdə istifadə edilmir, Spotify sadəcə xananın doldurulmasını tələb edir; http ilə yalnız 127.0.0.1 qəbul olunur, localhost isə rədd edilir.",
      "Şərtləri qəbul edin və Save düyməsi ilə tətbiqi yaradın.",
      "Dashboard-a qayıtdıqdan sonra siyahıdan tətbiqin adına klikləyin. Settings düyməsi əsas səhifədə deyil, tətbiqin öz səhifəsinin sağ yuxarı hissəsindədir.",
      "Settings səhifəsində Client ID açıq mətn kimi görünür, onu kopyalayın. Altındakı View client secret keçidinə klikləyərək Client Secret-i göstərin və onu da kopyalayın.",
      "Hər ikisini aşağıdakı xanalara yapışdırın və Yoxla və yadda saxla düyməsini basın.",
    ],
    clientIdLabel: "Client ID",
    clientIdPlaceholder: "Spotify Client ID",
    clientSecretLabel: "Client Secret",
    clientSecretPlaceholder: "Spotify Client Secret",
    verifyAndSave: "Yoxla və yadda saxla",
    verifying: "Yoxlanılır…",
    verifiedSaved: "Açarlar Spotify tərəfindən yoxlanıldı və bu brauzerdə saxlanıldı.",
    verifyTitle: "Yoxlama",
    verifyNotice: "Açarlar əvvəlcə Spotify vasitəsilə yoxlanılır; üç mərhələ tamamlanmadan saxlanılmır.",
    stepFormat: "Format yoxlaması",
    stepToken: "Spotify açarları tanıyırmı",
    stepSearch: "Axtarış icazəsi işləyirmi",
    statusPending: "gözləyir",
    statusRunning: "davam edir",
    statusOk: "uğurlu",
    statusFail: "uğursuz",
    verifyRequestFailed: (p) => `Yoxlama sorğusu uğursuz oldu (${p.status}).`,
    invalidId: "Client ID səhv görünür. 32 simvoldan ibarət olmalıdır; Settings səhifəsindən kopyalayın.",
    invalidSecret: "Client Secret səhv görünür. View client secret ilə göstərin və yenidən yapışdırın.",
    authFailed: "Spotify bu açarları qəbul etmədi. Artıq boşluqları yoxlayıb yenidən sınayın.",
  },
  youtubeKey: {
    title: "YouTube bağlantısı",
    intro: "YouTube axtarışı üçün YouTube API açarı tələb olunur. Açar yalnız bu brauzerdə saxlanılır və başqa yerə yazılmır.",
    steps: [
      "console.cloud.google.com ünvanına keçin və yeni layihə yaradın.",
      "APIs & Services > Library səhifəsini açın.",
      "“YouTube Data API v3” axtarın və Enable düyməsi ilə aktivləşdirin.",
      "APIs & Services > Credentials bölməsində Create credentials > API key seçin.",
      "Açılan pəncərədə ad yazın (məsələn, Turkify). “Authenticate API calls through a service account” xanasını İŞARƏLƏMƏYİN; bu seçim Vertex/Gemini üçündür və YouTube açarının işləməsinə mane olur.",
      "API restrictions bölməsində YouTube Data API v3 seçili qalsın. Application restrictions bölməsində None seçin: sorğunu brauzer deyil, öz serveriniz göndərir; Websites seçilsə, referrer olmadığı üçün 403 xətası yaranar.",
      "Create düyməsini basın, yaradılmış açarı kopyalayın, aşağıdakı xanaya yapışdırın və Yoxla və yadda saxla düyməsini basın.",
    ],
    apiKeyLabel: "API açarı",
    apiKeyPlaceholder: "YouTube API açarı",
    verifyAndSave: "Yoxla və yadda saxla",
    verifying: "Yoxlanılır…",
    verifiedSaved: "Açar YouTube tərəfindən yoxlanıldı və bu brauzerdə saxlanıldı.",
    verifyTitle: "Yoxlama",
    verifyNotice: "Yoxlama 1 kvota vahidlik videos.list sorğusundan istifadə edir; real axtarış sınağı 100 vahid sərf etdiyi üçün məqsədli şəkildə ötürülür.",
    stepFormat: "Format yoxlaması",
    stepKey: "Google açarı qəbul edirmi",
    statusPending: "gözləyir",
    statusRunning: "davam edir",
    statusOk: "uğurlu",
    statusFail: "uğursuz",
    verifyRequestFailed: (p) => `Yoxlama sorğusu uğursuz oldu (${p.status}).`,
    invalidKey: "API açarı səhv görünür. “AIza” ilə başlayan 39 simvoldan ibarət olmalıdır; Credentials səhifəsindən kopyalayın.",
    keyFailed: "YouTube bu açarı qəbul etmədi. Artıq boşluqları yoxlayıb yenidən sınayın.",
  },
};

export const MESSAGES: Record<Locale, Messages> = { tr: TR, en: EN, az: AZ };

export type GreetingPeriod = "morning" | "afternoon" | "evening";

/** Cihazin yerel saatine gore selamlama donemini secer (tek dogruluk kaynagi). */
export function getGreetingPeriod(hour: number): GreetingPeriod {
  if (hour >= 5 && hour < 12) return "morning";
  if (hour >= 12 && hour < 18) return "afternoon";
  return "evening";
}

/** Verilen saate gore o dilin karsiligini dondurur. */
export function getTimeBasedGreeting(messages: Messages, hour: number): string {
  return messages.home.greeting[getGreetingPeriod(hour)];
}
