import type { Track } from "./types";

export type HomeTab = "liked" | "all";

/**
 * Ana sayfada gosterilecek parcalari sekmeye gore secer.
 *
 * Begenilenler sekmesinde siralama `likedIds` sirasi degil, kutuphane sirasidir:
 * boylece bir parcayi begenip birakinca liste zıplamaz, parcalar yerinde kalir.
 */
export function selectHomeTracks(
  allTracks: Track[],
  likedIds: string[],
  tab: HomeTab,
): Track[] {
  if (tab === "all") return allTracks;
  const liked = new Set(likedIds);
  return allTracks.filter((track) => liked.has(track.id));
}
