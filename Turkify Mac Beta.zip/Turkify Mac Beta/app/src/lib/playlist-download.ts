import type { ExternalTrack, ImportedPlaylistTrack } from "./types";

/** Liste ithalat kaydını mevcut download hook'unun beklediği modele çevirir. */
export function importedTrackToExternalTrack(
  track: ImportedPlaylistTrack,
): ExternalTrack {
  if (track.source === "youtube") {
    return {
      id: track.id,
      source: "youtube",
      videoId: track.youtubeId ?? "",
      externalUrl: track.youtubeUrl ?? "",
      title: track.title,
      artist: track.artist,
      album: track.album,
      duration: track.duration,
      cover: track.cover,
    };
  }
  return {
    id: track.id,
    source: "spotify",
    externalUrl: track.spotifyUrl ?? "",
    previewUrl: null,
    title: track.title,
    artist: track.artist,
    album: track.album,
    duration: track.duration,
    cover: track.cover,
  };
}

/** Toplu indirmede diskte bulunan harici kimlikleri yeniden sıraya alma. */
export function pendingPlaylistDownloads(
  tracks: ImportedPlaylistTrack[],
  downloadedExternalIds: Iterable<string>,
): ExternalTrack[] {
  const downloaded = new Set(downloadedExternalIds);
  const queued = new Set<string>();
  const pending: ExternalTrack[] = [];
  for (const imported of tracks) {
    const track = importedTrackToExternalTrack(imported);
    if (downloaded.has(track.id) || queued.has(track.id)) continue;
    queued.add(track.id);
    pending.push(track);
  }
  return pending;
}
