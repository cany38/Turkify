import fs from "fs";
import os from "os";
import path from "path";
import { resolveDataDir } from "./data-dir";

/**
 * Remix indirmelerinin yazildigi klasor.
 *
 * `Musics` uygulamanin kendi arsivi ve degismez. Remix cikisi ise
 * kullanicinin kendi dosyasi: nereye inecegini kendisi secer, secim burada
 * saklanir ve bir daha sorulmaz.
 *
 * Yalnizca sunucu tarafi: `fs`/`os` kullanir, istemci paketine girmemeli.
 */
const CONFIG_FILE = path.join(resolveDataDir(), ".turkify-download-dir.json");

/** Hicbir sey secilmemisken kullanilan yer: isletim sisteminin indirilenler klasoru. */
export function defaultDownloadDir(): string {
  return path.join(os.homedir(), "Downloads");
}

/**
 * Kullanicinin girdigi yolu kabul edilebilir bicime getirir.
 *
 * Mutlak olmayan yol reddedilir: goreli yol sunucunun calisma dizinine gore
 * cozulur ve kullanicinin bekledigi yere yazmaz. Bos bayt Windows/POSIX
 * dosya API'lerinde tanimsiz davranistir, o da reddedilir.
 */
export function normalizeDownloadDirInput(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim().replace(/^"(.*)"$/, "$1").trim();
  if (!trimmed || trimmed.includes("\0")) return null;
  if (!path.isAbsolute(trimmed)) return null;
  return path.normalize(trimmed);
}

export interface DownloadDirInfo {
  dir: string;
  /** true ise kullanici kendi secmis; false ise varsayilan gosteriliyor. */
  custom: boolean;
}

export async function readDownloadDir(): Promise<DownloadDirInfo> {
  try {
    const raw = await fs.promises.readFile(CONFIG_FILE, "utf8");
    const parsed: unknown = JSON.parse(raw);
    const dir =
      typeof parsed === "object" && parsed !== null
        ? normalizeDownloadDirInput((parsed as Record<string, unknown>).dir)
        : null;
    if (dir) return { dir, custom: true };
  } catch {
    // Kayit yok ya da bozuk; varsayilana dus.
  }
  return { dir: defaultDownloadDir(), custom: false };
}

/** Klasor yazilabilir mi; yoksa olusturulabilir mi. */
export async function checkDownloadDir(dir: string): Promise<string | null> {
  try {
    const stat = await fs.promises.stat(dir);
    if (!stat.isDirectory()) return "Bu yol bir klasör değil.";
    await fs.promises.access(dir, fs.constants.W_OK);
    return null;
  } catch (err) {
    const code = (err as NodeJS.ErrnoException).code;
    if (code === "ENOENT") return "Klasör bulunamadı.";
    if (code === "EACCES" || code === "EPERM") return "Bu klasöre yazma izni yok.";
    return "Klasöre erişilemedi.";
  }
}

export async function writeDownloadDir(dir: string): Promise<void> {
  await fs.promises.writeFile(CONFIG_FILE, JSON.stringify({ dir }, null, 2), "utf8");
}
