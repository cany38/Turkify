import { spawn } from "node:child_process";
import fs from "node:fs/promises";
import fsSync from "node:fs";
import os from "node:os";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { registerChild, type ChildPurpose } from "./child-processes";

import {
  audioFormatExtension,
  getSpotDlFormat,
  getYtDlpSelector,
  type AudioFormat,
} from "./audio-format";

const AUDIO_EXTENSIONS = [".m4a", ".opus", ".webm", ".ogg", ".oga", ".aac", ".mp3", ".flac"];
const SPOTIFY_RESOLUTION_TTL_MS = 10 * 60 * 1000;

const spotifyResolutionGlobal = globalThis as typeof globalThis & {
  __turkifySpotifyResolutionCache?: Map<string, { url: string; expiresAt: number }>;
};
const spotifyResolutionCache =
  spotifyResolutionGlobal.__turkifySpotifyResolutionCache ??=
    new Map<string, { url: string; expiresAt: number }>();

export function runCommand(
  command: string,
  args: string[],
  timeoutMs: number,
  signal?: AbortSignal,
  /** Kayit amaci: cagiran tarafin isini toplu iptal edebilmek icin. */
  purpose: ChildPurpose = "download",
): Promise<{
  code: number | null;
  stdout: string;
  stderr: string;
  timedOut: boolean;
  aborted: boolean;
}> {
  if (signal?.aborted) {
    return Promise.resolve({
      code: null,
      stdout: "",
      stderr: "",
      timedOut: false,
      aborted: true,
    });
  }
  return new Promise((resolve) => {
    const child = spawn(command, args, { windowsHide: true });
    const unregister = registerChild(child, purpose);
    let stdout = "";
    let stderr = "";
    let timedOut = false;
    let aborted = false;
    let settled = false;
    let abortFallback: ReturnType<typeof setTimeout> | undefined;
    const finish = (code: number | null) => {
      if (settled) return;
      settled = true;
      unregister();
      clearTimeout(timer);
      if (abortFallback) clearTimeout(abortFallback);
      signal?.removeEventListener("abort", handleAbort);
      resolve({ code, stdout, stderr, timedOut, aborted });
    };
    const handleAbort = () => {
      if (settled || aborted) return;
      aborted = true;
      try {
        child.kill();
      } catch {
        // close/error veya aşağıdaki kısa fallback promise'i tamamlar
      }
      abortFallback = setTimeout(() => finish(null), 750);
    };
    const timer = setTimeout(() => {
      timedOut = true;
      child.kill();
    }, timeoutMs);
    signal?.addEventListener("abort", handleAbort, { once: true });
    child.stdout?.on("data", (chunk: Buffer) => {
      stdout += chunk.toString();
    });
    child.stderr?.on("data", (chunk: Buffer) => {
      stderr += chunk.toString();
    });
    child.on("error", (error) => {
      stderr += String(error);
      finish(1);
    });
    child.on("close", (code) => {
      finish(code);
    });
  });
}

async function findAudio(dir: string): Promise<string | null> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  for (const extension of AUDIO_EXTENSIONS) {
    const file = entries.find(
      (entry) => entry.isFile() && entry.name.toLowerCase().endsWith(extension),
    );
    if (file) return path.join(dir, file.name);
  }
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const nested = await findAudio(path.join(dir, entry.name));
    if (nested) return nested;
  }
  return null;
}

function sourceUrl(origin: "spotify" | "youtube", externalId: string): string {
  if (origin === "youtube") {
    const videoId = externalId.replace(/^youtube-/, "");
    if (!/^[A-Za-z0-9_-]{6,20}$/.test(videoId)) throw new Error("invalid youtube id");
    return `https://www.youtube.com/watch?v=${videoId}`;
  }
  const spotifyId = externalId.replace(/^spotify-/, "");
  if (!/^[A-Za-z0-9]{10,30}$/.test(spotifyId)) throw new Error("invalid spotify id");
  return `https://open.spotify.com/track/${spotifyId}`;
}

/** `spotdl url` ciktisindaki son YouTube adresini alir. */
export function extractMediaUrl(output: string): string | null {
  const urls = output.match(/https?:\/\/\S+/g) ?? [];
  const media = urls
    .map((url) => url.replace(/["'.,;)]+$/, ""))
    .filter((url) =>
      /^(https?:\/\/)?(www\.|music\.)?(youtube\.com\/watch|youtu\.be\/)/.test(url),
    );
  return media.length > 0 ? (media[media.length - 1] ?? null) : null;
}

/**
 * Spotify metadata kaydini, hem format yoklamasinin hem indirmenin kullanacagi
 * ayni YouTube medya adresine cozer. Kisa cache iki istegin ayni eslesmeyi
 * kullanmasini saglar; suresi dolmus imzali adresler uzun sure tutulmaz.
 */
export async function resolveSpotifyMediaUrl(
  spotifyUrl: string,
  title: string,
  artist: string,
  expectedDuration?: number,
): Promise<string | null> {
  let parsed: URL;
  try {
    parsed = new URL(spotifyUrl);
  } catch {
    return null;
  }
  if (
    parsed.protocol !== "https:" ||
    parsed.hostname !== "open.spotify.com" ||
    !/^\/track\/[A-Za-z0-9]{10,30}\/?$/.test(parsed.pathname)
  ) {
    return null;
  }

  const cacheKey = parsed.pathname.toLowerCase();
  const cached = spotifyResolutionCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return cached.url;

  const result = await runCommand(
    process.env.TURKIFY_PYTHON || "python3",
    ["-m", "spotdl", "url", parsed.toString()],
    45_000,
  );
  let mediaUrl = result.timedOut || result.code !== 0
    ? null
    : extractMediaUrl(`${result.stdout}\n${result.stderr}`);
  if (!mediaUrl) {
    const videoId = await resolveYoutubeVideoId(title, artist, expectedDuration);
    if (videoId) mediaUrl = `https://www.youtube.com/watch?v=${videoId}`;
  }
  if (mediaUrl) {
    spotifyResolutionCache.set(cacheKey, {
      url: mediaUrl,
      expiresAt: Date.now() + SPOTIFY_RESOLUTION_TTL_MS,
    });
  }
  return mediaUrl;
}

export async function downloadTrackedAudio(input: {
  origin: "spotify" | "youtube";
  externalId: string;
  title: string;
  format: AudioFormat;
  outputDir: string;
}): Promise<string> {
  await fs.mkdir(input.outputDir, { recursive: true });
  const url = sourceUrl(input.origin, input.externalId);
  let result: Awaited<ReturnType<typeof runCommand>>;

  if (input.origin === "youtube") {
    const args = [
      "-m",
      "yt_dlp",
      "-f",
      getYtDlpSelector(input.format),
      "--no-playlist",
      "-o",
      path.join(input.outputDir, "replacement.%(ext)s"),
    ];
    const toolsDir = path.join(os.homedir(), ".spotdl");
    const ffmpegPath = path.join(toolsDir, "ffmpeg");
    const denoPath = path.join(toolsDir, "deno");
    if (fsSync.existsSync(ffmpegPath)) args.push("--ffmpeg-location", toolsDir);
    if (fsSync.existsSync(denoPath)) args.push("--js-runtimes", `deno:${denoPath}`);
    args.push(url);
    result = await runCommand(process.env.TURKIFY_PYTHON || "python3", args, 120_000);
  } else {
    const output = path.join(input.outputDir, `replacement${audioFormatExtension(input.format)}`);
    result = await runCommand(
      process.env.TURKIFY_PYTHON || "python3",
      [
        "-m",
        "spotdl",
        "--output",
        output,
        "--format",
        getSpotDlFormat(input.format),
        "--bitrate",
        "disable",
        "download",
        url,
      ],
      120_000,
    );
  }

  if (result.timedOut || result.code !== 0) throw new Error("provider download failed");
  const audioPath = await findAudio(input.outputDir);
  if (!audioPath) throw new Error("provider returned no audio");
  return audioPath;
}

/**
 * M4A dosyasına kapağı tek karelik `attached_pic` stream'i olarak ekler.
 * Audio stream `copy` edilir; ikinci bir kayıplı encode yapılmaz. Kaynak dosya
 * değiştirilmez, çağıran yalnız başarılı çıktıyı sahiplenir.
 */
export async function embedCoverInM4a(
  audioPath: string,
  coverPath: string,
): Promise<string> {
  if (path.extname(audioPath).toLowerCase() !== ".m4a") {
    throw new Error("cover embedding requires M4A");
  }
  if (!new Set([".jpg", ".jpeg", ".png", ".webp"]).has(path.extname(coverPath).toLowerCase())) {
    throw new Error("unsupported cover image");
  }

  const bundled = path.join(os.homedir(), ".spotdl", "ffmpeg");
  const command = fsSync.existsSync(bundled) ? bundled : "ffmpeg";
  const output = path.join(
    path.dirname(audioPath),
    `${path.basename(audioPath, ".m4a")}.cover-${randomUUID()}.m4a`,
  );
  try {
    const result = await runCommand(
      command,
      [
        "-hide_banner",
        "-loglevel",
        "error",
        "-y",
        "-i",
        audioPath,
        "-i",
        coverPath,
        "-map",
        "0:a:0",
        "-map",
        "1:v:0",
        "-c:a",
        "copy",
        "-c:v",
        "mjpeg",
        "-disposition:v:0",
        "attached_pic",
        "-metadata:s:v:0",
        "title=Cover",
        "-metadata:s:v:0",
        "comment=Cover (front)",
        "-movflags",
        "+faststart",
        output,
      ],
      30_000,
    );
    if (result.timedOut || result.code !== 0) throw new Error("cover mux failed");
    const stat = await fs.stat(output);
    if (!stat.isFile() || stat.size < 1_024) throw new Error("cover mux output invalid");
    return output;
  } catch {
    await fs.unlink(output).catch(() => undefined);
    throw new Error("cover mux failed");
  }
}

export async function inspectAudioFile(
  filePath: string,
): Promise<{ codec: string; ext: string; duration?: number }> {
  const bundled = path.join(os.homedir(), ".spotdl", "ffmpeg");
  const command = fsSync.existsSync(bundled) ? bundled : "ffmpeg";
  const nullTarget = process.platform === "win32" ? "NUL" : "/dev/null";
  const result = await runCommand(
    command,
    ["-hide_banner", "-i", filePath, "-map", "0:a:0", "-t", "0.1", "-f", "null", nullTarget],
    20_000,
  );
  if (result.timedOut || result.code !== 0) throw new Error("audio validation failed");
  const codec = /Audio:\s*([^,\s]+)/i.exec(result.stderr)?.[1]?.toLowerCase();
  if (!codec) throw new Error("audio codec unavailable");
  const match = /Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(result.stderr);
  const duration = match ? Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]) : 0;
  return { codec, ext: path.extname(filePath).toLowerCase(), ...(duration > 0 ? { duration } : {}) };
}

/** yt-dlp `--print id` çıktısındaki ilk geçerli video kimliği. */
export function extractFirstVideoId(output: string): string | null {
  for (const line of output.split("\n")) {
    const candidate = line.trim();
    if (/^[A-Za-z0-9_-]{11}$/.test(candidate)) return candidate;
  }
  return null;
}

/**
 * YouTube aramasıyla video kimliği çözer: önce "başlık sanatçı", boş
 * dönerse yalnız "başlık" denenir. Uzun kuyruklu sorgular (parantez,
 * hariç tutma işareti, çok terim) bazen sıfır sonuç verir; başlık tek
 * başına genelde eşleşir.
 */
export interface YoutubeCandidate {
  id: string;
  /** Saniye; yt-dlp "NA" dondurduyse null. */
  duration: number | null;
}

/** Adayin dogru surum sayilmasi icin izin verilen sapma (saniye). */
export const DURATION_TOLERANCE_SECONDS = 3;

/** `id|sure` satirlarini adaya cevirir; bozuk satirlar atlanir. */
export function parseYoutubeCandidates(output: string): YoutubeCandidate[] {
  const candidates: YoutubeCandidate[] = [];
  for (const line of output.split("\n")) {
    const [rawId, rawDuration] = line.trim().split("|");
    const id = (rawId ?? "").trim();
    if (!/^[A-Za-z0-9_-]{11}$/.test(id)) continue;
    const seconds = Number.parseFloat((rawDuration ?? "").trim());
    candidates.push({
      id,
      duration: Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds) : null,
    });
  }
  return candidates;
}

/**
 * Adaylar arasindan dogru surumu secer.
 *
 * Ayni sarkinin YouTube'da bircok yuklemesi olur: remix, canli kayit, uzatilmis
 * edit. Baslik hepsinde benzediginden ilk sonucu almak yanlis surum indirmeye
 * yol acabiliyor. Spotify'in verdigi sure elimizde oldugu icin ona en yakin
 * adayi seciyoruz. Sure bilinmiyorsa eski davranis korunur: ilk aday.
 */
export function pickBestCandidate(
  candidates: YoutubeCandidate[],
  expectedDuration?: number,
): YoutubeCandidate | null {
  if (candidates.length === 0) return null;
  const first = candidates[0] ?? null;
  if (!expectedDuration || expectedDuration <= 0) return first;

  const timed = candidates.filter((c) => c.duration !== null);
  if (timed.length === 0) return first;

  const within = timed.find(
    (c) => Math.abs((c.duration as number) - expectedDuration) <= DURATION_TOLERANCE_SECONDS,
  );
  if (within) return within;

  // Hicbiri tutmuyorsa en yakinini al: yanlis surum, hic indirmemekten iyidir.
  let closest = timed[0] as YoutubeCandidate;
  for (const candidate of timed) {
    const diff = Math.abs((candidate.duration as number) - expectedDuration);
    const bestDiff = Math.abs((closest.duration as number) - expectedDuration);
    if (diff < bestDiff) closest = candidate;
  }
  console.warn(
    `YouTube eslesmesinde sure tutmadi: beklenen ${expectedDuration} sn, secilen ${closest.duration} sn (${closest.id}).`,
  );
  return closest;
}

export async function resolveYoutubeVideoId(
  title: string,
  artist: string,
  expectedDuration?: number,
  signal?: AbortSignal,
  purpose: ChildPurpose = "download",
): Promise<string | null> {
  const queries = [`${title} ${artist}`.trim(), title.trim()].filter((q, i, all) => q.length >= 2 && all.indexOf(q) === i);
  // Sure bilinmiyorsa tek sonuc yeter; biliniyorsa aralarindan secebilmek icin
  // birkac aday cekilir.
  const useDuration = typeof expectedDuration === "number" && expectedDuration > 0;
  for (const query of queries) {
    const args = ["-m", "yt_dlp", "--no-playlist", "--no-warnings", "--print"];
    args.push(useDuration ? "%(id)s|%(duration)s" : "id");
    const denoPath = path.join(os.homedir(), ".spotdl", "deno");
    if (fsSync.existsSync(denoPath)) args.push("--js-runtimes", `deno:${denoPath}`);
    args.push(`${useDuration ? "ytsearch5" : "ytsearch1"}:${query}`);
    const result = await runCommand(
      process.env.TURKIFY_PYTHON || "python3",
      args,
      useDuration ? 40_000 : 25_000,
      signal,
      purpose,
    );
    if (result.aborted) return null;
    if (result.timedOut || result.code !== 0) continue;
    if (!useDuration) {
      const id = extractFirstVideoId(result.stdout);
      if (id) return id;
      continue;
    }
    const best = pickBestCandidate(parseYoutubeCandidates(result.stdout), expectedDuration);
    if (best) return best.id;
  }
  return null;
}
