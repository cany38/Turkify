import type { Playlist, Track } from "./types";
import type { ListeningHistory } from "./listening-history";

/** Karistirma dugmesi uc durum doner: kapali, liste ici, akilli. */
export type ShuffleMode = "off" | "on" | "smart";

export const SHUFFLE_KEY = "turkify:shuffle-mode:v1";

/** Her kac liste sarkisinda bir oneri girer. */
export const SMART_EVERY = 3;
/** Tek baglamda en fazla oneri. */
export const SMART_MAX = 6;
/** Liste bitince tek seferde eklenecek devam onerisi. */
export const SMART_REFILL = 3;
/** Son 24 saatte dinlenen, oneri havuzuna girmez. */
export const SMART_RECENT_MS = 24 * 60 * 60 * 1000;

const TITLE_STOPWORDS = new Set([
  "ve", "bir", "ile", "the", "de", "da", "mi", "mu", "feat", "ft", "vs",
]);

export function loadShuffleMode(): ShuffleMode {
  try {
    const value = localStorage.getItem(SHUFFLE_KEY);
    if (value === "on" || value === "smart" || value === "off") return value;
    return "off";
  } catch { return "off"; }
}

export function saveShuffleMode(mode: ShuffleMode): void {
  try { localStorage.setItem(SHUFFLE_KEY, mode); } catch { /* Keep session mode if storage is unavailable. */ }
}

/** Baslik benzerligi icin kucuk token kumesi; 3 harften kisalar ve edatlar atilir. */
export function titleTokens(title: string): Set<string> {
  const tokens = new Set<string>();
  for (const raw of title.toLocaleLowerCase("tr-TR").split(/[^a-zçğıöşü0-9]+/)) {
    if (raw.length < 3 || TITLE_STOPWORDS.has(raw)) continue;
    tokens.add(raw);
  }
  return tokens;
}

export interface SimilarityContext {
  likedIds: string[];
  playlists: Playlist[];
  history: ListeningHistory;
  now?: number;
}

/**
 * Aday parcanin tohum listedeki sarkilarla baglanti skoru. Buyuk skor daha
 * baglantili demek: ayni sanatci agir basar, ayni listede bulunma ve baslik
 * ortakligi onu izler, begeni ve dinlenme gecmisi hafif arti verir.
 */
export function scoreCandidate(
  candidate: Track,
  seeds: Track[],
  ctx: SimilarityContext,
): number {
  const candidateArtist = candidate.title ? candidate.artist.trim().toLocaleLowerCase("tr-TR") : "";
  const candidateTokens = titleTokens(candidate.title);
  let score = 0;
  let playlistBonus = 0;
  let tokenBonus = 0;
  for (const seed of seeds) {
    if (
      candidateArtist &&
      seed.artist.trim().toLocaleLowerCase("tr-TR") === candidateArtist
    ) {
      score += 4;
    }
    const seedTokens = titleTokens(seed.title);
    for (const token of candidateTokens) {
      if (seedTokens.has(token)) tokenBonus += 1;
    }
  }
  for (const playlist of ctx.playlists) {
    const ids = new Set([
      ...playlist.trackIds,
      ...(playlist.importedTracks ?? []).map((track) => track.id),
    ]);
    if (!ids.has(candidate.id)) continue;
    if (seeds.some((seed) => ids.has(seed.id))) playlistBonus += 2;
  }
  score += Math.min(playlistBonus, 4) + Math.min(tokenBonus, 3);
  if (ctx.likedIds.includes(candidate.id)) score += 1;
  const record = ctx.history[candidate.id];
  if (record) score += Math.min(record.count, 2);
  return score;
}

/**
 * Havuzdan tohumlara en baglantili adaylari secer. Tohumlar ve son 24 saatte
 * dinlenenler dislanir (havuz cok darsa son dinlenme filtresi gevsetilir).
 * Cesitlilik icin en yuksek skor grubunun icinden rastgele secilir.
 */
export function pickSuggestions(
  pool: Track[],
  seeds: Track[],
  count: number,
  ctx: SimilarityContext,
  rand: () => number = Math.random,
): Track[] {
  if (count <= 0) return [];
  const now = ctx.now ?? Date.now();
  const seedIds = new Set(seeds.map((track) => track.id));
  const fresh = pool.filter((track) => {
    if (seedIds.has(track.id)) return false;
    const record = ctx.history[track.id];
    if (record && now - record.lastPlayed < SMART_RECENT_MS) return false;
    return true;
  });
  const relaxed = fresh.length >= count
    ? fresh
    : pool.filter((track) => !seedIds.has(track.id));
  const ranked = relaxed
    .map((track) => ({ track, score: scoreCandidate(track, seeds, ctx) }))
    .sort((a, b) => b.score - a.score);
  const head = ranked.slice(0, Math.max(count * 2, 5));
  const picked: Track[] = [];
  const candidates = [...head];
  while (picked.length < count && candidates.length > 0) {
    const index = Math.floor(rand() * candidates.length);
    const next = candidates.splice(index, 1)[0];
    if (next) picked.push(next.track);
  }
  return picked;
}

/**
 * Baglami onerilerle harmanlar: her SMART_EVERY sarkida bir oneri araya
 * girer. Donen smartIds hangi parcalarin oneri oldugunu isaretler.
 */
export function interleaveSuggestions(
  context: Track[],
  suggestions: Track[],
): { queue: Track[]; smartIds: string[] } {
  const queue: Track[] = [];
  const smartIds: string[] = [];
  let used = 0;
  context.forEach((track, index) => {
    queue.push(track);
    if (
      used < suggestions.length &&
      suggestions.length > 0 &&
      (index + 1) % SMART_EVERY === 0
    ) {
      const suggestion = suggestions[used]!;
      used += 1;
      queue.push(suggestion);
      smartIds.push(suggestion.id);
    }
  });
  for (; used < suggestions.length; used += 1) {
    const suggestion = suggestions[used]!;
    queue.push(suggestion);
    smartIds.push(suggestion.id);
  }
  return { queue, smartIds };
}

function shuffleInPlace(ids: string[], rand: () => number): void {
  for (let i = ids.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rand() * (i + 1));
    [ids[i], ids[j]] = [ids[j]!, ids[i]!];
  }
}

/**
 * Yesil karistirma sirasi: baslayan parca sabittir, gerisi Fisher-Yates ile
 * karisir. Spotify'in "fewer repeats" yaklasiminin yereli: birkac rastgele
 * dizi uretilip son dinlenenler one dusenler elenir, en taze dizi kazanir.
 */
export function buildShuffleOrder(
  ids: string[],
  startId: string,
  history: ListeningHistory,
  samples = 4,
  rand: () => number = Math.random,
  now: number = Date.now(),
): string[] {
  const rest = ids.filter((id) => id !== startId);
  if (rest.length <= 1) return [startId, ...rest];
  const recentPenalty = (order: string[]): number => {
    let penalty = 0;
    order.forEach((id, index) => {
      const record = history[id];
      if (!record) return;
      if (now - record.lastPlayed < 2 * SMART_RECENT_MS) {
        penalty += order.length - index;
      }
    });
    return penalty;
  };
  let best: string[] | null = null;
  let bestPenalty = Number.POSITIVE_INFINITY;
  for (let s = 0; s < samples; s += 1) {
    const candidate = [...rest];
    shuffleInPlace(candidate, rand);
    const penalty = recentPenalty(candidate);
    if (penalty < bestPenalty) {
      bestPenalty = penalty;
      best = candidate;
    }
  }
  return [startId, ...(best ?? rest)];
}
