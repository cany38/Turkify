/** Kullanicinin anahtarlariyla `/v1/tracks?ids=` ucundan toplanan parca bilgisi. */
export interface TrackDetail {
  album: string;
  cover: string;
}

const TOKEN_URL = "https://accounts.spotify.com/api/token";
const TRACKS_URL = "https://api.spotify.com/v1/tracks";
// Toplu uc bir istekte en fazla 50 kimlik kabul eder.
const PAGE_SIZE = 50;
// Istekler arasi bekleme yok; ama takilmaya karsi tum islem ustten sinirlidir.
const TOTAL_TIMEOUT_MS = 60_000;

interface SpotifyDetailTrack {
  id?: string;
  album?: {
    name?: string;
    images?: { url?: string }[];
  };
}

/** Arama ucundaki `getSpotifyToken` deseni; alinamazsa null doner. */
async function getAppToken(clientId: string, clientSecret: string, timeoutMs: number): Promise<string | null> {
  try {
    const basic = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(TOKEN_URL, {
        method: "POST",
        headers: {
          Authorization: `Basic ${basic}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: "grant_type=client_credentials",
        cache: "no-store",
        signal: controller.signal,
      });
      if (!res.ok) return null;
      const data = (await res.json()) as { access_token: string; expires_in: number };
      if (!data.access_token) return null;
      return data.access_token;
    } finally {
      clearTimeout(timer);
    }
  } catch {
    return null;
  }
}

/**
 * Kimliklere ait album adi ve kapagi toplar; hicbir durumda hata firlatmaz.
 *
 * Anahtar bossa ya da token alinamazsa bos Map doner. Bir sayfa hata
 * verirse (403/429/ag kopmasi) o ana kadar toplanmis Map doner; route
 * kalan parcalarda mevcut yedege duser.
 */
export async function fetchTrackDetails(
  ids: string[],
  clientId: string,
  clientSecret: string,
): Promise<Map<string, TrackDetail>> {
  const details = new Map<string, TrackDetail>();
  if (!clientId || !clientSecret) return details;
  const clean = ids.filter((id) => id.trim().length > 0);
  if (clean.length === 0) return details;
  const deadline = Date.now() + TOTAL_TIMEOUT_MS;
  const token = await getAppToken(clientId, clientSecret, TOTAL_TIMEOUT_MS);
  if (!token) return details;
  for (let start = 0; start < clean.length; start += PAGE_SIZE) {
    const remaining = deadline - Date.now();
    if (remaining <= 0) break;
    const chunk = clean.slice(start, start + PAGE_SIZE);
    const url = new URL(TRACKS_URL);
    url.searchParams.set("ids", chunk.join(","));
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), remaining);
    try {
      const res = await fetch(url.toString(), {
        headers: { Authorization: `Bearer ${token}` },
        cache: "no-store",
        signal: controller.signal,
      });
      if (!res.ok) {
        console.error(`Spotify parca detayi alinamadi (${res.status}).`);
        return details;
      }
      const data = (await res.json()) as { tracks?: (SpotifyDetailTrack | null)[] };
      for (const item of data.tracks ?? []) {
        const id = item?.id;
        const album = item?.album?.name;
        const cover = item?.album?.images?.[0]?.url;
        // Biri eksikse kayit eklenmez; route yedege duser.
        if (!id || !album || !cover) continue;
        details.set(id, { album, cover });
      }
    } catch (error) {
      console.error(
        `Spotify parca detayi alinamadi: ${error instanceof Error ? error.message : "bilinmeyen hata"}`,
      );
      return details;
    } finally {
      clearTimeout(timer);
    }
  }
  return details;
}
