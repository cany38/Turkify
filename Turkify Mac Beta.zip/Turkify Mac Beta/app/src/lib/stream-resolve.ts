import fs from "fs";
import os from "os";
import path from "path";
import { getYtDlpSelector, parseAudioFormat } from "./audio-format";
import { resolveYoutubeVideoId, runCommand } from "./external-audio";
import type { AudioFormat } from "./audio-format";

/**
 * Ses akisi adresinin cozumlenmesi.
 *
 * Bu is yt-dlp calistirmayi gerektiriyor ve 2-25 saniye suruyor. Eskiden
 * dogrudan `<audio>` elementinin istegi icinde olurdu: element saniyelerce
 * yarim kalmis bir yukleme tutar, kullanici baska bir parcaya gectiginde
 * tarayicinin once o yuklemeyi sokmesi gerekirdi. Artik cozumleme ayri bir
 * uctan yapiliyor ve element yalnizca hazir bir adrese baglaniyor.
 *
 * Onbellekler HMR'de kaybolmasin diye `globalThis` uzerinde tutuluyor.
 */

const CACHE_TTL_MS = 30 * 60 * 1000;
/**
 * Basarisiz cozumleme kisa sure hatirlanir: bozuk bir parcaya ikinci kez
 * tiklamak bastan 25 saniye beklemesin. Kalici degil, cunku hata gecici
 * olabilir (ag kesintisi, YouTube tarafinda anlik sorun).
 */
const NEGATIVE_TTL_MS = 60 * 1000;
const RESOLVE_TIMEOUT_MS = 25_000;

interface CacheEntry {
  url: string;
  expiresAt: number;
}

interface FailureEntry {
  error: string;
  expiresAt: number;
}

const cacheGlobal = globalThis as typeof globalThis & {
  __turkifyStreamUrlCache?: Map<string, CacheEntry>;
  __turkifyStreamFailCache?: Map<string, FailureEntry>;
};
const urlCache = (cacheGlobal.__turkifyStreamUrlCache ??= new Map<string, CacheEntry>());
const failCache = (cacheGlobal.__turkifyStreamFailCache ??= new Map<string, FailureEntry>());

export interface StreamTarget {
  cacheKey: string;
  target: string;
  format: AudioFormat;
  title: string;
  artist: string;
  expectedDuration: number;
  /** Yedek eslesme yalnizca sorgu tabanli (Spotify) istekler icin anlamli. */
  query: string;
}

export type StreamTargetResult =
  | { ok: true; value: StreamTarget }
  | { ok: false; error: string; status: number };

/**
 * Istek parametrelerini tek yerde yorumlar.
 *
 * Hem cozumleme ucu hem akis ucu bunu kullanir; boylece ikisi ayni onbellek
 * anahtarini uretir ve akis ucu cozumlemenin sonucunu kesin olarak bulur.
 */
export function readStreamTarget(params: URLSearchParams): StreamTargetResult {
  const videoId = params.get("v")?.trim() ?? "";
  const query = params.get("q")?.trim() ?? "";
  const title = params.get("title")?.trim() ?? "";
  const artist = params.get("artist")?.trim() ?? "";
  const rawDuration = Number.parseFloat(params.get("duration") ?? "");
  const expectedDuration =
    Number.isFinite(rawDuration) && rawDuration > 0 ? Math.round(rawDuration) : 0;

  const parsedFormat = parseAudioFormat(params.get("format"));
  if (!parsedFormat.ok) {
    return { ok: false, error: "Geçersiz ses formatı.", status: 400 };
  }
  const format = parsedFormat.value;

  if (videoId) {
    if (!/^[A-Za-z0-9_-]{6,20}$/.test(videoId)) {
      return { ok: false, error: "Geçersiz video kimliği.", status: 400 };
    }
    return {
      ok: true,
      value: {
        cacheKey: `${format}:v:${videoId}`,
        target: `https://www.youtube.com/watch?v=${videoId}`,
        format,
        title,
        artist,
        expectedDuration,
        query: "",
      },
    };
  }

  if (query) {
    if (query.length < 2 || query.length > 200) {
      return { ok: false, error: "Sorgu çok kısa veya çok uzun.", status: 400 };
    }
    // Spotify satirlarinda calinabilir ses yok; eslesen kaydi YouTube'da ara.
    return {
      ok: true,
      value: {
        cacheKey: `${format}:q:${query.toLowerCase()}`,
        target: `ytsearch1:${query}`,
        format,
        title,
        artist,
        expectedDuration,
        query,
      },
    };
  }

  return { ok: false, error: "Çalınacak kaynak belirtilmedi.", status: 400 };
}

async function resolveDirectUrl(
  target: string,
  format: AudioFormat,
  signal: AbortSignal,
): Promise<{ url: string | null; error: string; aborted: boolean }> {
  const args = ["-m", "yt_dlp", "-g", "-f", getYtDlpSelector(format)];

  // Indirme ucuyla ayni JS calisma zamani cozumu; yoksa bazi formatlar dusuyor.
  try {
    const denoPath = path.join(os.homedir(), ".spotdl", "deno");
    if (fs.existsSync(denoPath)) args.push("--js-runtimes", `deno:${denoPath}`);
  } catch {
    // yok say
  }
  args.push(target);

  const result = await runCommand(
    process.env.TURKIFY_PYTHON || "python3",
    args,
    RESOLVE_TIMEOUT_MS,
    signal,
    "playback",
  );
  if (result.aborted) return { url: null, error: "İstek iptal edildi.", aborted: true };
  if (result.timedOut) {
    return { url: null, error: "Ses adresi çözülürken zaman aşımı.", aborted: false };
  }
  // -g birden fazla satir dondurebilir; ilk gecerli http adresi bize yeter.
  const line = result.stdout
    .split("\n")
    .map((l) => l.trim())
    .find((l) => l.startsWith("http"));
  return { url: line ?? null, error: result.stderr.slice(0, 400), aborted: false };
}

async function getDirectUrl(
  cacheKey: string,
  target: string,
  format: AudioFormat,
  signal: AbortSignal,
): Promise<{ url: string | null; error: string; aborted: boolean }> {
  const now = Date.now();
  const cached = urlCache.get(cacheKey);
  if (cached && now < cached.expiresAt) return { url: cached.url, error: "", aborted: false };

  const resolved = await resolveDirectUrl(target, format, signal);
  if (resolved.url) {
    urlCache.set(cacheKey, { url: resolved.url, expiresAt: now + CACHE_TTL_MS });
  }
  return resolved;
}

/** Çözülmüş adresi önbellekten düşürür; eskimiş adres hata verince çağrılır. */
export function forgetStreamUrl(cacheKey: string): void {
  urlCache.delete(cacheKey);
}

export interface ResolveOutcome {
  url: string | null;
  error: string;
  aborted: boolean;
  /** Sonuç önbellekten geldiyse true; yt-dlp çalıştırılmadı. */
  cached: boolean;
}

/**
 * Bir hedefi çözer: önce önbellek, sonra yt-dlp, gerekirse başlık üzerinden
 * yedek eşleşme.
 */
export async function resolveStream(
  spec: StreamTarget,
  signal: AbortSignal,
): Promise<ResolveOutcome> {
  const now = Date.now();
  const cachedUrl = urlCache.get(spec.cacheKey);
  if (cachedUrl && now < cachedUrl.expiresAt) {
    return { url: cachedUrl.url, error: "", aborted: false, cached: true };
  }
  const cachedFail = failCache.get(spec.cacheKey);
  if (cachedFail && now < cachedFail.expiresAt) {
    return { url: null, error: cachedFail.error, aborted: false, cached: true };
  }

  const first = await getDirectUrl(spec.cacheKey, spec.target, spec.format, signal);
  if (first.aborted || signal.aborted) {
    return { url: null, error: first.error, aborted: true, cached: false };
  }

  let url = first.url;
  let error = first.error;

  if (!url && spec.query && spec.title) {
    // Tam sorgu sıfır sonuç verirse (uzun kuyruklu/parantezli başlıklar)
    // başlığa düşülerek video bulunur, akış o adresten çözülür.
    const fallbackId = await resolveYoutubeVideoId(
      spec.title,
      spec.artist,
      spec.expectedDuration,
      signal,
      "playback",
    );
    if (signal.aborted) return { url: null, error, aborted: true, cached: false };
    if (fallbackId) {
      const fallback = await getDirectUrl(
        `${spec.format}:v:${fallbackId}`,
        `https://www.youtube.com/watch?v=${fallbackId}`,
        spec.format,
        signal,
      );
      if (fallback.aborted || signal.aborted) {
        return { url: null, error: fallback.error, aborted: true, cached: false };
      }
      if (fallback.url) {
        // Yedekten gelen adresi asıl anahtara da yaz: akış ucu aynı isteği
        // tekrarladığında yt-dlp bir daha çalışmasın.
        urlCache.set(spec.cacheKey, {
          url: fallback.url,
          expiresAt: Date.now() + CACHE_TTL_MS,
        });
      }
      url = fallback.url;
      error = fallback.error;
    }
  }

  if (!url && !signal.aborted) {
    failCache.set(spec.cacheKey, {
      error: error || "Ses akışı bulunamadı.",
      expiresAt: Date.now() + NEGATIVE_TTL_MS,
    });
  }
  return { url, error, aborted: false, cached: false };
}
