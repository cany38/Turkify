/**
 * Bir parcayi `Musics` klasorune yazar.
 *
 * Indirilen parcalar zaten sunucu tarafinda klasore yaziliyor; burasi
 * kullanicinin kendi yukledigi dosyalar icin. Basarili yazma sonrasi
 * sadece `true` doner, baska kayit tutulmaz.
 */
export async function syncTrackToMusics(
  trackId: string,
  fileName: string,
  blob: Blob,
): Promise<boolean> {
  void trackId; // IndexedDB kalkti; id artik disk adindan turetiliyor.
  const base = fileName.trim();
  if (!base) return false;
  const name = /\.[a-z0-9]{2,5}$/i.test(base) ? base : `${base}.mp3`;

  try {
    const res = await fetch(`/api/media/save?name=${encodeURIComponent(name)}`, {
      method: "POST",
      headers: { "Content-Type": "application/octet-stream" },
      body: blob,
    });
    if (!res.ok) return false;
    return true;
  } catch {
    // Sunucu kapaliysa sessizce gec; kullanici dosyayi blob ile dinlemeye devam eder.
    return false;
  }
}
