export interface ListeningEntry { count: number; lastPlayed: number }
export type ListeningHistory = Record<string, ListeningEntry>;
export const HISTORY_KEY = "turkify:listening-history:v1";

/** Liste dinlemeleri parca id'leriyle cakismasin diye one eklenir. */
export const PLAYLIST_HISTORY_PREFIX = "playlist:";

export function playlistHistoryKey(playlistId: string): string {
  return `${PLAYLIST_HISTORY_PREFIX}${playlistId}`;
}

export function playlistIdFromHistoryKey(key: string): string | null {
  if (!key.startsWith(PLAYLIST_HISTORY_PREFIX)) return null;
  const id = key.slice(PLAYLIST_HISTORY_PREFIX.length);
  return id ? id : null;
}

export function rankListenedTracks<T extends { id: string }>(tracks: T[], history: ListeningHistory): T[] {
  return tracks.filter((track) => Object.hasOwn(history, track.id))
    .sort((a, b) => history[b.id].count - history[a.id].count || history[b.id].lastPlayed - history[a.id].lastPlayed)
    .slice(0, 4);
}

export type FeaturedItem<T, P> =
  | { kind: "track"; track: T }
  | { kind: "playlist"; playlist: P };

/**
 * En cok dinlenenler karisik siralanir: parca ve liste ayni olcekte
 * yarisir (once sayi, sonra son dinleme). Boylece cok dinlenen liste
 * one gecer, listeden daha cok dinlenen sarki varsa sarki one gecer.
 */
export function rankFeaturedItems<T extends { id: string }, P extends { id: string }>(
  tracks: T[],
  playlists: P[],
  history: ListeningHistory,
  limit = 4,
): FeaturedItem<T, P>[] {
  const candidates: { entry: FeaturedItem<T, P>; count: number; lastPlayed: number }[] = [];
  for (const track of tracks) {
    const record = history[track.id];
    if (record) candidates.push({ entry: { kind: "track", track } as FeaturedItem<T, P>, count: record.count, lastPlayed: record.lastPlayed });
  }
  for (const playlist of playlists) {
    const record = history[playlistHistoryKey(playlist.id)];
    if (record) candidates.push({ entry: { kind: "playlist", playlist } as FeaturedItem<T, P>, count: record.count, lastPlayed: record.lastPlayed });
  }
  return candidates
    .sort((a, b) => b.count - a.count || b.lastPlayed - a.lastPlayed)
    .slice(0, limit)
    .map((candidate) => candidate.entry);
}

export function loadListeningHistory(): ListeningHistory {
  try {
    const value = JSON.parse(localStorage.getItem(HISTORY_KEY) ?? "{}");
    if (!value || typeof value !== "object" || Array.isArray(value)) return {};
    return Object.fromEntries(Object.entries(value).filter(([, entry]) => {
      const item = entry as ListeningEntry | null;
      return item && Number.isInteger(item.count) && item.count >= 0 && Number.isFinite(item.lastPlayed);
    })) as ListeningHistory;
  } catch { return {}; }
}
