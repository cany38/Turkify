/**
 * Sunucu durumu: Launcher gizli baslatir, Ayarlar en alttaki Sunucu
 * bolumu buradan okur. Test edilebilir kalsin diye saf fonksiyonlar
 * burada, Next'e ozel kisim route dosyalarinda.
 */

export const SERVER_PORT = 3401;

export function serverUrl(port: number = SERVER_PORT): string {
  return `http://127.0.0.1:${port}`;
}

export interface ServerStatus {
  running: true;
  url: string;
  uptimeSeconds: number;
  startedAt: string;
  version: string;
}

export function buildServerStatus(input: {
  startedAt: number;
  now: number;
  version: string;
  port?: number;
}): ServerStatus {
  const uptimeSeconds = Math.max(0, Math.floor((input.now - input.startedAt) / 1000));
  return {
    running: true,
    url: serverUrl(input.port),
    uptimeSeconds,
    startedAt: new Date(input.startedAt).toISOString(),
    version: input.version,
  };
}

/**
 * Durdurma istegi yalnizca bu makineden gelebilir. Host basligi
 * disaridan geliyorsa (ornegin agdaki baska cihaz) 403 dondurur.
 */
export function isLoopbackHost(host: string | null): boolean {
  if (!host) return false;
  const first = host.split(",")[0].trim().toLowerCase();
  if (!first) return false;
  const bare = first.startsWith("[")
    ? first.slice(1, first.indexOf("]") === -1 ? undefined : first.indexOf("]"))
    : first.split(":")[0];
  if (bare === "localhost" || bare === "::1") return true;
  if (bare.endsWith(".localhost")) return true;
  return /^127\.(\d{1,3}\.){2}\d{1,3}$/.test(bare);
}
