import type { ExternalTrack, LibraryState, Playlist } from "./types";
import { cleanExternalTracks } from "./library-identity";
import { getAllTracksFromDB } from "./audio-db";

export const LIBRARY_STORAGE_KEY = "turkify:library:v1";
export const LIBRARY_STORAGE_VERSION = 1;
/** Eski `local-...` id'lerin `disk-...` karsiligina tasindigini isaretler. */
export const DISK_ID_MIGRATION_KEY = "turkify:disk-id-migration:v1";

interface StoredLibrary {
  version: number;
  likedIds: string[];
  playlists: Playlist[];
  removedTrackIds: string[];
  externalTracks: ExternalTrack[];
}

function isStringArray(value: unknown): value is string[] {
  return Array.isArray(value) && value.every((item) => typeof item === "string");
}

function isPlaylist(value: unknown): value is Playlist {
  if (typeof value !== "object" || value === null) return false;
  const v = value as Record<string, unknown>;
  return (
    typeof v.id === "string" &&
    typeof v.name === "string" &&
    Array.isArray(v.trackIds) &&
    (v.trackIds as unknown[]).every((t) => typeof t === "string") &&
    typeof v.createdAt === "number"
  );
}

/** blob: gibi gecici URL id'leri kalici kayda yazilmaz; yerel parcalar IndexedDB'de saklandigi icin id'leri kalicidir. */
export function isPersistableTrackId(id: string): boolean {
  return !id.startsWith("blob:");
}

function sanitize(input: LibraryState): StoredLibrary {
  const likedIds = input.likedIds.filter(
    (id) => typeof id === "string" && isPersistableTrackId(id),
  );
  const playlists = input.playlists
    .filter((p) => isPlaylist(p))
    .map((p) => ({
      ...p,
      name: p.name.trim().slice(0, 60),
      trackIds: p.trackIds.filter(
        (id) => typeof id === "string" && isPersistableTrackId(id),
      ),
    }));
  const removedTrackIds = input.removedTrackIds.filter(
    (id) => typeof id === "string" && isPersistableTrackId(id),
  );
  // Harici kopyalar id tabanlı değil, bütün kayıt temizlenip taşınır.
  const externalTracks = cleanExternalTracks(input.externalTracks);
  return { version: LIBRARY_STORAGE_VERSION, likedIds, playlists, removedTrackIds, externalTracks };
}

export function loadLibrary(): LibraryState | null {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return null;
    const raw = window.localStorage.getItem(LIBRARY_STORAGE_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (typeof parsed !== "object" || parsed === null) return null;
    const obj = parsed as Record<string, unknown>;
    if (obj.version !== LIBRARY_STORAGE_VERSION) return null;
    const likedIds = isStringArray(obj.likedIds) ? obj.likedIds : [];
    const playlists = Array.isArray(obj.playlists)
      ? (obj.playlists as unknown[]).filter(isPlaylist)
      : [];
    const removedTrackIds = isStringArray(obj.removedTrackIds)
      ? obj.removedTrackIds
      : [];
    const cleaned = sanitize({ likedIds, playlists, removedTrackIds, externalTracks: cleanExternalTracks(obj.externalTracks) });
    return {
      likedIds: cleaned.likedIds,
      playlists: cleaned.playlists,
      removedTrackIds: cleaned.removedTrackIds,
      externalTracks: cleaned.externalTracks,
    };
  } catch {
    // Bozuk kayıt uygulamayı çökertmesin; yok say.
    return null;
  }
}

export function saveLibrary(state: LibraryState): boolean {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return false;
    const payload = sanitize(state);
    window.localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(payload));
    return true;
  } catch {
    // Kota dolması / erişim engeli sessizce yok sayılır.
    return false;
  }
}

/**
 * Tek seferlik tasima: eski IndexedDB id'lerini disk adlarina cevirir.
 *
 * Parca kimligi `local-<zaman>-<rastgele>` yerine `disk-<dosyaadi>` oldu.
 * Begeniler ve listeler eski id'leri tasidigi icin, bir esleme yapilmazsa
 * kullanicinin tum begenileri ve listeleri bosalirdi. Esleme IndexedDB'de
 * duran eski kayitlarin `fileName` alanindan cikariliyor.
 *
 * `useLibrary` bunu `loadLibrary()` cagrisindan ONCE bekler; sirasi onemli.
 */
export async function migrateLocalIdsToDisk(): Promise<void> {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return;
    if (window.localStorage.getItem(DISK_ID_MIGRATION_KEY)) return;

    const stored = await getAllTracksFromDB();
    const mapping = new Map<string, string>();
    for (const item of stored ?? []) {
      const fileName = item.fileName?.trim();
      if (fileName) mapping.set(item.id, `disk-${fileName}`);
    }

    if (mapping.size > 0) {
      const current = loadLibrary();
      if (current) {
        const remap = (id: string) => mapping.get(id) ?? id;
        const unique = (ids: string[]) => Array.from(new Set(ids.map(remap)));
        saveLibrary({
          likedIds: unique(current.likedIds),
          playlists: current.playlists.map((p) => ({
            ...p,
            trackIds: unique(p.trackIds),
          })),
          removedTrackIds: unique(current.removedTrackIds),
          externalTracks: current.externalTracks,
        });
      }
    }

    window.localStorage.setItem(DISK_ID_MIGRATION_KEY, "1");
  } catch (err) {
    // Tasima basarisiz olursa mevcut veriyi bozma; bayrak da konmaz, tekrar denenir.
    console.error("Disk id tasimasi basarisiz", err);
  }
}
