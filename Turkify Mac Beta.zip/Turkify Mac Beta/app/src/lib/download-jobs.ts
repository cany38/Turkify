/**
 * Suregiden indirme islerinin iptal kaydi: progressId -> oldur.
 *
 * Ayri modulde durur cunku route dosyalari yalniz rota islevi disa
 * acabilir; paylasilan kayit burada yasar, iki rota da buradan kullanir.
 * HMR'da sifirlanmamasi icin globalThis uzerinde tutulur.
 */

const holder = globalThis as typeof globalThis & {
  __turkifyDownloadKills?: Map<string, () => void>;
};

export const downloadKills: Map<string, () => void> =
  holder.__turkifyDownloadKills ?? (holder.__turkifyDownloadKills = new Map());

/** İptal ucunun da kullandığı gövde doğrulama. */
export function parseCancelBody(body: unknown): { progressIds: string[] } | null {
  if (typeof body !== "object" || body === null) return null;
  const record = body as Record<string, unknown>;
  const raw =
    record.progressIds !== undefined
      ? record.progressIds
      : record.progressId !== undefined
        ? [record.progressId]
        : null;
  if (!Array.isArray(raw)) return null;
  const ids = raw.filter(
    (id): id is string => typeof id === "string" && /^[a-zA-Z0-9-]{1,80}$/.test(id),
  );
  return ids.length > 0 ? { progressIds: ids } : null;
}
