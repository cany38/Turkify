import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";
import { MUSICS_DIR } from "./musics-dir";

/**
 * `Musics` klasöründeki bilgi dosyası: indirilen her parçanın başlık, sanatçı,
 * albüm, kaynak ve kapak dosya adı burada durur.
 *
 * Liste eskiden dosya adı dışındaki tüm bilgiyi düşürüyordu; kapak her açılışta
 * liste sırasına göre yeniden atanıyordu. Bu dosya o kaybı kapatır. Kaydı
 * olmayan dosyalar (kullanıcının elle attıkları) eskisi gibi dosya adından
 * türetilir, çalışmaya devam eder.
 *
 * Yalnızca sunucu tarafı: `fs`/`path` kullandığı için istemci paketine girmemeli.
 */

export const TRACK_META_FILE = ".turkify-meta.json";

export interface TrackMetaEntry {
  title: string;
  artist: string;
  album: string;
  origin?: "spotify" | "youtube";
  coverFile?: string;
  /**
   * İndirildiği arama kaydının id'si (`youtube-<videoId>`, `spotify-<id>`).
   * Arama satırındaki Download düğmesi buradan grileşir, iki kez indirilmez.
   */
  externalId?: string;
  /** Dosya adi/uzantisi degisse de begeni ve listelerde sabit kalan kimlik. */
  libraryId?: string;
  /** Codec migration öncesindeki dosya adları; eski localStorage ID'leri için. */
  previousFileNames?: string[];
  updatedAt: number;
}

export type TrackMetaMap = Record<string, TrackMetaEntry>;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** Bozuk veya yabancı alanlı kayıtlar listeyi bozmasın diye süzülür. */
export function isMetaEntry(value: unknown): value is TrackMetaEntry {
  if (!isRecord(value)) return false;
  if (typeof value.title !== "string") return false;
  if (typeof value.artist !== "string") return false;
  if (typeof value.album !== "string") return false;
  if (value.origin !== undefined && value.origin !== "spotify" && value.origin !== "youtube") {
    return false;
  }
  if (value.coverFile !== undefined) {
    if (typeof value.coverFile !== "string") return false;
    const base = path.basename(value.coverFile);
    if (base !== value.coverFile || base.startsWith(".")) return false;
  }
  if (value.externalId !== undefined) {
    if (typeof value.externalId !== "string") return false;
    if (value.externalId.length === 0 || value.externalId.length > 120) return false;
    if (value.externalId.includes("/") || value.externalId.includes("\\")) return false;
  }
  if (value.libraryId !== undefined) {
    if (typeof value.libraryId !== "string") return false;
    if (!/^[A-Za-z0-9_-]{1,120}$/.test(value.libraryId)) return false;
  }
  if (value.previousFileNames !== undefined) {
    if (!Array.isArray(value.previousFileNames) || value.previousFileNames.length > 50) {
      return false;
    }
    if (
      value.previousFileNames.some(
        (fileName) =>
          typeof fileName !== "string" ||
          !fileName ||
          fileName.startsWith(".") ||
          path.basename(fileName) !== fileName,
      )
    ) {
      return false;
    }
  }
  if (typeof value.updatedAt !== "number" || !Number.isFinite(value.updatedAt)) return false;
  return true;
}

/** Dosya yoksa veya bozuksa boş döner; bu hata değil, kayıtsız parça demek. */
export async function readTrackMeta(dir: string = MUSICS_DIR): Promise<TrackMetaMap> {
  try {
    const raw = await fs.promises.readFile(path.join(dir, TRACK_META_FILE), "utf8");
    // Elle düzenlenen dosyalar BOM ile kaydolabilir; JSON.parse öncesi atılır.
    const parsed: unknown = JSON.parse(raw.replace(/^\uFEFF/, ""));
    if (!isRecord(parsed)) return {};
    const out: TrackMetaMap = {};
    for (const [key, value] of Object.entries(parsed)) {
      if (!key || key.startsWith(".") || path.basename(key) !== key) continue;
      if (isMetaEntry(value)) out[key] = value;
    }
    return out;
  } catch {
    return {};
  }
}

export async function writeTrackMeta(
  map: Record<string, unknown>,
  dir: string = MUSICS_DIR,
): Promise<void> {
  await fs.promises.mkdir(dir, { recursive: true });
  const target = path.join(dir, TRACK_META_FILE);
  const temporary = path.join(
    dir,
    `${TRACK_META_FILE}.tmp-${process.pid}-${randomUUID()}`,
  );
  try {
    await fs.promises.writeFile(temporary, JSON.stringify(map), "utf8");
    await fs.promises.rename(temporary, target);
  } finally {
    await fs.promises.unlink(temporary).catch(() => undefined);
  }
}

/**
 * Yazma yolları için ham okuma: doğrulanmamış girdiler bile aynen korunur.
 *
 * `ok` yalnızca dosya yoksa ya da içeriği gerçekten boşsa ve yeniden
 * yazmak güvenliyse true'dur. Dosya varken çözümlenemiyorsa KANIT KORUNUR:
 * ok=false döner ve çağıran YAZMAZ. Okuma hatasını sessizce {} sayıp
 * üzerine yazmak, tüm bilgi dosyasını tek hamlede siler.
 */
export async function readTrackMetaRaw(
  dir: string = MUSICS_DIR,
): Promise<{ ok: boolean; record: Record<string, unknown> }> {
  let raw: string;
  try {
    const data = await fs.promises.readFile(path.join(dir, TRACK_META_FILE), "utf8");
    raw = typeof data === "string" ? data : Buffer.from(data as Uint8Array).toString("utf8");
  } catch {
    return { ok: true, record: {} }; // dosya yok: sıfırdan başlanabilir
  }
  if (raw.replace(/^\uFEFF/, "").trim() === "") {
    return { ok: true, record: {} }; // boş dosya: kaybedilecek veri yok
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw.replace(/^\uFEFF/, ""));
  } catch {
    return { ok: false, record: {} };
  }
  if (!isRecord(parsed)) return { ok: false, record: {} };
  const record: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(parsed)) {
    if (!key || key.startsWith(".") || path.basename(key) !== key) continue;
    record[key] = value;
  }
  return { ok: true, record };
}

export async function saveTrackMetaEntry(
  fileName: string,
  entry: TrackMetaEntry,
  dir: string = MUSICS_DIR,
): Promise<void> {
  try {
    const { ok, record } = await readTrackMetaRaw(dir);
    if (!ok) {
      console.error("Parça bilgisi yazılamadı: bilgi dosyası okunamadı, üzerine yazılmadı");
      return;
    }
    record[fileName] = entry;
    await writeTrackMeta(record, dir);
  } catch (err) {
    console.error("Parça bilgisi yazılamadı", err);
  }
}

export async function removeTrackMetaEntry(
  fileName: string,
  dir: string = MUSICS_DIR,
): Promise<void> {
  try {
    const { ok, record } = await readTrackMetaRaw(dir);
    if (!ok) {
      console.error("Parça bilgisi silinemedi: bilgi dosyası okunamadı, dokunulmadı");
      return;
    }
    if (!(fileName in record)) return;
    delete record[fileName];
    await writeTrackMeta(record, dir);
  } catch (err) {
    console.error("Parça bilgisi silinemedi", err);
  }
}

/** Yalniz kaynagi kanitli indirmelere bir kez kalici kutuphane kimligi verir. */
export async function ensureTrackLibraryIds(
  dir: string = MUSICS_DIR,
): Promise<TrackMetaMap> {
  const { ok, record } = await readTrackMetaRaw(dir);
  if (!ok) return {};
  let changed = false;
  for (const value of Object.values(record)) {
    if (!isMetaEntry(value)) continue;
    if (value.libraryId || !value.origin || !value.externalId) continue;
    value.libraryId = randomUUID();
    changed = true;
  }
  if (changed) await writeTrackMeta(record, dir);
  return readTrackMeta(dir);
}

const PRUNE_COVER_EXTS = new Set([".jpg", ".jpeg", ".png", ".webp"]);
/** O an yazilmakta olan kapak silinmesin diye yas siniri: 5 dakika. */
const PRUNE_COVER_MIN_AGE_MS = 5 * 60 * 1000;

async function isFileIn(dir: string, name: string): Promise<boolean> {
  try {
    const stat = await fs.promises.stat(path.join(dir, name));
    return stat.isFile();
  } catch {
    return false;
  }
}

/**
 * Elle silinen parcalarin kalintilarini temizler: sesi olmayan bilgi
 * kayitlari silinir; hicbir kaydin gostermedigi ve ses kardesi olmayan
 * kapak resimleri silinir.
 *
 * Kurallar (muhafazakar):
 * - Bilgi dosyasi okunamazsa HICBIR SEY yapilmaz, kanit korunur.
 * - Yalniz bilgi dosyasindaki kayitlar ve resim uzantili kok dosyalara
 *   dokunulur; ses dosyalarina asla dokunulmaz.
 * - Yeni yazilmakta olan kapak (5 dakikadan genc) atlanir.
 * - Ayni anda inen parcanin kaydi ezilmesin diye silinecek kayitlar yazmadan
 *   hemen once tekrar dogrulanir.
 */
export async function pruneOrphanedTrackData(
  dir: string = MUSICS_DIR,
): Promise<{ removedMeta: number; removedCovers: number }> {
  const empty = { removedMeta: 0, removedCovers: 0 };
  let entries: string[];
  try {
    entries = await fs.promises.readdir(dir);
  } catch {
    return empty;
  }
  const present = new Set(entries);
  const audioStems = new Set<string>();
  for (const name of entries) {
    if (name.startsWith(".")) continue;
    const ext = path.extname(name).toLowerCase();
    if (ext && !PRUNE_COVER_EXTS.has(ext)) {
      audioStems.add(name.slice(0, name.length - ext.length).toLowerCase());
    }
  }

  const first = await readTrackMetaRaw(dir);
  if (!first.ok) return empty;
  const deadKeys = Object.keys(first.record).filter((key) => !present.has(key));

  // Yazma oncesi taze oku: araya giren indirme kaybi yasanmasin.
  const fresh = await readTrackMetaRaw(dir);
  if (!fresh.ok) return empty;
  let removedMeta = 0;
  for (const key of deadKeys) {
    if (!(key in fresh.record)) continue;
    if (await isFileIn(dir, key)) continue;
    delete fresh.record[key];
    removedMeta += 1;
  }
  // Referanslar ölü kayitlar dustukten sonra toplanir.
  const referencedCovers = new Set<string>();
  for (const value of Object.values(fresh.record)) {
    const cover = (value as { coverFile?: unknown }).coverFile;
    if (typeof cover === "string" && cover) referencedCovers.add(cover);
  }
  // Kapak baska kayda bagliysa ya da sesi duruyorsa el degmez.
  const now = Date.now();
  let removedCovers = 0;
  for (const name of entries) {
    if (name.startsWith(".")) continue;
    if (!PRUNE_COVER_EXTS.has(path.extname(name).toLowerCase())) continue;
    if (referencedCovers.has(name)) continue;
    const stem = name.slice(0, name.length - path.extname(name).length).toLowerCase();
    if (audioStems.has(stem)) continue;
    try {
      const stat = await fs.promises.stat(path.join(dir, name));
      if (!stat.isFile() || now - stat.mtimeMs < PRUNE_COVER_MIN_AGE_MS) continue;
      await fs.promises.unlink(path.join(dir, name));
      removedCovers += 1;
    } catch {
      // yok say
    }
  }
  if (removedMeta > 0) {
    try {
      await writeTrackMeta(fresh.record, dir);
    } catch {
      // kayit yazilamazsa dosya silinmis sayilmaz
      return { removedMeta: 0, removedCovers };
    }
  }
  return { removedMeta, removedCovers };
}
