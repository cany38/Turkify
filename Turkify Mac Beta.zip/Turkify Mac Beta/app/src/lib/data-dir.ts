import path from "path";
import os from "os";

/**
 * `TURKIFY_DATA_DIR` mutlak bir yola isaret ediyorsa onu, aksi halde
 * kullanicinin Library/Application Support/Turkify klasorunu kullanir.
 * Yalnizca sunucu tarafinda calisir.
 */
export function resolveDataDir(): string {
  const override = process.env.TURKIFY_DATA_DIR;
  if (
    typeof override === "string" &&
    override.trim().length > 0 &&
    path.isAbsolute(override)
  ) {
    return path.normalize(override);
  }
  return path.join(os.homedir(), "Library", "Application Support", "Turkify");
}

/** `scripts/*.py` yardimcilarinin bulundugu klasoru cozer. */
export function resolveScriptsDir(cwd = process.cwd()): string {
  const override = process.env.TURKIFY_SCRIPTS_DIR;
  if (
    typeof override === "string" &&
    override.trim().length > 0 &&
    path.isAbsolute(override)
  ) {
    return path.normalize(override);
  }
  return path.resolve(cwd, "scripts");
}
