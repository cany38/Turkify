export interface FormatInfo {
  codec: string;
  bitrate: number | null;
  ext: string;
  sampleRate: number | null;
}

const DOWNLOADED_CODEC_BY_EXTENSION: Record<string, string> = {
  aac: "aac",
  flac: "flac",
  m4a: "aac",
  mp3: "mp3",
  oga: "opus",
  ogg: "opus",
  opus: "opus",
  wav: "pcm",
  webm: "opus",
};

/**
 * Uygulamanin indirdigi dosyada codec uzantidan bellidir. Ortalama bitrate,
 * local dosya boyutu ve gercek sureden hesaplanir; remote provider yoklamasi
 * gerekmez.
 */
export function inferDownloadedFormatInfo(
  fileName: string,
  fileSize: number | undefined,
  duration: number,
): FormatInfo | null {
  const match = /\.([A-Za-z0-9]+)$/.exec(fileName.trim());
  const ext = match?.[1]?.toLowerCase() ?? "";
  const codec = DOWNLOADED_CODEC_BY_EXTENSION[ext];
  if (!codec) return null;
  const bitrate =
    typeof fileSize === "number" &&
    Number.isFinite(fileSize) &&
    fileSize > 0 &&
    Number.isFinite(duration) &&
    duration > 0
      ? Math.max(1, Math.round((fileSize * 8) / duration / 1000))
      : null;
  return { codec, bitrate, ext, sampleRate: null };
}

export const FORMAT_INFO_STORAGE_KEY = "turkify:format-info:v1";
const FORMAT_INFO_TTL_MS = 90 * 24 * 60 * 60 * 1000;
const MAX_FORMAT_INFO_ENTRIES = 5000;

interface StoredFormatInfo {
  info: FormatInfo;
  savedAt: number;
}

function isFormatInfo(value: unknown): value is FormatInfo {
  if (!value || typeof value !== "object") return false;
  const info = value as Partial<FormatInfo>;
  return (
    typeof info.codec === "string" &&
    info.codec.length > 0 &&
    info.codec.length <= 40 &&
    typeof info.ext === "string" &&
    info.ext.length <= 20 &&
    (info.bitrate === null || (typeof info.bitrate === "number" && Number.isFinite(info.bitrate))) &&
    (info.sampleRate === null || (typeof info.sampleRate === "number" && Number.isFinite(info.sampleRate)))
  );
}

function readEntries(now: number): Record<string, StoredFormatInfo> {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return {};
    const parsed = JSON.parse(window.localStorage.getItem(FORMAT_INFO_STORAGE_KEY) ?? "{}");
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    const valid: Record<string, StoredFormatInfo> = {};
    for (const [key, raw] of Object.entries(parsed)) {
      if (!raw || typeof raw !== "object" || key.length > 240) continue;
      const entry = raw as Partial<StoredFormatInfo>;
      if (
        typeof entry.savedAt !== "number" ||
        !Number.isFinite(entry.savedAt) ||
        now - entry.savedAt > FORMAT_INFO_TTL_MS ||
        !isFormatInfo(entry.info)
      ) continue;
      valid[key] = { info: entry.info, savedAt: entry.savedAt };
    }
    return valid;
  } catch {
    return {};
  }
}

export function readStoredFormatInfo(now = Date.now()): Record<string, FormatInfo> {
  return Object.fromEntries(
    Object.entries(readEntries(now)).map(([key, entry]) => [key, entry.info]),
  );
}

export function storeFormatInfo(key: string, info: FormatInfo, now = Date.now()): boolean {
  try {
    if (typeof window === "undefined" || !("localStorage" in window) || !isFormatInfo(info)) return false;
    const entries = readEntries(now);
    entries[key] = { info, savedAt: now };
    const limited = Object.fromEntries(
      Object.entries(entries)
        .sort(([, a], [, b]) => b.savedAt - a.savedAt)
        .slice(0, MAX_FORMAT_INFO_ENTRIES),
    );
    window.localStorage.setItem(FORMAT_INFO_STORAGE_KEY, JSON.stringify(limited));
    return true;
  } catch {
    return false;
  }
}
