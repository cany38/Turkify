/**
 * 16-bit PCM WAV yazici.
 *
 * Remix cikisi tarayicida uretiliyor ve tarayicida mp3/m4a kodlayici yok;
 * WAV kayipsiz ve ek bagimlilik istemeyen tek secenek. Dosya buyuk oluyor,
 * ama cikan sey kullanicinin duydugunun birebir ayni.
 *
 * Saf fonksiyonlar: tarayici API'si kullanmaz, Node'da test edilebilir.
 */

export const WAV_HEADER_BYTES = 44;

/** Kare sayisindan dosya boyutu; on-kontrol ve test icin. */
export function wavByteLength(frames: number, channelCount: number): number {
  return WAV_HEADER_BYTES + frames * channelCount * 2;
}

/**
 * Tepe deger 1.0'i asiyorsa tum orneklere uygulanacak kucultme carpani.
 *
 * Bass boost ile reverb birlesince cikis 1.0'i gecebiliyor. Sertce kirpmak
 * duyulur bozulma birakir; tek carpanla kucultmek yalnizca sesi biraz kisar,
 * dalga sekli bozulmaz. 1.0 altinda kalan sinyale hic dokunulmaz (carpan 1).
 */
export function peakScale(channels: Float32Array[]): number {
  let peak = 0;
  for (const channel of channels) {
    for (let i = 0; i < channel.length; i += 1) {
      const value = Math.abs(channel[i]);
      if (Number.isFinite(value) && value > peak) peak = value;
    }
  }
  return peak > 1 ? 1 / peak : 1;
}

function writeAscii(view: DataView, offset: number, text: string): void {
  for (let i = 0; i < text.length; i += 1) {
    view.setUint8(offset + i, text.charCodeAt(i));
  }
}

/** Kanallar ayri Float32Array'ler olarak gelir (Web Audio'nun verdigi bicim). */
export function encodeWav(channels: Float32Array[], sampleRate: number): ArrayBuffer {
  const channelCount = channels.length;
  if (channelCount === 0) throw new Error("WAV icin en az bir kanal gerekir.");
  const frames = channels[0].length;
  for (const channel of channels) {
    if (channel.length !== frames) throw new Error("Kanal uzunluklari esit olmali.");
  }
  if (!Number.isInteger(sampleRate) || sampleRate <= 0) {
    throw new Error("Gecersiz ornekleme hizi.");
  }

  const scale = peakScale(channels);
  const dataBytes = frames * channelCount * 2;
  const buffer = new ArrayBuffer(WAV_HEADER_BYTES + dataBytes);
  const view = new DataView(buffer);

  writeAscii(view, 0, "RIFF");
  view.setUint32(4, 36 + dataBytes, true);
  writeAscii(view, 8, "WAVE");
  writeAscii(view, 12, "fmt ");
  view.setUint32(16, 16, true); // fmt bolumu uzunlugu
  view.setUint16(20, 1, true); // 1 = PCM
  view.setUint16(22, channelCount, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * channelCount * 2, true); // bayt/sn
  view.setUint16(32, channelCount * 2, true); // blok hizalama
  view.setUint16(34, 16, true); // ornek basina bit
  writeAscii(view, 36, "data");
  view.setUint32(40, dataBytes, true);

  let offset = WAV_HEADER_BYTES;
  for (let i = 0; i < frames; i += 1) {
    for (let ch = 0; ch < channelCount; ch += 1) {
      const raw = channels[ch][i] * scale;
      // NaN/Infinity sessizlige cevrilir; tek bozuk ornek dosyayi patlatmasin.
      const sample = Number.isFinite(raw) ? Math.max(-1, Math.min(1, raw)) : 0;
      view.setInt16(offset, Math.round(sample * 32767), true);
      offset += 2;
    }
  }
  return buffer;
}
