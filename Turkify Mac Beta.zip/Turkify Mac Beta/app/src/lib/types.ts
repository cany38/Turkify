interface BaseTrack {
  id: string;
  title: string;
  artist: string;
  album: string;
  /** Süre (saniye). Bilinmiyorsa 0. */
  duration: number;
  /** /covers/... gibi lokal yol veya uzak kapak URL'i */
  cover: string;
  /** Birincil kapak yüklenemezse kullanılacak yerel yedek. */
  fallbackCover?: string;
}

export type TrackSource = "library" | "local" | "spotify" | "youtube";

/** Spotify arama sonucu: harici katalog kaydı, doğrudan çalınamaz. */
export interface SpotifyTrack extends BaseTrack {
  source: "spotify";
  /** Spotify web URL'i */
  externalUrl: string;
  /** 30sn önizleme URL'i (varsa) */
  previewUrl: string | null;
}

/** YouTube arama sonucu: harici katalog kaydı, doğrudan çalınamaz. */
export interface YoutubeTrack extends BaseTrack {
  source: "youtube";
  /** YouTube video ID */
  videoId: string;
  /** YouTube watch URL'i */
  externalUrl: string;
}

export type ExternalTrack = SpotifyTrack | YoutubeTrack;

export type SearchSource = "local" | "spotify" | "youtube" | "mixed";

export interface SearchApiResponse {
  source: SearchSource;
  query: string;
  results: ExternalTrack[];
  /** Kismi basarisizlikta saglayici bazli hata mesajlari */
  errors?: string[];
  /** Spotify anahtari eksik ya da reddedildi; arayuz giris panelini gosterir */
  needsSpotifyKeys?: boolean;
  needsYoutubeKey?: boolean;
  /** YouTube günlük kotası doldu (429); ham hata metni yerine kısa uyarı gösterilir */
  youtubeQuotaExceeded?: boolean;
  /** Sonraki Spotify sayfasi icin offset; Spotify tukendiyse tanimsiz. */
  nextSpotifyOffset?: number;
  /** YouTube'un verdigi sayfa tokeni; son sayfadaysa tanimsiz. */
  nextYoutubePageToken?: string;
}

/** Tarayicida saklanan Spotify API anahtarlari (harici arama icin). */
export interface SpotifyKeys {
  clientId: string;
  clientSecret: string;
}

export interface ImportedPlaylistTrack extends BaseTrack {
  /** Kaynak servis; eski kayıtlarda yok, okunurken spotify varsayılır. */
  source: "spotify" | "youtube";
  spotifyId?: string;
  spotifyUrl?: string;
  youtubeId?: string;
  youtubeUrl?: string;
  localTrackId?: string;
}

/** YouTube Data API v3 anahtari; yalniz tarayicida saklanir. */
export interface YoutubeKey {
  apiKey: string;
}

/** Yerel kütüphane kaydı: `public/audio` altındaki tam parça. */
export interface LibraryTrack extends BaseTrack {
  source: "library";
  /** Kök-göreli tam parça URL'i (örn. `/audio/example.mp3`). */
  url: string;
}

/** Kullanıcının oturumluk yüklediği dosya. */
export interface LocalTrack extends BaseTrack {
  source: "local";
  /** Session'luk object URL (yalnızca local track'ler). Persist edilmez. */
  objectUrl?: string;
  /** Yüklenen dosyanın adı (yalnızca local). */
  fileName?: string;
  /** Local dosyanın bayt cinsinden boyutu; ortalama bitrate hesabı için. */
  fileSize?: number;
  /**
   * Parçanın hangi servisten indirildiği. Kullanıcının kendi yüklediği
   * dosyalarda tanımsızdır; rozet yalnızca bu alan doluyken gösterilir.
   */
  origin?: "spotify" | "youtube";
  /** İndirmeyi başlatan harici katalog kaydı; yerel oynatma eşlemesi için. */
  externalId?: string;
}

export type Track = LibraryTrack | LocalTrack;

export interface Playlist {
  id: string;
  name: string;
  trackIds: string[];
  importedTracks?: ImportedPlaylistTrack[];
  spotifyId?: string;
  youtubeId?: string;
  createdAt: number;
  /** Liste kapagi: kullanicinin sectigi gorselin data URL'i. Yoksa varsayilan gorunum. */
  cover?: string;
}

export interface LibraryState {
  likedIds: string[];
  playlists: Playlist[];
  /** Kullanıcının uygulama kataloğundan kaldırdığı kalıcı parça id'leri. */
  removedTrackIds: string[];
  /**
   * İndirilmemiş arama sonuçlarının Beğenilenler/liste görünümünde
   * çalınabilmesi için saklanan kopyası (id ile eşleşir).
   */
  externalTracks: ExternalTrack[];
}

export type RepeatMode = "off" | "context" | "one";

export type MainView = "home" | "search" | "library" | "liked" | "playlist" | "settings";

export interface CreatePlaylistResult {
  ok: boolean;
  message: string;
  playlist?: Playlist;
}

export interface PlaylistMutationResult {
  ok: boolean;
  message: string;
}
