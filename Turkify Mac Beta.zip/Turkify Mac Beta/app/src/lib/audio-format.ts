export type AudioFormat = "aac" | "opus";

export const DEFAULT_AUDIO_FORMAT: AudioFormat = "aac";
export const AUDIO_FORMAT_STORAGE_KEY = "turkify:audio-format:v1";

export type ParsedAudioFormat =
  | { ok: true; value: AudioFormat }
  | { ok: false; value: null };

export type AudioFormatTarget =
  | { id: string; source: "youtube"; videoId: string }
  | {
      id: string;
      source: "spotify";
      title: string;
      artist: string;
      externalUrl?: string;
    };

/** Eksik eski istekler AAC kalır; bilinmeyen değerler sessizce kabul edilmez. */
export function parseAudioFormat(value: unknown): ParsedAudioFormat {
  if (value === null || value === undefined || value === "") {
    return { ok: true, value: DEFAULT_AUDIO_FORMAT };
  }
  if (value === "aac" || value === "opus") {
    return { ok: true, value };
  }
  return { ok: false, value: null };
}

export function getYtDlpSelector(format: AudioFormat): string {
  return format === "opus" ? "bestaudio[acodec=opus]" : "bestaudio[ext=m4a]";
}

/** yt-dlp'nin seçilen videoda native Opus akışı bulamadığı özel durum. */
export function isRequestedAudioFormatUnavailable(
  format: AudioFormat,
  output: string,
): boolean {
  return format === "opus" && /requested format is not available/i.test(output);
}

export function getSpotDlFormat(format: AudioFormat): "m4a" | "opus" {
  return format === "opus" ? "opus" : "m4a";
}

export function audioFormatExtension(format: AudioFormat): ".m4a" | ".opus" {
  return format === "opus" ? ".opus" : ".m4a";
}

export function buildFormatSearchParams(
  format: AudioFormat,
  target: AudioFormatTarget,
): string {
  const params = new URLSearchParams();
  if (target.source === "youtube") {
    params.set("v", target.videoId);
  } else {
    params.set("q", `${target.title} ${target.artist}`.trim());
    // Tam sorgu sıfır sonuç verirse sunucu başlığa düşer.
    params.set("title", target.title);
    params.set("artist", target.artist);
  }
  params.set("format", format);
  return params.toString();
}

export function buildFormatCacheKey(
  format: AudioFormat,
  target: AudioFormatTarget,
): string {
  return `${format}:${target.id}`;
}

export function matchesAudioFormat(
  format: AudioFormat,
  codec: string,
  extension: string,
): boolean {
  const normalizedCodec = codec.trim().toLowerCase();
  const rawExtension = extension.trim().toLowerCase();
  const normalizedExtension = rawExtension.startsWith(".")
    ? rawExtension
    : `.${rawExtension}`;

  if (format === "opus") {
    return (
      normalizedCodec === "opus" &&
      [".opus", ".ogg", ".oga", ".webm"].includes(normalizedExtension)
    );
  }

  return (
    (normalizedCodec === "aac" || normalizedCodec.startsWith("mp4a")) &&
    normalizedExtension === ".m4a"
  );
}

export function readStoredAudioFormat(): AudioFormat | null {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return null;
    const parsed = parseAudioFormat(window.localStorage.getItem(AUDIO_FORMAT_STORAGE_KEY));
    return parsed.ok ? parsed.value : null;
  } catch {
    return null;
  }
}

export function writeStoredAudioFormat(format: AudioFormat): boolean {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return false;
    window.localStorage.setItem(AUDIO_FORMAT_STORAGE_KEY, format);
    return true;
  } catch {
    return false;
  }
}
