import fs from "fs";
import path from "path";
import { resolveDataDir } from "./data-dir";

/**
 * Tum muzik dosyalarinin tek adresi: veri kokundeki `Musics` klasoru.
 *
 * Next `app/` icinden calisiyor, klasor ise onun bir ustunde duruyor. Hem
 * kutuphanedeki hazir parcalar hem indirilen her parca buraya yazilir; baska
 * bir ses klasoru yok.
 *
 * Paketlenmis masaustu uygulamasinda veri koku `TURKIFY_DATA_DIR` ile
 * verilir (ayni arsiv gosterilir); tanimsizsa davranis degismez.
 *
 * Yalnizca sunucu tarafi: `fs`/`path` kullandigi icin istemci paketine girmemeli.
 */
export const MUSICS_DIR = path.join(resolveDataDir(), "Musics");

/** Var olan dosyanin ustune yazmamak icin " (2)", " (3)" diye ilerler. */
export async function uniqueTargetName(dir: string, desired: string): Promise<string> {
  const ext = path.extname(desired);
  const stem = desired.slice(0, desired.length - ext.length);
  let candidate = desired;
  for (let i = 2; i < 500; i++) {
    try {
      await fs.promises.access(path.join(dir, candidate));
    } catch {
      return candidate; // yok, kullanilabilir
    }
    candidate = `${stem} (${i})${ext}`;
  }
  return `${stem} (${Date.now()})${ext}`;
}

/** Dosya adindan Windows'ta gecersiz olan karakterleri temizler. */
export function sanitizeMusicFileName(value: string): string {
  const cleaned = value.replace(/[\\/:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim();
  const sliced = cleaned.slice(0, 80).trim();
  return sliced.length > 0 ? sliced : "parca";
}
