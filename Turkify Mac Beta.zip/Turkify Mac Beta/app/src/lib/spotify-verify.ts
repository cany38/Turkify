/**
 * Spotify anahtar dogrulamasinin ortak sozlesmesi.
 *
 * Dogrulama tek bir POST istegi ile calisir ve sonuclar NDJSON olarak
 * adim adim akar; boylece panel her adimi bittigi anda isaretleyebilir.
 */

/** `format` istemcide, digerleri sunucuda kosar. */
export type VerifyStepId = "format" | "token" | "search";

export type VerifyStatus = "pending" | "running" | "ok" | "fail";

export interface VerifyEvent {
  step: VerifyStepId;
  status: VerifyStatus;
  /** Yalnizca `fail` durumunda dolu. */
  message?: string;
}

export const VERIFY_STEP_ORDER: VerifyStepId[] = ["format", "token", "search"];

/** Bir NDJSON satirinin gecerli olay olup olmadigini dogrular. */
export function isVerifyEvent(value: unknown): value is VerifyEvent {
  if (typeof value !== "object" || value === null) return false;
  const v = value as Record<string, unknown>;
  if (typeof v.step !== "string" || typeof v.status !== "string") return false;
  if (!VERIFY_STEP_ORDER.includes(v.step as VerifyStepId)) return false;
  return ["pending", "running", "ok", "fail"].includes(v.status);
}
