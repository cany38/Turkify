import type { ChildProcess } from "node:child_process";

/**
 * Yaşayan yardımcı süreçlerin kaydı.
 *
 * Neden var: ölçüm gösterdi ki istemci bağlantıyı kesince sunucudaki
 * `python`/`yt-dlp`/`spotdl` süreci ölmüyor — tek bir kodek yoklaması 7 süreç
 * doğuruyor ve bağlantı kapandıktan 15 saniye sonra hepsi hâlâ ayaktaydı.
 * `request.signal`'e güvenmek yetmiyor.
 *
 * Bu yüzden süreçler amaçlarıyla kaydediliyor: kullanıcı bir parçaya
 * bastığında çalma ucu, kozmetik iş yapan ("badge") süreçlerin hepsini
 * doğrudan öldürüyor. Kullanıcının kuralı basit: tıklandığında ne iş varsa
 * bırakılır.
 *
 * Kayıt `globalThis` üzerinde: geliştirme modunda modül yeniden yüklenince
 * çalışan süreçlerin izi kaybolmasın.
 */

export type ChildPurpose = "badge" | "playback" | "download";

interface Entry {
  child: ChildProcess;
  purpose: ChildPurpose;
}

const registryGlobal = globalThis as typeof globalThis & {
  __turkifyChildRegistry?: Map<number, Entry>;
  __turkifyChildSeq?: number;
};
const registry = (registryGlobal.__turkifyChildRegistry ??= new Map<number, Entry>());

function nextId(): number {
  const current = registryGlobal.__turkifyChildSeq ?? 0;
  registryGlobal.__turkifyChildSeq = current + 1;
  return current;
}

/**
 * Süreci kaydeder. Dönen fonksiyon kaydı düşürür; süreç bittiğinde mutlaka
 * çağrılmalı, yoksa kayıt ölü süreçlerle şişer.
 */
export function registerChild(child: ChildProcess, purpose: ChildPurpose): () => void {
  const id = nextId();
  registry.set(id, { child, purpose });
  let released = false;
  return () => {
    if (released) return;
    released = true;
    registry.delete(id);
  };
}

/**
 * Belirtilen amaçtaki tüm süreçleri öldürür ve kaç tanesini öldürdüğünü
 * döner. Kayıt burada silinmez: süreç `close` verince kendi bırakma
 * fonksiyonunu çağırıp temizlenir, böylece iki kez silme yarışı olmaz.
 */
export function killByPurpose(purpose: ChildPurpose): number {
  let killed = 0;
  for (const entry of registry.values()) {
    if (entry.purpose !== purpose) continue;
    if (entry.child.exitCode !== null || entry.child.signalCode !== null) continue;
    try {
      entry.child.kill();
      killed += 1;
    } catch {
      // Süreç zaten ölmüş olabilir; kayıt `close` ile temizlenecek.
    }
  }
  return killed;
}

/** Yalnızca gözlem/test için: amaca göre yaşayan süreç sayısı. */
export function countByPurpose(purpose: ChildPurpose): number {
  let total = 0;
  for (const entry of registry.values()) {
    if (entry.purpose === purpose) total += 1;
  }
  return total;
}

/** Yalnızca test için: kaydı boşaltır. Süreçleri öldürmez. */
export function resetChildRegistry(): void {
  registry.clear();
}
