/**
 * `Content-Disposition` basligi icin dosya adi tasiyicisi.
 *
 * Baslik degerleri Latin-1 (ByteString) olmak zorunda; Fransizca kesme
 * isareti (’), s, g gibi karakterler `Headers.set` icinde patlar ve
 * indirme BASARILI olsa bile istemciye 500 doner. Bu yuzden RFC 5987:
 * duz `filename` yalniz ASCII tasir, gercek ad `filename*` UTF-8 ile gelir.
 */

function encodeRfc5987(value: string): string {
  return encodeURIComponent(value).replace(/['()*!]/g, (c) =>
    `%${c.charCodeAt(0).toString(16).toUpperCase()}`,
  );
}

export function buildContentDisposition(fileName: string): string {
  const cleaned = fileName.replace(/"/g, "");
  const ascii = cleaned.replace(/[^\x20-\x7E]/g, "_").trim() || "parca";
  return `inline; filename="${ascii}"; filename*=UTF-8''${encodeRfc5987(cleaned)}`;
}

/** Yanittaki dosya adini okur; once `filename*`, yoksa duz `filename`. */
export function parseDispositionFileName(header: string): string | undefined {
  const encoded = /filename\*=UTF-8''([^;]+)/i.exec(header)?.[1];
  if (encoded !== undefined) {
    const text = encoded.trim();
    if (!text) return undefined;
    try {
      return decodeURIComponent(text);
    } catch {
      return text;
    }
  }
  const plain =
    /filename="([^"]+)"/.exec(header)?.[1] ?? /filename=([^;]+)/.exec(header)?.[1];
  const cleaned = plain?.replace(/[";]/g, "").trim();
  return cleaned || undefined;
}
