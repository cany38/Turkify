import type { Playlist } from "./types";

/**
 * Liste kapagi: kullanici gorsel yuklediyse o, yoksa listeye ozel sablon.
 * Kapaksiz liste gosterilmez; secim id'den turetilir, her acilista aynidir.
 */
const TEMPLATE_ARTWORK = [
  "/covers/demo-01.svg",
  "/covers/demo-02.svg",
  "/covers/demo-03.svg",
  "/covers/demo-04.svg",
  "/covers/demo-05.svg",
  "/covers/demo-06.svg",
  "/covers/demo-07.svg",
  "/covers/demo-08.svg",
  "/covers/demo-09.svg",
  "/covers/demo-10.svg",
];

export function playlistArtwork(
  playlist: Pick<Playlist, "id" | "cover">,
): string {
  if (playlist.cover) return playlist.cover;
  let hash = 5381;
  const id = playlist.id || "playlist";
  for (let i = 0; i < id.length; i++) {
    hash = ((hash << 5) + hash + id.charCodeAt(i)) | 0;
  }
  return TEMPLATE_ARTWORK[(hash >>> 0) % TEMPLATE_ARTWORK.length] ?? "/covers/demo-01.svg";
}
