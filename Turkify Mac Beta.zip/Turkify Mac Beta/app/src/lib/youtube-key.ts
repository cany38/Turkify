import type { YoutubeKey } from "./types";

export const YOUTUBE_KEY_STORAGE_KEY = "turkify:youtube-key:v1";

/** Google API anahtarlari "AIza" + 35 karakter bicimindedir. */
const API_KEY_RE = /^AIza[0-9A-Za-z_-]{35}$/;

/** Sekil + bicim dogrulamasi; yanlis kopyalamayi kayda gecirmeden yakalar. */
export function isValidYoutubeKey(input: unknown): input is YoutubeKey {
  if (typeof input !== "object" || input === null) return false;
  const v = input as Record<string, unknown>;
  if (typeof v.apiKey !== "string") return false;
  return API_KEY_RE.test(v.apiKey.trim());
}

export function isValidYoutubeApiKey(value: string): boolean {
  return API_KEY_RE.test(value.trim());
}

export function loadYoutubeKey(): YoutubeKey | null {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return null;
    const raw = window.localStorage.getItem(YOUTUBE_KEY_STORAGE_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (!isValidYoutubeKey(parsed)) return null;
    return { apiKey: parsed.apiKey.trim() };
  } catch {
    // Bozuk kayit uygulamayi cokertmesin; yok say.
    return null;
  }
}

export function saveYoutubeKey(key: YoutubeKey): boolean {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return false;
    if (!isValidYoutubeKey(key)) return false;
    window.localStorage.setItem(
      YOUTUBE_KEY_STORAGE_KEY,
      JSON.stringify({ apiKey: key.apiKey.trim() }),
    );
    return true;
  } catch {
    // Kota dolmasi / erisim engeli sessizce yok sayilir.
    return false;
  }
}

export function clearYoutubeKey(): boolean {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return false;
    window.localStorage.removeItem(YOUTUBE_KEY_STORAGE_KEY);
    return true;
  } catch {
    // Erisim engeli sessizce yok sayilir.
    return false;
  }
}
