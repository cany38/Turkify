import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";

import {
  matchesAudioFormat,
  type AudioFormat,
} from "./audio-format";
import {
  ensureTrackLibraryIds,
  isMetaEntry,
  readTrackMetaRaw,
  writeTrackMeta,
} from "./track-meta";

export const CODEC_MIGRATION_FILE = ".turkify-codec-migration.json";

const AUDIO_EXTENSIONS = new Set([
  ".mp3",
  ".m4a",
  ".aac",
  ".opus",
  ".ogg",
  ".oga",
  ".webm",
  ".wav",
  ".flac",
]);
const MIN_REPLACEMENT_BYTES = 1_024;
const MAX_REPLACEMENT_BYTES = 80 * 1024 * 1024;

export type CodecMigrationTrackState =
  | "pending"
  | "downloading"
  | "replacement_ready"
  | "metadata_committed"
  | "completed"
  | "skipped"
  | "failed";

export interface CodecMigrationFailure {
  libraryId: string;
  title: string;
  code:
    | "download_failed"
    | "invalid_replacement"
    | "metadata_failed"
    | "cleanup_failed";
  message: string;
}

export interface CodecMigrationTrack {
  libraryId: string;
  title: string;
  origin: "spotify" | "youtube";
  externalId: string;
  oldFileName: string;
  replacementFileName?: string;
  state: CodecMigrationTrackState;
  error?: CodecMigrationFailure;
}

export interface CodecMigrationJob {
  version: 1;
  id: string;
  format: AudioFormat;
  state: "running" | "completed";
  createdAt: number;
  updatedAt: number;
  manualCount: number;
  tracks: CodecMigrationTrack[];
  total: number;
  completed: number;
  succeeded: number;
  skipped: number;
  failed: number;
  percent: number;
  currentTitle?: string;
  failures: CodecMigrationFailure[];
}

interface CodecMigrationDependencies {
  musicsDir: string;
  download(input: {
    origin: "spotify" | "youtube";
    externalId: string;
    title: string;
    format: AudioFormat;
    outputDir: string;
  }): Promise<string>;
  inspect(filePath: string): Promise<{ codec: string; ext: string }>;
  embedCover?(audioPath: string, coverPath: string): Promise<string>;
  makeId?: () => string;
  now?: () => number;
}

export class MigrationConflictError extends Error {
  constructor() {
    super("Başka bir format dönüştürme işlemi zaten devam ediyor.");
    this.name = "MigrationConflictError";
  }
}

export class InvalidMigrationStateError extends Error {
  constructor() {
    super("Format dönüştürme kaydı okunamadı.");
    this.name = "InvalidMigrationStateError";
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isAudioFile(fileName: string): boolean {
  return AUDIO_EXTENSIONS.has(path.extname(fileName).toLowerCase());
}

function isTerminal(state: CodecMigrationTrackState): boolean {
  return state === "completed" || state === "skipped" || state === "failed";
}

function isMetadataCommitted(track: CodecMigrationTrack): boolean {
  return track.state === "metadata_committed";
}

function withProgress(job: CodecMigrationJob): CodecMigrationJob {
  const completed = job.tracks.filter((track) => isTerminal(track.state)).length;
  const succeeded = job.tracks.filter((track) => track.state === "completed").length;
  const skipped = job.tracks.filter((track) => track.state === "skipped").length;
  const failures = job.tracks
    .map((track) => track.error)
    .filter((failure): failure is CodecMigrationFailure => Boolean(failure));
  const total = job.tracks.length;
  return {
    ...job,
    total,
    completed,
    succeeded,
    skipped,
    failed: failures.length,
    percent: total === 0 ? 100 : Math.floor((completed / total) * 100),
    failures,
  };
}

function normalizeJob(value: unknown): CodecMigrationJob {
  if (!isRecord(value) || value.version !== 1) throw new InvalidMigrationStateError();
  if (typeof value.id !== "string" || (value.format !== "aac" && value.format !== "opus")) {
    throw new InvalidMigrationStateError();
  }
  if (value.state !== "running" && value.state !== "completed") {
    throw new InvalidMigrationStateError();
  }
  if (!Array.isArray(value.tracks)) throw new InvalidMigrationStateError();

  const tracks: CodecMigrationTrack[] = value.tracks.map((item) => {
    if (!isRecord(item)) throw new InvalidMigrationStateError();
    const validState = [
      "pending",
      "downloading",
      "replacement_ready",
      "metadata_committed",
      "completed",
      "skipped",
      "failed",
    ].includes(String(item.state));
    if (
      typeof item.libraryId !== "string" ||
      typeof item.title !== "string" ||
      (item.origin !== "spotify" && item.origin !== "youtube") ||
      typeof item.externalId !== "string" ||
      typeof item.oldFileName !== "string" ||
      path.basename(item.oldFileName) !== item.oldFileName ||
      !validState
    ) {
      throw new InvalidMigrationStateError();
    }
    if (
      item.replacementFileName !== undefined &&
      (typeof item.replacementFileName !== "string" ||
        path.basename(item.replacementFileName) !== item.replacementFileName)
    ) {
      throw new InvalidMigrationStateError();
    }
    return item as unknown as CodecMigrationTrack;
  });

  const createdAt = typeof value.createdAt === "number" ? value.createdAt : 0;
  const updatedAt = typeof value.updatedAt === "number" ? value.updatedAt : createdAt;
  const manualCount =
    typeof value.manualCount === "number" && value.manualCount >= 0
      ? Math.floor(value.manualCount)
      : 0;
  return withProgress({
    version: 1,
    id: value.id,
    format: value.format,
    state: value.state,
    createdAt,
    updatedAt,
    manualCount,
    tracks,
    total: 0,
    completed: 0,
    succeeded: 0,
    skipped: 0,
    failed: 0,
    percent: 0,
    currentTitle: typeof value.currentTitle === "string" ? value.currentTitle : undefined,
    failures: [],
  });
}

function safeFailure(
  track: CodecMigrationTrack,
  code: CodecMigrationFailure["code"],
): CodecMigrationFailure {
  const messages: Record<CodecMigrationFailure["code"], string> = {
    download_failed: "Kaynak indirilemedi.",
    invalid_replacement: "İndirilen yeni dosya doğrulanamadı.",
    metadata_failed: "Şarkı bilgileri güvenli biçimde güncellenemedi.",
    cleanup_failed: "Eski dosya güvenli biçimde kaldırılamadı.",
  };
  return { libraryId: track.libraryId, title: track.title, code, message: messages[code] };
}

async function exists(filePath: string): Promise<boolean> {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

function assertInside(parentDir: string, childPath: string): void {
  const parent = path.resolve(parentDir);
  const child = path.resolve(childPath);
  if (child !== parent && !child.startsWith(`${parent}${path.sep}`)) {
    throw new Error("replacement escaped staging directory");
  }
}

async function chooseReplacementName(
  musicsDir: string,
  oldFileName: string,
  downloadedExtension: string,
): Promise<string> {
  const extension = downloadedExtension.startsWith(".")
    ? downloadedExtension.toLowerCase()
    : `.${downloadedExtension.toLowerCase()}`;
  const stem = path.basename(oldFileName, path.extname(oldFileName));
  for (let index = 0; index < 10_000; index += 1) {
    const suffix = index === 0 ? "" : ` (${index + 1})`;
    const candidate = `${stem}${suffix}${extension}`;
    if (candidate === oldFileName) continue;
    if (!(await exists(path.join(musicsDir, candidate)))) return candidate;
  }
  throw new Error("replacement name unavailable");
}

export function createCodecMigrationService(deps: CodecMigrationDependencies) {
  const now = deps.now ?? Date.now;
  const makeId = deps.makeId ?? randomUUID;
  const jobPath = path.join(deps.musicsDir, CODEC_MIGRATION_FILE);

  async function save(job: CodecMigrationJob): Promise<CodecMigrationJob> {
    const normalized = withProgress({ ...job, updatedAt: now() });
    const temporary = `${jobPath}.tmp-${process.pid}-${randomUUID()}`;
    await fs.mkdir(deps.musicsDir, { recursive: true });
    try {
      await fs.writeFile(temporary, JSON.stringify(normalized), "utf8");
      await fs.rename(temporary, jobPath);
    } finally {
      await fs.unlink(temporary).catch(() => undefined);
    }
    return normalized;
  }

  async function getStatus(): Promise<CodecMigrationJob | null> {
    try {
      return normalizeJob(JSON.parse(await fs.readFile(jobPath, "utf8")));
    } catch (error) {
      if (isRecord(error) && error.code === "ENOENT") return null;
      if (error instanceof InvalidMigrationStateError) throw error;
      throw new InvalidMigrationStateError();
    }
  }

  async function start(format: AudioFormat): Promise<CodecMigrationJob> {
    const existing = await getStatus();
    if (existing?.state === "running") throw new MigrationConflictError();

    const meta = await ensureTrackLibraryIds(deps.musicsDir);
    const directoryEntries = await fs.readdir(deps.musicsDir, { withFileTypes: true });
    const audioFiles = directoryEntries
      .filter((entry) => entry.isFile() && isAudioFile(entry.name))
      .map((entry) => entry.name);
    const audioFileSet = new Set(audioFiles);
    const tracks: CodecMigrationTrack[] = [];

    for (const [fileName, entry] of Object.entries(meta)) {
      if (!audioFileSet.has(fileName)) continue;
      if (!entry.libraryId || !entry.origin || !entry.externalId) continue;
      tracks.push({
        libraryId: entry.libraryId,
        title: entry.title,
        origin: entry.origin,
        externalId: entry.externalId,
        oldFileName: fileName,
        state: "pending",
      });
    }

    const job = withProgress({
      version: 1,
      id: makeId(),
      format,
      state: "running",
      createdAt: now(),
      updatedAt: now(),
      manualCount: Math.max(0, audioFiles.length - tracks.length),
      tracks,
      total: 0,
      completed: 0,
      succeeded: 0,
      skipped: 0,
      failed: 0,
      percent: 0,
      failures: [],
    });
    return save(job);
  }

  async function failTrack(
    job: CodecMigrationJob,
    track: CodecMigrationTrack,
    code: CodecMigrationFailure["code"],
  ): Promise<CodecMigrationJob> {
    track.state = "failed";
    track.error = safeFailure(track, code);
    job.currentTitle = undefined;
    return save(job);
  }

  async function finishMetadataCommitted(
    job: CodecMigrationJob,
    track: CodecMigrationTrack,
  ): Promise<CodecMigrationJob> {
    const replacementName = track.replacementFileName;
    if (!replacementName) return failTrack(job, track, "metadata_failed");
    const { record: committedMeta } = await readTrackMetaRaw(deps.musicsDir);
    const committedRaw: unknown = committedMeta[replacementName];
    if (!isMetaEntry(committedRaw) || committedRaw.libraryId !== track.libraryId) {
      return failTrack(job, track, "metadata_failed");
    }
    try {
      await fs.unlink(path.join(deps.musicsDir, track.oldFileName));
    } catch (error) {
      if (!(isRecord(error) && error.code === "ENOENT")) {
        return failTrack(job, track, "cleanup_failed");
      }
    }
    track.state = "completed";
    track.error = undefined;
    job.currentTitle = undefined;
    return save(job);
  }

  async function commitReplacement(
    job: CodecMigrationJob,
    track: CodecMigrationTrack,
  ): Promise<CodecMigrationJob> {
    if (!track.replacementFileName) {
      return failTrack(job, track, "metadata_failed");
    }

    const replacementPath = path.join(deps.musicsDir, track.replacementFileName);
    try {
      const stat = await fs.stat(replacementPath);
      const info = await deps.inspect(replacementPath);
      if (
        !stat.isFile() ||
        stat.size < MIN_REPLACEMENT_BYTES ||
        stat.size > MAX_REPLACEMENT_BYTES ||
        !matchesAudioFormat(job.format, info.codec, info.ext)
      ) {
        throw new Error("invalid replacement");
      }
    } catch {
      await fs.unlink(replacementPath).catch(() => undefined);
      track.replacementFileName = undefined;
      return failTrack(job, track, "invalid_replacement");
    }

    const { ok, record: meta } = await readTrackMetaRaw(deps.musicsDir);
    if (!ok) {
      await fs.unlink(replacementPath).catch(() => undefined);
      track.replacementFileName = undefined;
      return failTrack(job, track, "metadata_failed");
    }
    const replacementRaw = meta[track.replacementFileName];
    const replacementEntry = isMetaEntry(replacementRaw) ? replacementRaw : undefined;
    if (replacementEntry?.libraryId === track.libraryId) {
      track.state = "metadata_committed";
      return save(job);
    }

    const oldRaw: unknown = meta[track.oldFileName];
    const oldEntry = isMetaEntry(oldRaw) ? oldRaw : undefined;
    if (!oldEntry || oldEntry.libraryId !== track.libraryId) {
      await fs.unlink(replacementPath).catch(() => undefined);
      track.replacementFileName = undefined;
      return failTrack(job, track, "metadata_failed");
    }

    const updatedMeta = {
      ...meta,
      [track.replacementFileName]: {
        ...oldEntry,
        previousFileNames: Array.from(
          new Set([...(oldEntry.previousFileNames ?? []), track.oldFileName]),
        ),
        updatedAt: now(),
      },
    };
    delete updatedMeta[track.oldFileName];
    try {
      await writeTrackMeta(updatedMeta, deps.musicsDir);
    } catch {
      await fs.unlink(replacementPath).catch(() => undefined);
      track.replacementFileName = undefined;
      return failTrack(job, track, "metadata_failed");
    }

    // Metadata commit edildikten sonra replacement artık ana kopyadır. Bundan
    // sonraki state yazımı patlarsa restart, metadata üzerinden bu aşamayı tanır.
    track.state = "metadata_committed";
    return save(job);
  }

  async function processTrack(
    job: CodecMigrationJob,
    track: CodecMigrationTrack,
  ): Promise<CodecMigrationJob> {
    if (track.state === "metadata_committed") {
      return finishMetadataCommitted(job, track);
    }
    if (track.state === "replacement_ready") {
      job = await commitReplacement(job, track);
      return isMetadataCommitted(track)
        ? finishMetadataCommitted(job, track)
        : job;
    }

    const oldPath = path.join(deps.musicsDir, track.oldFileName);
    try {
      const oldInfo = await deps.inspect(oldPath);
      if (matchesAudioFormat(job.format, oldInfo.codec, oldInfo.ext)) {
        track.state = "skipped";
        track.error = undefined;
        job.currentTitle = undefined;
        return save(job);
      }
    } catch {
      return failTrack(job, track, "invalid_replacement");
    }

    const stagingDir = path.join(
      deps.musicsDir,
      ".turkify-codec-staging",
      job.id,
      track.libraryId,
    );

    // Crash recovery: onceki denemede replacement ana klasore tasinmis ama
    // `replacement_ready` henuz yazilmadan process kapanmis olabilir. Isim
    // job'da kayitliysa dosyayi dogrula; gecerliyse tekrar indirmeden devam et.
    // Gecersiz ya da kayip dosya guvenli sekilde yok sayilir (kullanici dosyasi
    // olabilecegi icin silinmez) ve taze indirme yapilir.
    if (track.replacementFileName) {
      const orphanPath = path.join(deps.musicsDir, track.replacementFileName);
      let recovered = false;
      try {
        const stat = await fs.stat(orphanPath);
        const info = await deps.inspect(orphanPath);
        recovered =
          stat.isFile() &&
          stat.size >= MIN_REPLACEMENT_BYTES &&
          stat.size <= MAX_REPLACEMENT_BYTES &&
          matchesAudioFormat(job.format, info.codec, info.ext);
      } catch {
        recovered = false;
      }
      if (recovered) {
        track.state = "replacement_ready";
        job.currentTitle = track.title;
        job = await save(job);
        await fs.rm(stagingDir, { recursive: true, force: true }).catch(() => undefined);
        job = await commitReplacement(job, track);
        return isMetadataCommitted(track) ? finishMetadataCommitted(job, track) : job;
      }
      track.replacementFileName = undefined;
    }

    track.state = "downloading";
    track.error = undefined;
    job.currentTitle = track.title;
    job = await save(job);

    let downloadedPath: string;
    try {
      // Staging'i temiz baslat: yarim kalan onceki denemenin dosyasi
      // download sonrasi aramada (findAudio) yanlis eslesmesin.
      await fs.rm(stagingDir, { recursive: true, force: true }).catch(() => undefined);
      await fs.mkdir(stagingDir, { recursive: true });
      downloadedPath = await deps.download({
        origin: track.origin,
        externalId: track.externalId,
        title: track.title,
        format: job.format,
        outputDir: stagingDir,
      });
      assertInside(stagingDir, downloadedPath);
    } catch {
      await fs.rm(stagingDir, { recursive: true, force: true }).catch(() => undefined);
      return failTrack(job, track, "download_failed");
    }

    let replacementPath: string | undefined;
    let moved = false;
    try {
      if (job.format === "aac" && deps.embedCover) {
        const { record } = await readTrackMetaRaw(deps.musicsDir);
        const rawMeta: unknown = record[track.oldFileName];
        if (isMetaEntry(rawMeta) && rawMeta.coverFile) {
          const coverPath = path.join(deps.musicsDir, rawMeta.coverFile);
          const coverExists = await fs
            .stat(coverPath)
            .then((stat) => stat.isFile())
            .catch(() => false);
          if (coverExists) {
            downloadedPath = await deps.embedCover(downloadedPath, coverPath);
            assertInside(stagingDir, downloadedPath);
          }
        }
      }
      const stat = await fs.stat(downloadedPath);
      const info = await deps.inspect(downloadedPath);
      if (
        !stat.isFile() ||
        stat.size < MIN_REPLACEMENT_BYTES ||
        stat.size > MAX_REPLACEMENT_BYTES ||
        !matchesAudioFormat(job.format, info.codec, info.ext)
      ) {
        throw new Error("invalid replacement");
      }
      const replacementName = await chooseReplacementName(
        deps.musicsDir,
        track.oldFileName,
        info.ext,
      );
      replacementPath = path.join(deps.musicsDir, replacementName);
      // Niyet once diske yazilir: rename ile `replacement_ready` arasinda crash
      // olursa restart, job'daki bu isim uzerinden dosyayi sahiplenir (yukarida
      // recovery). State bilerek henuz `downloading` birakilir.
      track.replacementFileName = replacementName;
      job = await save(job);
      await fs.rename(downloadedPath, replacementPath);
      moved = true;
      track.state = "replacement_ready";
      job = await save(job);
    } catch {
      // rename tamamlanmadiysa ana klasore tasan dosya yoktur; rename tamamlanip
      // save patladiysa dosyaya bilerek dokunulmaz, recovery bulsun diye.
      if (!moved) track.replacementFileName = undefined;
      if (!moved && replacementPath) await fs.unlink(replacementPath).catch(() => undefined);
      await fs.rm(stagingDir, { recursive: true, force: true }).catch(() => undefined);
      return failTrack(job, track, "invalid_replacement");
    }

    job = await commitReplacement(job, track);
    if (!isMetadataCommitted(track)) return job;

    await fs.rm(stagingDir, { recursive: true, force: true }).catch(() => undefined);
    return finishMetadataCommitted(job, track);
  }

  async function run(id: string): Promise<CodecMigrationJob> {
    let job = await getStatus();
    if (!job || job.id !== id) throw new InvalidMigrationStateError();

    for (const track of job.tracks) {
      if (isTerminal(track.state)) continue;
      job = await processTrack(job, track);
    }
    job.state = "completed";
    job.currentTitle = undefined;
    job = await save(job);
    // Bitmis job'un staging artiklarini kaldir (basarisiz indirme cirpintisi
    // birikmesin). Kullanici dosyasina dokunulmaz, sadece job'un kendi klasoru.
    await fs
      .rm(path.join(deps.musicsDir, ".turkify-codec-staging", job.id), {
        recursive: true,
        force: true,
      })
      .catch(() => undefined);
    return job;
  }

  async function retry(id: string): Promise<CodecMigrationJob> {
    let job = await getStatus();
    if (!job || job.id !== id) throw new InvalidMigrationStateError();
    // Calisan job uzerinde retry, aktif run dongusuyle yarismamasi icin
    // service seviyesinde reddedilir. UI zaten engelliyor; bu ikinci kapi.
    // Bitmis job (state completed) her zaman retry edilebilir.
    if (job.state === "running") throw new MigrationConflictError();
    for (const track of job.tracks) {
      if (track.state !== "failed") continue;
      track.state = track.error?.code === "cleanup_failed" ? "metadata_committed" : "pending";
      track.error = undefined;
    }
    job.state = "running";
    job.currentTitle = undefined;
    job = await save(job);
    return job;
  }

  async function dismiss(id: string): Promise<null> {
    const job = await getStatus();
    if (!job || job.id !== id) throw new InvalidMigrationStateError();
    // Calisan isi ortada birakmamak icin kapatma reddedilir; yaris kalmis
    // dosyalar aktif run dongusunun sorumlulugunda kalir.
    if (job.state === "running") throw new MigrationConflictError();
    // Bitmis ozeti kapat: yalnizca job'un kendi staging klasoru temizlenir,
    // kullanici dosyasina dokunulmaz.
    await fs
      .rm(path.join(deps.musicsDir, ".turkify-codec-staging", job.id), {
        recursive: true,
        force: true,
      })
      .catch(() => undefined);
    await fs.unlink(jobPath).catch(() => undefined);
    return null;
  }

  return { start, run, retry, dismiss, getStatus };
}

/** Tamamlanmış job kaydı, eski sürüm metadata'sında eksik kalan ID köprüsünü sağlar. */
export async function readCodecMigrationLegacyNames(
  musicsDir: string,
): Promise<Record<string, string[]>> {
  try {
    const job = normalizeJob(
      JSON.parse(await fs.readFile(path.join(musicsDir, CODEC_MIGRATION_FILE), "utf8")),
    );
    const result: Record<string, string[]> = {};
    for (const track of job.tracks) {
      if (track.state !== "completed" && track.state !== "metadata_committed") continue;
      result[track.libraryId] = Array.from(
        new Set([...(result[track.libraryId] ?? []), track.oldFileName]),
      );
    }
    return result;
  } catch {
    return {};
  }
}
