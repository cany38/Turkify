import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";

import type { ImportedPlaylistTrack, LibraryState, Playlist } from "./types";
import { cleanExternalTracks } from "./library-identity";

/**
 * Kutuphane durumu (begeniler, listeler, kaldirilanlar) sunucuda durur:
 * `Musics/.turkify-library.json`. Tarayici verisi silinse bile proje
 * ayaga kalkinca listeler geri gelir. Istemci `localStorage`'i yalnizca
 * hizli acilis ve cevrimdisi yedek olarak kullanir; kaynak bu dosyadir.
 *
 * Yalnizca sunucu tarafi: `fs`/`path` kullandigi icin istemci paketine girmemeli.
 */

export const LIBRARY_STORE_FILE = ".turkify-library.json";
const STORE_VERSION = 1;

// Tek kullanicili yerel uygulama icin guvenlik sinirlari; asanlar sessizce
// kirpilir (istemciyi kilitlemek yerine kayit kurtarilir).
const MAX_LIKED_IDS = 5_000;
const MAX_REMOVED_IDS = 5_000;
const MAX_PLAYLISTS = 200;
const MAX_TRACK_IDS_PER_PLAYLIST = 2_000;
const MAX_ID_LENGTH = 200;
const MAX_EXTERNAL_TEXT_LENGTH = 200;
const MAX_EXTERNAL_COVER_LENGTH = 2_000;
const MAX_PLAYLIST_NAME_LENGTH = 60;
const MAX_COVER_LENGTH = 50 * 1024 * 1024;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function cleanIdList(value: unknown, cap: number): string[] {
  if (!Array.isArray(value)) return [];
  const out: string[] = [];
  for (const item of value) {
    if (typeof item !== "string") continue;
    if (item.startsWith("blob:")) continue;
    const trimmed = item.trim();
    if (!trimmed || trimmed.length > MAX_ID_LENGTH) continue;
    out.push(trimmed);
    if (out.length >= cap) break;
  }
  return out;
}

function cleanPlaylist(value: unknown): Playlist | null {
  if (!isRecord(value)) return null;
  if (typeof value.id !== "string" || !value.id.trim() || value.id.length > MAX_ID_LENGTH) {
    return null;
  }
  if (typeof value.name !== "string") return null;
  const name = value.name.trim().slice(0, MAX_PLAYLIST_NAME_LENGTH);
  if (!name) return null;
  if (typeof value.createdAt !== "number" || !Number.isFinite(value.createdAt)) return null;
  // Parca listesi dizi degilse kayit bozuktur; bos saymak veri kaybi olur.
  if (!Array.isArray(value.trackIds)) return null;
  const cleaned: Playlist = {
    id: value.id.trim(),
    name,
    trackIds: cleanIdList(value.trackIds, MAX_TRACK_IDS_PER_PLAYLIST),
    createdAt: value.createdAt,
  };
  if (Array.isArray(value.importedTracks)) {
    const importedTracks: ImportedPlaylistTrack[] = [];
    const seenIds = new Set<string>();
    for (const item of value.importedTracks) {
      if (!isRecord(item)) continue;
      if (typeof item.id !== "string" || typeof item.title !== "string") continue;
      // Aynı id iki kez geçerse React key çakışması listeyi karıştırır; ilki korunur.
      if (seenIds.has(item.id)) continue;
      // Eski kayıtlarda kaynak alanı yok; hepsi Spotify ithalatıydı.
      const source = item.source === "youtube" ? "youtube" as const : "spotify" as const;
      const base = {
        id: item.id,
        title: item.title.slice(0, MAX_EXTERNAL_TEXT_LENGTH),
        artist: typeof item.artist === "string" ? item.artist.slice(0, MAX_EXTERNAL_TEXT_LENGTH) : "Bilinmeyen sanatçı",
        album: typeof item.album === "string" ? item.album.slice(0, MAX_EXTERNAL_TEXT_LENGTH) : "Spotify",
        duration: typeof item.duration === "number" && Number.isFinite(item.duration) ? item.duration : 0,
        cover: typeof item.cover === "string" ? item.cover.slice(0, MAX_EXTERNAL_COVER_LENGTH) : "/covers/demo-01.svg",
      };
      if (source === "youtube") {
        if (typeof item.youtubeId !== "string" || !item.youtubeId) continue;
        seenIds.add(item.id);
        importedTracks.push({
          ...base,
          source,
          youtubeId: item.youtubeId,
          youtubeUrl: typeof item.youtubeUrl === "string" ? item.youtubeUrl : `https://www.youtube.com/watch?v=${item.youtubeId}`,
          ...(typeof item.localTrackId === "string" ? { localTrackId: item.localTrackId } : {}),
        });
      } else {
        if (typeof item.spotifyId !== "string" || !item.spotifyId) continue;
        seenIds.add(item.id);
        importedTracks.push({
          ...base,
          source,
          spotifyId: item.spotifyId,
          spotifyUrl: typeof item.spotifyUrl === "string" ? item.spotifyUrl : `https://open.spotify.com/track/${item.spotifyId}`,
          ...(typeof item.localTrackId === "string" ? { localTrackId: item.localTrackId } : {}),
        });
      }
      if (importedTracks.length >= MAX_TRACK_IDS_PER_PLAYLIST) break;
    }
    if (importedTracks.length) cleaned.importedTracks = importedTracks;
  }
  if (typeof value.spotifyId === "string" && value.spotifyId.length <= MAX_ID_LENGTH) cleaned.spotifyId = value.spotifyId;
  if (typeof value.youtubeId === "string" && value.youtubeId.length <= MAX_ID_LENGTH) cleaned.youtubeId = value.youtubeId;
  if (typeof value.cover === "string" && value.cover.length > 0) {
    // Kapak data URL'i kotayi sismemesin diye sinirli tutulur.
    if (value.cover.length <= MAX_COVER_LENGTH) cleaned.cover = value.cover;
  }
  return cleaned;
}

/** Gecersiz kayit `null` doner; cagiran 400 ile reddeder, dosyaya dokunmaz. */
export function sanitizeLibraryState(input: unknown): LibraryState | null {
  if (!isRecord(input)) return null;
  // Surum yoksa istemciden gelen taze kayit sayilir; varsa 1 olmali.
  if (input.version !== undefined && input.version !== STORE_VERSION) return null;
  // Ust seviye alanlar dizi olmak zorunda; tip yanlissa bos saymak begeni/liste
  // siler, o yuzden butun kayit reddedilir (fail-closed).
  if (
    !Array.isArray(input.likedIds) ||
    !Array.isArray(input.playlists) ||
    !Array.isArray(input.removedTrackIds)
  ) {
    return null;
  }
  const playlists: Playlist[] = [];
  for (const item of input.playlists) {
    const cleaned = cleanPlaylist(item);
    if (cleaned) playlists.push(cleaned);
    if (playlists.length >= MAX_PLAYLISTS) break;
  }
  return {
    likedIds: cleanIdList(input.likedIds, MAX_LIKED_IDS),
    playlists,
    removedTrackIds: cleanIdList(input.removedTrackIds, MAX_REMOVED_IDS),
    externalTracks: cleanExternalTracks(input.externalTracks),
  };
}

/** Dosya yoksa veya bozuksa `null`; bu hata degil, bos kutuphane demek. */
export async function readLibraryFile(dir: string): Promise<LibraryState | null> {
  try {
    const raw = await fs.readFile(path.join(dir, LIBRARY_STORE_FILE), "utf8");
    return sanitizeLibraryState(JSON.parse(raw.replace(/^\uFEFF/, "")));
  } catch {
    return null;
  }
}

/** Atomik yazar (tmp + rename); gecersiz girdi diske degmeden reddedilir. */
export async function writeLibraryFile(input: unknown, dir: string): Promise<LibraryState> {
  const cleaned = sanitizeLibraryState(input);
  if (!cleaned) throw new Error("Gecersiz kutuphane kaydi.");
  const payload: LibraryState & { version: number } = { ...cleaned, version: STORE_VERSION };
  await fs.mkdir(dir, { recursive: true });
  const target = path.join(dir, LIBRARY_STORE_FILE);
  const temporary = path.join(dir, `${LIBRARY_STORE_FILE}.tmp-${process.pid}-${randomUUID()}`);
  try {
    await fs.writeFile(temporary, JSON.stringify(payload), "utf8");
    await fs.rename(temporary, target);
  } finally {
    await fs.unlink(temporary).catch(() => undefined);
  }
  return cleaned;
}
