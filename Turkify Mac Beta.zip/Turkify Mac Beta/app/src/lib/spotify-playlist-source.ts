import { spawn } from "child_process";
import path from "path";
import { resolveScriptsDir } from "./data-dir";
import type { ImportedPlaylistTrack } from "./types";

/** Betigin stdout'a yazdigi ham parca kaydi; eski istemcilerde album/kapak bos olabilir. */
export interface FetchedPlaylistTrack {
  id: string;
  title: string;
  artist: string;
  album: string;
  /** Sure (saniye, yuvarlanmis). */
  duration: number;
  url: string;
  cover?: string;
}

/** Betikten cozulmus liste; parca kapaklari bos olabilir. */
export interface FetchedPlaylist {
  name: string;
  cover: string;
  tracks: FetchedPlaylistTrack[];
}

// 1000 parcalik liste icin bol tutulur; spotDL kendi icinde sayfalar.
const FETCH_TIMEOUT_MS = 90_000;

/** Betik stdout'unu `FetchedPlaylist`e cevirir; bozuksa okunabilir hata atar. */
export function parsePlaylistScriptOutput(stdout: string): FetchedPlaylist {
  let parsed: unknown;
  try {
    // Betik tek satir JSON yazar; sondaki bos satir ayiklanir.
    parsed = JSON.parse(stdout.trim().split("\n").filter(Boolean).pop() ?? "");
  } catch {
    throw new Error("Liste okunamadı: python veya spotDL çalıştırılamadı.");
  }
  if (typeof parsed !== "object" || parsed === null) {
    throw new Error("Liste okunamadı: python veya spotDL çalıştırılamadı.");
  }
  const record = parsed as { ok?: unknown; error?: unknown };
  if (record.ok !== true) {
    const detail =
      typeof record.error === "string" && record.error.trim()
        ? record.error.trim().slice(0, 200)
        : "Spotify playlist okunamadı.";
    throw new Error(`Liste okunamadı: ${detail}`);
  }
  const body = record as {
    name?: unknown;
    cover?: unknown;
    tracks?: unknown;
  };
  const tracks = Array.isArray(body.tracks) ? body.tracks : [];
  return {
    name: typeof body.name === "string" && body.name ? body.name : "Spotify playlist",
    cover: typeof body.cover === "string" ? body.cover : "",
    tracks: tracks.filter((t): t is FetchedPlaylistTrack => isFetchedTrack(t)),
  };
}

/** Ham kaydın beklenen sekilde olup olmadigini denetler. */
function isFetchedTrack(value: unknown): value is FetchedPlaylistTrack {
  if (typeof value !== "object" || value === null) return false;
  const v = value as Record<string, unknown>;
  return (
    typeof v.id === "string" &&
    typeof v.title === "string" &&
    typeof v.artist === "string" &&
    typeof v.album === "string" &&
    typeof v.duration === "number" &&
    typeof v.url === "string"
  );
}

/**
 * Betik ciktisini arayuzun kullandigi ize donusturur; saf fonksiyondur.
 *
 * Ham SpotAPI verisi normalde album ve kapak tasir. Eski/eksik istemci
 * ciktisinda bos album "Spotify"a, bos kapak liste kapagına (o da yoksa
 * varsayilana) duser.
 */
export function mapFetchedTracks(
  tracks: FetchedPlaylistTrack[],
  playlistCover: string,
): ImportedPlaylistTrack[] {
  const fallbackCover = playlistCover || "/covers/demo-01.svg";
  const mapped: ImportedPlaylistTrack[] = [];
  for (const track of tracks) {
    if (!track.id || !track.title) continue;
    mapped.push({
      id: `spotify-${track.id}`,
      source: "spotify",
      spotifyId: track.id,
      spotifyUrl: track.url || `https://open.spotify.com/track/${track.id}`,
      title: track.title,
      artist: track.artist || "Bilinmeyen sanatçı",
      album: track.album || "Spotify",
      duration: Math.round(track.duration),
      cover: track.cover || fallbackCover,
    });
  }
  return mapped;
}

/** Betigi `python` ile calistirip JSON ciktisini cozer. */
export function fetchSpotifyPlaylist(playlistId: string): Promise<FetchedPlaylist> {
  return new Promise((resolve, reject) => {
    const scriptPath = path.join(resolveScriptsDir(), "spotify-playlist.py");
    const child = spawn(process.env.TURKIFY_PYTHON || "python3", [scriptPath, playlistId], { windowsHide: true });
    let stdout = "";
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      try {
        child.kill();
      } catch {
        // yok say
      }
    }, FETCH_TIMEOUT_MS);

    child.stdout?.on("data", (d: Buffer) => {
      stdout += d.toString();
    });
    child.on("error", () => {
      clearTimeout(timer);
      reject(new Error("Liste okunamadı: python veya spotDL çalıştırılamadı."));
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      if (timedOut) {
        reject(new Error("Liste okunamadı: işlem zaman aşımına uğradı."));
        return;
      }
      if (code !== 0 && !stdout.trim()) {
        reject(new Error("Liste okunamadı: python veya spotDL çalıştırılamadı."));
        return;
      }
      try {
        resolve(parsePlaylistScriptOutput(stdout));
      } catch (error) {
        reject(error instanceof Error ? error : new Error("Liste okunamadı."));
      }
    });
  });
}
