import type { SpotifyKeys } from "./types";

export const SPOTIFY_KEYS_STORAGE_KEY = "turkify:spotify-keys:v1";

const CLIENT_ID_RE = /^[0-9a-f]{32}$/i;

/** Sekil + bicim dogrulamasi; yanlis kopyalamayi kayda gecirmeden yakalar. */
export function isValidSpotifyKeys(input: unknown): input is SpotifyKeys {
  if (typeof input !== "object" || input === null) return false;
  const v = input as Record<string, unknown>;
  if (typeof v.clientId !== "string" || typeof v.clientSecret !== "string") return false;
  const id = v.clientId.trim();
  const secret = v.clientSecret.trim();
  return CLIENT_ID_RE.test(id) && secret.length >= 16;
}

export function loadSpotifyKeys(): SpotifyKeys | null {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return null;
    const raw = window.localStorage.getItem(SPOTIFY_KEYS_STORAGE_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (!isValidSpotifyKeys(parsed)) return null;
    return { clientId: parsed.clientId.trim(), clientSecret: parsed.clientSecret.trim() };
  } catch {
    // Bozuk kayit uygulamayi cokertmesin; yok say.
    return null;
  }
}

export function saveSpotifyKeys(keys: SpotifyKeys): boolean {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return false;
    if (!isValidSpotifyKeys(keys)) return false;
    window.localStorage.setItem(
      SPOTIFY_KEYS_STORAGE_KEY,
      JSON.stringify({ clientId: keys.clientId.trim(), clientSecret: keys.clientSecret.trim() }),
    );
    return true;
  } catch {
    // Kota dolmasi / erisim engeli sessizce yok sayilir.
    return false;
  }
}

export function clearSpotifyKeys(): boolean {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return false;
    window.localStorage.removeItem(SPOTIFY_KEYS_STORAGE_KEY);
    return true;
  } catch {
    // Erisim engeli sessizce yok sayilir.
    return false;
  }
}
