/**
 * Çalma isteği, kozmetik yoklamaların önüne geçer.
 *
 * Kodek rozetini doldurmak için yapılan `/api/format` yoklaması da yt-dlp
 * çalıştırıyor ve saniyeler sürüyor. Kullanıcı bir parçaya bastığında asıl
 * beklediği şey ses; rozet beklese de olur. Bu kapı, çalma kaynağı çözülürken
 * yeni rozet yoklaması başlamasını engeller — süregiden yoklama kesilmez,
 * yalnızca sıradaki başlatılmaz.
 *
 * Modül düzeyinde sayaç tutar: aynı anda birden fazla çözümleme olabilir
 * (kullanıcı hızlı hızlı tıklarsa), hepsi bitmeden kapı açılmaz.
 */

let active = 0;
const waiters = new Set<() => void>();

function release(): void {
  active = Math.max(0, active - 1);
  if (active === 0) {
    // Kopya uzerinde don: uyanan bir bekleyen yeniden kayit olabilir.
    for (const wake of [...waiters]) {
      waiters.delete(wake);
      wake();
    }
  }
}

/**
 * Çalma çözümlemesinin başladığını bildirir. Dönen fonksiyon bir kez
 * çağrıldığında bırakır; iki kez çağrılması sayacı bozmaz.
 */
export function beginPlaybackResolve(): () => void {
  active += 1;
  let released = false;
  return () => {
    if (released) return;
    released = true;
    release();
  };
}

export function isPlaybackResolving(): boolean {
  return active > 0;
}

/**
 * Çalma çözümlemesi bitene kadar bekler. Beklenmiyorsa anında döner.
 *
 * `timeoutMs`: kapı sonsuza kadar kapalı kalmasın. Bir çözümleme sızdırırsa
 * (beklenmedik bir hata yolu) rozetler tamamen durmasın diye üst sınır var.
 */
export function waitForIdlePlayback(timeoutMs = 30_000): Promise<void> {
  if (active === 0) return Promise.resolve();
  return new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      waiters.delete(finish);
      resolve();
    };
    const timer = setTimeout(finish, timeoutMs);
    waiters.add(finish);
  });
}

/** Yalnızca test için: sayacı ve bekleyenleri sıfırlar. */
export function resetPlaybackPriority(): void {
  active = 0;
  for (const wake of [...waiters]) {
    waiters.delete(wake);
    wake();
  }
}
