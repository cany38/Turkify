import type { ExternalTrack, LibraryState } from "./types";

export function stableDownloadTrackId(libraryId: string): string {
  return `download-${libraryId}`;
}

export function remapLibraryState(
  state: LibraryState,
  mapping: Record<string, string>,
): LibraryState {
  const remap = (id: string): string => mapping[id] ?? id;
  const unique = (ids: string[]): string[] => Array.from(new Set(ids.map(remap)));

  return {
    likedIds: unique(state.likedIds),
    playlists: state.playlists.map((playlist) => ({
      ...playlist,
      trackIds: unique(playlist.trackIds),
    })),
    removedTrackIds: unique(state.removedTrackIds),
    externalTracks: state.externalTracks,
  };
}

const MAX_EXTERNAL_TRACKS = 2_000;
const MAX_EXTERNAL_TEXT_LENGTH = 200;
const MAX_EXTERNAL_COVER_LENGTH = 2_000;
const MAX_EXTERNAL_ID_LENGTH = 200;

function isExternalRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * İndirilmemiş arama sonucu kopyası; bozuk kayıt atılır, dizi değilse boş
 * sayılır (eski kayıtlar). İstemci yedeği ve sunucu dosyası ortak kullanır.
 */
export function cleanExternalTracks(value: unknown): ExternalTrack[] {
  if (!Array.isArray(value)) return [];
  const out: ExternalTrack[] = [];
  for (const item of value) {
    if (!isExternalRecord(item)) continue;
    if (item.source !== "spotify" && item.source !== "youtube") continue;
    if (typeof item.id !== "string" || !item.id.trim() || item.id.length > MAX_EXTERNAL_ID_LENGTH) continue;
    if (typeof item.title !== "string" || !item.title) continue;
    const base = {
      id: item.id.trim(),
      title: item.title.slice(0, MAX_EXTERNAL_TEXT_LENGTH),
      artist: typeof item.artist === "string" ? item.artist.slice(0, MAX_EXTERNAL_TEXT_LENGTH) : "Bilinmeyen sanatçı",
      album: typeof item.album === "string" ? item.album.slice(0, MAX_EXTERNAL_TEXT_LENGTH) : "",
      duration: typeof item.duration === "number" && Number.isFinite(item.duration) ? item.duration : 0,
      cover: typeof item.cover === "string" ? item.cover.slice(0, MAX_EXTERNAL_COVER_LENGTH) : "/covers/demo-01.svg",
    };
    if (item.source === "youtube") {
      if (typeof item.videoId !== "string" || !item.videoId) continue;
      out.push({
        ...base,
        source: "youtube",
        videoId: item.videoId,
        externalUrl: typeof item.externalUrl === "string" ? item.externalUrl : `https://www.youtube.com/watch?v=${item.videoId}`,
      });
    } else {
      out.push({
        ...base,
        source: "spotify",
        externalUrl: typeof item.externalUrl === "string" ? item.externalUrl : "",
        previewUrl: typeof item.previewUrl === "string" ? item.previewUrl : null,
      });
    }
    if (out.length >= MAX_EXTERNAL_TRACKS) break;
  }
  return out;
}
