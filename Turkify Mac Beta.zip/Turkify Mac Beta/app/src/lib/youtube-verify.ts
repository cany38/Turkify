/**
 * YouTube anahtar dogrulamasinin ortak sozlesmesi.
 *
 * Spotify tarafiyla ayni desen: tek POST, NDJSON akisi, adim adim sonuc.
 * Fark, adim listesinin daha kisa olmasi: YouTube'da gercek bir arama
 * denemesi 100 kota birimi yakardi (gunluk toplam 10.000), bu yuzden
 * dogrulama 1 birimlik `videos.list` cagrisiyla yapilir. O cagri gecerse
 * anahtar gecerli, API acik ve kota musait demektir.
 */

/** `format` istemcide, `key` sunucuda kosar. */
export type YtVerifyStepId = "format" | "key";

export type YtVerifyStatus = "pending" | "running" | "ok" | "fail";

export interface YtVerifyEvent {
  step: YtVerifyStepId;
  status: YtVerifyStatus;
  /** Yalnizca `fail` durumunda dolu. */
  message?: string;
}

export const YT_VERIFY_STEP_ORDER: YtVerifyStepId[] = ["format", "key"];

export function isYtVerifyEvent(value: unknown): value is YtVerifyEvent {
  if (typeof value !== "object" || value === null) return false;
  const v = value as Record<string, unknown>;
  if (typeof v.step !== "string" || typeof v.status !== "string") return false;
  if (!YT_VERIFY_STEP_ORDER.includes(v.step as YtVerifyStepId)) return false;
  return ["pending", "running", "ok", "fail"].includes(v.status);
}
