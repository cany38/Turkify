import {
  buildFormatCacheKey,
  buildFormatSearchParams,
  type AudioFormat,
  type AudioFormatTarget,
} from "./audio-format";
import { storeFormatInfo, type FormatInfo } from "./format-info-cache";
import { waitForIdlePlayback } from "./playback-priority";

/**
 * Tek, modul duzeyinde kuyruk. Ayni anda yalnizca bir format yoklamasi
 * ucarak, calma onceligini bozmaz ve kullanici baska bir parcaya bastiginda
 * hepsi iptal edilebilir.
 *
 * `MAX_PARALLEL` her calistirmaya ozel olursa ayni anda birden fazla
 * "tek kuyruk" dogar; olcumde makineyi mesgul eden de buydu. Burada gercekten
 * tek bir calisan vardir.
 */

interface QueueItem {
  key: string;
  target: AudioFormatTarget;
  format: AudioFormat;
}

interface QueueState {
  items: QueueItem[];
  controller: AbortController | null;
  running: boolean;
  /** Su an islenen anahtar; ayni anda ayni key iki key yoklanmaz. */
  currentKey: string | null;
  /** Ayni anahtar iki kez yoklanmasin: tamamlananlar buraya yazilir. */
  completed: Set<string>;
  /** Sonuclari tuketmeye hazir bekleyenler. */
  subscribers: Map<
    string,
    { onResult: (key: string, info: FormatInfo | null) => void }[]
  >;
}

const state: QueueState = {
  items: [],
  controller: null,
  running: false,
  currentKey: null,
  completed: new Set<string>(),
  subscribers: new Map<string, { onResult: (key: string, info: FormatInfo | null) => void }[]>(),
};

function notifySubscribers(key: string, info: FormatInfo | null): void {
  const list = state.subscribers.get(key);
  if (!list) return;
  for (const subscriber of list) {
    try {
      subscriber.onResult(key, info);
    } catch {
      // yok say
    }
  }
}

function finishItem(key: string, info: FormatInfo | null): void {
  state.completed.add(key);
  if (info) {
    storeFormatInfo(key, info);
  }
  notifySubscribers(key, info);
}

async function runQueue(): Promise<void> {
  while (state.items.length > 0) {
    if (state.controller?.signal.aborted) break;
    const item = state.items.shift();
    if (!item) continue;

    const controller = new AbortController();
    state.controller = controller;
    state.currentKey = item.key;

    // Calma kaynagi cozuluyorsa yeni rozet yoklamasi baslatma.
    await waitForIdlePlayback();
    if (controller.signal.aborted) {
      finishItem(item.key, null);
      continue;
    }

    try {
      const res = await fetch(`/api/format?${buildFormatSearchParams(item.format, item.target)}`, {
        signal: controller.signal,
      });
      if (controller.signal.aborted) {
        finishItem(item.key, null);
        continue;
      }
      if (!res.ok) {
        finishItem(item.key, null);
        continue;
      }
      const data = (await res.json()) as FormatInfo;
      finishItem(item.key, data);
    } catch {
      finishItem(item.key, null);
    } finally {
      if (state.currentKey === item.key) {
        state.currentKey = null;
      }
    }
  }
  state.running = false;
  state.controller = null;
  state.currentKey = null;
}

function ensureRunning(): void {
  if (state.running) return;
  state.running = true;
  void runQueue();
}

/**
 * Hedefleri kuyruga ekler. Ayni anda yalnizca bir fetch calisir.
 * Daha once tamamlanmis anahtarlar tekrar yoklanmaz.
 */
export function enqueueFormatProbes(
  targets: AudioFormatTarget[],
  format: AudioFormat,
  onResult: (key: string, info: FormatInfo | null) => void,
): void {
  const added: QueueItem[] = [];
  const existingQueueKeys = new Set(state.items.map((i) => i.key));
  existingQueueKeys.add(state.currentKey ?? "");
  for (const target of targets) {
    const key = buildFormatCacheKey(format, target);
    const entry = { onResult };
    const subscriberList = state.subscribers.get(key);
    if (subscriberList) {
      subscriberList.push(entry);
    } else {
      state.subscribers.set(key, [entry]);
    }
    if (state.completed.has(key)) {
      continue;
    }
    if (existingQueueKeys.has(key)) {
      // Görünürlük degisti: zaten kuyrukta olani basa tasiyarak
      // yeniden oncelik ver.
      const index = state.items.findIndex((i) => i.key === key);
      if (index > 0) {
        const [item] = state.items.splice(index, 1);
        state.items.unshift(item);
      }
      continue;
    }
    added.push({ key, target, format });
  }

  if (added.length > 0) {
    // Yeniler basa ekle: gorunurdeki siraya gore yoklama baslar.
    state.items.unshift(...added);
  }

  ensureRunning();
}

/** Suregiden yoklamayi iptal eder ve kuyrugu bosaltir. */
export function cancelAllFormatWork(): void {
  state.controller?.abort();
  state.controller = null;
  state.items = [];
}

/** Kuyruktaki bekleyen istek sayisi (test/gozlem). */
export function formatQueueSize(): number {
  return state.items.length;
}

/** Tum kuyruk durumunu sifirlar (test). */
export function resetFormatQueue(): void {
  state.controller?.abort();
  state.controller = null;
  state.items = [];
  state.running = false;
  state.currentKey = null;
  state.completed.clear();
  state.subscribers.clear();
}

/** Sadece test/gozlem: kuyrukta bekleyen anahtarlar. */
export function formatQueueKeys(): string[] {
  return state.items.map((i) => i.key);
}
