import type { LocalTrack, Track } from "./types";

export const PLAYBACK_SESSION_KEY = "turkify:playback:v1";
export const PLAYBACK_SESSION_VERSION = 1;

interface StoredStreamTrack {
  title: string;
  artist: string;
  album: string;
  duration: number;
  cover: string;
  origin: "spotify" | "youtube";
  url: string;
}

export interface PlaybackSession {
  version: 1;
  trackId: string;
  contextKey: string;
  position: number;
  savedAt: number;
  fileName?: string;
  stream?: StoredStreamTrack;
}

const MAX_TEXT = 500;
const MAX_POSITION = 7 * 24 * 60 * 60;

function boundedText(value: unknown, max = MAX_TEXT): string | null {
  return typeof value === "string" && value.length > 0 && value.length <= max
    ? value
    : null;
}

function boundedString(value: unknown, max = MAX_TEXT): string | null {
  return typeof value === "string" && value.length <= max ? value : null;
}

function safeNumber(value: unknown, max = MAX_POSITION): number | null {
  return typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= max
    ? value
    : null;
}

function isSafeStreamUrl(value: unknown): value is string {
  return typeof value === "string" &&
    value.length <= 2_000 &&
    value.startsWith("/api/stream?");
}

function parseStream(value: unknown): StoredStreamTrack | undefined {
  if (typeof value !== "object" || value === null) return undefined;
  const item = value as Record<string, unknown>;
  const title = boundedText(item.title);
  const artist = boundedString(item.artist);
  const album = boundedString(item.album);
  const cover = boundedString(item.cover, 2_000);
  const duration = safeNumber(item.duration);
  const origin = item.origin === "spotify" || item.origin === "youtube"
    ? item.origin
    : null;
  if (!title || artist === null || album === null || cover === null || duration === null || !origin || !isSafeStreamUrl(item.url)) {
    return undefined;
  }
  return { title, artist, album, duration, cover, origin, url: item.url };
}

export function buildPlaybackSession(
  track: Track,
  contextKey: string,
  position: number,
  savedAt = Date.now(),
): PlaybackSession | null {
  const trackId = boundedText(track.id);
  const safeContext = boundedText(contextKey, 200);
  const safePosition = safeNumber(position);
  const safeSavedAt = safeNumber(savedAt, Number.MAX_SAFE_INTEGER);
  if (!trackId || trackId.startsWith("blob:") || !safeContext || safePosition === null || safeSavedAt === null) {
    return null;
  }

  const fileName = track.source === "local"
    ? boundedText(track.fileName, 260) ?? undefined
    : undefined;
  const stream = track.source === "local" &&
      track.origin &&
      isSafeStreamUrl(track.objectUrl)
    ? parseStream({
        title: track.title,
        artist: track.artist,
        album: track.album,
        duration: track.duration,
        cover: track.cover,
        origin: track.origin,
        url: track.objectUrl,
      })
    : undefined;

  // Kalici dosya kimligi veya yeniden cozulur stream yoksa blob oturumu
  // yeniden acilamaz; gecici adresi kayda almayiz.
  if (track.source === "local" && track.objectUrl?.startsWith("blob:") && !fileName) {
    return null;
  }

  return {
    version: PLAYBACK_SESSION_VERSION,
    trackId,
    contextKey: safeContext,
    position: safePosition,
    savedAt: safeSavedAt,
    ...(fileName ? { fileName } : {}),
    ...(stream ? { stream } : {}),
  };
}

export function parsePlaybackSession(raw: string | null): PlaybackSession | null {
  if (!raw) return null;
  try {
    const parsed: unknown = JSON.parse(raw);
    if (typeof parsed !== "object" || parsed === null) return null;
    const item = parsed as Record<string, unknown>;
    if (item.version !== PLAYBACK_SESSION_VERSION) return null;
    const trackId = boundedText(item.trackId);
    const contextKey = boundedText(item.contextKey, 200);
    const position = safeNumber(item.position);
    const savedAt = safeNumber(item.savedAt, Number.MAX_SAFE_INTEGER);
    if (!trackId || trackId.startsWith("blob:") || !contextKey || position === null || savedAt === null) {
      return null;
    }
    const fileName = item.fileName === undefined
      ? undefined
      : boundedText(item.fileName, 260) ?? null;
    if (fileName === null) return null;
    const stream = item.stream === undefined ? undefined : parseStream(item.stream);
    if (item.stream !== undefined && !stream) return null;
    return {
      version: PLAYBACK_SESSION_VERSION,
      trackId,
      contextKey,
      position,
      savedAt,
      ...(fileName ? { fileName } : {}),
      ...(stream ? { stream } : {}),
    };
  } catch {
    return null;
  }
}

export function resolvePlaybackTrack(session: PlaybackSession, pool: Track[]): Track | null {
  const exact = pool.find((track) => track.id === session.trackId);
  if (exact) return exact;

  if (session.fileName) {
    const byFile = pool.find(
      (track) => track.source === "local" && track.fileName === session.fileName,
    );
    if (byFile) return byFile;
  }

  const byExternalId = pool.find(
    (track) => track.source === "local" && track.externalId === session.trackId,
  );
  if (byExternalId) return byExternalId;

  if (!session.stream) return null;
  const stream = session.stream;
  const restored: LocalTrack = {
    id: session.trackId,
    title: stream.title,
    artist: stream.artist,
    album: stream.album,
    duration: stream.duration,
    cover: stream.cover,
    source: "local",
    objectUrl: stream.url,
    origin: stream.origin,
  };
  return restored;
}

export function loadPlaybackSession(): PlaybackSession | null {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return null;
    return parsePlaybackSession(window.localStorage.getItem(PLAYBACK_SESSION_KEY));
  } catch {
    return null;
  }
}

export function savePlaybackSession(
  track: Track,
  contextKey: string,
  position: number,
): boolean {
  try {
    if (typeof window === "undefined" || !("localStorage" in window)) return false;
    const session = buildPlaybackSession(track, contextKey, position);
    if (!session) return false;
    window.localStorage.setItem(PLAYBACK_SESSION_KEY, JSON.stringify(session));
    return true;
  } catch {
    return false;
  }
}

export function clearPlaybackSession(): void {
  try {
    if (typeof window !== "undefined" && "localStorage" in window) {
      window.localStorage.removeItem(PLAYBACK_SESSION_KEY);
    }
  } catch {
    // Depolama kapaliysa calar yine oturum icinde calismaya devam eder.
  }
}
