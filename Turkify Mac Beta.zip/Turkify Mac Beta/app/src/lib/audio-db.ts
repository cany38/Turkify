﻿// yalnizca eski kayitlardan tasima icin duruyor; yeni ses blob'u tutulmaz.

const DB_NAME = "turkify_db";
const DB_VERSION = 1;
const STORE_NAME = "tracks";

export interface StoredAudioTrack {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number;
  cover: string;
  fileName?: string;
  /**
   * Dosya `Musics` klasorune yazildi mi. Eski kayitlarda yok; acilista bir kez
   * senkronlanip isaretleniyorlar.
   */
  savedToDisk?: boolean;
  /** Indirildigi servis; eski kayitlarda yok, o zaman rozet cikmaz. */
  origin?: "spotify" | "youtube";
  blob: Blob;
  createdAt: number;
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined" || !("indexedDB" in window)) {
      reject(new Error("IndexedDB is not supported"));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: "id" });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

/** Tasmada eski id -> dosya adi eslemesi buradan cikarilir. */
export async function getAllTracksFromDB(): Promise<StoredAudioTrack[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readonly");
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => {
        resolve(req.result || []);
      };
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error("Failed to read audio tracks from IndexedDB", err);
    return [];
  }
}
