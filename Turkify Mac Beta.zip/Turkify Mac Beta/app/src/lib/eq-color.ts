"use client";

import { EQ_MAX_DB } from "../lib/audio-effects";

/**
 * Kazanc renk skalasi: en alt kirmizi, ortada turuncu/sari, en ustte koyu
 * yesil. Deger dogrudan bant kazanci (dB) olarak alinir.
 *
 * Skala tek yerden yonetilir; hem bant konumu hem de renk ayni normalize
 * degeri (`t`, 0 = en alt, 1 = en ust) kullanir.
 */
const STOPS: { t: number; rgb: [number, number, number] }[] = [
  { t: 0.0, rgb: [239, 68, 68] }, // kirmizi
  { t: 0.25, rgb: [249, 115, 22] }, // turuncu
  { t: 0.5, rgb: [234, 179, 8] }, // sari
  { t: 0.75, rgb: [132, 204, 22] }, // yesil
  { t: 1.0, rgb: [21, 128, 61] }, // koyu yesil
];

/** Normalize konum (0..1) icin ara deger renk hesaplar. */
export function rampColor(t: number, alpha = 1): string {
  const clamped = Math.min(1, Math.max(0, t));
  let lower = STOPS[0];
  let upper = STOPS[STOPS.length - 1];
  for (let i = 0; i < STOPS.length - 1; i += 1) {
    const a = STOPS[i];
    const b = STOPS[i + 1];
    if (a && b && clamped >= a.t && clamped <= b.t) {
      lower = a;
      upper = b;
      break;
    }
  }
  const span = upper.t - lower.t || 1;
  const f = (clamped - lower.t) / span;
  const rgb = lower.rgb.map((value, index) => Math.round(value + ((upper.rgb[index] ?? value) - value) * f));
  const [r, g, b] = rgb;
  return alpha >= 1 ? `rgb(${r}, ${g}, ${b})` : `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

/** Bant kazancini (dB) renk skalasina oturtur. */
export function gainColor(db: number, alpha = 1): string {
  return rampColor((db + EQ_MAX_DB) / (EQ_MAX_DB * 2), alpha);
}

/** Bant kazancini 0..1 konuma oturtur (slider doldurma oranlari icin). */
export function gainPosition(db: number): number {
  return Math.min(1, Math.max(0, (db + EQ_MAX_DB) / (EQ_MAX_DB * 2)));
}

/** 60 -> "60", 12000 -> "12K" gibi kisa frekans etiketi. */
export function formatFrequency(hz: number): string {
  if (hz >= 1000) {
    const k = hz / 1000;
    return `${Number.isInteger(k) ? k : k.toFixed(1)}K`;
  }
  return String(hz);
}
