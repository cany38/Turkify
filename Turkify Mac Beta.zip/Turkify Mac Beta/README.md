# Turkify macOS Test Versiyası

Windows tətbiqindən uyğunlaşdırılmış, brauzerdə işləyən Next.js mənbə versiyası.
Electron deyil. Intel və Apple Silicon üçün asılılıqlar Mac-də qurulur.
Bu paket Windows-da yığılıb, boş məlumatlarla təcrid olunmuş şəkildə sınaqdan
keçirilib; əsl macOS, Finder, launchd, Safari və səs endirmə axınlarında
yoxlanılmayıb.

## İlk Quraşdırma

1. `Turkify Mac Beta` qovluğunu istifadəçi qovluğunuzda daimi, yazıla bilən
   bir yerə qoyun. Köçürsəniz, əvvəlcə `Stop.command` işlədin, sonra yeni
   yerdə quraşdırmanı təkrarlayın. `Turkify.app` təkbaşına köçürülmür.
2. [Homebrew](https://brew.sh) qurulu olmalıdır. Terminalda:

   ```sh
   brew install node@22 python@3.12 ffmpeg deno
   ```

   Yalnızca Node.js ve Python yeterli deyil; `Setup.command` FFmpeg ve Deno
   olmadan davam etmir. İlk quraşdırma üçün internet bağlantısı da lazımdır.

3. Terminalda `cd ` yazın, açılan qovluğu Terminala sürükləyib Enter-i basın.
   Sonra:

   ```sh
   bash Setup.command
   ```

Quraşdırma internet istəyir: `npm ci`, istehsal yığması (Google Fonts daxil)
və ayrı `.venv` içinə yt-dlp, spotDL, spotapi qurur. Python paketləri versiya
aralıqları ilə göstərilib, tam kilidli deyil; təchizatçı dəyişiklikləri
sonrakı quraşdırmalarda fərq yarada bilər. Qlobal Pythona paket qurulmur.
Node ən azı 22 olmalıdır. Apple Silicon `/opt/homebrew`, Intel `/usr/local`
PATH-ləri dəstəklənir; nvm/asdf və ya xüsusi ünvanlar avtomatik yüklənmir.

## Açma Və Bağlama

- Quraşdırmanın yaratdığı `Turkify.app` faylını ikiqat klikləyin.
  Brauzer `http://127.0.0.1:3401` ünvanında açılır; Terminal açıq qalmır.
- Alternativ: `bash Launcher.command`. Komanda başlatma bitincə sonlanır.
- Bağlamaq üçün `Stop.command` ikiqat kliklənə bilər və ya `bash Stop.command`
  işlədilə bilər. Yalnız bu qovluğa aid launchd işi dayandırılır.
- Brauzer vərəqini bağlamaq serveri bağlamır. Sessiya bağlananda server
  sönür; avtomatik giriş başlaması qurulmur. İnterfeysdə HTTP dayandırma
  düyməsi yoxdur.
- Port doludursa başqa proses öldürülmür və başqa serverə qoşulma olmur;
  xəta verilir. Əvvəlcə digər tətbiqi və ya əvvəlki Turkify nüsxəsini
  özünüz bağlayın.

`.app` Mac-də AppleScript ilə yaradılan imzasız, noter təsdiqsiz bir
başlatıcıdır; qurulu yerli mənbə kodunu işlədir. Gatekeeper xəbərdarlığı və
ya işlətmə icazəsi əngəli ola bilər. Yalnız mənbəyinə güvənirsinizsə Finderdə
sağ klik > Open ya da System Settings > Privacy & Security > Open Anyway
yolunu işlədin. Sistem təhlükəsizliyini ümumiyyətlə bağlamayın. Fayl
ötürülməsi icazə bitlərini qorumursa
`chmod u+x Setup.command Launcher.command Stop.command` işlədin; `bash` ilə
işlətmə executable bit istəmir. İdarə olunan Mac siyasəti əngəlləyə bilər.

## Məlumat Və Məxfilik

Paket boş kataloqla başlayır. Musiqi, bəyənmələr, siyahılar, keçmiş, API
açarları, `.env.local`, Windows istifadəçi yolları, brauzer profili və şəxsi
şəkillər ötürülmür. Tətbiq loqosu, vərəq nişanı və PWA nişanları daxildir;
loqo xaricində yalnız yoxlanılmış həndəsi SVG üzlüklər işlədilir.

Öz musiqi və kitabxana məlumatlarınız `~/Library/Application Support/Turkify`
altında, səslər `Musics/` içində saxlanılır. Remix çıxışı susmaya görə öz
`~/Downloads` qovluğunuza gedir. Seçimlər və daxil etdiyiniz könüllü API
açarları bu Mac-in brauzer yaddaşında saxlanıla bilər; bunlar şifrəli kassa
deyil. Üçüncü tərəf alətlər öz istifadəçi keşlərini yarada bilər.

Tətbiq yalnız loopback-ə bağlanır; internetə və ya LAN-a yayımlamayın.
API yazma sorğuları eyni origin istəyir. Ümumi məqsədli çoxistifadəçili və
ya uzaqdan girişli server kimi təhlükəsizlik yoxlamasından keçməyib.
Axtarış/endirmə internet təchizatçılarına sorğu göndərir; özəl/DRM/region/yaş
məhdudiyyətli məzmun işləməyə bilər. Spotify uyğunlaşmaları YouTube səsindən
gəlir. Yalnız endirmə/istifadə hüququnuz olan məzmunları işlədin. Safari
kodek fərqlərində M4A seçimini və ya aktual Chrome-u yoxlayın.

## Yoxlamalar Və Problemlər

Mac başlatma problemi üçün əvvəlcə `bash Stop.command`, sonra `app` qovluğunda:

```sh
export PATH="../.venv/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
export TURKIFY_PYTHON="$(cd ../.venv/bin && pwd)/python3"
npm start
```

Bu diaqnoz rejimi Terminalda xəta göstərir; Ctrl+C ilə bağlanır. Başlatıcı
jurnal faylı yazmır; server çıxışı `/dev/null`-a gedir. `Setup.command`
yenidən işlədilə bilər; musiqi məlumatını silmir. Node/Homebrew
yenilənməsindən sonra quraşdırmanı təkrarlamaq lazım gələ bilər.

## Paylaşma

Bu qovluğu başqası ilə paylaşanda quraşdırmanın yaratdığı `.venv`,
`node_modules`, `.next` və `Turkify.app` hallərini göndərməyin; qarşı tərəf
`Setup.command` ilə quraşdırmanı özü qurur. Musiqi, bəyənmə, siyahı və API
açarları sizdə qalır. Lisenziya: `LICENSE`.
