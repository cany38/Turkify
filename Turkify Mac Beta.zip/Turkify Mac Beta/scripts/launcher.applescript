on run
    set bundlePath to POSIX path of (path to me)
    set rootPath to do shell script "/usr/bin/dirname " & quoted form of bundlePath
    try
        do shell script quoted form of (rootPath & "/.venv/bin/python3") & " " & quoted form of (rootPath & "/scripts/launcher.py") & " start"
    on error messageText
        display dialog messageText with title "Turkify" buttons {"OK"} default button "OK" with icon caution
    end try
end run
