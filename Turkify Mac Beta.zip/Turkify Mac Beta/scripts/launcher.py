#!/usr/bin/env python3
"""Local launchd controller. Never kills a process by PID or by port."""
import hashlib
import json
import os
from pathlib import Path
import plistlib
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
import uuid

PORT = 3401
URL = f'http://127.0.0.1:{PORT}'


def check_port(port):
    with socket.socket() as probe:
        try:
            probe.bind(('127.0.0.1', port))
        except OSError as exc:
            raise RuntimeError(f'Port {port} is busy. Close the other application or stop the previous Turkify instance.') from exc


def job_plist(root, node, search_path, instance, label):
    return plistlib.dumps({
        'Label': label,
        'ProgramArguments': [node, str(root / 'app/node_modules/next/dist/bin/next'), 'start', '--hostname', '127.0.0.1', '--port', str(PORT)],
        'WorkingDirectory': str(root / 'app'),
        'EnvironmentVariables': {
            'PATH': search_path,
            'HOME': str(Path.home()),
            'NODE_ENV': 'production',
            'NEXT_TELEMETRY_DISABLED': '1',
            'TURKIFY_PYTHON': str(root / '.venv/bin/python3'),
            'TURKIFY_DATA_DIR': str(Path.home() / 'Library/Application Support/Turkify'),
            'TURKIFY_SCRIPTS_DIR': str(root / 'app/scripts'),
            'TURKIFY_INSTANCE': instance,
        },
        'RunAtLoad': True,
        'KeepAlive': False,
        'StandardOutPath': '/dev/null',
        'StandardErrorPath': '/dev/null',
    })


def control(action):
    if sys.platform != 'darwin':
        raise RuntimeError('This launcher requires macOS.')
    root = Path(__file__).resolve().parents[1]
    label = 'local.turkify.' + hashlib.sha256(str(root).encode()).hexdigest()[:16]
    domain = f'gui/{os.getuid()}'
    target = f'{domain}/{label}'
    state = root / '.runtime'
    state.mkdir(mode=0o700, exist_ok=True)
    ticket = state / 'instance'
    loaded = subprocess.run(['/bin/launchctl', 'print', target], capture_output=True).returncode == 0
    if action == 'stop':
        if loaded:
            subprocess.run(['/bin/launchctl', 'bootout', target], check=True, capture_output=True)
        return
    if not (root / 'app/.next/BUILD_ID').is_file():
        raise RuntimeError('Run Setup.command first.')
    search_path = f'{root}/.venv/bin:/opt/homebrew/bin:/opt/homebrew/opt/node@22/bin:/usr/local/bin:/usr/local/opt/node@22/bin:/usr/bin:/bin:/usr/sbin:/sbin'
    node = shutil.which('node', path=search_path)
    if not node or not (root / '.venv/bin/python3').is_file():
        raise RuntimeError('Node or the Python environment is missing. Run Setup.command.')
    if loaded:
        if not ticket.is_file():
            raise RuntimeError('Launcher state missing. Use Stop.command, then start again.')
        instance = ticket.read_text().strip()
    else:
        check_port(PORT)
        instance = uuid.uuid4().hex
        ticket.write_text(instance)
        plist = state / 'server.plist'
        plist.write_bytes(job_plist(root, node, search_path, instance, label))
        (Path.home() / 'Library/Application Support/Turkify').mkdir(parents=True, exist_ok=True)
        subprocess.run(['/bin/launchctl', 'bootstrap', domain, str(plist)], check=True, capture_output=True)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for _ in range(60):
        try:
            with opener.open(URL + '/api/server', timeout=1) as response:
                if json.load(response).get('instance') == instance:
                    subprocess.run(['/usr/bin/open', URL], check=True)
                    return
        except (OSError, ValueError):
            pass
        time.sleep(1)
    if not loaded:
        subprocess.run(['/bin/launchctl', 'bootout', target], capture_output=True)
    raise RuntimeError('Server did not become ready. Run Setup.command again; see README for foreground diagnostics.')


if __name__ == '__main__':
    try:
        action = sys.argv[1] if len(sys.argv) == 2 else 'start'
        if action not in ('start', 'stop'):
            raise RuntimeError('Expected start or stop.')
        control(action)
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
